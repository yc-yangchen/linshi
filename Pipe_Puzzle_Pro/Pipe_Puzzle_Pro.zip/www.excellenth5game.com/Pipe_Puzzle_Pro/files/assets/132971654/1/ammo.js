// This is ammo.js, a port of Bullet Physics to JavaScript. zlib licensed.
var Ammo = (function() {
	var _scriptDir = typeof document !== 'undefined' && document.currentScript ? document.currentScript.src : undefined;
	if(typeof __filename !== 'undefined') _scriptDir = _scriptDir || __filename;

})();
if(typeof exports === 'object' && typeof module === 'object') module.exports = Ammo;
else if(typeof define === 'function' && define['amd']) define([], function() {
	return Ammo;
});
else if(typeof exports === 'object') exports["Ammo"] = Ammo;