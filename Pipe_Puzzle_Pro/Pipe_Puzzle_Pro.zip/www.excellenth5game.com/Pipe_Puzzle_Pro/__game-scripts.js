var TextureMovementComponent = pc.createScript("textureMovementComponent");
TextureMovementComponent.attributes.add("speed", {
  type: "number",
  default: 0.1,
}),
  TextureMovementComponent.attributes.add("sizeOffset", {
    type: "number",
    default: 4,
  }),
  TextureMovementComponent.attributes.add("textureOffset", {
    type: "vec2",
    default: [0, 0],
  }),
  (TextureMovementComponent.prototype.update = function (t) {
    this.init(),
      (this.textureOffset.x += this.speed * t),
      (this.textureOffset.y += this.speed * t);
    var e = this.sizeOffset * (2 * this.parent.getLocalScale().y);
    (this.uniform0 = []),
      (this.uniform0[0] = e),
      (this.uniform0[1] = 0),
      (this.uniform0[2] = this.textureOffset.x),
      (this.uniform1 = []),
      (this.uniform1[0] = 0),
      (this.uniform1[1] = e),
      (this.uniform1[2] = this.textureOffset.y),
      this.material.setParameter(
        "texture_specularMapTransform0",
        this.uniform0
      ),
      this.material.setParameter(
        "texture_specularMapTransform1",
        this.uniform1
      );
  }),
  (TextureMovementComponent.prototype.init = function () {
    if (!this.isInit) {
      (this.isInit = !0),
        (this.parent = this.entity.parent),
        (this.material = this.entity.render.material);
      var t = this.entity.getLocalScale();
      this.entity
        .tween(this.entity.getLocalScale())
        .to(new pc.Vec3(t.x + 0.15, t.y + 0.1, t.z - 0.25), 1, pc.SineOut)
        .loop(!0)
        .yoyo(!0)
        .start(),
        this.tween();
    }
  }),
  (TextureMovementComponent.prototype.tween = function () {
    var t = 0.5 / this.parent.getLocalScale().y;
    t = pc.math.clamp(t, 0, 5);
    var e = this;
    this.entity
      .tween(this.entity.getLocalEulerAngles())
      .rotate(new pc.Vec3(0, 0, t), 2, pc.Linear)
      .on("complete", function () {
        e.entity
          .tween(e.entity.getLocalEulerAngles())
          .rotate(new pc.Vec3(0, 0, -t), 2, pc.Linear)
          .on("complete", function () {
            e.tween();
          })
          .start();
      })
      .start();
  });
var WaterComponent = pc.createScript("waterComponent");
WaterComponent.attributes.add("model", { type: "entity" }),
  WaterComponent.attributes.add("waterfall", { type: "entity" }),
  WaterComponent.attributes.add("waterfallnew", { type: "entity", array: !0 }),
  (window.water = function () {
    return pc.Application.getApplication().root.findByName("Water").script
      .waterComponent;
  }),
  (WaterComponent.prototype.update = function (e) {
    this.init();
  }),
  (WaterComponent.prototype.init = function () {
    if (!this.isInit) {
      (this.isInit = !0),
        (this.isFull = !1),
        (this.isEmpty = !1),
        (this.isPause = !1),
        (this.gameSystem =
          this.app.root.findByName("GameSystem").script.gameSystem),
        this.waterfall.setLocalScale(new pc.Vec3(1, 0, 0)),
        this.waterfallnew[0].setLocalScale(new pc.Vec3(1, 0, 0)),
        this.waterfallnew[1].setLocalScale(new pc.Vec3(1, 0, 0));
      var e = this.entity.getLocalScale(),
        t = this;
      this.entity.setLocalScale(new pc.Vec3(e.x, 0.1, e.z)),
        (this.timerTween = this.entity
          .tween(this.entity.getLocalScale())
          .to(new pc.Vec3(e.x, 1, e.z), this.gameSystem.waterTime, pc.Linear)
          .on("complete", function () {
            (t.isFull = !0),
              t.gameSystem.levelFailed(),
              t.waterfall
                .tween(t.waterfall.getLocalScale())
                .to(new pc.Vec3(1, 2, 1), 1.5, pc.Linear)
                .start(),
              t.waterfallnew[0]
                .tween(t.waterfallnew[0].getLocalScale())
                .to(new pc.Vec3(1, 1, 1), 1, pc.BackOut)
                .on("complete", function () {
                  t.waterfallnew[0]
                    .tween(t.waterfallnew[0].getLocalScale())
                    .to(new pc.Vec3(1.05, 0.8, 1.05), 0.25, pc.Linear)
                    .loop(!0)
                    .yoyo(!0)
                    .start();
                })
                .start(),
              t.waterfallnew[1]
                .tween(t.waterfallnew[1].getLocalScale())
                .to(new pc.Vec3(1, 1, 1), 0.75, pc.BackInOut)
                .on("complete", function () {
                  t.waterfallnew[1]
                    .tween(t.waterfallnew[1].getLocalScale())
                    .to(new pc.Vec3(1, 1.5, 1), 0.5, pc.BackIn)
                    .loop(!0)
                    .yoyo(!0)
                    .start();
                })
                .start();
          })
          .start()),
        (window.pipeTurn().water = this),
        (window.pipeMove().water = this),
        this.waterPause(!0);
    }
  }),
  (WaterComponent.prototype.waterPause = function (e) {
    this.isPause != e &&
      ((this.isPause = e),
      e
        ? this.timerTween.stop()
        : (this.timerTween.start(),
          window.famobi_analytics.trackEvent("EVENT_LEVELSTART", {
            levelName: "Level " + this.gameSystem.levelStart,
          }),
          window.famobi.playerReady()));
  }),
  (WaterComponent.prototype.pumpingOut = function () {
    this.timerTween.stop();
    var e = this.entity.getLocalScale(),
      t = this;
    this.entity
      .tween(this.entity.getLocalScale())
      .to(
        new pc.Vec3(e.x, 0, e.z),
        pc.math.clamp(10 * e.y, 1, this.gameSystem.pumpingOutTime),
        pc.Linear
      )
      .on("complete", function () {
        t.model.destroy();
      })
      .on("update", function () {
        t.isEmpty ||
          (t.entity.getLocalScale().y <= 0.1 &&
            ((t.isEmpty = !0),
            (t.gameSystem.level.enabled = !1),
            t.gameSystem.levelCompleted()));
      })
      .start();
  });
var PipeComponent = pc.createScript("pipeComponent");
PipeComponent.attributes.add("result", {
  type: "boolean",
  array: !0,
  title: "Correct result",
}),
  PipeComponent.attributes.add("isItem", {
    type: "boolean",
    default: !1,
    title: "Inventory item",
  }),
  PipeComponent.attributes.add("isAnim", {
    type: "boolean",
    default: !1,
    title: "Animator Controller",
  }),
  PipeComponent.attributes.add("effect", {
    type: "entity",
    title: "Effect Entity",
  }),
  PipeComponent.attributes.add("connectList", {
    type: "entity",
    array: !0,
    title: "Connect List",
  }),
  (PipeComponent.prototype.update = function (t) {
    this.init();
  }),
  (PipeComponent.prototype.init = function () {
    this.isInit ||
      ((this.isInit = !0),
      this.setState(),
      (this.gameSystem =
        this.app.root.findByName("GameSystem").script.gameSystem),
      this.gameSystem.pipeList.push(this),
      this.updateMaterial());
  }),
  (PipeComponent.prototype.rotate = function () {
    var t = this.entity.getLocalEulerAngles(),
      e = this;
    this.entity
      .tween(t)
      .rotate(new pc.Vec3(0, 0, t.z - 90), 0.25, pc.Linear)
      .on("complete", function () {
        e.gameSystem
          ? e.gameSystem.levelAnalysis()
          : window.gameSystem().levelAnalysis();
      })
      .start(),
      this.updateState();
  }),
  (PipeComponent.prototype.updateState = function () {
    (this.state += 1), this.state > 3 && (this.state = 0);
  }),
  (PipeComponent.prototype.checkStateLock = function () {
    this.lock = this.result[this.state];
  }),
  (PipeComponent.prototype.setState = function () {
    var t = this.entity.getLocalEulerAngles();
    switch (Math.round(t.z)) {
      case 0:
        this.state = 0;
        break;
      case -90:
        this.state = 1;
        break;
      case -180:
      case 180:
        this.state = 2;
        break;
      case 90:
        this.state = 3;
        break;
      default:
        this.state = -1;
    }
    this.checkStateLock();
  }),
  (PipeComponent.prototype.updateMaterial = function () {
    var t = this.result[this.state] ? 1 : 0;
    this.connectList.forEach((e) => {
      e.render.meshInstances[0].material =
        this.gameSystem.pipeMaterialList[t].resource;
    });
  });
var PipeTurnComponent = pc.createScript("pipeTurnComponent");
PipeTurnComponent.attributes.add("pipeTag", {
  type: "string",
  default: "Pipe",
}),
  (window.pipeTurn = function () {
    return pc.Application.getApplication().root.findByName("Camera").script
      .pipeTurnComponent;
  }),
  (PipeTurnComponent.prototype.update = function (t) {
    this.init();
  }),
  (PipeTurnComponent.prototype.init = function () {
    this.isInit ||
      ((this.isInit = !0),
      (this.isRotate = !1),
      (this.gameSystem =
        this.app.root.findByName("GameSystem").script.gameSystem),
      (this.water = null),
      (this.audioIndex = 1),
      this.app.mouse.on(pc.EVENT_MOUSEDOWN, this.mouseDown, this),
      this.app.touch &&
        this.app.touch.on(pc.EVENT_TOUCHSTART, this.touchStart, this));
  }),
  (PipeTurnComponent.prototype.mouseDown = function (t) {
    this.doRaycast(t.x, t.y);
  }),
  (PipeTurnComponent.prototype.touchStart = function (t) {
    1 === t.touches.length && this.doRaycast(t.touches[0].x, t.touches[0].y),
      t.event.preventDefault();
  }),
  (PipeTurnComponent.prototype.doRaycast = function (t, i) {
    if (!this.isRotate && !this.gameSystem.isFail) {
      var e = this.entity.getPosition(),
        o = this.entity.camera.screenToWorld(t, i, this.entity.camera.farClip),
        n = this.app.systems.rigidbody.raycastFirst(e, o);
      if (n) {
        var p = n.entity;
        if (p.tags.has(this.pipeTag)) {
          var s = p.script.pipeComponent;
          if (s) {
            if (s.isItem || s.lock) return;
            s.rotate(),
              (this.isRotate = !0),
              (this.audioIndex = 1 == this.audioIndex ? 2 : 1),
              this.gameSystem.playSound("Pipe_" + this.audioIndex),
              this.water.waterPause(!1);
          }
        }
      }
    }
  });
var GameSystem = pc.createScript("gameSystem");
GameSystem.attributes.add("levelStart", {
  type: "number",
  min: 1,
  title: "Level Number",
}),
  GameSystem.attributes.add("levelMax", {
    type: "number",
    default: 50,
    title: "Level Max",
  }),
  GameSystem.attributes.add("waterTime", { type: "number", default: 60 }),
  GameSystem.attributes.add("waterFlowTime", { type: "number", default: 5 }),
  GameSystem.attributes.add("pumpingOutTime", { type: "number", default: 3 }),
  GameSystem.attributes.add("failTime", {
    type: "number",
    default: 1.5,
    title: "Fail Time",
  }),
  GameSystem.attributes.add("nextTime", {
    type: "number",
    default: 1.5,
    title: "Next Time",
  }),
  GameSystem.attributes.add("tutorialAsset", {
    type: "asset",
    title: "Tutorial Asset",
  }),
  GameSystem.attributes.add("environment", {
    type: "asset",
    title: "Environment Asset",
  }),
  GameSystem.attributes.add("camera", { type: "entity", title: "Camera" }),
  GameSystem.attributes.add("cameraPosition", {
    type: "vec3",
    title: "Camera Position",
  }),
  GameSystem.attributes.add("audio", { type: "entity", title: "Audio List" }),
  GameSystem.attributes.add("backButton", {
    type: "entity",
    title: "Background Button",
  }),
  GameSystem.attributes.add("soundButton", {
    type: "entity",
    title: "Sound Button",
  }),
  GameSystem.attributes.add("restartButton", {
    type: "entity",
    title: "Restart Button",
  }),
  GameSystem.attributes.add("levelText", {
    type: "entity",
    title: "Level Text",
  }),
  GameSystem.attributes.add("effectList", {
    type: "asset",
    array: !0,
    title: "Effect List",
  }),
  GameSystem.attributes.add("materialList", {
    type: "asset",
    array: !0,
    title: "Material List",
  }),
  GameSystem.attributes.add("pipeMaterialList", {
    type: "asset",
    array: !0,
    title: "Pipe Material",
  }),
  (window.gameSystem = function () {
    return pc.Application.getApplication().root.findByName("GameSystem").script
      .gameSystem;
  }),
  document.addEventListener("visibilitychange", function () {
    if ("visible" === document.visibilityState) {
      var t =
        pc.Application.getApplication().root.findByName("GameSystem").script
          .gameSystem;
      if (t) {
        if (t.isPause) return;
        t.audio.sound.play("Music");
      }
    }
  }),
  (GameSystem.prototype.update = function (t) {
    this.init();
  }),
  (GameSystem.prototype.init = function () {
    if (!this.isInit) {
      (this.isInit = !0),
        (this.isTutorial = !0),
        (this.isPause = !1),
        (this.isMute = !1),
        (this.levelList = [
          25, 22, 43, 27, 44, 16, 29, 8, 42, 17, 6, 32, 41, 3, 20, 24, 38, 34,
          48, 15, 7, 28, 14, 35, 33, 13, 31, 4, 11, 50, 18, 9, 5, 39, 37, 40,
          10, 26, 45, 12, 22, 49, 30, 47, 19, 21, 46, 36, 15, 23,
        ]);
      var t = window.devicePixelRatio || 1;
      (this.app.graphicsDevice.maxPixelRatio = t),
        this.soundButton.button.on("click", this.soundUpdate, this),
        this.restartButton.button.on("click", this.restartLevel, this),
        this.famobiRequest();
    }
  }),
  (GameSystem.prototype.famobiRequest = function () {
    let createFamobiRequestHandlers = () => {
      if (window.famobi) {
        window.famobi.localStorage.getItem("muted") &&
          ((this.isMute = !0), (this.audio.sound.volume = 0), this.updateUI());
        var t = window.famobi.localStorage.getItem("level"),
          e = null == t ? 1 : t;
        this.createLevel(e);
      } else setTimeout(createFamobiRequestHandlers, 1e3);
    };
    createFamobiRequestHandlers();
  }),
  (GameSystem.prototype.createLevel = function (t) {
    (this.levelStart = t), (this.isFail = !1);
    var e = this.app.assets.find("Level " + this.getLevelIndex(t));
    e &&
      (this.level && (this.level.destroy(), this.levelEnvironment.destroy()),
      (this.pipeList = []),
      (this.levelEnvironment = this.environment.resource.instantiate()),
      this.entity.addChild(this.levelEnvironment),
      (this.discoBall = this.app.root.findByName("DiscoBall")),
      (this.level = e.resource.instantiate()),
      this.entity.addChild(this.level),
      (window.pipeTurn().isRotate = !1),
      (this.tutorial = this.addTutorial()),
      this.cameraReset(),
      this.audio.sound.stop("Win"),
      this.audio.sound.stop("Lose"),
      this.audio.sound.play("Music"),
      (this.restartButton.enabled = !0)),
      (this.levelText.element.text = this.levelStart);
  }),
  (GameSystem.prototype.levelCompleted = function () {
    window.famobi_analytics.trackEvent("EVENT_CUSTOM", {
      eventName: "LEVELEND",
      result: "success",
    }),
      this.levelStart++,
      window.famobi.localStorage.setItem("level", this.levelStart);
    var t = this.discoBall.getLocalPosition(),
      e = this;
    this.discoBall
      .tween(t)
      .to(new pc.Vec3(t.x, 0, t.z), 0.5, pc.Linear)
      .on("complete", function () {
        setTimeout(() => {
          e.audio.sound.stop("Win"),
            e.audio.sound.stop("Lose"),
            e.audio.sound.stop("Music"),
            setTimeout(
              function () {
                Promise.all([
                  window.famobi_analytics.trackEvent("EVENT_LEVELSUCCESS", {
                    levelName: "Level " + e.levelStart,
                  }),
                  window.famobi.showInterstitialAd(),
                ]).then(function () {
                  e.createLevel(e.levelStart);
                });
              }.bind(this),
              2e3
            );
        }, 1e3 * e.nextTime);
      })
      .start(),
      this.createEffect(0, this.discoBall),
      (t = this.camera.getLocalPosition()),
      this.camera
        .tween(t)
        .to(new pc.Vec3(t.x, t.y, t.z - 1), this.nextTime / 3, pc.SineOut)
        .yoyo(!0)
        .repeat(2)
        .start();
  }),
  (GameSystem.prototype.levelFailed = function () {
    (this.isFail = !0),
      window.famobi_analytics.trackEvent("EVENT_CUSTOM", {
        eventName: "LEVELEND",
        result: "fail",
      });
    var t = this.camera.getLocalPosition(),
      e = new pc.Vec3(t.x, t.y + 3, t.z);
    this.camera
      .tween(t)
      .to(e, this.failTime / 4, pc.Linear)
      .start(),
      setTimeout(() => {
        this.audio.sound.stop("Win"),
          this.audio.sound.stop("Lose"),
          this.audio.sound.stop("Music");
        var t = this;
        setTimeout(
          function () {
            Promise.all([
              window.famobi_analytics.trackEvent("EVENT_LEVELFAIL", {
                levelName: "Level " + this.levelStart,
                reason: "dead",
              }),
              window.famobi.showInterstitialAd(),
            ]).then(function () {
              t.createLevel(t.levelStart);
            });
          }.bind(this),
          2e3
        );
      }, 1e3 * this.failTime),
      this.playSound("Lose"),
      (this.restartButton.enabled = !1);
  }),
  (GameSystem.prototype.levelAnalysis = function () {
    var t = !0;
    this.pipeList.forEach((e) => {
      (e.result[e.state] && !e.isItem) || (t = !1);
    }),
      (window.pipeTurn().isRotate = t),
      t &&
        !this.isFail &&
        (window.water().pumpingOut(),
        window.waterFlow().action(),
        this.pipeList.forEach((t) => {
          t.isAnim && (t.entity.anim.speed = 1);
        }),
        this.playSound("Win"),
        (this.restartButton.enabled = !1));
  }),
  (GameSystem.prototype.cameraReset = function () {
    this.camera
      .tween(this.camera.getLocalPosition())
      .to(this.cameraPosition, 0.5, pc.Linear)
      .start();
  }),
  (GameSystem.prototype.createEffect = function (t, e) {
    switch (t) {
      case 0:
        var i = this.effectList[t].resource.instantiate();
        e.addChild(i);
        for (let t = 0; t < 10; t++)
          setTimeout(() => {
            var t = i.clone();
            e.addChild(t),
              t.setLocalPosition(
                new pc.Vec3(pc.math.random(-3, 3), pc.math.random(-3, 3), 0)
              );
          }, 100 * t);
        break;
      case 1:
        i = this.effectList[t].resource.instantiate();
        e.addChild(i);
        for (let t = 0; t < 3; t++) {
          var a = i.clone();
          e.addChild(a),
            a.setLocalPosition(
              new pc.Vec3(
                pc.math.random(-0.25, 0.25),
                pc.math.random(-0.25, 0.25),
                0
              )
            );
        }
        break;
      default:
        a = this.effectList[t].resource.instantiate();
        e.addChild(a), a.setLocalPosition(new pc.Vec3(0, 0, 0));
    }
  }),
  (GameSystem.prototype.addTutorial = function () {
    return this.isTutorial
      ? ((this.tutorial = this.tutorialAsset.resource.instantiate()),
        this.level.addChild(this.tutorial),
        (this.isTutorial = !1),
        this.tutorial)
      : null;
  }),
  (GameSystem.prototype.playSound = function (t) {
    this.audio.sound.play(t);
  }),
  (GameSystem.prototype.restartLevel = function () {
    this.createLevel(this.levelStart);
  }),
  (GameSystem.prototype.soundUpdate = function () {
    if (!this.isPause) {
      this.isMute = !this.isMute;
      var t = this.isMute ? 0 : 1;
      (this.audio.sound.volume = t),
        this.updateUI(),
        this.isMute
          ? window.famobi.localStorage.setItem("muted", !0)
          : window.famobi.localStorage.removeItem("muted");
    }
  }),
  (GameSystem.prototype.updateUI = function () {
    this.soundButton.element.texture =
      this.materialList[this.audio.sound.volume].resource;
  }),
  (GameSystem.prototype.getLevelIndex = function (t) {
    for (var e = t < 1 ? 1 : t, i = 0; e > this.levelMax; )
      (e -= this.levelMax), i++;
    return i > 0 && (e = this.levelList[e - 1]), e;
  });
var CharacterComponent = pc.createScript("characterComponent");
CharacterComponent.attributes.add("point", { type: "entity" }),
  CharacterComponent.attributes.add("isRight", {
    type: "boolean",
    default: !1,
  }),
  CharacterComponent.attributes.add("model", { type: "entity" }),
  CharacterComponent.attributes.add("animator", { type: "entity" }),
  CharacterComponent.attributes.add("percent", { type: "number" }),
  CharacterComponent.attributes.add("emotionList", {
    type: "entity",
    array: !0,
  }),
  (CharacterComponent.prototype.update = function (t) {
    this.init(),
      0 == this.state &&
        (this.entity.setPosition(this.point.getPosition()),
        this.water.isFull ? this.fall() : this.water.isEmpty && this.dance());
  }),
  (CharacterComponent.prototype.init = function () {
    if (!this.isInit) {
      (this.isInit = !0),
        (this.state = 0),
        (this.water = this.app.root.findByName("Water").script.waterComponent);
      var t = this.model.getLocalPosition();
      (this.idleTween = this.model
        .tween(this.model.getLocalPosition())
        .to(
          new pc.Vec3(t.x, t.y - 0.15, t.z),
          pc.math.random(0.5, 1),
          pc.SineOut
        )
        .loop(!0)
        .yoyo(!0)
        .start()),
        (this.entity.enabled = this.percent >= pc.math.random(0, 100)),
        this.setEmotion(0);
    }
  }),
  (CharacterComponent.prototype.fall = function () {
    (this.state = 1), this.idleTween.stop();
    var t = this.isRight ? -0.3 : 0.3,
      e = this.entity.getLocalPosition(),
      i = 0,
      o = this;
    this.entity
      .tween(e)
      .to(new pc.Vec3(e.x + t, e.y + 0.25, e.z), i, pc.Linear)
      .on("complete", function () {
        (t = o.isRight ? 0.25 : -0.25),
          (offsetPositionY = -2.5),
          (i = pc.math.random(0.25, 0.5)),
          (e = o.entity.getLocalPosition()),
          o.entity
            .tween(e)
            .to(new pc.Vec3(e.x + t, e.y - offsetPositionY, e.z), i, pc.Linear)
            .on("complete", function () {
              (e = o.entity.getLocalPosition()),
                o.entity
                  .tween(e)
                  .to(
                    new pc.Vec3(e.x, e.y - pc.math.random(0.15, 0.25), e.z),
                    0.25,
                    pc.Linear
                  )
                  .loop(!0)
                  .yoyo(!0)
                  .start();
            })
            .start();
      })
      .start();
    var n = this.isRight ? -60 : 60;
    this.model
      .tween(this.model.getLocalEulerAngles())
      .rotate(new pc.Vec3(0, 0, n), 0.25, pc.SineOut)
      .start(),
      this.animator.anim.setInteger("stateID", 3),
      this.setEmotion(2);
  }),
  (CharacterComponent.prototype.dance = function () {
    (this.state = 2),
      this.idleTween.stop(),
      this.model.setLocalPosition(new pc.Vec3(0, 0, 0));
    var t = 50 >= pc.math.random(0, 100) ? 1 : 2;
    this.animator.anim.setInteger("stateID", t), this.setEmotion(1);
  }),
  (CharacterComponent.prototype.setEmotion = function (t) {
    for (let e = 0; e < this.emotionList.length; e++)
      this.emotionList[e].enabled = t == e;
  });
var WaterfallComponent = pc.createScript("waterfallComponent");
WaterfallComponent.attributes.add("noise_1", {
  type: "asset",
  assetType: "texture",
}),
  WaterfallComponent.attributes.add("noise_2", {
    type: "asset",
    assetType: "texture",
  }),
  WaterfallComponent.attributes.add("top_light_color", { type: "rgba" }),
  WaterfallComponent.attributes.add("top_dark_color", { type: "rgba" }),
  WaterfallComponent.attributes.add("bot_light_color", { type: "rgba" }),
  WaterfallComponent.attributes.add("bot_dark_color", { type: "rgba" }),
  WaterfallComponent.attributes.add("speed", { type: "number", default: 1.1 }),
  WaterfallComponent.attributes.add("opacitySpeed", {
    type: "number",
    default: 1.1,
  }),
  (WaterfallComponent.prototype.update = function (t) {
    this.init(),
      this.material.setParameter("TIME", this.timestamp),
      (this.material.opacityMapOffset = new pc.Vec2(
        0,
        (-this.timestamp * this.opacitySpeed) % 1
      )),
      this.material.update(),
      (this.timestamp += t * this.speed);
  }),
  (WaterfallComponent.prototype.init = function () {
    if (!this.isInit) {
      this.isInit = !0;
      var t = this.entity.model.model;
      (this.timestamp = 0),
        (this.shader = ""),
        (this.shader += "#ifdef MAPCOLOR\n"),
        (this.shader += "uniform vec3 material_emissive;\n"),
        (this.shader += "#endif\n"),
        (this.shader += "\n"),
        (this.shader += "#ifdef MAPTEXTURE\n"),
        (this.shader += "uniform sampler2D texture_emissiveMap;\n"),
        (this.shader += "#endif\n"),
        (this.shader += "\n"),
        (this.shader += "uniform sampler2D noise_tex;\n"),
        (this.shader += "uniform sampler2D displ_tex;\n"),
        (this.shader += "uniform vec4 top_light_color;\n"),
        (this.shader += "uniform vec4 top_dark_color;\n"),
        (this.shader += "uniform vec4 bot_light_color;\n"),
        (this.shader += "uniform vec4 bot_dark_color;\n"),
        (this.shader += "const float displ_amount = 0.02;\n"),
        (this.shader += "const float bottom_foam_threshold = 0.48;\n"),
        (this.shader += "uniform float TIME;\n"),
        (this.shader += "\n"),
        (this.shader += "vec3 getEmission() {\n"),
        (this.shader += "    vec3 emission = vec3(1.0);\n"),
        (this.shader +=
          "    vec2 displ = texture(displ_tex, $UV - TIME / 8.0).xy;\n"),
        (this.shader += "    displ = ((displ * 2.0) - 1.0) * displ_amount;\n"),
        (this.shader += "    \n"),
        (this.shader +=
          "    float noise =  texture(noise_tex, vec2($UV.x, $UV.y / 3.0 - TIME / 4.0) + displ).x;\n"),
        (this.shader += "    noise =  floor(noise * 4.0) / 4.0;\n"),
        (this.shader += "    \n"),
        (this.shader +=
          "    vec4 col = mix(mix(top_dark_color, bot_dark_color, $UV.y), mix(top_light_color, bot_light_color, $UV.y), noise);\n"),
        (this.shader +=
          "    col = mix(vec4(1,1,1,1), col, step($UV.y + displ.y, bottom_foam_threshold));\n"),
        (this.shader += "    \n"),
        (this.shader += "    emission*= col.xyz;\n"),
        (this.shader += "    \n"),
        (this.shader += "    #ifdef MAPVERTEX\n"),
        (this.shader +=
          "        emission *= gammaCorrectInput(saturate(vVertexColor.$VC));\n"),
        (this.shader += "    #endif\n"),
        (this.shader += "    return emission;\n"),
        (this.shader += "}\n"),
        (this.material = t.meshInstances[0].material),
        this.material.setParameter("noise_tex", this.noise_1.resource),
        this.material.setParameter("displ_tex", this.noise_2.resource),
        this.material.setParameter(
          "top_light_color",
          this.top_light_color.data
        ),
        this.material.setParameter("top_dark_color", this.top_dark_color.data),
        this.material.setParameter(
          "bot_light_color",
          this.bot_light_color.data
        ),
        this.material.setParameter("bot_dark_color", this.bot_dark_color.data),
        (this.material.chunks.emissivePS = this.shader);
    }
  });
"undefined" != typeof document &&
  /*! FPSMeter 0.3.1 - 9th May 2013 | https://github.com/Darsain/fpsmeter */
  ((function (t, e) {
    function s(t, e) {
      for (var n in e)
        try {
          t.style[n] = e[n];
        } catch (t) {}
      return t;
    }
    function H(t) {
      return null == t
        ? String(t)
        : "object" == typeof t || "function" == typeof t
        ? Object.prototype.toString
            .call(t)
            .match(/\s([a-z]+)/i)[1]
            .toLowerCase() || "object"
        : typeof t;
    }
    function R(t, e) {
      if ("array" !== H(e)) return -1;
      if (e.indexOf) return e.indexOf(t);
      for (var n = 0, o = e.length; n < o; n++) if (e[n] === t) return n;
      return -1;
    }
    function I() {
      var t,
        e = arguments;
      for (t in e[1])
        if (e[1].hasOwnProperty(t))
          switch (H(e[1][t])) {
            case "object":
              e[0][t] = I({}, e[0][t], e[1][t]);
              break;
            case "array":
              e[0][t] = e[1][t].slice(0);
              break;
            default:
              e[0][t] = e[1][t];
          }
      return 2 < e.length
        ? I.apply(null, [e[0]].concat(Array.prototype.slice.call(e, 2)))
        : e[0];
    }
    function N(t) {
      return 1 === (t = Math.round(255 * t).toString(16)).length ? "0" + t : t;
    }
    function S(t, e, n, o) {
      t.addEventListener
        ? t[o ? "removeEventListener" : "addEventListener"](e, n, !1)
        : t.attachEvent && t[o ? "detachEvent" : "attachEvent"]("on" + e, n);
    }
    function D(t, e) {
      function g(t, e, n, o) {
        return h[0 | t][Math.round(Math.min(((e - n) / (o - n)) * M, M))];
      }
      function r() {
        F.legend.fps !== q &&
          ((F.legend.fps = q), (F.legend[c] = q ? "FPS" : "ms")),
          (b = q ? v.fps : v.duration),
          (F.count[c] = 999 < b ? "999+" : b.toFixed(99 < b ? 0 : O.decimals));
      }
      function m() {
        for (
          l = n(),
            P < l - O.threshold &&
              ((v.fps -= v.fps / Math.max(1, (60 * O.smoothing) / O.interval)),
              (v.duration = 1e3 / v.fps)),
            w = O.history;
          w--;

        )
          (T[w] = 0 === w ? v.fps : T[w - 1]),
            (j[w] = 0 === w ? v.duration : j[w - 1]);
        if ((r(), O.heat)) {
          if (z.length)
            for (w = z.length; w--; )
              z[w].el.style[o[z[w].name].heatOn] = q
                ? g(o[z[w].name].heatmap, v.fps, 0, O.maxFps)
                : g(o[z[w].name].heatmap, v.duration, O.threshold, 0);
          if (F.graph && o.column.heatOn)
            for (w = C.length; w--; )
              C[w].style[o.column.heatOn] = q
                ? g(o.column.heatmap, T[w], 0, O.maxFps)
                : g(o.column.heatmap, j[w], O.threshold, 0);
        }
        if (F.graph)
          for (y = 0; y < O.history; y++)
            C[y].style.height =
              (q
                ? T[y]
                  ? Math.round((x / O.maxFps) * Math.min(T[y], O.maxFps))
                  : 0
                : j[y]
                ? Math.round((x / O.threshold) * Math.min(j[y], O.threshold))
                : 0) + "px";
      }
      function k() {
        20 > O.interval
          ? ((p = i(k)), m())
          : ((p = setTimeout(k, O.interval)), (f = i(m)));
      }
      function G(t) {
        (t = t || window.event).preventDefault
          ? (t.preventDefault(), t.stopPropagation())
          : ((t.returnValue = !1), (t.cancelBubble = !0)),
          v.toggle();
      }
      function U() {
        O.toggleOn && S(F.container, O.toggleOn, G, 1),
          t.removeChild(F.container);
      }
      function V() {
        if (
          (F.container && U(),
          (o = D.theme[O.theme]),
          !(h = o.compiledHeatmaps || []).length && o.heatmaps.length)
        ) {
          for (y = 0; y < o.heatmaps.length; y++)
            for (h[y] = [], w = 0; w <= M; w++) {
              var e,
                n = h[y],
                a = w;
              e = (0.33 / M) * w;
              var i = o.heatmaps[y].saturation,
                l = o.heatmaps[y].lightness,
                p = void 0,
                c = void 0,
                u = void 0,
                d = (u = void 0),
                f = (p = c = void 0);
              f = void 0;
              0 === (u = 0.5 >= l ? l * (1 + i) : l + i - l * i)
                ? (e = "#000")
                : ((c = (u - (d = 2 * l - u)) / u),
                  (f = (e *= 6) - (p = Math.floor(e))),
                  (f *= u * c),
                  0 === p || 6 === p
                    ? ((p = u), (c = d + f), (u = d))
                    : 1 === p
                    ? ((p = u - f), (c = u), (u = d))
                    : 2 === p
                    ? ((p = d), (c = u), (u = d + f))
                    : 3 === p
                    ? ((p = d), (c = u - f))
                    : 4 === p
                    ? ((p = d + f), (c = d))
                    : ((p = u), (c = d), (u -= f)),
                  (e = "#" + N(p) + N(c) + N(u))),
                (n[a] = e);
            }
          o.compiledHeatmaps = h;
        }
        for (var b in ((F.container = s(
          document.createElement("div"),
          o.container
        )),
        (F.count = F.container.appendChild(
          s(document.createElement("div"), o.count)
        )),
        (F.legend = F.container.appendChild(
          s(document.createElement("div"), o.legend)
        )),
        (F.graph = O.graph
          ? F.container.appendChild(s(document.createElement("div"), o.graph))
          : 0),
        (z.length = 0),
        F))
          F[b] && o[b].heatOn && z.push({ name: b, el: F[b] });
        if (((C.length = 0), F.graph))
          for (
            F.graph.style.width =
              O.history * o.column.width +
              (O.history - 1) * o.column.spacing +
              "px",
              w = 0;
            w < O.history;
            w++
          )
            (C[w] = F.graph.appendChild(
              s(document.createElement("div"), o.column)
            )),
              (C[w].style.position = "absolute"),
              (C[w].style.bottom = 0),
              (C[w].style.right =
                w * o.column.width + w * o.column.spacing + "px"),
              (C[w].style.width = o.column.width + "px"),
              (C[w].style.height = "0px");
        s(F.container, O),
          r(),
          t.appendChild(F.container),
          F.graph && (x = F.graph.clientHeight),
          O.toggleOn &&
            ("click" === O.toggleOn && (F.container.style.cursor = "pointer"),
            S(F.container, O.toggleOn, G));
      }
      "object" === H(t) &&
        undefined === t.nodeType &&
        ((e = t), (t = document.body)),
        t || (t = document.body);
      var o,
        h,
        l,
        p,
        f,
        x,
        b,
        w,
        y,
        v = this,
        O = I({}, D.defaults, e || {}),
        F = {},
        C = [],
        M = 100,
        z = [],
        E = O.threshold,
        A = 0,
        P = n() - E,
        T = [],
        j = [],
        q = "fps" === O.show;
      (v.options = O),
        (v.fps = 0),
        (v.duration = 0),
        (v.isPaused = 0),
        (v.tickStart = function () {
          A = n();
        }),
        (v.tick = function () {
          (l = n()),
            (E += (l - P - E) / O.smoothing),
            (v.fps = 1e3 / E),
            (v.duration = A < P ? E : l - A),
            (P = l);
        }),
        (v.pause = function () {
          return (
            p && ((v.isPaused = 1), clearTimeout(p), a(p), a(f), (p = f = 0)), v
          );
        }),
        (v.resume = function () {
          return p || ((v.isPaused = 0), k()), v;
        }),
        (v.set = function (t, e) {
          return (
            (O[t] = e),
            (q = "fps" === O.show),
            -1 !== R(t, u) && V(),
            -1 !== R(t, d) && s(F.container, O),
            v
          );
        }),
        (v.showDuration = function () {
          return v.set("show", "ms"), v;
        }),
        (v.showFps = function () {
          return v.set("show", "fps"), v;
        }),
        (v.toggle = function () {
          return v.set("show", q ? "ms" : "fps"), v;
        }),
        (v.hide = function () {
          return v.pause(), (F.container.style.display = "none"), v;
        }),
        (v.show = function () {
          return v.resume(), (F.container.style.display = "block"), v;
        }),
        (v.destroy = function () {
          v.pause(), U(), (v.tick = v.tickStart = function () {});
        }),
        V(),
        k();
    }
    var n,
      o = t.performance;
    n =
      o && (o.now || o.webkitNow)
        ? o[o.now ? "now" : "webkitNow"].bind(o)
        : function () {
            return +new Date();
          };
    for (
      var a = t.cancelAnimationFrame || t.cancelRequestAnimationFrame,
        i = t.requestAnimationFrame,
        h = 0,
        l = 0,
        p = (o = ["moz", "webkit", "o"]).length;
      l < p && !a;
      ++l
    )
      i =
        (a =
          t[o[l] + "CancelAnimationFrame"] ||
          t[o[l] + "CancelRequestAnimationFrame"]) &&
        t[o[l] + "RequestAnimationFrame"];
    a ||
      ((i = function (e) {
        var o = n(),
          a = Math.max(0, 16 - (o - h));
        return (
          (h = o + a),
          t.setTimeout(function () {
            e(o + a);
          }, a)
        );
      }),
      (a = function (t) {
        clearTimeout(t);
      }));
    var c =
      "string" === H(document.createElement("div").textContent)
        ? "textContent"
        : "innerText";
    (D.extend = I),
      (window.FPSMeter = D),
      (D.defaults = {
        interval: 100,
        smoothing: 10,
        show: "fps",
        toggleOn: "click",
        decimals: 1,
        maxFps: 60,
        threshold: 100,
        position: "absolute",
        zIndex: 10,
        left: "5px",
        top: "5px",
        right: "auto",
        bottom: "auto",
        margin: "0 0 0 0",
        theme: "dark",
        heat: 0,
        graph: 0,
        history: 20,
      });
    var u = ["toggleOn", "theme", "heat", "graph", "history"],
      d = "position zIndex left top right bottom margin".split(" ");
  })(window),
  (function (t, e) {
    e.theme = {};
    var n = (e.theme.base = {
      heatmaps: [],
      container: {
        heatOn: null,
        heatmap: null,
        padding: "5px",
        minWidth: "95px",
        height: "30px",
        lineHeight: "30px",
        textAlign: "right",
        textShadow: "none",
      },
      count: {
        heatOn: null,
        heatmap: null,
        position: "absolute",
        top: 0,
        right: 0,
        padding: "5px 10px",
        height: "30px",
        fontSize: "24px",
        fontFamily: "Consolas, Andale Mono, monospace",
        zIndex: 2,
      },
      legend: {
        heatOn: null,
        heatmap: null,
        position: "absolute",
        top: 0,
        left: 0,
        padding: "5px 10px",
        height: "30px",
        fontSize: "12px",
        lineHeight: "32px",
        fontFamily: "sans-serif",
        textAlign: "left",
        zIndex: 2,
      },
      graph: {
        heatOn: null,
        heatmap: null,
        position: "relative",
        boxSizing: "padding-box",
        MozBoxSizing: "padding-box",
        height: "100%",
        zIndex: 1,
      },
      column: { width: 4, spacing: 1, heatOn: null, heatmap: null },
    });
    (e.theme.dark = e.extend({}, n, {
      heatmaps: [{ saturation: 0.8, lightness: 0.8 }],
      container: {
        background: "#222",
        color: "#fff",
        border: "1px solid #1a1a1a",
        textShadow: "1px 1px 0 #222",
      },
      count: { heatOn: "color" },
      column: { background: "#3f3f3f" },
    })),
      (e.theme.light = e.extend({}, n, {
        heatmaps: [{ saturation: 0.5, lightness: 0.5 }],
        container: {
          color: "#666",
          background: "#fff",
          textShadow:
            "1px 1px 0 rgba(255,255,255,.5), -1px -1px 0 rgba(255,255,255,.5)",
          boxShadow: "0 0 0 1px rgba(0,0,0,.1)",
        },
        count: { heatOn: "color" },
        column: { background: "#eaeaea" },
      })),
      (e.theme.colorful = e.extend({}, n, {
        heatmaps: [{ saturation: 0.5, lightness: 0.6 }],
        container: {
          heatOn: "backgroundColor",
          background: "#888",
          color: "#fff",
          textShadow: "1px 1px 0 rgba(0,0,0,.2)",
          boxShadow: "0 0 0 1px rgba(0,0,0,.1)",
        },
        column: { background: "#777", backgroundColor: "rgba(0,0,0,.2)" },
      })),
      (e.theme.transparent = e.extend({}, n, {
        heatmaps: [{ saturation: 0.8, lightness: 0.5 }],
        container: {
          padding: 0,
          color: "#fff",
          textShadow: "1px 1px 0 rgba(0,0,0,.5)",
        },
        count: { padding: "0 5px", height: "40px", lineHeight: "40px" },
        legend: { padding: "0 5px", height: "40px", lineHeight: "42px" },
        graph: { height: "40px" },
        column: {
          width: 5,
          background: "#999",
          heatOn: "backgroundColor",
          opacity: 0.5,
        },
      }));
  })(window, FPSMeter));
var Fps = pc.createScript("fps");
(Fps.prototype.initialize = function () {
  this.fps = new FPSMeter({ heat: !0, graph: !0 });
}),
  (Fps.prototype.update = function (t) {
    this.fps.tick();
  });
var Ribbon = pc.createScript("ribbon");
Ribbon.attributes.add("lifetime", { type: "number", default: 0.5 }),
  Ribbon.attributes.add("xoffset", { type: "number", default: -0.8 }),
  Ribbon.attributes.add("yoffset", { type: "number", default: 1 }),
  Ribbon.attributes.add("height", { type: "number", default: 0.4 }),
  Ribbon.attributes.add("color", { type: "vec4" });
var MAX_VERTICES = 6e3,
  VERTEX_SIZE = 4;
(Ribbon.prototype.initialize = function () {
  var e = {
      attributes: { aPositionAge: pc.SEMANTIC_POSITION },
      vshader: [
        "attribute vec4 aPositionAge;",
        "",
        "uniform mat4 matrix_viewProjection;",
        "uniform float trail_time;",
        "",
        "varying float vAge;",
        "",
        "void main(void)",
        "{",
        "    vAge = trail_time - aPositionAge.w;",
        "    gl_Position = matrix_viewProjection * vec4(aPositionAge.xyz, 1.0);",
        "}",
      ].join("\n"),
      fshader: [
        "precision mediump float;",
        "",
        "varying float vAge;",
        "",
        "uniform float trail_lifetime;",
        "uniform float color_red;",
        "uniform float color_green;",
        "uniform float color_blue;",
        "uniform float color_alpha;",
        "",
        "void main(void)",
        "{",
        "    gl_FragColor = vec4(color_red, color_green, color_blue, color_alpha);",
        "}",
      ].join("\n"),
    },
    t = new pc.Shader(this.app.graphicsDevice, e);
  (this.material = new pc.Material()),
    (this.material.shader = t),
    this.material.setParameter("trail_time", 0),
    this.material.setParameter("trail_lifetime", this.lifetime),
    this.material.setParameter("color_red", this.color.x),
    this.material.setParameter("color_green", this.color.y),
    this.material.setParameter("color_blue", this.color.z),
    this.material.setParameter("color_alpha", this.color.w),
    (this.material.cull = pc.CULLFACE_NONE),
    (this.material.blend = !0),
    (this.material.blendSrc = pc.BLENDMODE_SRC_ALPHA),
    (this.material.blendDst = pc.BLENDMODE_ONE_MINUS_SRC_ALPHA),
    (this.material.blendEquation = pc.BLENDEQUATION_ADD),
    (this.material.depthWrite = !1),
    (this.timer = 0),
    (this.vertices = []),
    (this.vertexData = new Float32Array(MAX_VERTICES * VERTEX_SIZE)),
    (this.vertexIndexArray = []);
  for (var i = 0; i < this.vertexData.length; ++i)
    this.vertexIndexArray.push(i);
  (this.mesh = new pc.Mesh(this.app.graphicsDevice)),
    this.mesh.clear(!0, !1),
    this.mesh.setPositions(this.vertexData, VERTEX_SIZE, MAX_VERTICES),
    this.mesh.setIndices(this.vertexIndexArray, MAX_VERTICES),
    this.mesh.update(pc.PRIMITIVE_TRISTRIP);
  var r = new pc.MeshInstance(this.mesh, this.material);
  this.entity.addComponent("render", {
    meshInstances: [r],
    layers: [this.app.scene.layers.getLayerByName("World").id],
    castShadows: !1,
  }),
    (this.entity.render.enabled = !1);
}),
  (Ribbon.prototype.reset = function () {
    (this.timer = 0), (this.vertices = []);
  }),
  (Ribbon.prototype.spawnNewVertices = function () {
    var e = this.entity,
      t = e.getPosition(),
      i = e.up.clone().scale(this.height),
      r = this.xoffset,
      a = this.yoffset,
      s = this.timer,
      o = [
        t.x + i.x * r,
        t.y + i.y * r,
        t.z + i.z * r,
        t.x + i.x * a,
        t.y + i.y * a,
        t.z + i.z * a,
      ];
    this.vertices.unshift({ spawnTime: s, vertexPair: o });
  }),
  (Ribbon.prototype.clearOldVertices = function () {
    for (var e = this.vertices.length - 1; e >= 0; e--) {
      var t = this.vertices[e];
      if (!(this.timer - t.spawnTime >= this.lifetime)) break;
      this.vertices.pop();
    }
  }),
  (Ribbon.prototype.prepareVertexData = function () {
    for (var e = 0; e < this.vertices.length; e++) {
      var t = this.vertices[e];
      if (
        ((this.vertexData[8 * e + 0] = t.vertexPair[0]),
        (this.vertexData[8 * e + 1] = t.vertexPair[1]),
        (this.vertexData[8 * e + 2] = t.vertexPair[2]),
        (this.vertexData[8 * e + 3] = t.spawnTime),
        (this.vertexData[8 * e + 4] = t.vertexPair[3]),
        (this.vertexData[8 * e + 5] = t.vertexPair[4]),
        (this.vertexData[8 * e + 6] = t.vertexPair[5]),
        (this.vertexData[8 * e + 7] = t.spawnTime),
        this.vertexData.length === e)
      )
        break;
    }
  }),
  (Ribbon.prototype.update = function (e) {
    if (
      ((this.timer += e),
      this.material.setParameter("trail_time", this.timer),
      this.clearOldVertices(),
      this.spawnNewVertices(),
      this.vertices.length > 1)
    ) {
      this.prepareVertexData();
      var t = 2 * this.vertices.length,
        i = MAX_VERTICES;
      t < i && (i = t),
        this.mesh.setPositions(this.vertexData, VERTEX_SIZE, i),
        this.mesh.setIndices(this.vertexIndexArray, i),
        this.mesh.update(pc.PRIMITIVE_TRISTRIP),
        (this.entity.render.enabled = !0);
    }
  });
var WaterFlowComponent = pc.createScript("waterFlowComponent");
WaterFlowComponent.attributes.add("model", { type: "entity" }),
  WaterFlowComponent.attributes.add("trail", { type: "entity" }),
  WaterFlowComponent.attributes.add("ribbonOffset", { type: "number" }),
  (window.waterFlow = function () {
    return pc.Application.getApplication().root.findByName("WaterFlow").script
      .waterFlowComponent;
  }),
  (WaterFlowComponent.prototype.update = function (t) {
    this.init();
  }),
  (WaterFlowComponent.prototype.init = function () {
    if (!this.isInit) {
      (this.isInit = !0),
        (this.ribbon = this.trail.script.ribbon),
        (this.gameSystem =
          this.app.root.findByName("GameSystem").script.gameSystem),
        (this.pathIndex = 0);
      var t = this.entity.getLocalScale();
      this.model
        .tween(t)
        .to(new pc.Vec3(t.x + 0.5, t.y, t.z + 0.25), 0.25, pc.SineOut)
        .loop(!0)
        .yoyo(!0)
        .start();
    }
  }),
  (WaterFlowComponent.prototype.action = function () {
    (this.pathRoot = this.app.root.findByName("Flow Path")),
      (this.nodes = this.pathRoot.children),
      this.pathRoot.addChild(this.entity),
      this.entity.setLocalPosition(
        this.nodes[this.pathIndex].getLocalPosition()
      ),
      this.move();
  }),
  (WaterFlowComponent.prototype.move = function () {
    if ((this.pathIndex++, this.pathIndex >= this.nodes.length)) {
      var t = this.app.root.findByName("Pump Flow");
      return (
        t
          .tween(t.getLocalScale())
          .to(new pc.Vec3(1, 1, 1), 0.5, pc.SineOut)
          .start(),
        void (this.model.enabled = !1)
      );
    }
    var e = this.nodes[this.pathIndex - 1].getLocalPosition(),
      o = this.nodes[this.pathIndex].getLocalPosition(),
      i = e.distance(o) / this.gameSystem.waterFlowTime;
    o.z < -1
      ? (this.gameSystem.pipeList.forEach((t) => {
          t.effect && (t.effect.enabled = !0);
        }),
        (i /= 20))
      : o.z < 0 &&
        ((this.model.enabled = !1),
        (this.ribbon.xoffset -= this.ribbonOffset),
        (this.ribbon.yoffset += this.ribbonOffset),
        (i /= 5),
        this.gameSystem.createEffect(2, this.nodes[this.pathIndex]));
    var n = this;
    this.entity
      .tween(this.entity.getLocalPosition())
      .to(o, i, pc.Linear)
      .on("complete", function () {
        n.move();
      })
      .start();
    var s = this.nodes[this.pathIndex].getLocalEulerAngles();
    this.entity
      .tween(this.entity.getLocalEulerAngles())
      .rotate(new pc.Vec3(0, 0, s.z), i, pc.Linear)
      .start();
  });
var InventoryComponent = pc.createScript("inventoryComponent");
InventoryComponent.attributes.add("inventory", {
  type: "entity",
  title: "Inventory Panel",
}),
  InventoryComponent.attributes.add("positionY", {
    type: "vec2",
    title: "Inventory Position",
  }),
  InventoryComponent.attributes.add("openTime", {
    type: "number",
    title: "Open Time",
  }),
  (window.inventory = function () {
    return pc.Application.getApplication().root.findByName("InventorySystem")
      .script.inventoryComponent;
  }),
  (InventoryComponent.prototype.update = function (t) {
    this.init();
  }),
  (InventoryComponent.prototype.init = function () {
    this.isInit || ((this.isInit = !0), (this.slotList = []), this.active(!0));
  }),
  (InventoryComponent.prototype.active = function (t) {
    var n = t ? this.positionY.x : this.positionY.y,
      o = t ? this.positionY.y : this.positionY.x,
      i = this.inventory.getLocalPosition();
    this.inventory.setLocalPosition(i.x, n, i.z),
      this.inventory
        .tween(this.inventory.getLocalPosition())
        .to(new pc.Vec3(i.x, o, i.z), this.openTime, pc.SineOut)
        .start();
  }),
  (InventoryComponent.prototype.check = function () {
    var t = !0;
    this.slotList.forEach((n) => {
      n.isFree && (t = !1);
    }),
      t && this.active(!1);
  });
var PipeMoveComponent = pc.createScript("pipeMoveComponent");
PipeMoveComponent.attributes.add("pipeTag", {
  type: "string",
  default: "Pipe",
}),
  PipeMoveComponent.attributes.add("slotTag", {
    type: "string",
    default: "Slot",
  }),
  (window.pipeMove = function () {
    return pc.Application.getApplication().root.findByName("Camera").script
      .pipeMoveComponent;
  }),
  (PipeMoveComponent.prototype.update = function (t) {
    this.init();
  }),
  (PipeMoveComponent.prototype.init = function () {
    this.isInit ||
      ((this.isInit = !0),
      (this.pipe = null),
      (this.gameSystem =
        this.app.root.findByName("GameSystem").script.gameSystem),
      (this.water = null),
      this.app.mouse.on(pc.EVENT_MOUSEDOWN, this.mouseDown, this),
      this.app.mouse.on(pc.EVENT_MOUSEMOVE, this.mouseMove, this),
      this.app.mouse.on(pc.EVENT_MOUSEUP, this.mouseUp, this),
      this.app.touch &&
        (this.app.touch.on(pc.EVENT_TOUCHSTART, this.touchStart, this),
        this.app.touch.on(pc.EVENT_TOUCHMOVE, this.touchMove, this),
        this.app.touch.on(pc.EVENT_TOUCHEND, this.touchEnd, this)));
  }),
  (PipeMoveComponent.prototype.mouseDown = function (t) {
    this.take(t, t.x, t.y);
  }),
  (PipeMoveComponent.prototype.mouseMove = function (t) {
    if (this.pipe) {
      var e = this.entity.getPosition().z - this.initialPosition.z,
        i = this.entity.camera.screenToWorld(
          t.x + this.offset.x,
          t.y + this.offset.y,
          e
        );
      this.pipe.entity.setPosition(i);
    }
  }),
  (PipeMoveComponent.prototype.mouseUp = function (t) {
    this.drop(t.x, t.y);
  }),
  (PipeMoveComponent.prototype.touchStart = function (t) {
    1 === t.touches.length &&
      (this.take(t, t.touches[0].x, t.touches[0].y),
      (this.touch = t.touches[0])),
      t.event.preventDefault();
  }),
  (PipeMoveComponent.prototype.touchMove = function (t) {
    if (this.pipe && 0 !== t.touches.length) {
      var e = this.entity.getPosition().z - this.initialPosition.z,
        i = this.entity.camera.screenToWorld(t.touches[0].x, t.touches[0].y, e);
      this.pipe.entity.setPosition(i),
        (this.touch = t.touches[0]),
        t.event.preventDefault();
    }
  }),
  (PipeMoveComponent.prototype.touchEnd = function (t) {
    this.drop(this.touch.x, this.touch.y);
  }),
  (PipeMoveComponent.prototype.take = function (t, e, i) {
    if (!this.gameSystem.isFail) {
      var o = this.doRaycast(e, i, this.pipeTag);
      if (o) {
        var s = o.script.pipeComponent;
        if (s) {
          if (!s.isItem) return;
          (this.pipe = s),
            (this.initialPosition = this.pipe.entity.getPosition().clone());
          var p = this.entity.camera.worldToScreen(this.initialPosition);
          (this.offset = new pc.Vec3().sub2(p, t)),
            (this.pipe.entity.collision.enabled = !1),
            this.gameSystem.playSound("Pipe_2"),
            this.water.waterPause(!1);
        }
      }
    }
  }),
  (PipeMoveComponent.prototype.drop = function (t, e) {
    if (this.pipe) {
      var i = this.doRaycast(t, e, this.slotTag);
      if (!this.gameSystem.isFail && i) {
        var o = i.script.slotComponent;
        o.isFree && o.check(this.pipe)
          ? ((o.isFree = !1),
            (o.model.enabled = !1),
            window.inventory().check(),
            i.addChild(this.pipe.entity),
            (i.collision.enabled = !1),
            this.pipe.entity.setLocalPosition(new pc.Vec3(0, 0, 0)),
            (this.pipe.entity.collision.enabled = !0),
            (this.pipe.isItem = !1),
            this.gameSystem.levelAnalysis(),
            this.gameSystem.createEffect(1, this.pipe.entity),
            (this.pipe = null),
            this.gameSystem.playSound("Pipe_1"))
          : this.reset();
      } else this.reset();
    }
  }),
  (PipeMoveComponent.prototype.reset = function () {
    this.pipe.entity.setLocalPosition(new pc.Vec3(0, 0, 0)),
      (this.pipe.entity.collision.enabled = !0),
      (this.pipe = null);
  }),
  (PipeMoveComponent.prototype.doRaycast = function (t, e, i) {
    var o = this.entity.getPosition(),
      s = this.entity.camera.screenToWorld(t, e, this.entity.camera.farClip),
      p = this.app.systems.rigidbody.raycastFirst(o, s);
    if (p) {
      var n = p.entity;
      if (n.tags.has(i)) return n;
    }
    return null;
  });
var SlotComponent = pc.createScript("slotComponent");
SlotComponent.attributes.add("model", { type: "entity" }),
  SlotComponent.attributes.add("isFree", { type: "boolean", default: !0 }),
  SlotComponent.attributes.add("result", { type: "entity", array: !0 }),
  (SlotComponent.prototype.update = function (t) {
    this.init();
  }),
  (SlotComponent.prototype.init = function () {
    this.isInit || ((this.isInit = !0), window.inventory().slotList.push(this));
  }),
  (SlotComponent.prototype.check = function (t) {
    var o = !1;
    return (
      this.result.forEach((n) => {
        n === t.entity && (o = !0);
      }),
      o
    );
  });
var TutorialComponent = pc.createScript("tutorialComponent");
TutorialComponent.attributes.add("scale", { type: "vec2" }),
  TutorialComponent.attributes.add("time", { type: "number" }),
  (TutorialComponent.prototype.update = function (t) {
    this.init();
    var e = this.getPipe(),
      i = null != e ? e.getPosition() : new pc.Vec3(0, 0, -5);
    this.entity.setPosition(i);
  }),
  (TutorialComponent.prototype.init = function () {
    if (!this.isInit) {
      (this.isInit = !0),
        (this.gameSystem =
          this.app.root.findByName("GameSystem").script.gameSystem);
      var t = this.scale;
      this.entity.setLocalScale(new pc.Vec3(t.x, t.x, t.x));
      var e = this.entity.getLocalScale();
      this.entity
        .tween(e)
        .to(new pc.Vec3(t.y, t.y, t.y), this.time, pc.SineOut)
        .loop(!0)
        .yoyo(!0)
        .start();
    }
  }),
  (TutorialComponent.prototype.getPipe = function () {
    var t = null;
    return (
      this.gameSystem.pipeList.forEach((e) => {
        e.result[e.state] || (t = e.entity);
      }),
      t
    );
  });
pc.extend(
  pc,
  (function () {
    var TweenManager = function (t) {
      (this._app = t), (this._tweens = []), (this._add = []);
    };
    TweenManager.prototype = {
      add: function (t) {
        return this._add.push(t), t;
      },
      update: function (t) {
        for (var i = 0, e = this._tweens.length; i < e; )
          this._tweens[i].update(t) ? i++ : (this._tweens.splice(i, 1), e--);
        if (this._add.length) {
          for (let t = 0; t < this._add.length; t++)
            this._tweens.indexOf(this._add[t]) > -1 ||
              this._tweens.push(this._add[t]);
          this._add.length = 0;
        }
      },
    };
    var Tween = function (t, i, e) {
        pc.events.attach(this),
          (this.manager = i),
          e && (this.entity = null),
          (this.time = 0),
          (this.complete = !1),
          (this.playing = !1),
          (this.stopped = !0),
          (this.pending = !1),
          (this.target = t),
          (this.duration = 0),
          (this._currentDelay = 0),
          (this.timeScale = 1),
          (this._reverse = !1),
          (this._delay = 0),
          (this._yoyo = !1),
          (this._count = 0),
          (this._numRepeats = 0),
          (this._repeatDelay = 0),
          (this._from = !1),
          (this._slerp = !1),
          (this._fromQuat = new pc.Quat()),
          (this._toQuat = new pc.Quat()),
          (this._quat = new pc.Quat()),
          (this.easing = pc.Linear),
          (this._sv = {}),
          (this._ev = {});
      },
      _parseProperties = function (t) {
        var i;
        return (
          t instanceof pc.Vec2
            ? (i = { x: t.x, y: t.y })
            : t instanceof pc.Vec3
            ? (i = { x: t.x, y: t.y, z: t.z })
            : t instanceof pc.Vec4 || t instanceof pc.Quat
            ? (i = { x: t.x, y: t.y, z: t.z, w: t.w })
            : t instanceof pc.Color
            ? ((i = { r: t.r, g: t.g, b: t.b }), void 0 !== t.a && (i.a = t.a))
            : (i = t),
          i
        );
      };
    Tween.prototype = {
      to: function (t, i, e, s, n, r) {
        return (
          (this._properties = _parseProperties(t)),
          (this.duration = i),
          e && (this.easing = e),
          s && this.delay(s),
          n && this.repeat(n),
          r && this.yoyo(r),
          this
        );
      },
      from: function (t, i, e, s, n, r) {
        return (
          (this._properties = _parseProperties(t)),
          (this.duration = i),
          e && (this.easing = e),
          s && this.delay(s),
          n && this.repeat(n),
          r && this.yoyo(r),
          (this._from = !0),
          this
        );
      },
      rotate: function (t, i, e, s, n, r) {
        return (
          (this._properties = _parseProperties(t)),
          (this.duration = i),
          e && (this.easing = e),
          s && this.delay(s),
          n && this.repeat(n),
          r && this.yoyo(r),
          (this._slerp = !0),
          this
        );
      },
      start: function () {
        var t, i, e, s;
        if (
          ((this.playing = !0),
          (this.complete = !1),
          (this.stopped = !1),
          (this._count = 0),
          (this.pending = this._delay > 0),
          this._reverse && !this.pending
            ? (this.time = this.duration)
            : (this.time = 0),
          this._from)
        ) {
          for (t in this._properties)
            this._properties.hasOwnProperty(t) &&
              ((this._sv[t] = this._properties[t]),
              (this._ev[t] = this.target[t]));
          this._slerp &&
            (this._toQuat.setFromEulerAngles(
              this.target.x,
              this.target.y,
              this.target.z
            ),
            (i =
              void 0 !== this._properties.x
                ? this._properties.x
                : this.target.x),
            (e =
              void 0 !== this._properties.y
                ? this._properties.y
                : this.target.y),
            (s =
              void 0 !== this._properties.z
                ? this._properties.z
                : this.target.z),
            this._fromQuat.setFromEulerAngles(i, e, s));
        } else {
          for (t in this._properties)
            this._properties.hasOwnProperty(t) &&
              ((this._sv[t] = this.target[t]),
              (this._ev[t] = this._properties[t]));
          this._slerp &&
            ((i =
              void 0 !== this._properties.x
                ? this._properties.x
                : this.target.x),
            (e =
              void 0 !== this._properties.y
                ? this._properties.y
                : this.target.y),
            (s =
              void 0 !== this._properties.z
                ? this._properties.z
                : this.target.z),
            void 0 !== this._properties.w
              ? (this._fromQuat.copy(this.target),
                this._toQuat.set(i, e, s, this._properties.w))
              : (this._fromQuat.setFromEulerAngles(
                  this.target.x,
                  this.target.y,
                  this.target.z
                ),
                this._toQuat.setFromEulerAngles(i, e, s)));
        }
        return (this._currentDelay = this._delay), this.manager.add(this), this;
      },
      pause: function () {
        this.playing = !1;
      },
      resume: function () {
        this.playing = !0;
      },
      stop: function () {
        (this.playing = !1), (this.stopped = !0);
      },
      delay: function (t) {
        return (this._delay = t), (this.pending = !0), this;
      },
      repeat: function (t, i) {
        return (
          (this._count = 0),
          (this._numRepeats = t),
          (this._repeatDelay = i || 0),
          this
        );
      },
      loop: function (t) {
        return (
          t
            ? ((this._count = 0), (this._numRepeats = 1 / 0))
            : (this._numRepeats = 0),
          this
        );
      },
      yoyo: function (t) {
        return (this._yoyo = t), this;
      },
      reverse: function () {
        return (this._reverse = !this._reverse), this;
      },
      chain: function () {
        for (var t = arguments.length; t--; )
          t > 0
            ? (arguments[t - 1]._chained = arguments[t])
            : (this._chained = arguments[t]);
        return this;
      },
      update: function (t) {
        if (this.stopped) return !1;
        if (!this.playing) return !0;
        if (
          (!this._reverse || this.pending
            ? (this.time += t * this.timeScale)
            : (this.time -= t * this.timeScale),
          this.pending)
        ) {
          if (!(this.time > this._currentDelay)) return !0;
          this._reverse
            ? (this.time = this.duration - (this.time - this._currentDelay))
            : (this.time -= this._currentDelay),
            (this.pending = !1);
        }
        var i = 0;
        ((!this._reverse && this.time > this.duration) ||
          (this._reverse && this.time < 0)) &&
          (this._count++,
          (this.complete = !0),
          (this.playing = !1),
          this._reverse
            ? ((i = this.duration - this.time), (this.time = 0))
            : ((i = this.time - this.duration), (this.time = this.duration)));
        var e,
          s,
          n = 0 === this.duration ? 1 : this.time / this.duration,
          r = this.easing(n);
        for (var h in this._properties)
          this._properties.hasOwnProperty(h) &&
            ((e = this._sv[h]),
            (s = this._ev[h]),
            (this.target[h] = e + (s - e) * r));
        if (
          (this._slerp && this._quat.slerp(this._fromQuat, this._toQuat, r),
          this.entity &&
            (this.entity._dirtifyLocal(),
            this.element &&
              this.entity.element &&
              (this.entity.element[this.element] = this.target),
            this._slerp && this.entity.setLocalRotation(this._quat)),
          this.fire("update", t),
          this.complete)
        ) {
          var a = this._repeat(i);
          return (
            a
              ? this.fire("loop")
              : (this.fire("complete", i),
                this.entity && this.entity.off("destroy", this.stop, this),
                this._chained && this._chained.start()),
            a
          );
        }
        return !0;
      },
      _repeat: function (t) {
        if (this._count < this._numRepeats) {
          if (
            (this._reverse ? (this.time = this.duration - t) : (this.time = t),
            (this.complete = !1),
            (this.playing = !0),
            (this._currentDelay = this._repeatDelay),
            (this.pending = !0),
            this._yoyo)
          ) {
            for (var i in this._properties) {
              var e = this._sv[i];
              (this._sv[i] = this._ev[i]), (this._ev[i] = e);
            }
            this._slerp &&
              (this._quat.copy(this._fromQuat),
              this._fromQuat.copy(this._toQuat),
              this._toQuat.copy(this._quat));
          }
          return !0;
        }
        return !1;
      },
    };
    var BounceOut = function (t) {
        return t < 1 / 2.75
          ? 7.5625 * t * t
          : t < 2 / 2.75
          ? 7.5625 * (t -= 1.5 / 2.75) * t + 0.75
          : t < 2.5 / 2.75
          ? 7.5625 * (t -= 2.25 / 2.75) * t + 0.9375
          : 7.5625 * (t -= 2.625 / 2.75) * t + 0.984375;
      },
      BounceIn = function (t) {
        return 1 - BounceOut(1 - t);
      };
    return {
      TweenManager: TweenManager,
      Tween: Tween,
      Linear: function (t) {
        return t;
      },
      QuadraticIn: function (t) {
        return t * t;
      },
      QuadraticOut: function (t) {
        return t * (2 - t);
      },
      QuadraticInOut: function (t) {
        return (t *= 2) < 1 ? 0.5 * t * t : -0.5 * (--t * (t - 2) - 1);
      },
      CubicIn: function (t) {
        return t * t * t;
      },
      CubicOut: function (t) {
        return --t * t * t + 1;
      },
      CubicInOut: function (t) {
        return (t *= 2) < 1 ? 0.5 * t * t * t : 0.5 * ((t -= 2) * t * t + 2);
      },
      QuarticIn: function (t) {
        return t * t * t * t;
      },
      QuarticOut: function (t) {
        return 1 - --t * t * t * t;
      },
      QuarticInOut: function (t) {
        return (t *= 2) < 1
          ? 0.5 * t * t * t * t
          : -0.5 * ((t -= 2) * t * t * t - 2);
      },
      QuinticIn: function (t) {
        return t * t * t * t * t;
      },
      QuinticOut: function (t) {
        return --t * t * t * t * t + 1;
      },
      QuinticInOut: function (t) {
        return (t *= 2) < 1
          ? 0.5 * t * t * t * t * t
          : 0.5 * ((t -= 2) * t * t * t * t + 2);
      },
      SineIn: function (t) {
        return 0 === t ? 0 : 1 === t ? 1 : 1 - Math.cos((t * Math.PI) / 2);
      },
      SineOut: function (t) {
        return 0 === t ? 0 : 1 === t ? 1 : Math.sin((t * Math.PI) / 2);
      },
      SineInOut: function (t) {
        return 0 === t ? 0 : 1 === t ? 1 : 0.5 * (1 - Math.cos(Math.PI * t));
      },
      ExponentialIn: function (t) {
        return 0 === t ? 0 : Math.pow(1024, t - 1);
      },
      ExponentialOut: function (t) {
        return 1 === t ? 1 : 1 - Math.pow(2, -10 * t);
      },
      ExponentialInOut: function (t) {
        return 0 === t
          ? 0
          : 1 === t
          ? 1
          : (t *= 2) < 1
          ? 0.5 * Math.pow(1024, t - 1)
          : 0.5 * (2 - Math.pow(2, -10 * (t - 1)));
      },
      CircularIn: function (t) {
        return 1 - Math.sqrt(1 - t * t);
      },
      CircularOut: function (t) {
        return Math.sqrt(1 - --t * t);
      },
      CircularInOut: function (t) {
        return (t *= 2) < 1
          ? -0.5 * (Math.sqrt(1 - t * t) - 1)
          : 0.5 * (Math.sqrt(1 - (t -= 2) * t) + 1);
      },
      BackIn: function (t) {
        var i = 1.70158;
        return t * t * ((i + 1) * t - i);
      },
      BackOut: function (t) {
        var i = 1.70158;
        return --t * t * ((i + 1) * t + i) + 1;
      },
      BackInOut: function (t) {
        var i = 2.5949095;
        return (t *= 2) < 1
          ? t * t * ((i + 1) * t - i) * 0.5
          : 0.5 * ((t -= 2) * t * ((i + 1) * t + i) + 2);
      },
      BounceIn: BounceIn,
      BounceOut: BounceOut,
      BounceInOut: function (t) {
        return t < 0.5
          ? 0.5 * BounceIn(2 * t)
          : 0.5 * BounceOut(2 * t - 1) + 0.5;
      },
      ElasticIn: function (t) {
        var i,
          e = 0.1;
        return 0 === t
          ? 0
          : 1 === t
          ? 1
          : (!e || e < 1
              ? ((e = 1), (i = 0.1))
              : (i = (0.4 * Math.asin(1 / e)) / (2 * Math.PI)),
            -e *
              Math.pow(2, 10 * (t -= 1)) *
              Math.sin(((t - i) * (2 * Math.PI)) / 0.4));
      },
      ElasticOut: function (t) {
        var i,
          e = 0.1;
        return 0 === t
          ? 0
          : 1 === t
          ? 1
          : (!e || e < 1
              ? ((e = 1), (i = 0.1))
              : (i = (0.4 * Math.asin(1 / e)) / (2 * Math.PI)),
            e *
              Math.pow(2, -10 * t) *
              Math.sin(((t - i) * (2 * Math.PI)) / 0.4) +
              1);
      },
      ElasticInOut: function (t) {
        var i,
          e = 0.1,
          s = 0.4;
        return 0 === t
          ? 0
          : 1 === t
          ? 1
          : (!e || e < 1
              ? ((e = 1), (i = 0.1))
              : (i = (s * Math.asin(1 / e)) / (2 * Math.PI)),
            (t *= 2) < 1
              ? e *
                Math.pow(2, 10 * (t -= 1)) *
                Math.sin(((t - i) * (2 * Math.PI)) / s) *
                -0.5
              : e *
                  Math.pow(2, -10 * (t -= 1)) *
                  Math.sin(((t - i) * (2 * Math.PI)) / s) *
                  0.5 +
                1);
      },
    };
  })()
),
  (function () {
    (pc.AppBase.prototype.addTweenManager = function () {
      (this._tweenManager = new pc.TweenManager(this)),
        this.on("update", function (t) {
          this._tweenManager.update(t);
        });
    }),
      (pc.AppBase.prototype.tween = function (t) {
        return new pc.Tween(t, this._tweenManager);
      }),
      (pc.Entity.prototype.tween = function (t, i) {
        var e = this._app.tween(t);
        return (
          (e.entity = this),
          this.once("destroy", e.stop, e),
          i && i.element && (e.element = i.element),
          e
        );
      });
    var t = pc.AppBase.getApplication();
    t && t.addTweenManager();
  })();
var EnvironmentComponent = pc.createScript("environmentComponent");
EnvironmentComponent.attributes.add("levelInterval", {
  type: "number",
  default: 1,
  title: "Background Interval",
}),
  EnvironmentComponent.attributes.add("back", {
    type: "entity",
    title: "Background",
  }),
  EnvironmentComponent.attributes.add("wallList", {
    type: "entity",
    title: "Walls",
  }),
  EnvironmentComponent.attributes.add("brickList", {
    type: "entity",
    title: "Bricks",
  }),
  EnvironmentComponent.attributes.add("backMaterialList", {
    type: "asset",
    array: !0,
    title: "Background Material",
  }),
  EnvironmentComponent.attributes.add("wallMaterialList", {
    type: "asset",
    array: !0,
    title: "Wall Material",
  }),
  EnvironmentComponent.attributes.add("brickMaterialList", {
    type: "asset",
    array: !0,
    title: "Brick Material",
  }),
  EnvironmentComponent.attributes.add("buttonColorList", {
    type: "rgba",
    array: !0,
    title: "Button Color",
  }),
  (EnvironmentComponent.prototype.update = function (t) {
    this.init();
  }),
  (EnvironmentComponent.prototype.init = function () {
    if (!this.isInit) {
      (this.isInit = !0),
        (this.gameSystem =
          this.app.root.findByName("GameSystem").script.gameSystem);
      var t = this.wallList.children,
        e = this.brickList.children,
        i = this.gameSystem.levelStart - 1,
        n = Math.trunc((i / this.levelInterval) % this.backMaterialList.length);
      (this.back.render.material = this.backMaterialList[n].resource),
        t.forEach((t) => {
          t.render.material = this.wallMaterialList[n].resource;
        }),
        e.forEach((t) => {
          t.render.meshInstances[0].material =
            this.brickMaterialList[n].resource;
        }),
        (this.gameSystem.backButton.element.color = this.buttonColorList[n]),
        (this.gameSystem.levelText.element.outlineColor =
          this.buttonColorList[n]);
    }
  });
if ("launch.playcanvas.com" === window.location.hostname) {
  let a = window.location.href;
  a.includes("play.staging.gc.famobi.com") ||
    (window.location.href = `https://play.staging.gc.famobi.com/playcanvas/?overwrite_html5_link=${a}/A-PLAYCANVAS-DEV&aid=A-PLAYCANVAS-DEV`);
}
pc.script.createLoadingScreen(function (n) {
  var e,
    t,
    i,
    a,
    r,
    o = void 0,
    l = document.createElement("canvas"),
    s = 0,
    getCoordinate = function (n) {
      return (
        (n -= 90),
        {
          x: (l.width / 2 - t) * Math.cos((n * Math.PI) / 180) + l.width / 2,
          y: (l.width / 2 - t) * Math.sin((n * Math.PI) / 180) + l.width / 2,
        }
      );
    };
  (a =
    "\n            .fam_bgr {\n            position: absolute;\n            top: 0;\n            left: 0;\n            width: 100%;\n            height: 100%;\n            margin: 0;\n            padding: 0;\n            border: 0;\n            background-color: #fff;\n            }\n\n            #progress_bar {\n            position: absolute;\n            margin-top: 2rem;\n            top: 50%;\n            left: 50%;\n            transform: translate(-50%,-50%);\n            z-index: 0;\n            }\n\n            .splash_wrapper {\n            position: absolute;\n            top: 50%;\n            left: 50%;\n            transform: translate(-50%,-50%);\n            }\n\n            .logo_wrapper {\n            width: 12rem;\n            height: 18rem;\n            margin-left: 1.813rem;\n            perspective: 5.625rem;\n            filter: drop-shadow(0.625rem 0.625rem 0.5rem #a3a3a3);\n            }\n\n            .title_wrapper {\n            position: absolute;\n            width: 15.625rem;\n            height: 4.375rem;\n            z-index: 1;\n            }\n\n            span {\n            margin: 0.188rem;\n            position: absolute;\n            }  \n\n            .row_1 {\n            top: 0;\n            }\n\n            .row_2 {\n            top: 6rem;\n            }\n\n            .row_3 {\n            top: 12rem;\n            }\n\n            .col_1 {\n            left: 0;\n            }\n\n            .col_2 {\n            left: 6rem;\n            }\n\n            .order_0 {\n            z-index: 3;\n            }\n\n            .order_1 {\n            z-index: 2;\n            }\n\n            .order_2 {\n            z-index: 1;\n            }\n\n            .square {\n            width: 5.625rem;\n            height: 5.625rem;\n            }\n\n            .triangle {\n            width: 0;\n            height: 0;\n            border-style: solid;\n            border-width: 2.813rem 0 2.813rem 3.75rem;\n            border-color: transparent transparent transparent #F07E00;\n            }\n\n            .blue {\n            background-color: #0194C6;\n            }\n\n            .orange {\n            background-color: #F07E00;\n            }\n\n            .grey {\n            background-color: #3D3D3B;\n            }\n\n            .ani_shiftright {\n            opacity: 0;\n            animation-name: shift-right;\n            animation-duration: 0.5s; \n            animation-timing-function: ease-out; \n            animation-fill-mode: forwards;\n            }\n\n            .ani_shiftdown {\n            opacity: 0;\n            animation-name: shift-down;\n            animation-duration: 0.5s;\n            animation-timing-function: ease-out; \n            animation-fill-mode: forwards;\n            }\n\n            .ani_title {\n            opacity: 0;\n            animation-name: title;\n            animation-duration: 1.7s;\n            animation-delay: 1.5s;\n            animation-timing-function: ease-out; \n            animation-fill-mode: forwards;\n            }\n\n            .ani_delay {\n            animation-duration: 0.5s;\n            animation-delay: 0.5s;\n            }\n\n            .ani_delay_long {\n            animation-duration: 0.5s;\n            animation-delay: 0.7s;\n            }\n\n            .ani_speed_fast {\n            animation-duration: 0.2s;\n            }\n\n            .ani_speed_medium {\n            animation-duration: 0.5s;\n            }\n\n            .ani_speed_slow {\n            animation-duration: 0.7s;\n            }\n\n            @keyframes shift-right { \n            0% {\n                opacity: 0;\n                margin-left: -5.625rem;\n            }\n            100% {\n                opacity: 1;\n                margin-left: 0.188rem;\n            }\n            }\n\n            @keyframes shift-down { \n            0% {\n                opacity: 0;\n                margin-top: -5.625rem;\n            }\n            100% {\n                opacity: 1;\n                margin-top: 0.188rem;\n            }\n            }\n\n            @keyframes title { \n            0% {\n                opacity: 0;\n                margin-top: -5.625rem;\n            }\n            100% {\n                opacity: 1;\n                margin-top: 0.188rem;\n            }\n            }\n        "),
    ((r = document.createElement("style")).type = "text/css"),
    r.styleSheet
      ? (r.styleSheet.cssText = a)
      : r.appendChild(document.createTextNode(a)),
    document.head.appendChild(r),
    (function () {
      var n = document.createElement("div");
      (n.id = "application-splash-wrapper"),
        (n.innerHTML =
          '\n            <div class="fam_bgr">\n                <div class="splash_wrapper">\n                    <div class="logo_wrapper">\n                    <span class="square blue row_1 col_1 order_0"></span>\n                    <span class="square blue row_1 col_2  order_1 ani_shiftright"></span>\n                    <span class="square orange row_2 col_1 order_1 ani_shiftdown"></span>\n                    <span class="triangle row_2 col_2 order_1 ani_shiftright ani_delay_long ani_speed_fast"></span>\n                    <span class="square grey row_3 col_1 order_2 ani_shiftdown ani_delay_long ani_speed_fast"></span>\n                    </div>\n                    <div class=\'title_wrapper ani_title\'>\n                    <svg width="100%" height="100%" viewBox="0 0 125 33" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" xmlns:serif="http://www.serif.com/" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2;">\n                        <g transform="matrix(1,0,0,1,-52.25,-46.5)">\n                            <path d="M65.7,65.4L58,65.4L58,77.6L53.3,77.6L53.3,50.6L68.7,50.6L68.7,54.7L58,54.7L58,61.2L65.7,61.2L65.7,65.4Z" style="fill:rgb(51,51,51);fill-rule:nonzero;"/>\n                            <path d="M82,77.6L81.7,75L81.5,75C80.8,75.9 79.8,76.7 78.5,77.2C77.2,77.8 75.9,78 74.6,78C72.9,78 71.5,77.5 70.6,76.5C69.6,75.5 69.1,74.2 69.1,72.6C69.1,71.5 69.3,70.5 69.8,69.6C70.3,68.7 71,68 71.9,67.4C72.8,66.8 73.9,66.3 75.1,66C76.4,65.7 77.8,65.5 79.3,65.5L81.1,65.5L81.1,64.9C81.1,63.8 80.8,63.1 80.1,62.6C79.4,62.1 78.3,61.9 76.8,61.9C74.8,61.9 73,62.3 71.4,63.2L70.5,59.8C72.3,58.7 74.5,58.2 77.1,58.2C79.8,58.2 81.9,58.8 83.3,59.9C84,60.4 84.5,61.1 84.9,61.9C85.3,62.7 85.5,63.7 85.5,64.8L85.5,77.6L82,77.6ZM76.4,74.5C77.3,74.5 78.1,74.3 79,73.9C79.9,73.5 80.6,72.9 81.1,72.2L81.1,68.5L80.3,68.5C78.1,68.5 76.4,68.8 75.4,69.4C74.4,70 73.9,70.9 73.9,72.1C74,73.7 74.8,74.5 76.4,74.5Z" style="fill:rgb(51,51,51);fill-rule:nonzero;"/>\n                            <path d="M103.2,77.6L103.2,65.2C103.2,63 102.3,61.9 100.5,61.9C100.1,61.9 99.6,62 99.1,62.1C98.6,62.3 98.1,62.5 97.6,62.8C97.1,63.1 96.7,63.5 96.3,64C95.9,64.5 95.6,65 95.5,65.6L95.5,77.6L91,77.6L91,58.8L94.5,58.8L94.7,61.6L94.9,61.6C95.4,60.5 96.3,59.6 97.5,59C98.7,58.4 99.9,58.2 101.3,58.2C102.6,58.2 103.7,58.5 104.8,59C105.8,59.5 106.6,60.4 107.1,61.6C107.6,60.5 108.5,59.6 109.7,59.1C110.9,58.5 112.1,58.3 113.5,58.3C114.4,58.3 115.2,58.4 116,58.6C116.8,58.8 117.5,59.2 118,59.7C118.6,60.2 119,60.9 119.4,61.7C119.7,62.5 119.9,63.6 119.9,64.8L119.9,77.6L115.4,77.6L115.4,65.2C115.4,63 114.5,61.9 112.7,61.9C112.3,61.9 111.8,62 111.3,62.1C110.8,62.3 110.3,62.5 109.8,62.8C109.3,63.1 108.9,63.5 108.5,64C108.1,64.5 107.8,65 107.7,65.6L107.7,77.6L103.2,77.6Z" style="fill:rgb(51,51,51);fill-rule:nonzero;"/>\n                            <path d="M133.5,58.2C135.2,58.2 136.6,58.5 137.8,59C139,59.6 140,60.3 140.8,61.2C141.6,62.1 142.1,63.2 142.5,64.4C142.9,65.6 143.1,66.9 143.1,68.2C143.1,69.5 142.9,70.8 142.5,72C142.1,73.2 141.6,74.2 140.8,75.1C140,76 139,76.7 137.9,77.2C136.7,77.7 135.3,78 133.7,78C132,78 130.6,77.7 129.4,77.2C128.2,76.7 127.2,75.9 126.4,75C125.6,74.1 125,73 124.6,71.8C124.2,70.6 124,69.3 124,68C124,66.7 124.2,65.4 124.6,64.2C125,63 125.6,62 126.3,61C127.1,60.1 128.1,59.4 129.3,58.8C130.5,58.5 131.9,58.2 133.5,58.2ZM133.6,74.7C134.4,74.7 135.1,74.5 135.7,74.2C136.3,73.9 136.8,73.4 137.2,72.8C137.6,72.2 137.9,71.5 138,70.8C138.2,70 138.3,69.2 138.3,68.4C138.3,67.5 138.2,66.7 138,65.9C137.8,65.1 137.5,64.4 137.1,63.8C136.7,63.2 136.2,62.7 135.6,62.3C135,61.9 134.3,61.7 133.4,61.7C132.6,61.7 131.9,61.9 131.4,62.2C130.8,62.5 130.4,63 130,63.6C129.6,64.2 129.4,64.8 129.2,65.6C129,66.4 128.9,67.2 128.9,68C128.9,68.9 129,69.7 129.2,70.5C129.4,71.3 129.7,72 130.1,72.6C130.5,73.2 131,73.7 131.6,74.1C132.1,74.5 132.8,74.7 133.6,74.7Z" style="fill:rgb(51,51,51);fill-rule:nonzero;"/>\n                            <path d="M157.9,78.1C156.4,78.1 155.2,77.8 154.2,77.2C153.2,76.6 152.4,75.9 151.6,75L151.4,75L151.1,77.6L147.5,77.6L147.5,47.4L152,47.4L152,60.7C152.6,59.9 153.5,59.3 154.5,58.9C155.5,58.5 156.7,58.2 158,58.2C159.4,58.2 160.7,58.5 161.7,59C162.8,59.5 163.6,60.3 164.4,61.2C165.1,62.1 165.6,63.1 166,64.3C166.3,65.5 166.5,66.7 166.5,68C166.5,69.4 166.3,70.8 165.9,72C165.5,73.2 164.9,74.3 164.2,75.2C163.5,76.1 162.5,76.8 161.5,77.3C160.4,77.8 159.2,78.1 157.9,78.1ZM157.3,74.7C158.1,74.7 158.8,74.5 159.4,74.1C160,73.7 160.5,73.2 160.9,72.6C161.3,72 161.6,71.3 161.8,70.5C162,69.7 162.1,68.9 162.1,68.1C162.1,67.3 162,66.4 161.8,65.7C161.6,64.9 161.3,64.2 160.9,63.6C160.5,63 159.9,62.5 159.3,62.2C158.7,61.9 157.9,61.7 157.1,61.7C156.3,61.7 155.5,61.9 154.7,62.3C153.9,62.7 153,63.4 152.2,64.4L152.2,72.2C152.5,72.6 152.9,73 153.3,73.3C153.7,73.6 154.2,73.9 154.7,74.1C155.2,74.3 155.7,74.5 156.2,74.6C156.7,74.7 156.9,74.7 157.3,74.7Z" style="fill:rgb(51,51,51);fill-rule:nonzero;"/>\n                            <path d="M170.4,52.8C170.4,52.4 170.5,52.1 170.6,51.7C170.7,51.3 171,51 171.2,50.7C171.5,50.4 171.8,50.2 172.1,50C172.4,49.8 172.8,49.8 173.2,49.8C173.6,49.8 173.9,49.9 174.3,50C174.7,50.2 175,50.4 175.3,50.7C175.6,51 175.8,51.3 176,51.7C176.2,52.1 176.2,52.4 176.2,52.8C176.2,53.2 176.1,53.6 176,53.9C175.8,54.2 175.6,54.5 175.3,54.8C175,55.1 174.7,55.3 174.3,55.4C173.9,55.5 173.6,55.6 173.2,55.6C172.4,55.6 171.7,55.3 171.2,54.7C170.6,54.3 170.4,53.6 170.4,52.8ZM175.5,77.6L171,77.6L171,58.8L175.5,58.8L175.5,77.6Z" style="fill:rgb(51,51,51);fill-rule:nonzero;"/>\n                        </g>\n                    </svg>\n                    </div>\n                    <div id="progress_bar"></div>\n                </div>\n            </div>\n        '),
        document.body.appendChild(n);
      var a = document.getElementById("progress_bar"),
        r =
          window.innerWidth ||
          document.documentElement.clientWidth ||
          document.body.clientWidth;
      (l.width = r / 3),
        (l.height = l.width),
        (e = l.getContext("2d")),
        (t = l.width / 10),
        (i = e.createLinearGradient(0, 0, l.width, 0)).addColorStop(
          "0",
          "#cce7ff"
        ),
        i.addColorStop("0.5", "#005095"),
        i.addColorStop("1", "#cce7ff"),
        (e.strokeStyle = i),
        a.appendChild(l);
    })(),
    n.on("preload:end", function () {
      n.off("preload:progress");
    }),
    n.on("preload:progress", function (n) {
      (n = Math.min(1, Math.max(0, n))),
        window &&
          window.famobi &&
          window.famobi.setPreloadProgress &&
          (window.famobi.setPreloadProgress(100 * n),
          1 === n && window.famobi.gameReady()),
        (function (n) {
          if (!e) return;
          o && clearInterval(o);
          let t = (n - s) / 10;
          o = setInterval(() => {
            s < n ? (s += t) : clearInterval(o);
            var a = 3.6 * s;
            e.clearRect(0, 0, l.width, l.height),
              e.beginPath(),
              (e.lineWidth = 10);
            var r = getCoordinate(0);
            e.moveTo(r.x, r.y), (e.strokeStyle = i);
            for (var d = 0; d < a; d++) {
              var C = getCoordinate(d);
              e.lineTo(C.x, C.y);
            }
            e.stroke(), e.beginPath(), (e.strokeStyle = "#c9c9c9");
            for (var m = a; m < 360; m++) {
              var p = getCoordinate(m);
              e.lineTo(p.x, p.y);
            }
            e.stroke();
          }, 50);
        })(100 * n);
    }),
    n.on("start", function () {
      var n = document.getElementById("application-splash-wrapper");
      n.parentElement.removeChild(n);
    });
});
if ("launch.playcanvas.com" === window.location.hostname) {
  window.famobi_config = {
    features: {
      highscores: 0,
      rewarded: 0,
      forced_mode: 0,
      skip_title: 0,
      external_start: 0,
      external_mute: 0,
      ads: 1,
    },
    game_i18n: { default: {} },
    game_info: {
      client_version: "0.10",
      api_version: "0.0",
      forced_mode: {
        state: {
          field_size_x: { min: 1, max: 15, type: "number" },
          field_size_y: { min: 1, max: 15, type: "number" },
          field_size_z: { min: 1, max: 15, type: "number" },
          win_row_length: { min: 2, max: 15, type: "number" },
        },
        override: {},
      },
      track_stats: {
        block_placed: {
          description: "Called every time a white block is placed.",
          params: { color: { type: "string", values: ["black", "white"] } },
        },
        row_length: {
          description: "Length of the users longest row",
          type: "number",
        },
      },
    },
  };
  document.body.innerHTML;
  let e = document.getElementsByTagName("script");
  console.log(e),
    (window.famobi_gameID = "{FAMOBI_GAMEID}"),
    (window.famobi_gameJS = [function () {}]),
    (window.famobi_pregameJS = window.famobi_pregameJS || []),
    window.famobi_pregameJS.push(
      new Promise(function (e, o) {
        window.famobi.config
          ? o("config already present")
          : window.addEventListener("famobiJsonLoaded", e);
      })
    );
  for (let o = 0, t = e.length; o < t; o++) {
    let t = e[o];
    t &&
      t.getAttribute("src") &&
      (window.famobi_gameJS.push(t.getAttribute("src")),
      console.log("removing script tag with src: ", t.getAttribute("src")),
      t.parentNode.removeChild(t));
  }
  console.log(famobi_gameJS),
    (function (e, o, t, n) {
      (t = e.createElement("script")),
        (n = e.getElementsByTagName("script")[0]),
        (t.src =
          "https://games.cdn.famobi.com/html5games/gameapi/v1.js?e=" +
          encodeURIComponent(e.location.href)),
        n.parentNode.insertBefore(t, n);
    })(document);
} else console.warn(window.location.hostname);
var FamobiSafeArea = pc.createScript("famobiSafeArea");
FamobiSafeArea.attributes.add("forceBodyBackgroundColor", {
  type: "boolean",
  default: !0,
  title: "Change <body> background",
  default: !0,
}),
  FamobiSafeArea.attributes.add("bodyBackgroundColor", {
    type: "rgba",
    title: "Body Background Color",
    description:
      "Background color of body element (where the banner should be displayed). Make sure the checkbox above is checked!",
    default: [0, 0, 0, 1],
  }),
  FamobiSafeArea.attributes.add("debugConfig", {
    type: "json",
    title: "Debug / Testing Mode",
    description:
      "Force safe areas to be applied to the UI. Useful testing layouts without a device.",
    schema: [
      { name: "enabled", type: "boolean", default: !1 },
      { name: "top", type: "number", default: 0 },
      { name: "bottom", type: "number", default: 0 },
      { name: "left", type: "number", default: 0 },
      { name: "right", type: "number", default: 0 },
    ],
  }),
  (FamobiSafeArea.prototype.initialize = function () {
    this.app.graphicsDevice.on("resizecanvas", this._onCanvasResize, this),
      this.on(
        "attr:debugConfig",
        function (e, t) {
          this._updateCanvasSizeAndPosition();
        },
        this
      ),
      this.on(
        "attr:bodyBackgroundColor",
        function (e, t) {
          this._backgroundColorUpdate();
        },
        this
      ),
      this.on(
        "destroy",
        function () {
          this.app.graphicsDevice.off(
            "resizecanvas",
            this._onCanvasResize,
            this
          );
        },
        this
      ),
      window.famobi &&
        "function" == typeof window.famobi.onOffsetChange &&
        window.famobi.onOffsetChange((e) => this._onCanvasResize()),
      window.visualViewport
        ? ((this.useVisualViewport = !0),
          window.visualViewport.addEventListener(
            "resize",
            this._onCanvasResize.bind(this)
          ))
        : ((this.useVisualViewport = !1),
          window.addEventListener(
            "resize",
            this._onCanvasResize.bind(this),
            !0
          )),
      this._onCanvasResize();
  }),
  (FamobiSafeArea.prototype._onCanvasResize = function () {
    this._updateCanvasSizeAndPosition(),
      (pc.platform.ios || pc.platform.mobile) &&
        setTimeout(() => this._updateCanvasSizeAndPosition(), 1500);
  }),
  (FamobiSafeArea.prototype._updateCanvasSizeAndPosition = function () {
    let e = 0,
      t = 0,
      i = 0,
      o = 0;
    if (this.debugConfig.enabled)
      (e = this.debugConfig.top),
        (t = this.debugConfig.bottom),
        (i = this.debugConfig.left),
        (o = this.debugConfig.right);
    else {
      if (!window.famobi || !window.famobi.getOffsets)
        return console.warn(
          "FamobiSafeArea: window.famobi.getOffsets is not defined!"
        );
      const a = window.famobi.getOffsets();
      (e = a.top), (t = a.bottom), (i = a.left), (o = a.right);
    }
    const a = window.innerHeight,
      n = window.innerWidth - i - o,
      s = a - e - t;
    this.app.setCanvasResolution(pc.RESOLUTION_FIXED, n, s),
      (this.app.graphicsDevice.canvas.style.width = n + "px"),
      (this.app.graphicsDevice.canvas.style.height = s + "px"),
      (this.app.graphicsDevice.canvas.style.left = i + "px"),
      (this.app.graphicsDevice.canvas.style.right = o + "px"),
      (this.app.graphicsDevice.canvas.style.top = e + "px"),
      (this.app.graphicsDevice.canvas.style.bottom = t + "px"),
      this.debugConfig.enabled &&
        console.log(
          `Canvas size set to ${n}x${s} (window ${window.innerWidth}x${window.innerHeight})`
        ),
      this.app.fire("famobi:resizeCanvas", n, s),
      this._backgroundColorUpdate();
  }),
  (FamobiSafeArea.prototype._backgroundColorUpdate = function () {
    if (!this.forceBodyBackgroundColor) return;
    const e = this.app.graphicsDevice.canvas.parentElement;
    e && (e.style.backgroundColor = this.bodyBackgroundColor.toString());
  }),
  (FamobiSafeArea.prototype.update = function (e) {}),
  (pc.CameraComponent.prototype.screenToWorld = function (e, t, i, o) {
    const a = this.system.app.graphicsDevice,
      n = a.width / a.maxPixelRatio,
      s = a.height / a.maxPixelRatio;
    return this._camera.screenToWorld(e, t, i, n, s, o);
  }),
  (pc.CameraComponent.prototype.worldToScreen = function (e, t) {
    const i = this.system.app.graphicsDevice,
      o = i.width / i.maxPixelRatio,
      a = i.height / i.maxPixelRatio;
    return this._camera.worldToScreen(e, o, a, t);
  });
