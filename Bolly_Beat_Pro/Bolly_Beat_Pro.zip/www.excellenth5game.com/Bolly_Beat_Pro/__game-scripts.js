var AsignaGlobal = pc.createScript("asignaGlobal");
AsignaGlobal.attributes.add("tipo", { type: "string", title: "tipo" }),
  (AsignaGlobal.prototype.initialize = function () {
    switch (this.tipo) {
      case "sonido":
        _sonidos = this.entity.sound;
        break;
      case "2dScreen":
        _2dScreen = this.entity;
        break;
      case "musica":
        (_musicas = this.entity.sound),
          (_sound = this.entity.sound),
          (_sound.slot("dummy").volume = 1e-4);
    }
  });
pc.extend(
  pc,
  (function () {
    var TweenManager = function (t) {
      (this._app = t), (this._tweens = []), (this._add = []);
    };
    TweenManager.prototype = {
      add: function (t) {
        return this._add.push(t), t;
      },
      update: function (t) {
        for (var i = 0, e = this._tweens.length; i < e; )
          this._tweens[i].update(t) ? i++ : (this._tweens.splice(i, 1), e--);
        if (this._add.length) {
          for (let t = 0; t < this._add.length; t++)
            this._tweens.indexOf(this._add[t]) > -1 ||
              this._tweens.push(this._add[t]);
          this._add.length = 0;
        }
      },
    };
    var Tween = function (t, i, e) {
        pc.events.attach(this),
          (this.manager = i),
          e && (this.entity = null),
          (this.time = 0),
          (this.complete = !1),
          (this.playing = !1),
          (this.stopped = !0),
          (this.pending = !1),
          (this.target = t),
          (this.duration = 0),
          (this._currentDelay = 0),
          (this.timeScale = 1),
          (this._reverse = !1),
          (this._delay = 0),
          (this._yoyo = !1),
          (this._count = 0),
          (this._numRepeats = 0),
          (this._repeatDelay = 0),
          (this._from = !1),
          (this._slerp = !1),
          (this._fromQuat = new pc.Quat()),
          (this._toQuat = new pc.Quat()),
          (this._quat = new pc.Quat()),
          (this.easing = pc.Linear),
          (this._sv = {}),
          (this._ev = {});
      },
      _parseProperties = function (t) {
        var i;
        return (
          t instanceof pc.Vec2
            ? (i = { x: t.x, y: t.y })
            : t instanceof pc.Vec3
            ? (i = { x: t.x, y: t.y, z: t.z })
            : t instanceof pc.Vec4 || t instanceof pc.Quat
            ? (i = { x: t.x, y: t.y, z: t.z, w: t.w })
            : t instanceof pc.Color
            ? ((i = { r: t.r, g: t.g, b: t.b }), void 0 !== t.a && (i.a = t.a))
            : (i = t),
          i
        );
      };
    Tween.prototype = {
      to: function (t, i, e, s, n, r) {
        return (
          (this._properties = _parseProperties(t)),
          (this.duration = i),
          e && (this.easing = e),
          s && this.delay(s),
          n && this.repeat(n),
          r && this.yoyo(r),
          this
        );
      },
      from: function (t, i, e, s, n, r) {
        return (
          (this._properties = _parseProperties(t)),
          (this.duration = i),
          e && (this.easing = e),
          s && this.delay(s),
          n && this.repeat(n),
          r && this.yoyo(r),
          (this._from = !0),
          this
        );
      },
      rotate: function (t, i, e, s, n, r) {
        return (
          (this._properties = _parseProperties(t)),
          (this.duration = i),
          e && (this.easing = e),
          s && this.delay(s),
          n && this.repeat(n),
          r && this.yoyo(r),
          (this._slerp = !0),
          this
        );
      },
      start: function () {
        var t, i, e, s;
        if (
          ((this.playing = !0),
          (this.complete = !1),
          (this.stopped = !1),
          (this._count = 0),
          (this.pending = this._delay > 0),
          this._reverse && !this.pending
            ? (this.time = this.duration)
            : (this.time = 0),
          this._from)
        ) {
          for (t in this._properties)
            this._properties.hasOwnProperty(t) &&
              ((this._sv[t] = this._properties[t]),
              (this._ev[t] = this.target[t]));
          this._slerp &&
            (this._toQuat.setFromEulerAngles(
              this.target.x,
              this.target.y,
              this.target.z
            ),
            (i =
              void 0 !== this._properties.x
                ? this._properties.x
                : this.target.x),
            (e =
              void 0 !== this._properties.y
                ? this._properties.y
                : this.target.y),
            (s =
              void 0 !== this._properties.z
                ? this._properties.z
                : this.target.z),
            this._fromQuat.setFromEulerAngles(i, e, s));
        } else {
          for (t in this._properties)
            this._properties.hasOwnProperty(t) &&
              ((this._sv[t] = this.target[t]),
              (this._ev[t] = this._properties[t]));
          this._slerp &&
            ((i =
              void 0 !== this._properties.x
                ? this._properties.x
                : this.target.x),
            (e =
              void 0 !== this._properties.y
                ? this._properties.y
                : this.target.y),
            (s =
              void 0 !== this._properties.z
                ? this._properties.z
                : this.target.z),
            void 0 !== this._properties.w
              ? (this._fromQuat.copy(this.target),
                this._toQuat.set(i, e, s, this._properties.w))
              : (this._fromQuat.setFromEulerAngles(
                  this.target.x,
                  this.target.y,
                  this.target.z
                ),
                this._toQuat.setFromEulerAngles(i, e, s)));
        }
        return (this._currentDelay = this._delay), this.manager.add(this), this;
      },
      pause: function () {
        this.playing = !1;
      },
      resume: function () {
        this.playing = !0;
      },
      stop: function () {
        (this.playing = !1), (this.stopped = !0);
      },
      delay: function (t) {
        return (this._delay = t), (this.pending = !0), this;
      },
      repeat: function (t, i) {
        return (
          (this._count = 0),
          (this._numRepeats = t),
          (this._repeatDelay = i || 0),
          this
        );
      },
      loop: function (t) {
        return (
          t
            ? ((this._count = 0), (this._numRepeats = 1 / 0))
            : (this._numRepeats = 0),
          this
        );
      },
      yoyo: function (t) {
        return (this._yoyo = t), this;
      },
      reverse: function () {
        return (this._reverse = !this._reverse), this;
      },
      chain: function () {
        for (var t = arguments.length; t--; )
          t > 0
            ? (arguments[t - 1]._chained = arguments[t])
            : (this._chained = arguments[t]);
        return this;
      },
      onUpdate: function (t) {
        return this.on("update", t), this;
      },
      onComplete: function (t) {
        return this.on("complete", t), this;
      },
      onLoop: function (t) {
        return this.on("loop", t), this;
      },
      update: function (t) {
        if (this.stopped) return !1;
        if (!this.playing) return !0;
        if (
          (!this._reverse || this.pending
            ? (this.time += t * this.timeScale)
            : (this.time -= t * this.timeScale),
          this.pending)
        ) {
          if (!(this.time > this._currentDelay)) return !0;
          this._reverse
            ? (this.time = this.duration - (this.time - this._currentDelay))
            : (this.time -= this._currentDelay),
            (this.pending = !1);
        }
        var i = 0;
        ((!this._reverse && this.time > this.duration) ||
          (this._reverse && this.time < 0)) &&
          (this._count++,
          (this.complete = !0),
          (this.playing = !1),
          this._reverse
            ? ((i = this.duration - this.time), (this.time = 0))
            : ((i = this.time - this.duration), (this.time = this.duration)));
        var e,
          s,
          n = 0 === this.duration ? 1 : this.time / this.duration,
          r = this.easing(n);
        for (var h in this._properties)
          this._properties.hasOwnProperty(h) &&
            ((e = this._sv[h]),
            (s = this._ev[h]),
            (this.target[h] = e + (s - e) * r));
        if (
          (this._slerp && this._quat.slerp(this._fromQuat, this._toQuat, r),
          this.entity &&
            (this.entity._dirtifyLocal(),
            this.element &&
              this.entity.element &&
              (this.entity.element[this.element] = this.target),
            this._slerp && this.entity.setLocalRotation(this._quat)),
          this.fire("update", t),
          this.complete)
        ) {
          var a = this._repeat(i);
          return (
            a
              ? this.fire("loop")
              : (this.fire("complete", i),
                this.entity && this.entity.off("destroy", this.stop, this),
                this._chained && this._chained.start()),
            a
          );
        }
        return !0;
      },
      _repeat: function (t) {
        if (this._count < this._numRepeats) {
          if (
            (this._reverse ? (this.time = this.duration - t) : (this.time = t),
            (this.complete = !1),
            (this.playing = !0),
            (this._currentDelay = this._repeatDelay),
            (this.pending = !0),
            this._yoyo)
          ) {
            for (var i in this._properties) {
              var e = this._sv[i];
              (this._sv[i] = this._ev[i]), (this._ev[i] = e);
            }
            this._slerp &&
              (this._quat.copy(this._fromQuat),
              this._fromQuat.copy(this._toQuat),
              this._toQuat.copy(this._quat));
          }
          return !0;
        }
        return !1;
      },
    };
    var BounceOut = function (t) {
        return t < 1 / 2.75
          ? 7.5625 * t * t
          : t < 2 / 2.75
          ? 7.5625 * (t -= 1.5 / 2.75) * t + 0.75
          : t < 2.5 / 2.75
          ? 7.5625 * (t -= 2.25 / 2.75) * t + 0.9375
          : 7.5625 * (t -= 2.625 / 2.75) * t + 0.984375;
      },
      BounceIn = function (t) {
        return 1 - BounceOut(1 - t);
      };
    return {
      TweenManager: TweenManager,
      Tween: Tween,
      Linear: function (t) {
        return t;
      },
      QuadraticIn: function (t) {
        return t * t;
      },
      QuadraticOut: function (t) {
        return t * (2 - t);
      },
      QuadraticInOut: function (t) {
        return (t *= 2) < 1 ? 0.5 * t * t : -0.5 * (--t * (t - 2) - 1);
      },
      CubicIn: function (t) {
        return t * t * t;
      },
      CubicOut: function (t) {
        return --t * t * t + 1;
      },
      CubicInOut: function (t) {
        return (t *= 2) < 1 ? 0.5 * t * t * t : 0.5 * ((t -= 2) * t * t + 2);
      },
      QuarticIn: function (t) {
        return t * t * t * t;
      },
      QuarticOut: function (t) {
        return 1 - --t * t * t * t;
      },
      QuarticInOut: function (t) {
        return (t *= 2) < 1
          ? 0.5 * t * t * t * t
          : -0.5 * ((t -= 2) * t * t * t - 2);
      },
      QuinticIn: function (t) {
        return t * t * t * t * t;
      },
      QuinticOut: function (t) {
        return --t * t * t * t * t + 1;
      },
      QuinticInOut: function (t) {
        return (t *= 2) < 1
          ? 0.5 * t * t * t * t * t
          : 0.5 * ((t -= 2) * t * t * t * t + 2);
      },
      SineIn: function (t) {
        return 0 === t ? 0 : 1 === t ? 1 : 1 - Math.cos((t * Math.PI) / 2);
      },
      SineOut: function (t) {
        return 0 === t ? 0 : 1 === t ? 1 : Math.sin((t * Math.PI) / 2);
      },
      SineInOut: function (t) {
        return 0 === t ? 0 : 1 === t ? 1 : 0.5 * (1 - Math.cos(Math.PI * t));
      },
      ExponentialIn: function (t) {
        return 0 === t ? 0 : Math.pow(1024, t - 1);
      },
      ExponentialOut: function (t) {
        return 1 === t ? 1 : 1 - Math.pow(2, -10 * t);
      },
      ExponentialInOut: function (t) {
        return 0 === t
          ? 0
          : 1 === t
          ? 1
          : (t *= 2) < 1
          ? 0.5 * Math.pow(1024, t - 1)
          : 0.5 * (2 - Math.pow(2, -10 * (t - 1)));
      },
      CircularIn: function (t) {
        return 1 - Math.sqrt(1 - t * t);
      },
      CircularOut: function (t) {
        return Math.sqrt(1 - --t * t);
      },
      CircularInOut: function (t) {
        return (t *= 2) < 1
          ? -0.5 * (Math.sqrt(1 - t * t) - 1)
          : 0.5 * (Math.sqrt(1 - (t -= 2) * t) + 1);
      },
      BackIn: function (t) {
        var i = 1.70158;
        return t * t * ((i + 1) * t - i);
      },
      BackOut: function (t) {
        var i = 1.70158;
        return --t * t * ((i + 1) * t + i) + 1;
      },
      BackInOut: function (t) {
        var i = 2.5949095;
        return (t *= 2) < 1
          ? t * t * ((i + 1) * t - i) * 0.5
          : 0.5 * ((t -= 2) * t * ((i + 1) * t + i) + 2);
      },
      BounceIn: BounceIn,
      BounceOut: BounceOut,
      BounceInOut: function (t) {
        return t < 0.5
          ? 0.5 * BounceIn(2 * t)
          : 0.5 * BounceOut(2 * t - 1) + 0.5;
      },
      ElasticIn: function (t) {
        var i,
          e = 0.1;
        return 0 === t
          ? 0
          : 1 === t
          ? 1
          : (!e || e < 1
              ? ((e = 1), (i = 0.1))
              : (i = (0.4 * Math.asin(1 / e)) / (2 * Math.PI)),
            -e *
              Math.pow(2, 10 * (t -= 1)) *
              Math.sin(((t - i) * (2 * Math.PI)) / 0.4));
      },
      ElasticOut: function (t) {
        var i,
          e = 0.1;
        return 0 === t
          ? 0
          : 1 === t
          ? 1
          : (!e || e < 1
              ? ((e = 1), (i = 0.1))
              : (i = (0.4 * Math.asin(1 / e)) / (2 * Math.PI)),
            e *
              Math.pow(2, -10 * t) *
              Math.sin(((t - i) * (2 * Math.PI)) / 0.4) +
              1);
      },
      ElasticInOut: function (t) {
        var i,
          e = 0.1,
          s = 0.4;
        return 0 === t
          ? 0
          : 1 === t
          ? 1
          : (!e || e < 1
              ? ((e = 1), (i = 0.1))
              : (i = (s * Math.asin(1 / e)) / (2 * Math.PI)),
            (t *= 2) < 1
              ? e *
                Math.pow(2, 10 * (t -= 1)) *
                Math.sin(((t - i) * (2 * Math.PI)) / s) *
                -0.5
              : e *
                  Math.pow(2, -10 * (t -= 1)) *
                  Math.sin(((t - i) * (2 * Math.PI)) / s) *
                  0.5 +
                1);
      },
    };
  })()
),
  (function () {
    (pc.AppBase.prototype.addTweenManager = function () {
      (this._tweenManager = new pc.TweenManager(this)),
        this.on("update", function (t) {
          this._tweenManager.update(t);
        });
    }),
      (pc.AppBase.prototype.tween = function (t) {
        return new pc.Tween(t, this._tweenManager);
      }),
      (pc.Entity.prototype.tween = function (t, i) {
        var e = this._app.tween(t);
        return (
          (e.entity = this),
          this.once("destroy", e.stop, e),
          i && i.element && (e.element = i.element),
          e
        );
      });
    var t = pc.AppBase.getApplication();
    t && t.addTweenManager();
  })();
var _sound,
  isMobile = {
    Android: function () {
      return navigator.userAgent.match(/Android/i);
    },
    BlackBerry: function () {
      return navigator.userAgent.match(/BlackBerry/i);
    },
    iOS: function () {
      return navigator.userAgent.match(/iPhone|iPad|iPod/i);
    },
    Opera: function () {
      return navigator.userAgent.match(/Opera Mini/i);
    },
    Windows: function () {
      return (
        navigator.userAgent.match(/IEMobile/i) ||
        navigator.userAgent.match(/WPDesktop/i)
      );
    },
    any: function () {
      return (
        isMobile.Android() ||
        isMobile.BlackBerry() ||
        isMobile.iOS() ||
        isMobile.Opera() ||
        isMobile.Windows() ||
        (window.devicePixelRatio >= 2 && navigator.maxTouchPoints > 0)
      );
    },
  },
  bajarVelocidadChico = !1,
  bajarVelocidadMedio = !1,
  bajarVelocidadGrande = !1,
  esTunel = !1,
  noLimitar = !1,
  mute = 0,
  _app = null,
  tutorialEnabled = !0,
  currentMusic = null,
  currentMusicVolume = [],
  tutorialMostrado = 0,
  gemas = 0,
  musicaAsset = null,
  musicaAssetx2 = null,
  musicaAssetx3 = null,
  musicaJugada = -1;
function RayCast(e, n, a) {
  var r = n.screenToWorld(e.x, e.y, n.nearClip),
    s = n.screenToWorld(e.x, e.y, n.farClip),
    o = a.systems.rigidbody.raycastFirst(r, s);
  return o ? o.entity : null;
}
function GetMouseGlobalPosition(e, n, a) {
  var r = n.screenToWorld(e.x, e.y, n.nearClip),
    s = n.screenToWorld(e.x, e.y, n.farClip),
    o = a.systems.rigidbody.raycastFirst(r, s);
  return o || null;
}
function GetMouseFloorPosition(e, n, a) {
  var r = n.screenToWorld(e.x, e.y, n.nearClip),
    s = n.screenToWorld(e.x, e.y, n.farClip);
  return (
    (result = a.systems.rigidbody.raycastFiltered(
      r,
      s,
      PhysicsFilter.A,
      PhysicsFilter.A
    )),
    result || null
  );
}
function reproduceAnim(e, n, a, r, s, o) {
  null != a && (e.animation.speed = a);
  var t = e.animation.assets[n],
    u = e.animation.animationsIndex[t];
  e.animation.play(u),
    (e.animation.loop = !!o),
    r &&
      setTimeout(function () {
        e.enabled = !1;
      }, s);
}
function reproduceParticulas(e, n) {
  var a = e;
  (a.enabled = !0),
    a.particlesystem.reset(),
    a.particlesystem.play(),
    setTimeout(function () {
      a.enabled = !1;
    }, n);
}
function addEventFunction(e, n, a, r) {
  var s = [];
  switch ((null != e.element && (e = e.element), a)) {
    case 1:
      (s[0] = "touchstart"), (s[1] = "mousedown");
      break;
    case 2:
      (s[0] = "touchend"), (s[1] = "mouseup");
      break;
    case 3:
      (s[0] = "touchmove"), (s[1] = "mousemove");
  }
  n
    ? isMobile.any()
      ? e.on(s[0], r)
      : e.on(s[1], r)
    : isMobile.any()
    ? e.off(s[0], r)
    : e.off(s[1], r);
}
function setTexto(e, n) {
  e.text = n;
}
function guarda_vars(e, n, a, r, s, o, t, u) {
  a
    ? 1 == r
      ? (e[s] = n)
      : 2 == r
      ? (e[s][o] = n)
      : 3 == r
      ? (e[s][o][t] = n)
      : 4 == r && (e[s][o][t][u] = n)
    : (e = n);
}
function cargaTextura(e, n, a) {
  _app.loader.getHandler("texture").crossOrigin = "anonymous";
  var r = new pc.Asset("foto" + Math.round(1e3 * Math.random()), "texture", {
    url: e,
  });
  _app.assets.add(r),
    _app.assets.load(r),
    r.on("load", function (e) {
      if (a)
        for (var r = n.model.meshInstances, s = 0; s < r.length; ++s) {
          var o = r[s];
          (o.material.diffuseMap = e.resource),
            (o.material.emissiveMap = e.resource),
            o.material.update();
        }
      else (n.element.textureAsset = e), (n.enabled = !0);
    });
}
function getTexture(e) {
  var n = new pc.gfx.Texture(_app.graphicsDevice),
    a = new Image();
  return (
    (a.onload = function () {
      (n.minFilter = pc.gfx.FILTER_LINEAR),
        (n.magFilter = pc.gfx.FILTER_LINEAR),
        (n.addressU = pc.ADDRESS_REPEAT),
        (n.addressV = pc.ADDRESS_REPEAT),
        n.setSource(a);
    }),
    (a.src = e),
    n
  );
}
function cambiaTextura3D(e, n) {
  for (var a = n.model.meshInstances, r = 0; r < a.length; ++r) {
    var s = a[r];
    (s.material.diffuseMap = e),
      (s.material.emissiveMap = e),
      s.material.update();
  }
}
function cargaMusica(e, n, a) {
  if (null == musicaAsset || musicaJugada != n)
    if (
      (null != musicaAsset &&
        (musicaAsset.unload(),
        (musicaAsset = null),
        (musicaJugada = -1),
        null != musicaAssetx2 &&
          (musicaAssetx2.unload(), (musicaAssetx2 = null)),
        null != musicaAssetx3 &&
          (musicaAssetx3.unload(), (musicaAssetx3 = null))),
      n <= 4)
    )
      (e = e + "song" + n + ".mp3"),
        console.log("intentando cargar URL " + e),
        _app.assets.loadFromUrl(e, "audio", function (e, r) {
          console.log("cargado!"),
            (musicaAsset = r),
            (_musicas.slot("song" + n).asset = r),
            (musicaJugada = n),
            null != a && a();
        });
    else {
      var r = 0,
        s = e + "song" + n + ".mp3";
      console.log("intentando cargar URL " + s),
        _app.assets.loadFromUrl(s, "audio", function (e, s) {
          (musicaAsset = s),
            (_musicas.slot("song" + n).asset = s),
            (musicaJugada = n),
            (r += 1),
            console.log("cargada la muscia " + s.name),
            3 == r && null != a && a();
        });
      var o = e + "song" + (n - 4) + ".mp3";
      console.log("intentando cargar URL " + o),
        _app.assets.loadFromUrl(o, "audio", function (e, s) {
          (musicaAsset = s),
            (_musicas.slot("song" + (n - 4)).asset = s),
            (r += 1),
            console.log("cargada la muscia " + s.name),
            3 == r && null != a && a();
        });
      var t = e + "song" + (n + 4) + ".mp3";
      console.log("intentando cargar URL " + t),
        _app.assets.loadFromUrl(t, "audio", function (e, s) {
          (musicaAsset = s),
            (_musicas.slot("song" + (n + 4)).asset = s),
            (r += 1),
            console.log("cargada la muscia " + s.name),
            3 == r && null != a && a();
        });
    }
  else a();
}
function playSound(e, n) {
  n
    ? ((currentMusic = e), _sound.play(e), 1 == mute && muteMusic())
    : 0 == mute &&
      (("apuntar" == e && _sound.slot(e).isPlaying) || _sound.play(e));
}
function muteMusic() {
  null != currentMusic &&
    "" != currentMusic &&
    (console.log("le pondre volumen 0 al slot " + currentMusic),
    (_sound.slot(currentMusic).volume = 1e-8));
}
function unmuteMusic() {
  null != currentMusic &&
    "" != currentMusic &&
    (console.log(currentMusic),
    (_sound.slot(currentMusic).volume = currentMusicVolume[currentMusic]),
    console.log(
      "le pondre volumen " +
        currentMusicVolume[currentMusic] +
        " al slot " +
        currentMusic
    ));
}
function mutear(e, n, a) {
  a || (mute = e),
    console.log("mutee esto?!?! " + e),
    0 == e
      ? (a || unmuteMusic(),
        null != n && n.script.animaMsg.clickBoton(null, !1, 0))
      : (a || muteMusic(),
        null != n && n.script.animaMsg.clickBoton(null, !1, 1));
}
function guardaVars(e, n) {
  if (((n = "google_tileHop_V2" + n), !supports_html5_storage())) return !1;
  enGoogle
    ? GameSnacks.storage.setItem(n, e + "")
    : localStorage.setItem(n, e + "");
}
function cargaVars(e) {
  return (
    (e = "google_tileHop_V2" + e),
    supports_html5_storage()
      ? enGoogle
        ? GameSnacks.storage.getItem(e)
        : localStorage.getItem(e)
      : 0
  );
}
function existeVars(e) {
  if (((e = "google_tileHop_V2" + e), !supports_html5_storage())) return !1;
  if (!enGoogle) return localStorage.hasOwnProperty(e);
  var n = GameSnacks.storage.getItem(e);
  return null != n && null != n && "" != n;
}
function getAllVars() {
  for (var e = 0; e < pelotasInfo.length; e++)
    existeVars("pelotasInfo_" + (e + 1) + "_unlock") &&
      (pelotasInfo[e][0] = parseInt(
        cargaVars("pelotasInfo_" + (e + 1) + "_unlock")
      ));
  for (e = 0; e < arrayCanciones.length; e++)
    existeVars("arrayCanciones_" + (e + 1) + "_unlock") &&
      (arrayCanciones[e][4] = parseInt(
        cargaVars("arrayCanciones_" + (e + 1) + "_unlock")
      ));
  for (e = 0; e < arrayCanciones.length; e++)
    existeVars("arrayCanciones_" + (e + 1) + "_score") &&
      (arrayCanciones[e][3] = parseInt(
        cargaVars("arrayCanciones_" + (e + 1) + "_score")
      ));
  existeVars("currentSkin")
    ? ((currentSkin = parseInt(cargaVars("currentSkin"))), _menu.setSkin())
    : ((currentSkin = 0), _menu.setSkin()),
    existeVars("currentCancion")
      ? (currentCancion = parseInt(cargaVars("currentCancion")))
      : (currentCancion = 0),
    (tutorialMostrado = 1),
    (gemas = existeVars("gemas") ? parseInt(cargaVars("gemas")) : 0);
}
function shake(e) {
  window.navigator && window.navigator.vibrate && navigator.vibrate(e);
}
function supports_html5_storage() {
  if (enGoogle) return !0;
  try {
    return "localStorage" in window && null !== window.localStorage;
  } catch (e) {
    return !1;
  }
}
(currentMusicVolume.prev1 = 1),
  (currentMusicVolume.prev2 = 1),
  (currentMusicVolume.prev3 = 1),
  (currentMusicVolume.prev4 = 1),
  (currentMusicVolume.prev5 = 1),
  (currentMusicVolume.prev6 = 1),
  (currentMusicVolume.prev7 = 1),
  (currentMusicVolume.prev8 = 1),
  (currentMusicVolume.song1 = 0.7),
  (currentMusicVolume.song2 = 0.7),
  (currentMusicVolume.song3 = 0.7),
  (currentMusicVolume.song4 = 0.7),
  (currentMusicVolume.song5 = 0.7),
  (currentMusicVolume.song6 = 0.7),
  (currentMusicVolume.song7 = 0.7),
  (currentMusicVolume.song8 = 0.7),
  (currentMusicVolume.song9 = 0.7),
  (currentMusicVolume.song10 = 0.7),
  (currentMusicVolume.song11 = 0.7),
  (currentMusicVolume.song12 = 0.7);
var AnimaMsg = pc.createScript("animaMsg");
AnimaMsg.attributes.add("destinox", {
  type: "number",
  default: 0,
  title: "destinox",
}),
  AnimaMsg.attributes.add("destinoy", {
    type: "number",
    default: 0,
    title: "destinoy",
  }),
  AnimaMsg.attributes.add("destinoz", {
    type: "number",
    default: 0,
    title: "destinoz",
  }),
  AnimaMsg.attributes.add("tiempo", {
    type: "number",
    default: 0.6,
    title: "tiempo",
  }),
  AnimaMsg.attributes.add("delaySaca", {
    type: "number",
    default: 1.8,
    title: "delaySaca",
  }),
  AnimaMsg.attributes.add("traducir", {
    type: "number",
    default: 1,
    title: "traducir",
  }),
  AnimaMsg.attributes.add("boton", {
    type: "asset",
    assetType: "texture",
    array: !0,
    title: "boton",
  }),
  AnimaMsg.attributes.add("tipoTween", {
    type: "string",
    default: "BounceOut",
    title: "tipoTween",
  }),
  (AnimaMsg.prototype.initialize = function () {
    (this.tween = null), (this.mc = this.entity);
    var t = this.entity.getLocalPosition();
    switch (
      ((this.origen = new pc.Vec3(t.x, t.y, t.z)),
      (this.destino = new pc.Vec3(this.destinox, this.destinoy, this.destinoz)),
      (this.terminado = !1),
      (this.enReproduccion = !1),
      this.tipoTween)
    ) {
      case "BounceOut":
        this.tipoTween = pc.BounceOut;
        break;
      case "SineIn":
        this.tipoTween = pc.SineIn;
        break;
      case "SineOut":
        this.tipoTween = pc.SineOut;
        break;
      case "SineInOut":
        this.tipoTween = pc.SineInOut;
    }
  }),
  (AnimaMsg.prototype.clickBoton = function (t, e, i) {
    null != e
      ? (this.entity.element.texture = this.boton[i].resource)
      : ((this.entity.element.texture = this.boton[1].resource),
        setTimeout(this.restauraBoton.bind(this, t), 180));
  }),
  (AnimaMsg.prototype.restauraBoton = function (t) {
    (this.entity.element.texture = this.boton[0].resource), t();
  }),
  (AnimaMsg.prototype.pone1Vez = function (t) {
    this.entity.setLocalScale(1, 0, 1),
      (this.entity.enabled = !0),
      (this.tween = this.entity
        .tween(this.entity.getLocalScale())
        .to(new pc.Vec3(1, 1, 1), this.tiempo, this.tipoTween)),
      null != t &&
        this.tween.onComplete(() => {
          t();
        }),
      this.tween.start();
  }),
  (AnimaMsg.prototype.pone1VezMSG = function (t) {
    this.entity.setLocalScale(0.15, 0, 0.1),
      (this.entity.enabled = !0),
      (this.tween = this.entity
        .tween(this.entity.getLocalScale())
        .to(new pc.Vec3(0.15, 0.1, 0.1), this.tiempo, this.tipoTween)),
      null != t &&
        this.tween.onComplete(() => {
          t();
        }),
      this.tween.start();
  }),
  (AnimaMsg.prototype.pone = function (t) {
    this.entity.setLocalScale(1, 0, 1),
      (this.tween = this.entity
        .tween(this.entity.getLocalScale())
        .to(new pc.Vec3(1, 1, 1), this.tiempo, this.tipoTween)
        .onComplete(() => {
          this.saca(t);
        })),
      this.tween.start();
  }),
  (AnimaMsg.prototype.saca = function (t) {
    (this.tween = this.entity
      .tween(this.entity.getLocalScale())
      .to(new pc.Vec3(1, 0, 1), this.tiempo - 0.1, this.tipoTween)),
      null != t &&
        this.tween.onComplete(() => {
          t();
        }),
      this.tween.delay(this.delaySaca),
      this.tween.start();
  }),
  (AnimaMsg.prototype.poneMueve = function (t, e) {
    if (null != this.origen) {
      var i = this.tiempo;
      null != e && (i = e),
        this.entity.setLocalPosition(
          this.origen.x,
          this.origen.y,
          this.origen.z
        );
      var n = this.entity.getLocalPosition(),
        s = new pc.Vec3(this.destinox, this.destinoy, this.destinoz),
        o = new pc.Vec3(n.x + s.x, n.y + s.y, n.z + s.z);
      this.entity.setLocalPosition(o.x, o.y, o.z),
        (this.entity.enabled = !0),
        (n = this.entity.getLocalPosition()),
        (this.tween = this.mc.tween(n).to(this.origen, i, this.tipoTween)),
        this.tween.onComplete(() => {
          this.terminaPone(t);
        }),
        this.tween.start();
    } else
      setTimeout(
        function () {
          (this.entity.enabled = !0), this.poneMueve();
        }.bind(this),
        16
      );
  }),
  (AnimaMsg.prototype.sacaMueveP = function (t, e, i) {
    var n = this.tiempo;
    null != i && (n = i),
      this.entity.setLocalPosition(this.origen.x, this.origen.y, this.origen.z);
    var s = this.entity.getLocalPosition(),
      o = new pc.Vec3(this.destinox, this.destinoy, this.destinoz);
    (o = new pc.Vec3(s.x + o.x, s.y + o.y, s.z + o.z)),
      (this.entity.enabled = !0),
      (this.tween = this.mc.tween(s).to(o, n, this.tipoTween)),
      this.tween.onComplete(() => {
        this.terminaSaca(t, e);
      }),
      this.tween.start();
  }),
  (AnimaMsg.prototype.terminaPone = function (t) {
    null != t && t();
  }),
  (AnimaMsg.prototype.terminaSaca = function (t, e) {
    t && (this.entity.enabled = !1),
      null != e && e(),
      (this.terminado = !0),
      (this.enReproduccion = !1);
  }),
  (AnimaMsg.prototype.poneYSaca = function () {
    (this.terminado = !1),
      (this.enReproduccion = !0),
      this.poneMueve(
        function () {
          setTimeout(
            function () {
              this.sacaMueveP(!1, null);
            }.bind(this),
            1e3 * this.delaySaca
          );
        }.bind(this)
      );
  }),
  (AnimaMsg.prototype.mueve = function (t) {
    (this.tween = this.entity
      .tween(this.entity.getLocalPosition())
      .to(this.destino, this.tiempo, this.tipoTween)
      .onComplete(() => {
        this.sacaMueve(t);
      })),
      this.tween.start();
  }),
  (AnimaMsg.prototype.sacaMueve = function (t) {
    null != t && t(),
      (this.tween = this.entity
        .tween(this.entity.getLocalPosition())
        .to(this.origen, this.tiempo - 0.1, this.tipoTween)),
      this.tween.delay(this.delaySaca),
      this.tween.start();
  }),
  (AnimaMsg.prototype.animaMano = function (t) {
    var e = this.tiempo,
      i = this.entity.getLocalPosition();
    if (0 == t) var n = new pc.Vec3(i.x + this.destinox, i.y, i.z);
    else if (1 == t) {
      n = new pc.Vec3(i.x - 2 * this.destinox, i.y, i.z);
      e *= 2;
    } else if (2 == t) {
      n = new pc.Vec3(i.x + 2 * this.destinox, i.y, i.z);
      e *= 2;
    }
    3 == (t += 1) && (t = 1),
      (this.entity.enabled = !0),
      (this.tween = this.mc.tween(i).to(n, e, this.tipoTween)),
      this.tween.onComplete(() => {
        this.animaMano(t);
      }),
      this.tween.start();
  }),
  (AnimaMsg.prototype.detieneMano = function (t) {
    null != this.tween && this.tween.stop();
  }),
  (AnimaMsg.prototype.traduce = function (t, e) {
    var i = (x = window.navigator.language || navigator.browserLanguage);
    t *= idiomas.length;
    var n = 0;
    if (
      (lenguajeManual
        ? (n = lenguajeEl)
        : -1 !== i.indexOf("de")
        ? (n = 1)
        : -1 !== i.indexOf("nl") && (n = 2),
      !0 === e)
    )
      for (var s = this.entity.model.meshInstances, o = 0; o < s.length; ++o) {
        var a = s[o];
        (a.material.diffuseMap = this.boton[t + n].resource),
          (a.material.opacityMap = this.boton[t + n].resource),
          a.material.update();
      }
    else this.entity.element.texture = this.boton[t + n].resource;
  });
var AnimaTexturas = pc.createScript("animaTexturas");
AnimaTexturas.attributes.add("texturas", {
  type: "asset",
  assetType: "texture",
  array: !0,
  title: "texturas",
}),
  AnimaTexturas.attributes.add("loop", {
    type: "number",
    default: 0,
    title: "loop",
  }),
  AnimaTexturas.attributes.add("autoAnim", {
    type: "number",
    default: 0,
    title: "autoAnim",
  }),
  AnimaTexturas.attributes.add("texture3D", {
    type: "number",
    default: 0,
    title: "texture3D",
  }),
  AnimaTexturas.attributes.add("frames", {
    type: "number",
    default: 60,
    title: "frames",
  }),
  (AnimaTexturas.prototype.initialize = function () {
    this.entity;
    var a = [
      this.entity,
      this.texturas,
      0,
      this.texturas.length,
      !1,
      0,
      0,
      0,
      !1,
    ];
    (this.cont = 0),
      (this.arrayAnimaciones = []),
      (this.arrayAnimaciones[0] = a),
      (this.callBack = null),
      1 == this.autoAnim &&
        (1 == this.loop && (this.arrayAnimaciones[0][8] = !0),
        (this.arrayAnimaciones[0][4] = !0));
  }),
  (AnimaTexturas.prototype.inicioAnim = function (a, i, t) {
    (this.callBack = a), (this.cont = 0);
    var r = [
      this.entity,
      this.texturas,
      0,
      this.texturas.length,
      !1,
      0,
      0,
      0,
      !1,
    ];
    if (((this.cont = 0), null != i && null != t))
      (this.arrayAnimaciones[0][2] = i), (this.arrayAnimaciones[0][3] = t);
    else {
      r = [
        this.entity,
        this.texturas,
        0,
        this.texturas.length,
        !1,
        0,
        0,
        0,
        !1,
      ];
      (this.arrayAnimaciones = []), (this.arrayAnimaciones[0] = r);
    }
    (this.cont = 0),
      0 == this.texture3D
        ? (this.entity.element.texture =
            this.texturas[this.arrayAnimaciones[0][2]].resource)
        : this.cambiaTextura3D(
            this.texturas[this.arrayAnimaciones[0][2]].resource
          ),
      (this.arrayAnimaciones[0][4] = !0);
  }),
  (AnimaTexturas.prototype.stopAnim = function () {
    this.arrayAnimaciones[0][4] = !1;
  }),
  (AnimaTexturas.prototype.update = function (a) {
    var i = a,
      t = 1 / i;
    this.cont = this.cont + i;
    var r = t / this.frames;
    if (((r /= t), this.cont >= r)) {
      this.cont = 0;
      for (var s = 0; s < this.arrayAnimaciones.length; s++)
        if (1 == this.arrayAnimaciones[s][4]) {
          var e;
          if (0 == this.arrayAnimaciones[s][7])
            0 == (e = this.arrayAnimaciones[s][5]) &&
              (e = this.arrayAnimaciones[s][2]),
              0 == this.texture3D
                ? (this.arrayAnimaciones[s][0].element.texture =
                    this.arrayAnimaciones[s][1][e].resource)
                : this.cambiaTextura3D(this.arrayAnimaciones[s][1][e].resource),
              (this.arrayAnimaciones[s][5] = this.arrayAnimaciones[s][5] + 1),
              (e = this.arrayAnimaciones[s][5]) ==
                this.arrayAnimaciones[s][3] &&
                (0 == this.arrayAnimaciones[s][6]
                  ? this.arrayAnimaciones[s][8]
                    ? (this.arrayAnimaciones[s][5] = 1)
                    : ((this.arrayAnimaciones[s][4] = !1),
                      (this.arrayAnimaciones[s][5] = 0),
                      null != this.callBack && this.callBack())
                  : 2 == this.arrayAnimaciones[s][6] &&
                    (this.arrayAnimaciones[s][7] = 1));
          if (1 == this.arrayAnimaciones[s][7])
            (e = this.arrayAnimaciones[s][5]) == this.arrayAnimaciones[s][3] &&
              ((e = this.arrayAnimaciones[s][3] - 2),
              (this.arrayAnimaciones[s][5] = e)),
              0 == this.texture3D
                ? (this.arrayAnimaciones[s][0].element.texture =
                    this.arrayAnimaciones[s][1][e].resource)
                : this.cambiaTextura3D(this.arrayAnimaciones[s][1][e].resource),
              (this.arrayAnimaciones[s][5] = this.arrayAnimaciones[s][5] - 1),
              (e = this.arrayAnimaciones[s][5]) ==
                this.arrayAnimaciones[s][2] - 1 &&
                ((this.arrayAnimaciones[s][4] = !1),
                (this.arrayAnimaciones[s][5] = 0),
                2 == this.arrayAnimaciones[s][6] &&
                  (this.arrayAnimaciones[s][7] = 0));
        }
    }
  }),
  (AnimaTexturas.prototype.cambiaTextura3D = function (a) {
    for (var i = this.entity.model.meshInstances, t = 0; t < i.length; ++t) {
      var r = i[t];
      (r.material.diffuseMap = a),
        (r.material.opacityMap = a),
        r.material.update();
    }
  });
var AnimaTextoMsg = pc.createScript("animaTextoMsg");
AnimaTextoMsg.attributes.add("destinox", {
  type: "number",
  default: 0,
  title: "destinox",
}),
  AnimaTextoMsg.attributes.add("destinoy", {
    type: "number",
    default: 0,
    title: "destinoy",
  }),
  AnimaTextoMsg.attributes.add("destinoz", {
    type: "number",
    default: 0,
    title: "destinoz",
  }),
  AnimaTextoMsg.attributes.add("tiempo", {
    type: "number",
    default: 0.6,
    title: "tiempo",
  }),
  AnimaTextoMsg.attributes.add("esElement", {
    type: "number",
    default: 0,
    title: "esElement",
  }),
  AnimaTextoMsg.attributes.add("delaySaca", {
    type: "number",
    default: 1.8,
    title: "delaySaca",
  }),
  AnimaTextoMsg.attributes.add("boton", {
    type: "string",
    array: !0,
    title: "boton",
  }),
  AnimaTextoMsg.attributes.add("tipoTween", {
    type: "string",
    default: "BounceOut",
    title: "tipoTween",
  }),
  (AnimaTextoMsg.prototype.elijeTween = function (t) {
    switch (t) {
      case "BounceOut":
        t = pc.BounceOut;
        break;
      case "SineIn":
        t = pc.SineIn;
        break;
      case "SineOut":
        t = pc.SineOut;
        break;
      case "SineInOut":
        t = pc.SineInOut;
    }
    return t;
  }),
  (AnimaTextoMsg.prototype.initialize = function () {
    (this.mc = this.entity), (this.tween = null);
    var t = this.entity.getLocalPosition();
    (this.origen = new pc.Vec3(t.x, t.y, t.z)),
      (this.tipoTween = this.elijeTween(this.tipoTween)),
      (this.entity.enabled = !1);
  }),
  (AnimaTextoMsg.prototype.clickBoton = function (t, e, i) {
    null != e
      ? null != this.boton &&
        null != this.boton[i] &&
        (this.entity.element.text = this.boton[i])
      : this.boton.length > 0 &&
        null != this.boton[1] &&
        ((this.entity.element.text = this.boton[1]),
        setTimeout(this.restauraBoton.bind(this, t), 180));
  }),
  (AnimaTextoMsg.prototype.restauraBoton = function (t) {
    null != this.boton[0] && ((this.entity.element.text = this.boton[0]), t());
  }),
  (AnimaTextoMsg.prototype.pone = function (t, e) {
    var i = this.tiempo;
    null != e && (i = e),
      this.entity.setLocalPosition(this.origen.x, this.origen.y, this.origen.z);
    var n = this.entity.getLocalPosition(),
      s = new pc.Vec3(this.destinox, this.destinoy, this.destinoz),
      o = new pc.Vec3(n.x + s.x, n.y + s.y, n.z + s.z);
    this.entity.setLocalPosition(o.x, o.y, o.z),
      (this.entity.enabled = !0),
      (n = this.entity.getLocalPosition()),
      (this.tween = this.mc.tween(n).to(this.origen, i, this.tipoTween)),
      this.tween.onComplete(() => {
        this.terminaPone(t);
      }),
      this.tween.start();
  }),
  (AnimaTextoMsg.prototype.poneYalfa = function (t, e) {
    (this.entity.children[0].element.opacity = 1),
      (this.entity.children[1].element.opacity = 1),
      (this.entity.children[2].element.opacity = 1),
      (this.entity.children[3].element.opacity = 1),
      (this.entity.children[0].element.outlineThickness = 1),
      (this.entity.children[1].element.outlineThickness = 1),
      (this.entity.children[2].element.outlineThickness = 1),
      (this.entity.children[3].element.outlineThickness = 1);
    var i = this.tiempo;
    null != e && (i = e);
    var n = this.entity.getLocalPosition(),
      s = new pc.Vec3(this.destinox, this.destinoy, this.destinoz),
      o = new pc.Vec3(n.x + s.x, n.y + s.y, n.z + s.z);
    (this.entity.enabled = !0),
      (this.tween = this.mc.tween(n).to(o, i, this.tipoTween)),
      this.tween.onComplete(() => {
        this.terminaPone(t);
      }),
      this.tween.start();
    var a = { x: 1 };
    this.app
      .tween(a)
      .to({ x: 0 }, 0.34, pc.SineOut)
      .onUpdate(() => {
        (this.entity.children[0].element.opacity = a.x),
          (this.entity.children[1].element.opacity = a.x),
          (this.entity.children[2].element.opacity = a.x),
          (this.entity.children[3].element.opacity = a.x),
          (this.entity.children[0].element.outlineThickness = a.x),
          (this.entity.children[1].element.outlineThickness = a.x),
          (this.entity.children[2].element.outlineThickness = a.x),
          (this.entity.children[3].element.outlineThickness = a.x);
      })
      .delay(0.55)
      .start();
  }),
  (AnimaTextoMsg.prototype.poneScale = function (t, e, i) {
    var n = this.tiempo;
    null != e && (n = e);
    var s = this.tipoTween;
    null != i && (s = i),
      (s = this.elijeTween(s)),
      this.entity.setLocalScale(0, 0, 0);
    var o = new pc.Vec3(1, 1, 1),
      a = this.entity.getLocalScale();
    (this.entity.enabled = !0),
      (this.tween = this.mc.tween(a).to(o, n, s)),
      this.tween.onComplete(() => {
        this.terminaPone(t);
      }),
      this.tween.start();
  }),
  (AnimaTextoMsg.prototype.sacaScale = function (t, e, i, n) {
    var s = this.tiempo;
    null != i && (s = i);
    var o = this.tipoTween;
    null != n && (o = n),
      (o = this.elijeTween(o)),
      this.entity.setLocalScale(1, 1, 1);
    var a = new pc.Vec3(0, 0, 0),
      h = this.entity.getLocalScale();
    (this.entity.enabled = !0),
      (this.tween = this.mc.tween(h).to(a, s, o)),
      this.tween.onComplete(() => {
        this.terminaSaca(t, e);
      }),
      this.tween.start();
  }),
  (AnimaTextoMsg.prototype.saca = function (t, e, i) {
    var n = this.tiempo;
    null != i && (n = i),
      this.entity.setLocalPosition(this.origen.x, this.origen.y, this.origen.z);
    var s = this.entity.getLocalPosition(),
      o = new pc.Vec3(this.destinox, this.destinoy, this.destinoz);
    (o = new pc.Vec3(s.x + o.x, s.y + o.y, s.z + o.z)),
      (this.entity.enabled = !0),
      (this.tween = this.mc.tween(s).to(o, n, this.tipoTween)),
      this.tween.onComplete(() => {
        this.terminaSaca(t, e);
      }),
      this.tween.start();
  }),
  (AnimaTextoMsg.prototype.sacaInverso = function (t, e, i) {
    var n = this.tiempo;
    null != i && (n = i),
      this.entity.setLocalPosition(this.origen.x, this.origen.y, this.origen.z);
    var s = this.entity.getLocalPosition(),
      o = new pc.Vec3(this.destinox, this.destinoy, this.destinoz);
    (o = new pc.Vec3(s.x - o.x, s.y - o.y, s.z - o.z)),
      (this.entity.enabled = !0),
      (this.tween = this.mc.tween(s).to(o, n, this.tipoTween)),
      this.tween.onComplete(() => {
        this.terminaSaca(t, e);
      }),
      this.tween.start();
  }),
  (AnimaTextoMsg.prototype.terminaPone = function (t) {
    null != t && t();
  }),
  (AnimaTextoMsg.prototype.terminaSaca = function (t, e) {
    t && (this.entity.enabled = !1), null != e && e();
  }),
  (AnimaTextoMsg.prototype.poneSaca = function (t) {});
var Ball2dRot = pc.createScript("ball2dRot");
Ball2dRot.attributes.add("radius", {
  type: "number",
  default: 0.19,
  title: "ball radius",
}),
  Ball2dRot.attributes.add("fakeEntity", {
    type: "entity",
    title: "fake entity for aux quat",
  }),
  Ball2dRot.attributes.add("axes", {
    type: "number",
    enum: [{ XY: 1 }, { XZ: 2 }, { YZ: 3 }],
    default: 1,
    title: "Axes",
    description: "The axes for fake 3d rotate",
  }),
  (Ball2dRot.prototype.initialize = function () {
    null == this.fakeEntity &&
      (this.fakeEntity = this.app.root.findByName("fakeEntity")),
      (this.lastPosition = this.entity.getPosition().clone());
  }),
  (Ball2dRot.prototype.rotateBall = function () {
    if (0 != this.radius) {
      var t = this.entity.getPosition().clone(),
        e = new pc.Vec3();
      e.sub2(this.lastPosition, t);
      var i = e.length();
      if (0 != i) {
        var a;
        switch ((i > 0.01 && (i = 0.01), this.axes)) {
          case 1:
            a = new pc.Vec3(0, 0, -30);
            break;
          case 2:
            a = new pc.Vec3(0, -50, 0);
            break;
          case 3:
            a = new pc.Vec3(-30, 0, 0);
        }
        var s = new pc.Vec3().cross(a, e);
        if (s != pc.Vec3.ZERO) {
          var n = (180 * (i / this.radius)) / Math.PI,
            o = new pc.Quat();
          o.setFromAxisAngle(s, n);
          var l = new pc.Quat();
          l.mul2(o, this.entity.getRotation()),
            this.fakeEntity.setRotation(l),
            this.entity.setLocalEulerAngles(
              this.fakeEntity.getLocalEulerAngles()
            );
        }
      }
    }
  }),
  (Ball2dRot.prototype.update = function (t) {
    this.rotateBall(), (this.lastPosition = this.entity.getPosition().clone());
  });
pc.extend(
  pc,
  (function () {
    var FxaaEffect = function (e) {
      var o = { aPosition: pc.SEMANTIC_POSITION },
        r = [
          "attribute vec2 aPosition;",
          "",
          "void main(void)",
          "{",
          "    gl_Position = vec4(aPosition, 0.0, 1.0);",
          "}",
        ].join("\n"),
        a = [
          "precision " + e.precision + " float;",
          "",
          "uniform sampler2D uColorBuffer;",
          "uniform vec2 uResolution;",
          "",
          "#define FXAA_REDUCE_MIN   (1.0/128.0)",
          "#define FXAA_REDUCE_MUL   (1.0/8.0)",
          "#define FXAA_SPAN_MAX     8.0",
          "",
          "void main()",
          "{",
          "    vec3 rgbNW = texture2D( uColorBuffer, ( gl_FragCoord.xy + vec2( -1.0, -1.0 ) ) * uResolution ).xyz;",
          "    vec3 rgbNE = texture2D( uColorBuffer, ( gl_FragCoord.xy + vec2( 1.0, -1.0 ) ) * uResolution ).xyz;",
          "    vec3 rgbSW = texture2D( uColorBuffer, ( gl_FragCoord.xy + vec2( -1.0, 1.0 ) ) * uResolution ).xyz;",
          "    vec3 rgbSE = texture2D( uColorBuffer, ( gl_FragCoord.xy + vec2( 1.0, 1.0 ) ) * uResolution ).xyz;",
          "    vec4 rgbaM  = texture2D( uColorBuffer,  gl_FragCoord.xy  * uResolution );",
          "    vec3 rgbM  = rgbaM.xyz;",
          "    float opacity  = rgbaM.w;",
          "",
          "    vec3 luma = vec3( 0.299, 0.587, 0.114 );",
          "",
          "    float lumaNW = dot( rgbNW, luma );",
          "    float lumaNE = dot( rgbNE, luma );",
          "    float lumaSW = dot( rgbSW, luma );",
          "    float lumaSE = dot( rgbSE, luma );",
          "    float lumaM  = dot( rgbM,  luma );",
          "    float lumaMin = min( lumaM, min( min( lumaNW, lumaNE ), min( lumaSW, lumaSE ) ) );",
          "    float lumaMax = max( lumaM, max( max( lumaNW, lumaNE) , max( lumaSW, lumaSE ) ) );",
          "",
          "    vec2 dir;",
          "    dir.x = -((lumaNW + lumaNE) - (lumaSW + lumaSE));",
          "    dir.y =  ((lumaNW + lumaSW) - (lumaNE + lumaSE));",
          "",
          "    float dirReduce = max( ( lumaNW + lumaNE + lumaSW + lumaSE ) * ( 0.25 * FXAA_REDUCE_MUL ), FXAA_REDUCE_MIN );",
          "",
          "    float rcpDirMin = 1.0 / ( min( abs( dir.x ), abs( dir.y ) ) + dirReduce );",
          "    dir = min( vec2( FXAA_SPAN_MAX, FXAA_SPAN_MAX), max( vec2(-FXAA_SPAN_MAX, -FXAA_SPAN_MAX), dir * rcpDirMin)) * uResolution;",
          "",
          "    vec3 rgbA = 0.5 * (",
          "        texture2D( uColorBuffer, gl_FragCoord.xy  * uResolution + dir * ( 1.0 / 3.0 - 0.5 ) ).xyz +",
          "        texture2D( uColorBuffer, gl_FragCoord.xy  * uResolution + dir * ( 2.0 / 3.0 - 0.5 ) ).xyz );",
          "",
          "    vec3 rgbB = rgbA * 0.5 + 0.25 * (",
          "        texture2D( uColorBuffer, gl_FragCoord.xy  * uResolution + dir * -0.5 ).xyz +",
          "        texture2D( uColorBuffer, gl_FragCoord.xy  * uResolution + dir * 0.5 ).xyz );",
          "",
          "    float lumaB = dot( rgbB, luma );",
          "",
          "    if ( ( lumaB < lumaMin ) || ( lumaB > lumaMax ) )",
          "    {",
          "        gl_FragColor = vec4( rgbA, opacity );",
          "    }",
          "    else",
          "    {",
          "        gl_FragColor = vec4( rgbB, opacity );",
          "    }",
          "}",
        ].join("\n");
      (this.fxaaShader = new pc.Shader(e, {
        attributes: o,
        vshader: r,
        fshader: a,
      })),
        (this.resolution = new Float32Array(2));
    };
    return (
      ((FxaaEffect = pc.inherits(FxaaEffect, pc.PostEffect)).prototype =
        pc.extend(FxaaEffect.prototype, {
          render: function (e, o, r) {
            var a = this.device,
              t = a.scope;
            (this.resolution[0] = 1 / e.width),
              (this.resolution[1] = 1 / e.height),
              t.resolve("uResolution").setValue(this.resolution),
              t.resolve("uColorBuffer").setValue(e.colorBuffer),
              pc.drawFullscreenQuad(
                a,
                o,
                this.vertexBuffer,
                this.fxaaShader,
                r
              );
          },
        })),
      { FxaaEffect: FxaaEffect }
    );
  })()
);
var Fxaa = pc.createScript("fxaa");
Fxaa.prototype.initialize = function () {
  this.effect = new pc.FxaaEffect(this.app.graphicsDevice);
  var e = this.entity.camera.postEffects;
  e.addEffect(this.effect),
    this.on("state", function (o) {
      o ? e.addEffect(this.effect) : e.removeEffect(this.effect);
    }),
    this.on("destroy", function () {
      e.removeEffect(this.effect);
    });
};
var UISlider = pc.createScript("uiSlider");
UISlider.attributes.add("handle", {
  type: "entity",
  default: null,
  title: "Handle",
}),
  UISlider.attributes.add("axis", {
    type: "string",
    default: "y",
    title: "Axis",
    description: "lock drag to axis: x, y or xy",
  }),
  UISlider.attributes.add("guiButton", { type: "entity" }),
  (UISlider.prototype.initialize = function () {
    (_masse = this),
      (this.screenX = 0),
      (this.screenY = 0),
      (this.forze = null),
      (this.hitForze = 0),
      (this.angle = 0);
  }),
  (UISlider.prototype.postInitialize = function () {
    if (
      (this.handle ||
        (this.handle = this.entity.parent.findByName("UISliderHandle")),
      !this.handle)
    )
      throw new Error("UISlider has no handle");
    this.addHandleListeners(),
      (this.isDragging = !1),
      (this.touchId = -1),
      (this.mousePos = new pc.Vec3()),
      (this.anchorPos = this.handle.getLocalPosition().clone()),
      (this.screen = this.getUIScreenComponent());
  }),
  (UISlider.prototype.getUIScreenComponent = function () {
    return this.handle.element.screen.screen;
  }),
  (UISlider.prototype.addHandleListeners = function () {
    (this.handle.element.useInput = !0),
      this.handle.element.on(pc.EVENT_MOUSEDOWN, this.onPressDown, this),
      this.app.mouse.on(pc.EVENT_MOUSEUP, this.onPressUp, this),
      this.app.mouse.on(pc.EVENT_MOUSEMOVE, this.onPressMove, this),
      isMobile.any() &&
        (console.log("initing touches"),
        this.handle.element.on(pc.EVENT_TOUCHSTART, this.onTouchStart, this),
        this.app.touch.on(pc.EVENT_TOUCHEND, this.onTouchEnd, this),
        this.app.touch.on(pc.EVENT_TOUCHCANCEL, this.onTouchEnd, this),
        this.app.touch.on(pc.EVENT_TOUCHMOVE, this.onTouchMove, this)),
      this.on("destroy", function () {
        this.handle.element.off(pc.EVENT_MOUSEDOWN, this.onPressDown, this),
          this.app.mouse.off(pc.EVENT_MOUSEUP, this.onPressUp, this),
          this.app.mouse.off(pc.EVENT_MOUSEMOVE, this.onPressMove, this),
          isMobile.any() &&
            (this.handle.element.off(
              pc.EVENT_TOUCHSTART,
              this.onTouchStart,
              this
            ),
            this.app.touch.off(pc.EVENT_TOUCHEND, this.onTouchEnd, this),
            this.app.touch.off(pc.EVENT_TOUCHCANCEL, this.onTouchEnd, this),
            this.app.touch.off(pc.EVENT_TOUCHMOVE, this.onTouchMove, this));
      });
  }),
  (UISlider.prototype.onTouchStart = function (t) {
    var e = t.changedTouches[0];
    (this.touchId = e.identifier),
      this.startDrag(t.x, t.y),
      t.event.stopPropagation();
  }),
  (UISlider.prototype.onTouchMove = function (t) {
    for (var e = 0; e < t.changedTouches.length; e++) {
      var i = t.changedTouches[e];
      if (i.id == this.touchId)
        return t.event.stopPropagation(), void this.updateMove(i.x, i.y);
    }
  }),
  (UISlider.prototype.onTouchEnd = function (t) {
    for (var e = 0; e < t.changedTouches.length; e++) {
      var i = t.changedTouches[e];
      if (i.id == this.touchId)
        return (
          t.event.stopImmediatePropagation(),
          (this.touchId = -1),
          void this.endDrag(i.x, i.y)
        );
    }
  }),
  (UISlider.prototype.onPressDown = function (t) {
    t.event.stopImmediatePropagation(), this.startDrag(t.x, t.y);
  }),
  (UISlider.prototype.onPressUp = function (t) {
    t.event.stopImmediatePropagation(), this.endDrag(t.x, t.y);
  }),
  (UISlider.prototype.onPressMove = function (t) {
    this.updateMove(t.x, t.y), t.event.stopImmediatePropagation();
  }),
  (UISlider.prototype.startDrag = function (t, e) {
    (this.isDragging = !0),
      this.setMouseXY(t, e),
      this.entity.setLocalScale(2.5, 2.5, 2.5),
      tocaSonido("tapWhite");
  }),
  (UISlider.prototype.updateMove = function (t, e) {
    this.isDragging && this.setMouseXY(t, e);
  }),
  (UISlider.prototype.endDrag = function (t, e) {
    this.isDragging && tocaSonido("endWhite"),
      (this.isDragging = !1),
      this.setMouseXY(t, e),
      this.entity.setLocalScale(1, 1, 1);
  }),
  (UISlider.prototype.setMouseXY = function (t, e) {
    (this.mousePos.x = t), (this.mousePos.y = e);
  }),
  (UISlider.prototype.update = function (t) {
    this.updateDrag();
  }),
  (UISlider.prototype.updateDrag = function () {
    if (this.isDragging) {
      var t = this.app.graphicsDevice,
        e = (this.handle.element.anchor.x * t.width) / window.devicePixelRatio,
        i = (this.handle.element.anchor.y * t.height) / window.devicePixelRatio,
        s = 1 / (this.screen.scale / window.devicePixelRatio),
        o =
          "x" == this.axis || "xy" == this.axis
            ? (this.mousePos.x - e) * s
            : this.anchorPos.x,
        h =
          "y" == this.axis || "xy" == this.axis
            ? (-this.mousePos.y + i) * s
            : this.anchorPos.y;
      console.log(o + "  ; " + h),
        Math.sqrt(Math.pow(o, 2) + Math.pow(h, 2)) <= 236 &&
          (this.handle.setLocalPosition(o, h, 0),
          (this.screenX = o),
          (this.screenY = h),
          this.guiButton.setLocalPosition(0.2 * o, 0.2 * h, 0));
    }
  }),
  (UISlider.prototype.doMasse = function (t, e) {
    if (!this.alreadyApply) {
      this.alreadyApply = !0;
      var i = this.angle,
        s = 1,
        o = 2;
      if ("ball" == e) {
        if (((s = 1.8), this.screenY > 0 && (o = 1), i >= 45 && i <= 135)) {
          var h =
              ((2.7 * s - (a = 0)) / (235 - (r = 0))) * (this.screenX - r) + a,
            n =
              ((2.7 * o - (a = 0)) / (235 - (r = 0))) * (this.screenY - r) + a;
          setTimeout(
            function () {
              t.script.p2Body.body.applyImpulseLocal([
                h * this.hitForze,
                n * this.hitForze,
              ]);
            }.bind(this),
            30
          );
        } else if (i <= -45 && i >= -135) {
          (h =
            ((-2.7 * s - (a = 0)) / (235 - (r = 0))) * (this.screenX - r) + a),
            (n =
              ((-2.7 * o - (a = 0)) / (235 - (r = 0))) * (this.screenY - r) +
              a);
          setTimeout(
            function () {
              t.script.p2Body.body.applyImpulseLocal([
                h * this.hitForze,
                n * this.hitForze,
              ]);
            }.bind(this),
            30
          );
        } else if ((i <= 180 && i >= 135) || (i <= -135 && i >= -180)) {
          (h =
            ((2.7 * s - (a = 0)) / (235 - (r = 0))) * (this.screenX - r) + a),
            (n =
              ((-2.7 * o - (a = 0)) / (235 - (r = 0))) * (this.screenY - r) +
              a);
          setTimeout(
            function () {
              t.script.p2Body.body.applyImpulseLocal([
                n * this.hitForze,
                h * this.hitForze,
              ]);
            }.bind(this),
            30
          );
        } else if (i <= 45 && i >= -45) {
          (h =
            ((-2.7 * s - (a = 0)) / (235 - (r = 0))) * (this.screenX - r) + a),
            (n =
              ((2.7 * o - (a = 0)) / (235 - (r = 0))) * (this.screenY - r) + a);
          setTimeout(
            function () {
              t.script.p2Body.body.applyImpulseLocal([
                n * this.hitForze,
                h * this.hitForze,
              ]);
            }.bind(this),
            30
          );
        }
      } else if (i >= 45 && i <= 135) {
        (h = ((2.7 * s - (a = 0)) / (235 - (r = 0))) * (this.screenX - r) + a),
          (n =
            ((-2.7 * s - (a = 0)) / (235 - (r = 0))) * (this.screenY - r) + a);
        t.script.p2Body.body.applyImpulseLocal([
          h * this.hitForze,
          n * this.hitForze,
        ]);
      } else if (i <= -45 && i >= -135) {
        (h = ((-2.7 * s - (a = 0)) / (235 - (r = 0))) * (this.screenX - r) + a),
          (n =
            ((2.7 * s - (a = 0)) / (235 - (r = 0))) * (this.screenY - r) + a);
        t.script.p2Body.body.applyImpulseLocal([
          h * this.hitForze,
          n * this.hitForze,
        ]);
      } else if ((i <= 180 && i >= 135) || (i <= -135 && i >= -180)) {
        (h = ((2.7 * s - (a = 0)) / (235 - (r = 0))) * (this.screenX - r) + a),
          (n =
            ((2.7 * s - (a = 0)) / (235 - (r = 0))) * (this.screenY - r) + a);
        t.script.p2Body.body.applyImpulseLocal([
          n * this.hitForze,
          h * this.hitForze,
        ]);
      } else if (i <= 45 && i >= -45) {
        var r, a;
        (h = ((-2.7 * s - (a = 0)) / (235 - (r = 0))) * (this.screenX - r) + a),
          (n =
            ((-2.7 * s - (a = 0)) / (235 - (r = 0))) * (this.screenY - r) + a);
        t.script.p2Body.body.applyImpulseLocal([
          n * this.hitForze,
          h * this.hitForze,
        ]);
      }
      this.resetMasse();
    }
  }),
  (UISlider.prototype.configMasse = function (t, e) {
    (this.alreadyApply = !1),
      (this.hitForze = e),
      (this.forze = t),
      this.forze.normalize(),
      (this.angle = Math.atan2(this.forze.y, this.forze.x)),
      (this.angle = (180 * this.angle) / Math.PI),
      console.log(this.angle);
  }),
  (UISlider.prototype.resetMasse = function () {
    this.handle.setLocalPosition(0, 0, 0),
      (this.screenX = 0),
      (this.screenY = 0),
      this.guiButton.setLocalPosition(0, 0, 0);
  });
var CambiaTextura = pc.createScript("cambiaTextura");
CambiaTextura.attributes.add("material", {
  type: "asset",
  assetType: "material",
  array: !1,
}),
  CambiaTextura.attributes.add("texturas", {
    type: "asset",
    assetType: "texture",
    array: !0,
    title: "texturas",
  }),
  CambiaTextura.attributes.add("transparente", {
    type: "number",
    default: 0,
    title: "transparente",
  }),
  CambiaTextura.attributes.add("emisivo", {
    type: "number",
    default: 0,
    title: "emisivo",
  }),
  CambiaTextura.attributes.add("esElement", {
    type: "number",
    default: 0,
    title: "esElement",
  }),
  (CambiaTextura.prototype.initialize = function () {}),
  (CambiaTextura.prototype.cambio = function (e) {
    var t = this.texturas[e];
    if (0 == this.esElement) {
      var a = this.material.resource;
      (a.diffuseMap = t.resource),
        1 == this.transparente && (a.opacityMap = t.resource),
        1 == this.emisivo && (a.emissiveMap = t.resource),
        a.update();
    } else this.entity.element.texture = t.resource;
  });
var ElementAlphaAnim = pc.createScript("elementAlphaAnim");
ElementAlphaAnim.attributes.add("speed", { type: "number", default: 1 }),
  ElementAlphaAnim.attributes.add("delayFadeIN", {
    type: "number",
    default: 1,
  }),
  ElementAlphaAnim.attributes.add("delayFadeOUT", {
    type: "number",
    default: 1,
  }),
  (ElementAlphaAnim.prototype.initialize = function () {
    (this.objeto = []), (this.tipo = []);
  }),
  (ElementAlphaAnim.prototype.fadeOut = function (t) {
    var e = this.entity.children[t];
    setTimeout(
      function () {
        if (this.objeto.includes(e)) {
          var t = this.objeto.indexOf(e);
          this.tipo[t] = -1;
        } else this.objeto.push(e), this.tipo.push(-1);
      }.bind(this),
      1e3 * this.delayFadeOUT
    );
  }),
  (ElementAlphaAnim.prototype.fadeIn = function (t) {
    var e = this.entity.children[t];
    setTimeout(
      function () {
        if (this.objeto.includes(e)) {
          var t = this.objeto.indexOf(e);
          this.tipo[t] = 1;
        } else this.objeto.push(e), this.tipo.push(1);
      }.bind(this),
      1e3 * this.delayFadeIN
    );
  }),
  (ElementAlphaAnim.prototype.reset = function (t, e) {
    var i = this.entity.children[t];
    if (((i.enabled = !0), this.objeto.includes(i))) {
      var n = this.objeto.indexOf(i);
      this.tipo[n] = 0;
    } else this.objeto.push(i), this.tipo.push(0);
    i.element.opacity = e;
  }),
  (ElementAlphaAnim.prototype.update = function (t) {
    for (var e = 0; e < this.objeto.length; e++) {
      var i = this.objeto[e],
        n = this.tipo[e],
        o = this.objeto[e].element.opacity;
      1 == n && o < 1
        ? ((o += t * this.speed) > 1 && (o = 1), (i.element.opacity = o))
        : -1 == n &&
          o > 0 &&
          ((o -= t * this.speed) < 0 && (o = 0), (i.element.opacity = o));
    }
  });
var DetectAspectRatio = pc.createScript("detectAspectRatio");
DetectAspectRatio.attributes.add("camara", { type: "entity" }),
  DetectAspectRatio.attributes.add("powerBar", { type: "entity" }),
  (DetectAspectRatio.prototype.initialize = function () {
    if (
      ((_2dScreen = this.entity),
      (this.powerBar.enabled = !1),
      window.innerWidth < window.innerHeight)
    )
      setTimeout(this.initialize.bind(this), 100);
    else if (isMobile.any()) {
      var t = window.innerWidth / window.innerHeight;
      if (t > 1.78) {
        this.camara.camera.orthoHeight = 3.9;
        i = this.camara.getPosition();
        this.camara.setPosition(-0.313, i.y, i.z);
      } else if (t <= 1.35) {
        this.camara.camera.orthoHeight = 5.25;
        i = this.camara.getPosition();
        this.camara.setPosition(-0.313, i.y, i.z);
      } else {
        this.camara.camera.orthoHeight = 3.95;
        i = this.camara.getPosition();
        this.camara.setPosition(-0.313, i.y, i.z);
      }
    } else {
      this.camara.camera.orthoHeight = 3.97;
      var i = this.camara.getPosition();
      this.camara.setPosition(0, i.y, i.z);
    }
  });
"undefined" != typeof document &&
  /*! FPSMeter 0.3.1 - 9th May 2013 | https://github.com/Darsain/fpsmeter */
  ((function (t, e) {
    function s(t, e) {
      for (var n in e)
        try {
          t.style[n] = e[n];
        } catch (t) {}
      return t;
    }
    function H(t) {
      return null == t
        ? String(t)
        : "object" == typeof t || "function" == typeof t
        ? Object.prototype.toString
            .call(t)
            .match(/\s([a-z]+)/i)[1]
            .toLowerCase() || "object"
        : typeof t;
    }
    function R(t, e) {
      if ("array" !== H(e)) return -1;
      if (e.indexOf) return e.indexOf(t);
      for (var n = 0, o = e.length; n < o; n++) if (e[n] === t) return n;
      return -1;
    }
    function I() {
      var t,
        e = arguments;
      for (t in e[1])
        if (e[1].hasOwnProperty(t))
          switch (H(e[1][t])) {
            case "object":
              e[0][t] = I({}, e[0][t], e[1][t]);
              break;
            case "array":
              e[0][t] = e[1][t].slice(0);
              break;
            default:
              e[0][t] = e[1][t];
          }
      return 2 < e.length
        ? I.apply(null, [e[0]].concat(Array.prototype.slice.call(e, 2)))
        : e[0];
    }
    function N(t) {
      return 1 === (t = Math.round(255 * t).toString(16)).length ? "0" + t : t;
    }
    function S(t, e, n, o) {
      t.addEventListener
        ? t[o ? "removeEventListener" : "addEventListener"](e, n, !1)
        : t.attachEvent && t[o ? "detachEvent" : "attachEvent"]("on" + e, n);
    }
    function D(t, e) {
      function g(t, e, n, o) {
        return h[0 | t][Math.round(Math.min(((e - n) / (o - n)) * M, M))];
      }
      function r() {
        O.legend.fps !== q &&
          ((O.legend.fps = q), (O.legend[c] = q ? "FPS" : "ms")),
          (b = q ? v.fps : v.duration),
          (O.count[c] = 999 < b ? "999+" : b.toFixed(99 < b ? 0 : F.decimals));
      }
      function m() {
        for (
          p = n(),
            P < p - F.threshold &&
              ((v.fps -= v.fps / Math.max(1, (60 * F.smoothing) / F.interval)),
              (v.duration = 1e3 / v.fps)),
            w = F.history;
          w--;

        )
          (j[w] = 0 === w ? v.fps : j[w - 1]),
            (T[w] = 0 === w ? v.duration : T[w - 1]);
        if ((r(), F.heat)) {
          if (z.length)
            for (w = z.length; w--; )
              z[w].el.style[o[z[w].name].heatOn] = q
                ? g(o[z[w].name].heatmap, v.fps, 0, F.maxFps)
                : g(o[z[w].name].heatmap, v.duration, F.threshold, 0);
          if (O.graph && o.column.heatOn)
            for (w = C.length; w--; )
              C[w].style[o.column.heatOn] = q
                ? g(o.column.heatmap, j[w], 0, F.maxFps)
                : g(o.column.heatmap, T[w], F.threshold, 0);
        }
        if (O.graph)
          for (y = 0; y < F.history; y++)
            C[y].style.height =
              (q
                ? j[y]
                  ? Math.round((x / F.maxFps) * Math.min(j[y], F.maxFps))
                  : 0
                : T[y]
                ? Math.round((x / F.threshold) * Math.min(T[y], F.threshold))
                : 0) + "px";
      }
      function k() {
        20 > F.interval
          ? ((l = a(k)), m())
          : ((l = setTimeout(k, F.interval)), (f = a(m)));
      }
      function G(t) {
        (t = t || window.event).preventDefault
          ? (t.preventDefault(), t.stopPropagation())
          : ((t.returnValue = !1), (t.cancelBubble = !0)),
          v.toggle();
      }
      function U() {
        F.toggleOn && S(O.container, F.toggleOn, G, 1),
          t.removeChild(O.container);
      }
      function V() {
        if (
          (O.container && U(),
          (o = D.theme[F.theme]),
          !(h = o.compiledHeatmaps || []).length && o.heatmaps.length)
        ) {
          for (y = 0; y < o.heatmaps.length; y++)
            for (h[y] = [], w = 0; w <= M; w++) {
              var e,
                n = h[y],
                i = w;
              e = (0.33 / M) * w;
              var a = o.heatmaps[y].saturation,
                p = o.heatmaps[y].lightness,
                l = void 0,
                c = void 0,
                u = void 0,
                d = (u = void 0),
                f = (l = c = void 0);
              f = void 0;
              0 === (u = 0.5 >= p ? p * (1 + a) : p + a - p * a)
                ? (e = "#000")
                : ((c = (u - (d = 2 * p - u)) / u),
                  (f = (e *= 6) - (l = Math.floor(e))),
                  (f *= u * c),
                  0 === l || 6 === l
                    ? ((l = u), (c = d + f), (u = d))
                    : 1 === l
                    ? ((l = u - f), (c = u), (u = d))
                    : 2 === l
                    ? ((l = d), (c = u), (u = d + f))
                    : 3 === l
                    ? ((l = d), (c = u - f))
                    : 4 === l
                    ? ((l = d + f), (c = d))
                    : ((l = u), (c = d), (u -= f)),
                  (e = "#" + N(l) + N(c) + N(u))),
                (n[i] = e);
            }
          o.compiledHeatmaps = h;
        }
        for (var b in ((O.container = s(
          document.createElement("div"),
          o.container
        )),
        (O.count = O.container.appendChild(
          s(document.createElement("div"), o.count)
        )),
        (O.legend = O.container.appendChild(
          s(document.createElement("div"), o.legend)
        )),
        (O.graph = F.graph
          ? O.container.appendChild(s(document.createElement("div"), o.graph))
          : 0),
        (z.length = 0),
        O))
          O[b] && o[b].heatOn && z.push({ name: b, el: O[b] });
        if (((C.length = 0), O.graph))
          for (
            O.graph.style.width =
              F.history * o.column.width +
              (F.history - 1) * o.column.spacing +
              "px",
              w = 0;
            w < F.history;
            w++
          )
            (C[w] = O.graph.appendChild(
              s(document.createElement("div"), o.column)
            )),
              (C[w].style.position = "absolute"),
              (C[w].style.bottom = 0),
              (C[w].style.right =
                w * o.column.width + w * o.column.spacing + "px"),
              (C[w].style.width = o.column.width + "px"),
              (C[w].style.height = "0px");
        s(O.container, F),
          r(),
          t.appendChild(O.container),
          O.graph && (x = O.graph.clientHeight),
          F.toggleOn &&
            ("click" === F.toggleOn && (O.container.style.cursor = "pointer"),
            S(O.container, F.toggleOn, G));
      }
      "object" === H(t) &&
        undefined === t.nodeType &&
        ((e = t), (t = document.body)),
        t || (t = document.body);
      var o,
        h,
        p,
        l,
        f,
        x,
        b,
        w,
        y,
        v = this,
        F = I({}, D.defaults, e || {}),
        O = {},
        C = [],
        M = 100,
        z = [],
        E = F.threshold,
        A = 0,
        P = n() - E,
        j = [],
        T = [],
        q = "fps" === F.show;
      (v.options = F),
        (v.fps = 0),
        (v.duration = 0),
        (v.isPaused = 0),
        (v.tickStart = function () {
          A = n();
        }),
        (v.tick = function () {
          (p = n()),
            (E += (p - P - E) / F.smoothing),
            (v.fps = 1e3 / E),
            (v.duration = A < P ? E : p - A),
            (P = p);
        }),
        (v.pause = function () {
          return (
            l && ((v.isPaused = 1), clearTimeout(l), i(l), i(f), (l = f = 0)), v
          );
        }),
        (v.resume = function () {
          return l || ((v.isPaused = 0), k()), v;
        }),
        (v.set = function (t, e) {
          return (
            (F[t] = e),
            (q = "fps" === F.show),
            -1 !== R(t, u) && V(),
            -1 !== R(t, d) && s(O.container, F),
            v
          );
        }),
        (v.showDuration = function () {
          return v.set("show", "ms"), v;
        }),
        (v.showFps = function () {
          return v.set("show", "fps"), v;
        }),
        (v.toggle = function () {
          return v.set("show", q ? "ms" : "fps"), v;
        }),
        (v.hide = function () {
          return v.pause(), (O.container.style.display = "none"), v;
        }),
        (v.show = function () {
          return v.resume(), (O.container.style.display = "block"), v;
        }),
        (v.destroy = function () {
          v.pause(), U(), (v.tick = v.tickStart = function () {});
        }),
        V(),
        k();
    }
    var n,
      o = t.performance;
    n =
      o && (o.now || o.webkitNow)
        ? o[o.now ? "now" : "webkitNow"].bind(o)
        : function () {
            return +new Date();
          };
    for (
      var i = t.cancelAnimationFrame || t.cancelRequestAnimationFrame,
        a = t.requestAnimationFrame,
        h = 0,
        p = 0,
        l = (o = ["moz", "webkit", "o"]).length;
      p < l && !i;
      ++p
    )
      a =
        (i =
          t[o[p] + "CancelAnimationFrame"] ||
          t[o[p] + "CancelRequestAnimationFrame"]) &&
        t[o[p] + "RequestAnimationFrame"];
    i ||
      ((a = function (e) {
        var o = n(),
          i = Math.max(0, 16 - (o - h));
        return (
          (h = o + i),
          t.setTimeout(function () {
            e(o + i);
          }, i)
        );
      }),
      (i = function (t) {
        clearTimeout(t);
      }));
    var c =
      "string" === H(document.createElement("div").textContent)
        ? "textContent"
        : "innerText";
    (D.extend = I),
      (window.FPSMeter = D),
      (D.defaults = {
        interval: 100,
        smoothing: 10,
        show: "fps",
        toggleOn: "click",
        decimals: 1,
        maxFps: 60,
        threshold: 100,
        position: "absolute",
        zIndex: 10,
        left: "5px",
        top: "5px",
        right: "auto",
        bottom: "auto",
        margin: "0 0 0 0",
        theme: "dark",
        heat: 0,
        graph: 0,
        history: 20,
      });
    var u = ["toggleOn", "theme", "heat", "graph", "history"],
      d = "position zIndex left top right bottom margin".split(" ");
  })(window),
  (function (t, e) {
    e.theme = {};
    var n = (e.theme.base = {
      heatmaps: [],
      container: {
        heatOn: null,
        heatmap: null,
        padding: "5px",
        minWidth: "95px",
        height: "30px",
        lineHeight: "30px",
        textAlign: "right",
        textShadow: "none",
      },
      count: {
        heatOn: null,
        heatmap: null,
        position: "absolute",
        top: 0,
        right: 0,
        padding: "5px 10px",
        height: "30px",
        fontSize: "24px",
        fontFamily: "Consolas, Andale Mono, monospace",
        zIndex: 2,
      },
      legend: {
        heatOn: null,
        heatmap: null,
        position: "absolute",
        top: 0,
        left: 0,
        padding: "5px 10px",
        height: "30px",
        fontSize: "12px",
        lineHeight: "32px",
        fontFamily: "sans-serif",
        textAlign: "left",
        zIndex: 2,
      },
      graph: {
        heatOn: null,
        heatmap: null,
        position: "relative",
        boxSizing: "padding-box",
        MozBoxSizing: "padding-box",
        height: "100%",
        zIndex: 1,
      },
      column: { width: 4, spacing: 1, heatOn: null, heatmap: null },
    });
    (e.theme.dark = e.extend({}, n, {
      heatmaps: [{ saturation: 0.8, lightness: 0.8 }],
      container: {
        background: "#222",
        color: "#fff",
        border: "1px solid #1a1a1a",
        textShadow: "1px 1px 0 #222",
      },
      count: { heatOn: "color" },
      column: { background: "#3f3f3f" },
    })),
      (e.theme.light = e.extend({}, n, {
        heatmaps: [{ saturation: 0.5, lightness: 0.5 }],
        container: {
          color: "#666",
          background: "#fff",
          textShadow:
            "1px 1px 0 rgba(255,255,255,.5), -1px -1px 0 rgba(255,255,255,.5)",
          boxShadow: "0 0 0 1px rgba(0,0,0,.1)",
        },
        count: { heatOn: "color" },
        column: { background: "#eaeaea" },
      })),
      (e.theme.colorful = e.extend({}, n, {
        heatmaps: [{ saturation: 0.5, lightness: 0.6 }],
        container: {
          heatOn: "backgroundColor",
          background: "#888",
          color: "#fff",
          textShadow: "1px 1px 0 rgba(0,0,0,.2)",
          boxShadow: "0 0 0 1px rgba(0,0,0,.1)",
        },
        column: { background: "#777", backgroundColor: "rgba(0,0,0,.2)" },
      })),
      (e.theme.transparent = e.extend({}, n, {
        heatmaps: [{ saturation: 0.8, lightness: 0.5 }],
        container: {
          padding: 0,
          color: "#fff",
          textShadow: "1px 1px 0 rgba(0,0,0,.5)",
        },
        count: { padding: "0 5px", height: "40px", lineHeight: "40px" },
        legend: { padding: "0 5px", height: "40px", lineHeight: "42px" },
        graph: { height: "40px" },
        column: {
          width: 5,
          background: "#999",
          heatOn: "backgroundColor",
          opacity: 0.5,
        },
      }));
  })(window, FPSMeter));
var Fps = pc.createScript("fps");
(Fps.prototype.initialize = function () {
  (_fps = this),
    (this.fps = new FPSMeter({ heat: !1, graph: !1 })),
    this.fps.hide(),
    (this.tiempo = 0),
    (this.tiempoMax = 1.2),
    (this.sumFps = 0),
    (this.cantFps = 0),
    (this.iniciarCalculos = !1),
    (this.primerIntento = !0),
    (this.rectificadores = 0),
    (this.maxRectificadores = 1);
}),
  (Fps.prototype.ini = function () {
    this.iniciarCalculos = !0;
  }),
  (Fps.prototype.update = function (t) {
    if (this.iniciarCalculos && this.rectificadores != this.maxRectificadores)
      if (
        (this.fps.tick(),
        (this.tiempo = this.tiempo + t),
        this.tiempo < this.tiempoMax)
      )
        (this.sumFps = this.sumFps + this.fps.fps),
          (this.cantFps = this.cantFps + 1);
      else {
        var e = this.sumFps / this.cantFps;
        if (this.primerIntento)
          console.log("el promedio de fps 1 intento fue de " + e),
            (this.primerIntento = !1),
            (this.tiempoMax = 2);
        else {
          console.log("el promedio de fps fue de " + e),
            (this.rectificadores = this.rectificadores + 1);
          e > 45 ? "alta" : e > 33 ? "media" : e > 14 ? "mediaBaja" : "baja";
        }
        (this.sumFps = 0), (this.tiempo = 0), (this.cantFps = 0);
      }
  });
var AnimaUvs = pc.createScript("animaUvs");
AnimaUvs.attributes.add("material", {
  type: "asset",
  assetType: "material",
  array: !1,
}),
  AnimaUvs.attributes.add("speed", {
    type: "number",
    default: 0.01,
    title: "speed",
  }),
  AnimaUvs.attributes.add("eje", {
    type: "number",
    default: 0,
    title: "ejeX_o_Y",
  }),
  AnimaUvs.attributes.add("loop", {
    type: "number",
    default: 1,
    title: "LOOP",
  }),
  AnimaUvs.attributes.add("desde", {
    type: "number",
    default: 0,
    title: "desde",
  }),
  AnimaUvs.attributes.add("hasta", {
    type: "number",
    default: 1,
    title: "hasta",
  }),
  AnimaUvs.attributes.add("tipoMaterial", {
    type: "string",
    default: "opacityMapOffset",
    title: "opacityMapOffset",
  }),
  AnimaUvs.attributes.add("tipoMaterial2", {
    type: "string",
    default: "",
    title: "diffuseMapOffset",
  }),
  AnimaUvs.attributes.add("tipoMaterial3", {
    type: "string",
    default: "",
    title: "emissiveMapOffset",
  }),
  (AnimaUvs.prototype.initialize = function () {
    this.materialCargado = this.material.resource;
  }),
  (AnimaUvs.prototype.resetMaterial = function (t) {
    (this.materialCargado[this.tipoMaterial] = new pc.Vec2(0, 0)),
      this.materialCargado.update(),
      (this.entity.enabled = !0),
      (this.eje = t);
  }),
  (AnimaUvs.prototype.update = function (t) {
    if (!pause) {
      var a;
      switch (this.tipoMaterial) {
        case "opacityMapOffset":
          a = this.materialCargado.opacityMapOffset;
          break;
        case "diffuseMapOffset":
          a = this.materialCargado.diffuseMapOffset;
          break;
        case "emissiveMapOffset":
          a = this.materialCargado.emissiveMapOffset;
      }
      if (0 == this.eje)
        (e = a.y - t * this.speed) < 0 &&
          (0 == this.loop ? ((e = 0), (this.eje = -99)) : (e = 1)),
          (this.materialCargado[this.tipoMaterial] = new pc.Vec2(0, e)),
          "" != this.tipoMaterial2 &&
            (this.materialCargado[this.tipoMaterial2] = new pc.Vec2(0, e)),
          "" != this.tipoMaterial3 &&
            (this.materialCargado[this.tipoMaterial3] = new pc.Vec2(0, e)),
          this.materialCargado.update();
      else if (1 == this.eje) {
        var e;
        (e = a.x + t * this.speed) > this.hasta &&
          (0 == this.loop
            ? ((e = this.hasta),
              (this.eje = -99),
              setTimeout(this.apagaObjeto.bind(this), 20))
            : (e = this.desde)),
          (this.materialCargado[this.tipoMaterial] = new pc.Vec2(e, 0)),
          "" != this.tipoMaterial2 &&
            (this.materialCargado[this.tipoMaterial2] = new pc.Vec2(e, 0)),
          "" != this.tipoMaterial3 &&
            (this.materialCargado[this.tipoMaterial3] = new pc.Vec2(e, 0)),
          this.materialCargado.update();
      }
    }
  }),
  (AnimaUvs.prototype.apagaObjeto = function () {
    this.entity.enabled = !1;
  });
var Parpadear = pc.createScript("parpadear");
Parpadear.attributes.add("tiempoDesaparicion", {
  type: "number",
  default: 0.85,
  title: "tiempoDesaparicion",
}),
  Parpadear.attributes.add("tiempoAparicion", {
    type: "number",
    default: 0.45,
    title: "tiempoAparicion",
  }),
  Parpadear.attributes.add("autoStart", {
    type: "number",
    default: 1,
    title: "autoStart",
  }),
  Parpadear.attributes.add("es3D", { type: "number", default: 0 }),
  Parpadear.attributes.add("parpadeoShader", { type: "number", default: 0 }),
  (Parpadear.prototype.initialize = function () {
    (this.contador = 0), (this.tipoParpadeo = 0);
  }),
  (Parpadear.prototype.update = function (t) {
    0 != this.autoStart &&
      ((this.contador = this.contador + t),
      0 == this.es3D
        ? this.entity.element.enabled
          ? this.contador > this.tiempoDesaparicion &&
            ((this.contador = 0), (this.entity.element.enabled = !1))
          : this.entity.element.enabled ||
            (this.contador > this.tiempoAparicion &&
              ((this.contador = 0),
              (this.entity.element.enabled = !0),
              2 == this.autoStart && (this.autoStart = 0)))
        : 0 == this.parpadeoShader
        ? this.entity.model.enabled
          ? this.contador > this.tiempoDesaparicion &&
            ((this.contador = 0), (this.entity.model.enabled = !1))
          : this.entity.model.enabled ||
            (this.contador > this.tiempoAparicion &&
              ((this.contador = 0),
              (this.entity.model.enabled = !0),
              2 == this.autoStart && (this.autoStart = 0)))
        : this.contador > this.tiempoDesaparicion &&
          ((this.contador = 0), this.parpadea()));
  }),
  (Parpadear.prototype.parpadea = function () {
    this.tipoParpadeo = 1 == this.tipoParpadeo ? 0 : 1;
    for (var t = this.entity.model.meshInstances, a = 0; a < t.length; ++a) {
      var e = t[a];
      (e.material.emissiveIntensity = this.tipoParpadeo), e.material.update();
    }
  }),
  (Parpadear.prototype.parpadeoReset = function () {
    this.tipoParpadeo = 0;
    for (var t = this.entity.model.meshInstances, a = 0; a < t.length; ++a) {
      var e = t[a];
      (e.material.emissiveIntensity = this.tipoParpadeo), e.material.update();
    }
  });
var ArrowMovement = pc.createScript("arrowMovement");
ArrowMovement.attributes.add("speed", { type: "number", default: 5 }),
  ArrowMovement.attributes.add("distanceX", { type: "number", default: 22 }),
  ArrowMovement.attributes.add("sentido", { type: "number", default: -1 }),
  (ArrowMovement.prototype.initialize = function () {
    (this.deltaX = 0),
      (this.initialPos = this.entity.getLocalPosition().clone());
  }),
  (ArrowMovement.prototype.update = function (t) {
    this.deltaX = this.speed * t;
    var e = this.entity.getLocalPosition();
    this.entity.setLocalPosition(e.x + this.sentido * this.deltaX, e.y, e.z),
      (e = this.entity.getLocalPosition()).x <=
      this.initialPos.x - this.distanceX
        ? ((this.sentido = 1), (this.deltaX = 0))
        : e.x >= this.initialPos.x + this.distanceX &&
          ((this.sentido = -1), (this.deltaX = 0));
  });
var ColorMaterial = pc.createScript("colorMaterial");
ColorMaterial.attributes.add("material", {
  type: "asset",
  assetType: "material",
  array: !1,
}),
  ColorMaterial.attributes.add("colours", { type: "string", array: !0 }),
  (ColorMaterial.prototype.initialize = function () {}),
  (ColorMaterial.prototype.colorChange = function (r) {
    var a = this.material.resource;
    (a.diffuse = new pc.Color().fromString(this.colours[r])), a.update();
  });
var GiroEntidad = pc.createScript("giroEntidad");
GiroEntidad.attributes.add("speed", { type: "number", default: 10 }),
  GiroEntidad.attributes.add("axis", { type: "number", default: 0 }),
  (GiroEntidad.prototype.initialize = function () {}),
  (GiroEntidad.prototype.update = function (t) {
    0 == this.axis
      ? this.entity.rotateLocal(t * this.speed, 0, 0)
      : 1 == this.axis
      ? this.entity.rotateLocal(0, t * this.speed, 0)
      : 2 == this.axis && this.entity.rotateLocal(0, 0, t * this.speed);
  });
var DragHelper = pc.createScript("dragHelper");
(DragHelper.prototype.initialize = function () {
  this.dragHelper = new pc.ElementDragHelper(this.entity.element, "y");
}),
  (DragHelper.prototype.update = function (e) {});
var Rebote = pc.createScript("rebote");
Rebote.attributes.add("velocidadSubida", { type: "number", default: 0.1 }),
  Rebote.attributes.add("velocidadBajada", { type: "number", default: 50 }),
  Rebote.attributes.add("aceleracion", { type: "number", default: 80 }),
  Rebote.attributes.add("aceleracionSpeed", { type: "number", default: 0.2 }),
  Rebote.attributes.add("limitePiso", { type: "number", default: 3.06 }),
  Rebote.attributes.add("aceleracionMaxima", { type: "number", default: 5 }),
  Rebote.attributes.add("pierdeVida", { type: "entity" }),
  Rebote.attributes.add("mcPisoHit", { type: "entity" }),
  (Rebote.prototype.initialize = function () {
    (_rebote = this),
      (this.empezo = !1),
      (this.forzarMover = !1),
      (this.bolaUpDownInitialPosZ =
        this.entity.children[0].children[currentSkin].getLocalPosition().z);
  }),
  (Rebote.prototype.creaGlobalVars = function () {
    (this.indexRebote = 1),
      (this.alturaMaxima = 0),
      (this.contadorDistancia = 0),
      (this.sentido = 1),
      (this.tiempoBola = 0),
      (this.tween = null),
      (this.tweenSalto = null),
      (this.tiempoDesdeRebote = 0.25),
      (this.contadorTiempoRebote = 0),
      (this.activaRebote = !0),
      (this.hiloTiempo = null),
      (this.contadorTiempoBajada = -1),
      (this.bolaSentido = 0),
      (this.indexBola = 0),
      (this.indexBolaArray = 0),
      (this.ordenSaltosIndex = []),
      (this.cancion = null),
      (this.arrayNotas = []),
      (this.recorrido = 0),
      (this.bolaUpDownInitialPosY = null),
      (this.tiempoParpadeo = 0),
      (this.tipoParpadeo = 0),
      (this.bolaUpDown = null),
      (this.notaAsaltar = null),
      (this.empezo = !1);
  }),
  (Rebote.prototype.restartAll = function () {
    null != this.tween && this.tween.stop(),
      null != this.tweenSalto && this.tweenSalto.stop(),
      (this.bolaSentido = 0),
      null != this.bolaUpDown &&
        (this.bolaUpDown.setLocalPosition(
          0,
          this.bolaUpDownInitialPosY,
          this.bolaUpDownInitialPosZ
        ),
        null == this.bolaUpDown.model
          ? (this.bolaUpDown.children[1].model.enabled = !1)
          : (this.bolaUpDown.model.enabled = !1));
  }),
  (Rebote.prototype.empezar = function () {
    var t = this.entity.getPosition();
    (this.posicionHasta = 0),
      (this.velocidad = 0),
      (this.distanciaAcomulada = 0),
      (this.distanciaAcomuladaAC = 0),
      this.creaGlobalVars(),
      (this.alturaMaxima = this.limitePiso - t.y),
      (this.ordenSaltosIndex = _coreSystem.ordenSaltosIndex[currentCancion]),
      (this.cancion = _coreSystem.cancion),
      (this.arrayNotas = _coreSystem.NOTAS_ARRAY),
      (this.bolaUpDown = this.entity.children[0].children[currentSkin]),
      (this.bolaUpDownInitialPosY = this.bolaUpDown.getLocalPosition().y),
      (this.bolaUpDown.parent.findByName("muerte").enabled = !1),
      this.creaSubida(),
      (this.empezo = !0),
      (this.forzarMover = !1);
  }),
  (Rebote.prototype.iniciaBola = function () {
    (this.velocidadBajada = 0.05),
      (this.aceleracionSpeed = 0.18),
      (this.indexBola = 0),
      (this.indexBolaArray = 0);
  }),
  (Rebote.prototype.creaCaida = function (t, e) {
    (this.aceleracion = 0), (this.bolaSentido = -1);
    var o = this.bolaUpDown.getLocalPosition();
    (this.tweenSalto = this.bolaUpDown
      .tween(o)
      .to(new pc.Vec3(o.x, o.y - e, o.z), t, pc.SineIn)),
      this.tweenSalto.start();
  }),
  (Rebote.prototype.creaSubida = function () {
    if (!_coreSystem.gameOver && null != this.ordenSaltosIndex) {
      var t = this.entity.getPosition();
      this.notaAsaltar = this.getNota(this.ordenSaltosIndex[this.recorrido]);
      var e = this.notaAsaltar.getPosition(),
        o =
          ((e = new pc.Vec3(t.x, t.y, e.z)).z - t.z) /
          (gameSpeed + extraSpeedSongs[currentCancion]);
      if (0 == this.recorrido) {
        var i = o - this.cancion[0][0];
        console.log(i), _coreSystem.tocaCancion(i);
      }
      var a = this.entity.getPosition().clone();
      this.entity.setPosition(e);
      this.entity.getLocalPosition().clone();
      this.entity.setPosition(a);
      var n = this.bolaUpDown.getLocalPosition();
      null != this.tweenSalto &&
        (this.tweenSalto.stop(),
        this.bolaUpDown.setLocalPosition(n.x, this.bolaUpDownInitialPosY, n.z)),
        (n = this.bolaUpDown.getLocalPosition()),
        (this.recorrido = this.recorrido + 1);
      var s = (o = Math.abs(o)) / 2,
        r = 2.2222222222222223 * (o - 0.1) + 0.5;
      r > 5 && (r = 5),
        (this.tweenSalto = this.bolaUpDown
          .tween(n)
          .to(new pc.Vec3(n.x, n.y + r, n.z), s, pc.SineOut)),
        this.tweenSalto.start(),
        (this.posicionHasta = r),
        (this.tiempoParaMov = s),
        (this.velocidad = r / s),
        (this.velAc = r / s),
        (this.bolaSentido = 1),
        (this.aceleracionMax = 1.8),
        (this.movListo = !1);
    }
  }),
  (Rebote.prototype.getIndexNota = function (t) {
    return t % this.arrayNotas.children.length;
  }),
  (Rebote.prototype.getNota = function (t) {
    for (var e = 0; e < this.arrayNotas.children.length; e++)
      if (this.arrayNotas.children[e].script.nota.ID == t)
        return this.arrayNotas.children[e];
  }),
  (Rebote.prototype.finSalto = function () {
    this.notaAsaltar.script.nota.index;
    var t = this.notaAsaltar.script.nota.ID;
    this.bolaSentido = 0;
    for (var e = [], o = 0; o < 3 && t + o != this.cancion.length; o++) {
      var i = this.getNota(t + o);
      e.push(i);
    }
    var a = this.colisiones(e, this.bolaUpDown);
    ("rojo" != a && "piso" != a) || this.matarBola(!0),
      t == this.cancion.length - 1
        ? (console.log("BOLA FINAL!! ENDKESS"),
          setTimeout(
            function () {
              (_coreSystem.finCancion = !0),
                (this.empezo = !1),
                this.bolaFinal();
            }.bind(this),
            160
          ))
        : this.creaSubida();
  }),
  (Rebote.prototype.matarBola = function (t) {
    if (t) {
      if (enParpadeo) return;
      currentVidas > 0 &&
        ((currentVidas -= 1),
        _menu.configVidas(),
        playSound("pierdeVida"),
        (this.pierdeVida.enabled = !0),
        this.pierdeVida.script.animaTexturas.inicioAnim(
          function () {
            this.pierdeVida.enabled = !1;
          }.bind(this)
        )),
        0 == currentVidas
          ? continues < posiblesContinues &&
            _coreSystem.gemas >= continueCost * (continues + 1)
            ? ((this.empezo = !1),
              (pause = !0),
              (enPausa = !0),
              _coreSystem.pauseMusic("pause"),
              _menu.poneContinue())
            : (console.log("mate la bola"),
              (this.empezo = !1),
              null != this.tweenSalto && this.tweenSalto.stop(),
              (this.bolaSentido = 0),
              null != this.tween && this.tween.stop(),
              t && (_coreSystem.esGameOver(), this.muerteAnim()))
          : this.parpadear(0);
    } else
      console.log("mate la bola"),
        (this.empezo = !1),
        null != this.tweenSalto && this.tweenSalto.stop(),
        (this.bolaSentido = 0),
        null != this.tween && this.tween.stop();
  }),
  (Rebote.prototype.parpadear = function (t) {
    var e;
    ((e =
      null == this.bolaUpDown.script
        ? this.bolaUpDown.children[1].script.parpadear
        : this.bolaUpDown.script.parpadear).enabled = !0),
      (enParpadeo = !0),
      setTimeout(
        function () {
          (enParpadeo = !1), e.parpadeoReset(), (e.enabled = !1);
        }.bind(this),
        tiempoParpadeo + t
      );
  }),
  (Rebote.prototype.revivir = function () {
    (this.empezo = !0), (pause = !1), _coreSystem.pauseMusic("resume");
  }),
  (Rebote.prototype.bolaFinal = function () {
    currentCancionAux >= 4 &&
    currentCancionAux <= 12 &&
    _coreSystem.cancionFase < 9999999
      ? (console.log("ENTRE A ESTA WEA PO Q PASA?!?! "),
        (this.empezo = !0),
        (this.forzarMover = !0),
        setTimeout(
          function () {
            (_coreSystem.cancionFase = _coreSystem.cancionFase + 1),
              _coreSystem.siguienteFase(),
              (_coreSystem.finCancion = !1),
              (this.forzarMover = !1);
          }.bind(this),
          2e3
        ))
      : this.finBolaFinal();
  }),
  (Rebote.prototype.finBolaFinal = function () {
    _coreSystem.animEndIni();
    var t = this.entity.getLocalPosition();
    this.entity.children[0].getLocalPosition();
    this.entity.children[0]
      .tween(this.entity.children[0].getLocalPosition())
      .to(new pc.Vec3(0, 0, 0), 0.5, pc.Linear)
      .start();
    var e = new pc.Vec3(t.x, t.y, t.z + 30);
    this.entity
      .tween(this.entity.getLocalPosition())
      .to(e, 1.2, pc.Linear)
      .onComplete(() => {
        this.finMov();
      })
      .start();
  }),
  (Rebote.prototype.finMov = function () {
    _coreSystem.animEndFin();
    var t = this.entity.getLocalPosition(),
      e = new pc.Vec3(t.x, t.y, t.z + 100);
    this.entity
      .tween(this.entity.getLocalPosition())
      .to(e, 1, pc.Linear)
      .onComplete(() => {
        playSound("clear"),
          _menu.terminaCancion("pasada"),
          (this.bolaUpDown.model.enabled = !1);
      })
      .start(),
      (gameOver = !0);
  }),
  (Rebote.prototype.update = function (t) {
    if (!pause && this.empezo)
      if (
        (this.entity.translate(
          0,
          0,
          t * (gameSpeed + extraSpeedSongs[currentCancion])
        ),
        1 == this.bolaSentido)
      ) {
        if (
          ((this.distanciaAcomulada =
            this.distanciaAcomulada + t * this.velocidad),
          this.distanciaAcomulada >= this.posicionHasta)
        ) {
          this.tweenSalto.stop();
          var e = this.bolaUpDown.getLocalPosition();
          this.bolaUpDown.setLocalPosition(e.x, this.posicionHasta, e.z),
            (this.distanciaAcomulada = 0),
            this.creaCaida(this.tiempoParaMov, this.posicionHasta);
        }
      } else if (
        -1 == this.bolaSentido &&
        ((this.distanciaAcomulada =
          this.distanciaAcomulada + t * this.velocidad),
        this.distanciaAcomulada >= this.posicionHasta)
      ) {
        this.tweenSalto.stop();
        e = this.bolaUpDown.getLocalPosition();
        this.bolaUpDown.setLocalPosition(e.x, this.bolaUpDownInitialPosY, e.z),
          (this.distanciaAcomulada = 0),
          this.finSalto();
      }
  }),
  (Rebote.prototype.muerteAnim = function () {
    (this.characterState = 0),
      (this.tiempoParpadeo = 0),
      (this.tipoParpadeo = 0);
    playSound("muerte");
    for (var t = 0; t < 6; t++)
      setTimeout(
        function () {
          this.parpadea();
        }.bind(this),
        this.tiempoParpadeo + 150 * t
      ),
        5 == t &&
          setTimeout(
            function () {
              null == this.bolaUpDown.model
                ? (this.bolaUpDown.children[1].model.enabled = !1)
                : (this.bolaUpDown.model.enabled = !1);
              var t = this.bolaUpDown.parent.findByName("muerte");
              (t.enabled = !0),
                t.particlesystem.reset(),
                t.particlesystem.play(),
                setTimeout(
                  function () {
                    currentCancion >= 0 &&
                    currentCancion <= 3 &&
                    -1 == currentCancionAux
                      ? _menu.terminaCancion("muerte")
                      : _menu.terminaCancion("muerteEndless");
                  }.bind(this),
                  600
                );
            }.bind(this),
            this.tiempoParpadeo + 150 * t
          );
  }),
  (Rebote.prototype.parpadea = function () {
    var t = this.bolaUpDown.model;
    null == t && (t = this.bolaUpDown.children[1].model),
      (this.tipoParpadeo = 1 == this.tipoParpadeo ? 0 : 1);
    for (var e = t.meshInstances, o = 0; o < e.length; ++o) {
      var i = e[o];
      (i.material.emissiveIntensity = this.tipoParpadeo), i.material.update();
    }
  }),
  (Rebote.prototype.colisiones = function (t, e) {
    for (var o = 0; o < t.length; o++) {
      var i = t[o],
        a = e.getPosition(),
        n = i.script.nota.tipoNota,
        s = i.getPosition();
      if (
        a.x >= s.x - anchoPlataforma &&
        a.x <= s.x + anchoPlataforma &&
        a.z <= s.z + largoPlataforma &&
        a.z >= s.z - largoPlataforma
      )
        return 1 == n
          ? "rojo"
          : (a.x >= s.x - anchoPlataforma / toleranciaPerfect &&
            a.x <= s.x + anchoPlataforma / toleranciaPerfect &&
            a.z <= s.z + largoPlataforma &&
            a.z >= s.z - largoPlataforma
              ? i.script.nota.mataNota("perfect")
              : a.x >= s.x - anchoPlataforma / toleranciaGema &&
                a.x <= s.x + anchoPlataforma / toleranciaGema &&
                a.z <= s.z + largoPlataforma &&
                a.z >= s.z - largoPlataforma
              ? i.script.nota.mataNota("gema")
              : i.script.nota.mataNota("hit"),
            "hit");
    }
    a = e.getPosition().clone();
    return (
      (a = new pc.Vec3(a.x, a.y - 0.6, a.z)),
      (this.mcPisoHit.enabled = !0),
      this.mcPisoHit.setPosition(a),
      "piso"
    );
  });
var Nota = pc.createScript("nota");
Nota.attributes.add("carriles", { type: "number", array: !0 }),
  Nota.attributes.add("carril", { type: "number", default: 0 }),
  Nota.attributes.add("tipoNota", { type: "number", default: 0 }),
  Nota.attributes.add("ID", { type: "number", default: 0 }),
  Nota.attributes.add("index", { type: "number", default: 0 }),
  Nota.attributes.add("tiempo", { type: "number", default: 0 }),
  (Nota.prototype.initialize = function () {
    (this.notaBuena = this.entity.children[0]),
      (this.notaMala = this.entity.children[1]),
      (this.gema = this.notaBuena.children[0]),
      (this.nota = null),
      (this.porcentajes = this.notaBuena.children[1]),
      (this.fase = 0),
      (this.inicioFase1 = new pc.Vec3()),
      (this.destinoFase1 = new pc.Vec3()),
      (this.inicioFase2 = new pc.Vec3()),
      (this.destinoFase2 = new pc.Vec3()),
      (this.velocidadFase1 = 0),
      (this.velocidadFase2 = 0),
      (this.notaMov = 0),
      (this.velocidadMov = 3.8),
      (this.sentido = 0),
      (this.conGema = 0),
      (this.tweenMov = null),
      (this.player = this.app.root.findByName("bola")),
      (this.comboMSG = this.player.children[0].children[numSkins]),
      (this.scoreMSG = this.player.children[0].children[numSkins + 1]),
      (this.particulas = this.notaBuena.children[2]);
  }),
  (Nota.prototype.setPorcentaje = function () {
    var t = (100 / (_coreSystem.cancion.length - 1 - 0)) * (this.ID - 0) + 0;
    if (
      ((percentajeCompleted = Math.round(t)),
      percentajeCompleted > 100 && (percentajeCompleted = 100),
      !(currentCancionAux > 3))
    )
      switch (_coreSystem.currentPorcentaje) {
        case 0:
          t >= 10 &&
            (2 == this.carril || 1 == this.carril || 3 == this.carril) &&
            0 == this.tipoNota &&
            ((this.porcentajes.children[0].enabled = !0),
            (_coreSystem.currentPorcentaje = 1));
          break;
        case 1:
          t >= 20 &&
            (2 == this.carril || 1 == this.carril || 3 == this.carril) &&
            0 == this.tipoNota &&
            ((this.porcentajes.children[1].enabled = !0),
            (_coreSystem.currentPorcentaje = 2));
          break;
        case 2:
          t >= 30 &&
            (2 == this.carril || 1 == this.carril || 3 == this.carril) &&
            0 == this.tipoNota &&
            ((this.porcentajes.children[2].enabled = !0),
            (_coreSystem.currentPorcentaje = 3));
          break;
        case 3:
          t >= 40 &&
            (2 == this.carril || 1 == this.carril || 3 == this.carril) &&
            0 == this.tipoNota &&
            ((this.porcentajes.children[3].enabled = !0),
            (_coreSystem.currentPorcentaje = 4));
          break;
        case 4:
          t >= 50 &&
            (2 == this.carril || 1 == this.carril || 3 == this.carril) &&
            0 == this.tipoNota &&
            ((this.porcentajes.children[4].enabled = !0),
            (_coreSystem.currentPorcentaje = 5));
          break;
        case 5:
          t >= 60 &&
            (2 == this.carril || 1 == this.carril || 3 == this.carril) &&
            0 == this.tipoNota &&
            ((this.porcentajes.children[5].enabled = !0),
            (_coreSystem.currentPorcentaje = 6));
          break;
        case 6:
          t >= 70 &&
            (2 == this.carril || 1 == this.carril || 3 == this.carril) &&
            0 == this.tipoNota &&
            ((this.porcentajes.children[6].enabled = !0),
            (_coreSystem.currentPorcentaje = 7));
          break;
        case 7:
          t >= 80 &&
            (2 == this.carril || 1 == this.carril || 3 == this.carril) &&
            0 == this.tipoNota &&
            ((this.porcentajes.children[7].enabled = !0),
            (_coreSystem.currentPorcentaje = 8));
          break;
        case 8:
          t >= 90 &&
            (2 == this.carril || 1 == this.carril || 3 == this.carril) &&
            0 == this.tipoNota &&
            ((this.porcentajes.children[8].enabled = !0),
            (_coreSystem.currentPorcentaje = 9));
          break;
        case 9:
          t >= 99.9 &&
            0 == this.tipoNota &&
            ((this.porcentajes.children[9].enabled = !0),
            (_coreSystem.currentPorcentaje = 10));
      }
  }),
  (Nota.prototype.apagaEndless = function () {
    (this.entity.children[2].enabled = !1),
      (this.entity.children[3].enabled = !1),
      (this.entity.children[4].enabled = !1),
      (this.entity.children[5].enabled = !1);
    for (var t = this.entity.children[2].getLocalPosition(), e = 2; e <= 5; e++)
      this.entity.children[e].setLocalPosition(0, 0, t.z);
  }),
  (Nota.prototype.prendeEndless = function (t) {
    this.entity.children[t].enabled = !0;
    var e = this.entity.children[2].getLocalPosition();
    this.entity.children[t].setLocalPosition(
      e.x - this.carriles[this.carril],
      0,
      e.z
    );
  }),
  (Nota.prototype.setValues = function (t, e, i, s, a, o, r, n) {
    null != this.tweenMov && this.tweenMov.stop(),
      0 == this.index && this.apagaEndless(),
      (this.tiempo = t),
      (this.carril = e - 1),
      (this.notaMov = a),
      (this.conGema = r),
      (this.sentido = o),
      (this.notaBuena.enabled = !1),
      (this.notaMala.enabled = !1),
      (this.gema.enabled = !1),
      0 == i
        ? ((this.tipoNota = i),
          (this.notaBuena.enabled = !1),
          reproduceAnim(this.notaBuena, 0),
          (this.nota = this.notaBuena))
        : ((this.tipoNota = 1),
          (this.notaMala.enabled = !1),
          (this.nota = this.notaMala)),
      (this.ID = s);
    for (var c = 0; c < this.porcentajes.children.length; c++)
      this.porcentajes.children[c].enabled = !1;
    this.setPorcentaje();
    var h = this.entity.getPosition();
    this.entity.setPosition(this.carriles[this.carril], h.y, notaStart + n),
      1 == this.conGema &&
        ((this.gema.enabled = !0), (this.gema.model.enabled = !0)),
      (this.fase = 1);
  }),
  (Nota.prototype.preparaNota = function () {
    this.fase = 2;
  }),
  (Nota.prototype.cambiaFase = function () {
    (this.inicioFase2 = this.entity.getPosition().clone()),
      (this.destinoFase2 = new pc.Vec3(
        this.inicioFase2.x,
        this.inicioFase2.y,
        _coreSystem.player.getPosition().z
      ));
    var t = Math.abs(this.inicioFase2.z - this.destinoFase2.z);
    (this.velocidadFase2 = t / tiempoNotaLLegadaFase2),
      (this.fase = 2),
      (this.velocidad = this.velocidadFase2);
  }),
  (Nota.prototype.update = function (t) {
    if (!gameOver && 0 != this.fase) {
      if (
        _coreSystem.player.getPosition().distance(this.entity.getPosition()) <=
          50 &&
        1 == this.fase
      ) {
        if (
          ((this.nota.enabled = !0), -1 != currentCancionAux && 0 == this.ID)
        ) {
          var e = _coreSystem.getCancionFase();
          e > 2 ? this.prendeEndless(5) : this.prendeEndless(e + 2);
        }
        (this.fase = 2), this.entity.translate(0, 0, 48);
        var i = this.entity.getLocalPosition();
        0 == this.tipoNota && reproduceAnim(this.nota, 0),
          null != this.tweenMov && this.tweenMov.stop(),
          (this.tweenMov = this.entity
            .tween(this.entity.getLocalPosition())
            .to(new pc.Vec3(i.x, i.y, i.z - 48), 1, pc.Linear)
            .start());
      }
      if (this.fase > 0)
        if (0 == this.notaMov) this.entity.translateLocal(0, 0, 0);
        else
          this.entity.translateLocal(
            t * this.velocidadMov * this.sentido,
            0,
            0
          ),
            (i = this.entity.getPosition()).x >= this.carriles[4]
              ? (this.entity.setPosition(this.carriles[4], i.y, i.z),
                (this.sentido = -1))
              : i.x <= this.carriles[0] &&
                (this.entity.setPosition(this.carriles[0], i.y, i.z),
                (this.sentido = 1));
      i = this.entity.getPosition();
      _coreSystem.player.getPosition().z - i.z >= distMataNota &&
        this.mataNota("porMiss");
    }
  }),
  (Nota.prototype.mataNota = function (t) {
    "porMiss" == t
      ? ((this.fase = 0), reproduceAnim(this.notaBuena, 0), this.resetNota())
      : "perfect" == t
      ? (this.scoreMSG.script.scoreNumerosManager.poneNumero("/"),
        _coreSystem.addScore(1),
        _coreSystem.addCombo(1),
        _coreSystem.addScore(_coreSystem.combo),
        this.comboMSG.script.scoreNumerosManager.poneNumero(
          "+" + _coreSystem.combo
        ),
        reproduceAnim(this.notaBuena, 2),
        1 == this.conGema &&
          (playSound("comeDiamante"),
          (_coreSystem.gemas = _coreSystem.gemas + 1),
          (_coreSystem.gemasInGame = _coreSystem.gemasInGame + 1),
          _menu.setGema(_coreSystem.gemas),
          (this.gema.model.enabled = !1),
          reproduceParticulas(this.particulas, 1200)))
      : "gema" == t
      ? (reproduceAnim(this.notaBuena, 1),
        this.scoreMSG.script.scoreNumerosManager.poneNumero("/"),
        _coreSystem.addScore(1),
        _coreSystem.addCombo(-1),
        1 == this.conGema &&
          (playSound("comeDiamante"),
          (_coreSystem.gemas = _coreSystem.gemas + 1),
          (_coreSystem.gemasInGame = _coreSystem.gemasInGame + 1),
          _menu.setGema(_coreSystem.gemas),
          (this.gema.model.enabled = !1),
          reproduceParticulas(this.particulas, 1200)))
      : "hit" == t &&
        (reproduceAnim(this.notaBuena, 1),
        this.scoreMSG.script.scoreNumerosManager.poneNumero("/"),
        _coreSystem.addScore(1),
        _coreSystem.addCombo(-1),
        this.conGema);
  }),
  (Nota.prototype.resetNota = function () {
    var t = _coreSystem.currentNota,
      e = _coreSystem.cancion;
    t == e.length ||
      (-1 != currentCancionAux && 0 == this.ID && this.apagaEndless(),
      this.setValues(
        e[t][0],
        e[t][1],
        e[t][2],
        t,
        e[t][3],
        e[t][4],
        e[t][5],
        e[t][6]
      ),
      (t += 1),
      (_coreSystem.currentNota = t));
  });
var Menu = pc.createScript("menu");
Menu.attributes.add("gemasMC", { type: "entity" }),
  Menu.attributes.add("scoreMC", { type: "entity" }),
  Menu.attributes.add("pauseMC", { type: "entity" }),
  Menu.attributes.add("settingsMC", { type: "entity" }),
  Menu.attributes.add("logoMC", { type: "entity" }),
  Menu.attributes.add("discosMC", { type: "entity" }),
  Menu.attributes.add("loadingMC", { type: "entity" }),
  Menu.attributes.add("manoMC", { type: "entity" }),
  Menu.attributes.add("izqb", { type: "entity" }),
  Menu.attributes.add("derb", { type: "entity" }),
  Menu.attributes.add("playb", { type: "entity" }),
  Menu.attributes.add("puntos", { type: "entity" }),
  Menu.attributes.add("skinbMC", { type: "entity" }),
  Menu.attributes.add("skinsPanelMC", { type: "entity" }),
  Menu.attributes.add("barraSwipeMC", { type: "entity" }),
  Menu.attributes.add("manoSwipeMC", { type: "entity" }),
  Menu.attributes.add("settingsPanelMC", { type: "entity" }),
  Menu.attributes.add("pausePanelMC", { type: "entity" }),
  Menu.attributes.add("continuePanelMC", { type: "entity" }),
  Menu.attributes.add("endingWinPanelMC", { type: "entity" }),
  Menu.attributes.add("endingLoosePanelMC", { type: "entity" }),
  Menu.attributes.add("endingFondo3D", { type: "entity" }),
  Menu.attributes.add("stages", { type: "entity" }),
  Menu.attributes.add("playerSkins", { type: "entity", array: !0 }),
  Menu.attributes.add("tutorialPanelMC", { type: "entity" }),
  Menu.attributes.add("countMC", { type: "entity" }),
  Menu.attributes.add("msgBeatIni", { type: "entity" }),
  Menu.attributes.add("msgBeatEnd", { type: "entity" }),
  Menu.attributes.add("vidasMC", { type: "entity" }),
  Menu.attributes.add("rewardPanelAd", { type: "entity" }),
  (Menu.prototype.initialize = function () {
    (_app = this.app),
      (_menu = this),
      (rewardPanelAd = this.rewardPanelAd),
      (this.hiloSwipeMano = null),
      getAllVars(),
      (this.hiloMano = null),
      (this.hiloDisco = null),
      addEventFunction(this.izqb, !0, 1, this.clickIzq.bind(this)),
      addEventFunction(this.derb, !0, 1, this.clickDer.bind(this)),
      addEventFunction(this.playb, !0, 1, this.clickStart.bind(this)),
      (this.enAnim = !1),
      this.poneTutoFast(!1),
      this.discosMC.rotateLocal(0, 0, 45 * currentCancion),
      addEventFunction(this.skinbMC, !0, 1, this.clickSkins.bind(this)),
      addEventFunction(this.settingsMC, !0, 1, this.clickSettings.bind(this)),
      addEventFunction(this.pauseMC, !0, 1, this.clickPause.bind(this)),
      setTimeout(function () {}.bind(this), 200),
      enGoogle &&
        (console.log("SE llamara a gamesnack READY"),
        GameSnacks.game.ready(),
        GameSnacks.audio.subscribe((e) => {
          if (
            (console.log(
              "dentro del subcribe audio de google tenemos el audio enabled?? " +
                e
            ),
            e)
          ) {
            currentMute = 0;
            var n = this.pausePanelMC.findByName("muteb");
            mutear(0, n, !1),
              (n = this.settingsPanelMC.findByName("muteb_settings")),
              mutear(0, n, !1);
          } else {
            currentMute = 1;
            n = this.pausePanelMC.findByName("muteb");
            mutear(1, n, !1),
              (n = this.settingsPanelMC.findByName("muteb_settings")),
              mutear(1, n, !1);
          }
        })),
      this.audioChange();
  }),
  (Menu.prototype.poneTutoFast = function (e) {
    (this.barraSwipeMC.enabled = e),
      (this.manoSwipeMC.enabled = e),
      console.log("LLAMAMOS A PONE TUTO FAST CON ORDEN " + e),
      e &&
        (this.manoSwipeMC.setPosition(0, this.manoSwipeMC.getPosition().y, 0),
        addEventFunction(this.barraSwipeMC.children[1], !1),
        addEventFunction(this.barraSwipeMC.children[1], !0, 1, () => {
          playSound("click"),
            addEventFunction(this.barraSwipeMC.children[1], !1),
            this.poneTutoFast(!1),
            _coreSystem.restart(),
            (permitirPause = !0);
        }));
  }),
  (Menu.prototype.setMenu = function () {
    (this.gemasMC.enabled = !0),
      (this.settingsMC.enabled = !0),
      (this.logoMC.enabled = !0),
      (this.discosMC.enabled = !0),
      (this.skinbMC.enabled = !0),
      (this.manoMC.enabled = !1),
      (this.endingFondo3D.enabled = !1),
      (this.stages.enabled = !0),
      (this.puntos.enabled = !0),
      (this.playb.enabled = !0),
      (this.izqb.enabled = !0),
      (this.derb.enabled = !0),
      this.configCancion(),
      reproduceAnim(this.discosMC, 0, 1, null, null, !0),
      (gameOver = !1),
      (enMenu = !0),
      this.setGema(_coreSystem.gemas);
  }),
  (Menu.prototype.hideMenu = function () {
    (this.manoMC.enabled = !1),
      (this.gemasMC.enabled = !1),
      (this.settingsMC.enabled = !1),
      (this.logoMC.enabled = !1),
      (this.discosMC.enabled = !1),
      (this.skinbMC.enabled = !1),
      (this.puntos.enabled = !1),
      (this.playb.enabled = !1),
      (this.izqb.enabled = !1),
      (this.derb.enabled = !1),
      (enMenu = !1);
  }),
  (Menu.prototype.setInGame = function () {
    (this.gemasMC.enabled = !0),
      (this.pauseMC.enabled = !0),
      (this.scoreMC.enabled = !0),
      (this.vidasMC.enabled = !0),
      this.setGema(_coreSystem.gemas),
      this.setScore(_coreSystem.score);
  }),
  (Menu.prototype.hideInGame = function () {
    (this.gemasMC.enabled = !1),
      (this.pauseMC.enabled = !1),
      (this.scoreMC.enabled = !1),
      (this.vidasMC.enabled = !1);
  }),
  (Menu.prototype.setScore = function (e) {
    this.scoreMC.children[0].element.text = "" + e;
  }),
  (Menu.prototype.setGema = function (e) {
    (this.gemasMC.children[0].element.text = "" + e), guardaVars(e, "gemas");
  }),
  (Menu.prototype.update = function (e) {}),
  (Menu.prototype.setPunto = function () {
    for (var e = 0; e < totalCanciones; e++)
      this.puntos.children[e].children[1].enabled = !1;
    this.puntos.children[currentCancion].children[1].enabled = !0;
  }),
  (Menu.prototype.configVidas = function () {
    for (var e = 0; e < totalVidas; e++)
      this.vidasMC.children[e].children[1].enabled = !1;
    for (e = 0; e < currentVidas; e++)
      this.vidasMC.children[e].children[1].enabled = !0;
  }),
  (Menu.prototype.configCancion = function () {
    (this.msgBeatEnd.enabled = !1), (this.msgBeatIni.enabled = !1);
    for (var e = 0; e < totalCanciones; e++)
      (this.discosMC.children[e].script.text.text = arrayCanciones[e][3] + ""),
        e > 3 &&
          ((this.discosMC.children[e + 4].enabled = !1),
          0 == arrayCanciones[e][4] &&
            ((this.discosMC.children[e + 4].enabled = !0),
            e == currentCancion &&
              (this.endingFondo3D.enabled
                ? (this.msgBeatEnd.enabled = !0)
                : (this.msgBeatIni.enabled = !0))));
    this.setPunto(),
      null != this.hiloMano && this.hiloMano.stop(),
      1 == arrayCanciones[currentCancion][4] && this.activaAnimMano(),
      null != this.hiloDisco && this.hiloDisco.stop(),
      (this.izqb.enabled = !0),
      (this.derb.enabled = !0),
      (currentMusic = "prev" + (currentCancion + 1)),
      playSound(currentMusic, !0);
    for (e = 0; e < this.stages.children.length; e++)
      this.stages.children[e].enabled = !1;
    console.log("Stage" + (currentCancion + 1)),
      (this.stages.findByName("Stage" + (currentCancion + 1)).enabled = !0);
  }),
  (Menu.prototype.activaAnimMano = function () {
    this.enAnim ||
      (this.hiloMano = this.entity
        .tween(this.entity.getLocalPosition())
        .to(this.entity.getLocalPosition(), 3, pc.Linear)
        .onComplete(() => {
          (this.manoMC.enabled = !0),
            reproduceAnim(this.manoMC, 0),
            this.manoMC.script.animaAlfa3d.empiezaAnim(0, 1),
            (this.hiloMano = this.entity
              .tween(this.entity.getLocalPosition())
              .to(this.entity.getLocalPosition(), 1, pc.Linear)
              .onComplete(() => {
                this.manoMC.script.animaAlfa3d.empiezaAnim(1, 0),
                  this.activaAnimMano();
              })
              .start());
        })
        .start());
  }),
  (Menu.prototype.clickDer = function () {
    if (!this.enAnim) {
      (this.enAnim = !0),
        null != this.hiloMano && this.hiloMano.stop(),
        (this.manoMC.enabled = !1),
        (this.izqb.enabled = !1),
        (this.derb.enabled = !1),
        (currentCancion += 1),
        currentCancion == totalCanciones && (currentCancion = 0),
        guardaVars(currentCancion, "currentCancion"),
        playSound("cambiaDisco"),
        _musicas.slot(currentMusic).stop(),
        this.setPunto(),
        (this.msgBeatIni.enabled = !1),
        (this.msgBeatEnd.enabled = !1),
        (this.endingWinPanelMC.findByName("complete").enabled = !1);
      var e = { x: 0 },
        n = 0;
      this.hiloDisco = this.app
        .tween(e)
        .to({ x: 45 }, 0.5, pc.SineOut)
        .onComplete(() => {
          (this.enAnim = !1), this.configCancion();
        })
        .onUpdate(() => {
          this.discosMC.rotateLocal(0, 0, e.x - n), (n = e.x);
        })
        .start();
    }
  }),
  (Menu.prototype.clickIzq = function () {
    if (!this.enAnim) {
      (this.enAnim = !0),
        (this.endingWinPanelMC.findByName("complete").enabled = !1),
        null != this.hiloMano && this.hiloMano.stop(),
        (this.manoMC.enabled = !1),
        (this.izqb.enabled = !1),
        (this.derb.enabled = !1),
        (currentCancion -= 1),
        currentCancion < 0 && (currentCancion = totalCanciones - 1),
        guardaVars(currentCancion, "currentCancion"),
        playSound("cambiaDisco"),
        _musicas.slot(currentMusic).stop(),
        (this.msgBeatIni.enabled = !1),
        (this.msgBeatEnd.enabled = !1),
        this.setPunto();
      var e = { x: 0 },
        n = 0;
      this.hiloDisco = this.app
        .tween(e)
        .to({ x: -45 }, 0.5, pc.SineOut)
        .onComplete(() => {
          (this.enAnim = !1), this.configCancion();
        })
        .onUpdate(() => {
          this.discosMC.rotateLocal(0, 0, e.x - n), (n = e.x);
        })
        .start();
    }
  }),
  (Menu.prototype.clickStart = function () {
    if (!this.enAnim)
      if (0 != tutorialMostrado) {
        if (0 != arrayCanciones[currentCancion][4]) {
          null != this.hiloMano && this.hiloMano.stop(),
            reproduceAnim(this.discosMC, 2),
            (this.enAnim = !0),
            (this.manoMC.enabled = !1),
            (this.izqb.enabled = !1),
            (this.derb.enabled = !1),
            playSound("start"),
            _musicas.slot(currentMusic).stop();
          this.hiloDisco = this.app
            .tween({ x: 0 })
            .to({ x: 45 }, 0.45, pc.SineOut)
            .onComplete(() => {
              (this.enAnim = !1),
                this.hideMenu(),
                (this.loadingMC.enabled = !0),
                this.loadingMC.script.alphaConVelocidad.fadeIn(
                  function () {
                    cargaMusica(
                      urlBaseAssets,
                      currentCancion + 1,
                      this.callBackStart.bind(this)
                    );
                  }.bind(this)
                );
            })
            .start();
          for (var e = 0; e < totalCanciones; e++)
            this.discosMC.children[e].script.text.text = "";
        }
      } else this.clickBotonTutorial("inicial", 0);
  }),
  (Menu.prototype.callBackStart = function () {
    this.loadingMC.script.alphaConVelocidad.fadeOut(),
      setTimeout(
        function () {
          this.poneTutoFast(!0),
            _coreSystem.destruyeTodo(),
            (this.loadingMC.enabled = !1),
            (this.enAnim = !1);
        }.bind(this),
        100
      ),
      clearInterval(this.hiloSwipeMano);
  }),
  (Menu.prototype.clickSkins = function () {
    playSound("click"),
      (this.skinbMC.enabled = !1),
      (this.skinsPanelMC.enabled = !0),
      this.eventosSkins();
  }),
  (Menu.prototype.cerrarMenuSkins = function () {
    playSound("click"),
      this.sacaEventosSkins(),
      (this.skinsPanelMC.enabled = !1),
      (this.skinbMC.enabled = !0);
  }),
  (Menu.prototype.eventosSkins = function () {
    for (var e = 0, n = 0; n < numSkins; n++) {
      var t = this.skinsPanelMC.findByName("skin" + (n + 1)),
        i = t.children[0],
        a = t.children[1],
        s = t.children[2];
      (i.enabled = !1),
        (a.enabled = !1),
        (s.enabled = !1),
        0 == pelotasInfo[n][0]
          ? ((i.enabled = !0),
            (i.children[0].element.text = pelotasInfo[n][1]),
            (s.enabled = !0))
          : (e += 1),
        n == currentSkin && (a.enabled = !0),
        addEventFunction(t, !0, 1, this.clickSkin.bind(this, n));
    }
    var o = this.skinsPanelMC.findByName("barra");
    this.skinsPanelMC.findByName("infot").element.text = e + "/" + numSkins;
    var r = (1 / (numSkins - 0)) * (e - 0) + 0;
    o.setLocalScale(r, 1, 1);
    var d = this.skinsPanelMC.findByName("cerrarb");
    addEventFunction(d, !0, 1, this.cerrarMenuSkins.bind(this));
    var l = this.skinsPanelMC.findByName("cerrarAllb");
    addEventFunction(l, !0, 1, this.cerrarMenuSkins.bind(this));
  }),
  (Menu.prototype.sacaEventosSkins = function () {
    for (var e = 0; e < numSkins; e++) {
      var n = this.skinsPanelMC.findByName("skin" + (e + 1));
      addEventFunction(n, !1);
    }
    var t = this.skinsPanelMC.findByName("cerrarb");
    addEventFunction(t, !1);
    var i = this.skinsPanelMC.findByName("cerrarAllb");
    addEventFunction(i, !1);
  }),
  (Menu.prototype.clickSkin = function (e) {
    1 == pelotasInfo[e][0]
      ? (playSound("click"),
        (currentSkin = e),
        guardaVars(currentSkin, "currentSkin"),
        this.setSkin(),
        this.sacaEventosSkins(),
        this.eventosSkins())
      : 0 == pelotasInfo[e][0] &&
        (_coreSystem.gemas >= pelotasInfo[e][1]
          ? (playSound("compra"),
            (pelotasInfo[e][0] = 1),
            guardaVars(pelotasInfo[e][0], "pelotasInfo_" + (e + 1) + "_unlock"),
            (currentSkin = e),
            guardaVars(currentSkin, "currentSkin"),
            (_coreSystem.gemas = _coreSystem.gemas - pelotasInfo[e][1]),
            (gemas = _coreSystem.gemas),
            this.setGema(_coreSystem.gemas),
            this.setSkin(),
            this.sacaEventosSkins(),
            this.eventosSkins())
          : playSound("noCoins"));
  }),
  (Menu.prototype.setSkin = function () {
    for (var e = 0; e < numSkins; e++) this.playerSkins[e].enabled = !1;
    (this.playerSkins[currentSkin].enabled = !0),
      null == this.playerSkins[currentSkin].model
        ? (this.playerSkins[currentSkin].children[1].model.enabled = !1)
        : (this.playerSkins[currentSkin].model.enabled = !1);
  }),
  (Menu.prototype.clickSettings = function () {
    playSound("click"), (this.settingsPanelMC.enabled = !0);
    var e = this.settingsPanelMC.findByName("cerrarb_settings"),
      n = this.settingsPanelMC.findByName("cerrarAllb_settings"),
      t = this.settingsPanelMC.findByName("muteb_settings"),
      i = this.settingsPanelMC.findByName("botonTuto_settings");
    if (
      (addEventFunction(t, !0, 1, this.clickBotonMute.bind(this, t)),
      addEventFunction(i, !0, 1, this.clickBotonTutorial.bind(this, "main", 0)),
      addEventFunction(e, !0, 1, this.clickCerrarSettings.bind(this)),
      addEventFunction(n, !0, 1, this.clickCerrarSettings.bind(this)),
      0 == mute)
    ) {
      t = this.pausePanelMC.findByName("muteb");
      mutear(0, t, !0),
        (t = this.settingsPanelMC.findByName("muteb_settings")),
        mutear(0, t, !0);
    } else {
      t = this.pausePanelMC.findByName("muteb");
      mutear(1, t, !0),
        (t = this.settingsPanelMC.findByName("muteb_settings")),
        mutear(1, t, !0);
    }
  }),
  (Menu.prototype.clickSettingsEndGame = function () {
    playSound("click"), (this.settingsPanel.enabled = !0);
    var e = this.settingsPanel.findByName("cerrarb_settings"),
      n = this.settingsPanel.findByName("cerrarAllb_settings"),
      t = this.settingsPanel.findByName("muteb_settings"),
      i = this.settingsPanel.findByName("botonTuto_settings"),
      a = this.settingsPanel.findByName("homeb");
    if (
      ((a.enabled = !0),
      addEventFunction(t, !0, 1, this.clickBotonMute.bind(this, t)),
      addEventFunction(i, !0, 1, this.clickBotonTutorial.bind(this, "end")),
      addEventFunction(e, !0, 1, this.clickCerrarSettingsEndGame.bind(this)),
      addEventFunction(n, !0, 1, this.clickCerrarSettingsEndGame.bind(this)),
      addEventFunction(a, !0, 1, this.endGameEnd.bind(this, "home")),
      (this.screen2D.findByName("PanelEnd").enabled = !1),
      0 == mute)
    ) {
      t = this.pausePanelMC.findByName("muteb");
      mutear(0, t, !0),
        (t = this.settingsPanelMC.findByName("muteb_settings")),
        mutear(0, t, !0);
    } else {
      t = this.pausePanelMC.findByName("muteb");
      mutear(1, t, !0),
        (t = this.settingsPanelMC.findByName("muteb_settings")),
        mutear(1, t, !0);
    }
  }),
  (Menu.prototype.clickCerrarSettings = function () {
    playSound("click");
    var e = this.settingsPanelMC.findByName("cerrarb_settings"),
      n = this.settingsPanelMC.findByName("cerrarAllb_settings"),
      t = this.settingsPanelMC.findByName("muteb_settings"),
      i = this.settingsPanelMC.findByName("botonTuto_settings");
    addEventFunction(t, !1),
      addEventFunction(i, !1),
      addEventFunction(e, !1),
      addEventFunction(n, !1),
      (this.settingsPanelMC.enabled = !1);
  }),
  (Menu.prototype.clickCerrarSettingsEndGame = function () {
    playSound("click");
    var e = this.settingsPanelMC.findByName("cerrarb_settings"),
      n = this.settingsPanelMC.findByName("cerrarAllb_settings"),
      t = this.settingsPanelMC.findByName("muteb_settings"),
      i = this.settingsPanelMC.findByName("botonTuto_settings"),
      a = this.settingsPanelMC.findByName("homeb");
    (a.enabled = !1),
      addEventFunction(t, !1),
      addEventFunction(i, !1),
      addEventFunction(e, !1),
      addEventFunction(n, !1),
      addEventFunction(a, !1),
      (this.settingsPanelMC.enabled = !1);
  }),
  (Menu.prototype.clickBotonMute = function (e) {
    (enGoogle ? GameSnacks.audio.isEnabled() : volumeMaster) &&
      (0 == mute ? mutear(1, e, !1) : mutear(0, e, !1), playSound("click"));
  }),
  (Menu.prototype.clickBotonTutorial = function (e, n) {
    this.hideMenu(),
      playSound("click"),
      "main" == e
        ? (this.settingsPanelMC.enabled = !1)
        : "inGame" == e &&
          ((this.pausePanelMC.enabled = !1),
          (this.app.timeScale = 1),
          this.hideInGame()),
      (this.tutorialPanelMC.enabled = !0);
    var t = this.tutorialPanelMC.findByName("leftb"),
      i = this.tutorialPanelMC.findByName("rightb"),
      a = this.tutorialPanelMC.findByName("puntos"),
      s = this.tutorialPanelMC.findByName("info1"),
      o = this.tutorialPanelMC.findByName("barraSwipe"),
      r = this.tutorialPanelMC.findByName("mano"),
      d = this.tutorialPanelMC.findByName("info2"),
      l = this.tutorialPanelMC.findByName("info3"),
      c = this.tutorialPanelMC.findByName("info4"),
      u = this.tutorialPanelMC.findByName("info5"),
      h = this.tutorialPanelMC.findByName("cerrarb"),
      m = this.tutorialPanelMC.findByName("playb");
    addEventFunction(t, !1),
      addEventFunction(i, !1),
      addEventFunction(h, !1),
      addEventFunction(m, !1),
      addEventFunction(t, !0, 1, this.clickBotonTutorial.bind(this, e, n - 1)),
      addEventFunction(i, !0, 1, this.clickBotonTutorial.bind(this, e, n + 1)),
      addEventFunction(h, !0, 1, this.clickCerrarTutorial.bind(this, e)),
      addEventFunction(m, !0, 1, this.clickCerrarTutorial.bind(this, e)),
      (h.enabled = !1),
      (m.enabled = !1),
      (s.enabled = !1),
      (o.enabled = !1),
      (r.enabled = !1),
      (d.enabled = !1),
      (l.enabled = !1),
      (c.enabled = !1),
      (u.enabled = !1);
    for (var b = 0; b < a.children.length - 1; b++)
      a.children[b].children[1].enabled = !1;
    (a.children[n].children[1].enabled = !0),
      (h.enabled = !0),
      0 == n
        ? ((t.enabled = !1),
          (i.enabled = !0),
          (s.enabled = !0),
          (d.enabled = !0),
          (o.enabled = !0),
          (r.enabled = !0))
        : 3 == n
        ? ((t.enabled = !0),
          (i.enabled = !1),
          "main" == e || "inGame" == e
            ? (h.enabled = !0)
            : "inicial" == e && (m.enabled = !0),
          (u.enabled = !0))
        : (2 == n ? (c.enabled = !0) : 1 == n && (l.enabled = !0),
          (t.enabled = !0),
          (i.enabled = !0));
  }),
  (Menu.prototype.clickCerrarTutorial = function (e) {
    var n = this.tutorialPanelMC.findByName("leftb"),
      t = this.tutorialPanelMC.findByName("rightb"),
      i = this.tutorialPanelMC.findByName("puntos"),
      a = this.tutorialPanelMC.findByName("info1"),
      s = this.tutorialPanelMC.findByName("barraSwipe"),
      o = this.tutorialPanelMC.findByName("mano"),
      r = this.tutorialPanelMC.findByName("info2"),
      d = this.tutorialPanelMC.findByName("info3"),
      l = this.tutorialPanelMC.findByName("cerrarb"),
      c = this.tutorialPanelMC.findByName("playb");
    (n.enabled = !0),
      (t.enabled = !0),
      (i.enabled = !0),
      (a.enabled = !0),
      (s.enabled = !0),
      (o.enabled = !0),
      (r.enabled = !0),
      (d.enabled = !0),
      (l.enabled = !0),
      (c.enabled = !0),
      addEventFunction(n, !1),
      addEventFunction(t, !1),
      addEventFunction(l, !1),
      addEventFunction(c, !1),
      "inicial" == e
        ? ((tutorialMostrado = 1),
          guardaVars(tutorialMostrado, "tutorialMostrado"),
          this.clickStart())
        : "main" == e
        ? (playSound("click"),
          (this.settingsPanelMC.enabled = !0),
          this.setMenu())
        : "inGame" == e &&
          ((this.pausePanelMC.enabled = !0),
          this.setInGame(),
          (this.app.timeScale = 0),
          playSound("click")),
      (this.tutorialPanelMC.enabled = !1);
  }),
  (Menu.prototype.clickPause = function () {
    if (!pause && !gameOver) {
      (permitirPause = !1), (this.pausePanelMC.enabled = !0), (enPausa = !0);
      var e = this.pausePanelMC.findByName("resumeb"),
        n = this.pausePanelMC.findByName("endgameb"),
        t = this.pausePanelMC.findByName("retryb"),
        i = this.pausePanelMC.findByName("botonTuto"),
        a = this.pausePanelMC.findByName("muteb");
      if (
        (addEventFunction(e, !0, 1, this.resumePause.bind(this)),
        addEventFunction(n, !0, 1, this.endGamePause.bind(this, "home")),
        addEventFunction(t, !0, 1, this.endGamePause.bind(this, "retry")),
        addEventFunction(a, !0, 1, this.clickBotonMute.bind(this, a)),
        addEventFunction(
          i,
          !0,
          1,
          this.clickBotonTutorial.bind(this, "inGame", 0)
        ),
        (pause = !0),
        playSound("click"),
        (this.app.timeScale = 0),
        _musicas.pause(currentMusic),
        0 == mute)
      ) {
        var s = this.pausePanelMC.findByName("muteb");
        mutear(0, s, !0),
          (s = this.settingsPanelMC.findByName("muteb_settings")),
          mutear(0, s, !0);
      } else {
        s = this.pausePanelMC.findByName("muteb");
        mutear(1, s, !0),
          (s = this.settingsPanelMC.findByName("muteb_settings")),
          mutear(1, s, !0);
      }
    }
  }),
  (Menu.prototype.resumePause = function () {
    var e = this.pausePanelMC.findByName("resumeb"),
      n = this.pausePanelMC.findByName("endgameb"),
      t = this.pausePanelMC.findByName("retryb"),
      i = this.pausePanelMC.findByName("botonTuto"),
      a = this.pausePanelMC.findByName("muteb");
    addEventFunction(e, !1),
      addEventFunction(n, !1),
      addEventFunction(t, !1),
      addEventFunction(i, !1),
      addEventFunction(a, !1),
      playSound("click"),
      (this.app.timeScale = 1),
      (this.pausePanelMC.enabled = !1),
      (enPausa = !1),
      (permitirPause = !1),
      this.setCounter(
        0,
        3,
        function () {
          (pause = !1),
            _musicas.resume(this.currentSong),
            (permitirPause = !0),
            this.poneTutoFast(!1);
        }.bind(this)
      ),
      clearInterval(this.hiloSwipeMano),
      this.poneTutoFast(!0);
  }),
  (Menu.prototype.endGamePause = function (e) {
    (() => {
      permitirPause = !1;
      var n = this.pausePanelMC.findByName("resumeb"),
        t = this.pausePanelMC.findByName("endgameb"),
        i = this.pausePanelMC.findByName("retryb"),
        a = this.pausePanelMC.findByName("botonTuto"),
        s = this.pausePanelMC.findByName("muteb");
      if (
        (addEventFunction(n, !1),
        addEventFunction(t, !1),
        addEventFunction(i, !1),
        addEventFunction(a, !1),
        addEventFunction(s, !1),
        playSound("click"),
        (pause = !1),
        (enPausa = !1),
        (this.app.timeScale = 1),
        (this.pausePanelMC.enabled = !1),
        enGoogle &&
          (console.log("Se setea Gamesnack gameOver "),
          GameSnacks.game.gameOver()),
        "retry" == e)
      ) {
        var o = this.getCancion();
        console.log("APRETE RETRY CANCION RQ"),
          (gameOver = !0),
          _rebote.matarBola(!1),
          _coreSystem.player.setPosition(_coreSystem.posInicial),
          _coreSystem.player.children[0].setLocalPosition(0, 0, 0),
          _coreSystem.moveCamera(0.016),
          _coreSystem.player.children[0].children[
            currentSkin
          ].children[0].script.ribbon.clearOld(),
          _coreSystem.player.children[0].children[
            currentSkin
          ].children[0].script.ribbon.reset(),
          _coreSystem.player.children[0].children[
            currentSkin
          ].children[0].script.ribbon.hideShadder(),
          (espera = 0),
          (currentCancionAux = -1),
          (_coreSystem.cancionFase = 0),
          _coreSystem.defaultAnims(),
          (_coreSystem.NOTAS_ARRAY.enabled = !1),
          null == this.playerSkins[currentSkin].model
            ? (this.playerSkins[currentSkin].children[1].model.enabled = !1)
            : (this.playerSkins[currentSkin].model.enabled = !1),
          _coreSystem.apagaMusicas(),
          (_coreSystem.tiempoCancionStart = -1),
          (espera = 0),
          (currentCancion = o),
          (currentCancionAux = -1),
          (_coreSystem.cancionFase = 0),
          _coreSystem.destruyeTodo(),
          this.poneTutoFast(!0);
      } else {
        playSound("click");
        o = this.getCancion();
        (currentCancion = o),
          (gameOver = !0),
          _rebote.matarBola(!1),
          _coreSystem.player.setPosition(_coreSystem.posInicial),
          _coreSystem.player.children[0].setLocalPosition(0, 0, 0),
          _coreSystem.moveCamera(0.016),
          _coreSystem.player.children[0].children[
            currentSkin
          ].children[0].script.ribbon.clearOld(),
          _coreSystem.player.children[0].children[
            currentSkin
          ].children[0].script.ribbon.reset(),
          _coreSystem.player.children[0].children[
            currentSkin
          ].children[0].script.ribbon.hideShadder(),
          (espera = 0),
          (currentCancionAux = -1),
          (_coreSystem.cancionFase = 0),
          _coreSystem.defaultAnims(),
          (_coreSystem.NOTAS_ARRAY.enabled = !1),
          null == this.playerSkins[currentSkin].model
            ? (this.playerSkins[currentSkin].children[1].model.enabled = !1)
            : (this.playerSkins[currentSkin].model.enabled = !1),
          _coreSystem.apagaMusicas(),
          (_coreSystem.tiempoCancionStart = -1),
          this.hideInGame(),
          this.setMenu();
      }
    })();
  }),
  (Menu.prototype.endGameEnd = function (e) {
    this.clickCerrarSettingsEndGame(),
      (pause = !1),
      (enPausa = !1),
      (this.app.timeScale = 1);
    var n = this.pausePanelMC.findByName("resumeb"),
      t = this.pausePanelMC.findByName("endgameb"),
      i = this.pausePanelMC.findByName("retryb"),
      a = this.pausePanelMC.findByName("botonTuto"),
      s = this.pausePanelMC.findByName("muteb");
    addEventFunction(n, !1),
      addEventFunction(t, !1),
      addEventFunction(i, !1),
      addEventFunction(a, !1),
      addEventFunction(s, !1),
      (this.pausePanelMC.enabled = !1);
  }),
  (Menu.prototype.terminaCancion = function (e) {
    _coreSystem.player.setPosition(_coreSystem.posInicial),
      _coreSystem.player.children[0].setLocalPosition(0, 0, 0),
      _coreSystem.moveCamera(0.016),
      _coreSystem.player.children[0].children[
        currentSkin
      ].children[0].script.ribbon.clearOld(),
      _coreSystem.player.children[0].children[
        currentSkin
      ].children[0].script.ribbon.reset(),
      _coreSystem.player.children[0].children[
        currentSkin
      ].children[0].script.ribbon.hideShadder(),
      setTimeout(
        function () {
          (_coreSystem.pisos[n].parent.enabled = !0),
            _coreSystem.defaultAnims(),
            (this.stages.enabled = !1);
        }.bind(this),
        800
      );
    var n = this.getCancion();
    (_coreSystem.pisos[n].parent.enabled = !1), (permitirPause = !1);
    var funcionDeTerminar = (t) => {
      if (
        (enGoogle &&
          (console.log("Se setea Gamesnack score " + _coreSystem.score),
          GameSnacks.score.update(_coreSystem.score),
          setTimeout(() => {
            window.parent.postMessage("next", "*");
            console.log("Se setea Gamesnack gameOver "),
              GameSnacks.game.gameOver();
          }, 200)),
        "muerte" == e)
      ) {
        (this.endingLoosePanelMC.enabled = !0),
          (this.endingFondo3D.enabled = !0);
        for (var i = 0; i < this.endingFondo3D.children.length; i++)
          this.endingFondo3D.children[i].enabled = !1;
        (this.endingFondo3D.children[n].enabled = !0),
          this.endingFondo3D.children[n].script.alphaConVelocidad.fadeIn();
        var a = this.endingLoosePanelMC.findByName("songName"),
          s = this.endingLoosePanelMC.findByName("completet"),
          o = this.endingLoosePanelMC.findByName("gemast"),
          r = this.endingLoosePanelMC.findByName("scoreFailed"),
          d = this.endingLoosePanelMC.findByName("homeb"),
          l = this.endingLoosePanelMC.findByName("restartb"),
          c = this.endingLoosePanelMC.findByName("discb");
        (this.skinbMC.enabled = !0),
          (l.enabled = !1),
          (this.izqb.enabled = !0),
          (this.derb.enabled = !0),
          this.hideInGame(),
          (this.gemasMC.enabled = !0),
          (r.element.text = _coreSystem.score + ""),
          (a.element.text = arrayCanciones[n][2]),
          (o.element.text = "+" + _coreSystem.gemasInGame * t),
          (s.element.text = percentajeCompleted + "% COMPLETED"),
          2 == t &&
            ((_coreSystem.gemas = _coreSystem.gemas + _coreSystem.gemasInGame),
            this.setGema(_coreSystem.gemas)),
          (this.discosMC.enabled = !0),
          reproduceAnim(this.discosMC, 2, 1, null, null, !1),
          (currentCancion = n),
          (currentCancionAux = -1),
          (_coreSystem.cancionFase = 0),
          _coreSystem.score > arrayCanciones[n][3] &&
            ((arrayCanciones[n][3] = _coreSystem.score),
            guardaVars(
              _coreSystem.score,
              "arrayCanciones_" + (n + 1) + "_score"
            )),
          setTimeout(
            function () {
              addEventFunction(d, !0, 1, this.clickHomeEndingLoose.bind(this)),
                addEventFunction(l, !0, 1, this.clickRestartSong.bind(this)),
                addEventFunction(c, !0, 1, this.clickRestartSong.bind(this));
              for (var e = 0; e < totalCanciones; e++)
                this.discosMC.children[e].script.text.text =
                  arrayCanciones[n][3] + "";
              reproduceAnim(this.discosMC, 0, 1, null, null, !0);
            }.bind(this),
            810
          );
      } else if ("muerteEndless" == e || "pasada" == e) {
        (this.endingWinPanelMC.enabled = !0), (this.endingFondo3D.enabled = !0);
        for (i = 0; i < this.endingFondo3D.children.length; i++)
          this.endingFondo3D.children[i].enabled = !1;
        (this.endingFondo3D.children[n].enabled = !0),
          this.endingFondo3D.children[n].script.alphaConVelocidad.fadeIn();
        (a = this.endingWinPanelMC.findByName("songName")),
          (r = this.endingWinPanelMC.findByName("score")),
          (o = this.endingWinPanelMC.findByName("gemast"));
        var u = this.endingWinPanelMC.findByName("streakt"),
          h = this.endingWinPanelMC.findByName("complete");
        h.enabled = !1;
        (d = this.endingWinPanelMC.findByName("homeb")),
          (l = this.endingWinPanelMC.findByName("restartb")),
          (c = this.endingWinPanelMC.findByName("discb"));
        (this.skinbMC.enabled = !0),
          (l.enabled = !1),
          (this.izqb.enabled = !0),
          (this.derb.enabled = !0),
          this.hideInGame(),
          (this.gemasMC.enabled = !0),
          (a.element.text = arrayCanciones[n][2]),
          (o.element.text = "+" + _coreSystem.gemasInGame * t),
          (u.element.text = "" + _coreSystem.maximoStreak),
          (r.element.text = _coreSystem.score + ""),
          2 == t &&
            ((_coreSystem.gemas = _coreSystem.gemas + _coreSystem.gemasInGame),
            this.setGema(_coreSystem.gemas)),
          (this.discosMC.enabled = !0),
          reproduceAnim(this.discosMC, 2, 1, null, null, !1),
          n >= 0 && n <= 3 && 0 == arrayCanciones[n + 4][4]
            ? ((h.enabled = !0),
              this.discosMC.rotateLocal(0, 0, 180),
              (arrayCanciones[n + 4][4] = 1),
              guardaVars(
                arrayCanciones[n + 4][4],
                "arrayCanciones_" + (n + 1 + 4) + "_unlock"
              ),
              (this.discosMC.children[n + 4 + 4].enabled = !1),
              (currentCancion = n + 4),
              (currentCancionAux = -1),
              (_coreSystem.cancionFase = 0))
            : "pasada" == e
            ? (this.discosMC.rotateLocal(0, 0, 45),
              (currentCancion = n + 1),
              (currentCancionAux = -1),
              (_coreSystem.cancionFase = 0))
            : ((currentCancion = n),
              (currentCancionAux = -1),
              (_coreSystem.cancionFase = 0)),
          _coreSystem.score > arrayCanciones[n][3] &&
            ((arrayCanciones[n][3] = _coreSystem.score),
            guardaVars(
              _coreSystem.score,
              "arrayCanciones_" + (n + 1) + "_score"
            ),
            enGoogle &&
              setTimeout(() => {
                console.log("Se llama gamesnack level complete "),
                  window.parent.postMessage("next", "*");
                GameSnacks.game.levelComplete(n + 1);
              }, 200)),
          setTimeout(
            function () {
              addEventFunction(d, !0, 1, this.clickHomeEndingWin.bind(this, e)),
                addEventFunction(
                  l,
                  !0,
                  1,
                  this.clickRestartSongWin.bind(this, e, !0)
                ),
                addEventFunction(
                  c,
                  !0,
                  1,
                  this.clickRestartSongWin.bind(this, e, !1)
                );
              for (var n = 0; n < totalCanciones; n++)
                this.discosMC.children[n].script.text.text =
                  arrayCanciones[n][3] + "";
              reproduceAnim(this.discosMC, 0, 1, null, null, !0);
            }.bind(this),
            810
          );
      }
    };
    console.log("el objecto rewardAd"),
      console.log(rewardAd),
      _coreSystem.gemasInGame > 0
        ? enGoogle && null != rewardAd
          ? (console.log(
              "llamaremos al panel de reward ad pk el objeto rewardAd no es null"
            ),
            ShowRewardPanel(_coreSystem.gemasInGame, funcionDeTerminar))
          : enGoogle && null == rewardAd
          ? funcionDeTerminar(1)
          : enGoogle ||
            ShowRewardPanel(_coreSystem.gemasInGame, funcionDeTerminar)
        : funcionDeTerminar(1);
  }),
  (Menu.prototype.clickHomeEndingLoose = function () {
    if ((playSound("click"), !this.stages.enabled)) {
      PrepareInterstitital(() => {
        (this.skinbMC.enabled = !1), this.mataEndingLoose();
        var e = this.getCancion();
        (currentCancion = e),
          (currentCancionAux = -1),
          (_coreSystem.cancionFase = 0),
          _coreSystem.defaultAnims(),
          (_coreSystem.NOTAS_ARRAY.enabled = !1),
          this.hideInGame(),
          this.setMenu();
      });
    }
  }),
  (Menu.prototype.clickHomeEndingWin = function (e) {
    if ((playSound("click"), !this.stages.enabled)) {
      PrepareInterstitital(() => {
        var n = this.endingWinPanelMC.findByName("complete");
        "pasada" == e &&
          (n.enabled
            ? this.discosMC.rotateLocal(0, 0, -180)
            : this.discosMC.rotateLocal(0, 0, -45)),
          (this.skinbMC.enabled = !1),
          this.mataEndingWin();
        var t = this.getCancion();
        (currentCancion = t),
          (currentCancionAux = -1),
          (_coreSystem.cancionFase = 0),
          _coreSystem.defaultAnims(),
          (_coreSystem.NOTAS_ARRAY.enabled = !1),
          this.hideInGame(),
          this.setMenu();
      });
    }
  }),
  (Menu.prototype.clickRestartSong = function () {
    if (
      !this.stages.enabled &&
      0 != arrayCanciones[currentCancion][4] &&
      !this.enAnim
    ) {
      (() => {
        null != this.hiloMano && this.hiloMano.stop(),
          (this.enAnim = !0),
          (this.skinbMC.enabled = !1),
          (this.izqb.enabled = !1),
          (this.derb.enabled = !1),
          _musicas.slot(currentMusic).stop(),
          playSound("start"),
          (this.discosMC.enabled = !0),
          reproduceAnim(this.discosMC, 2, 1, null, null, !1);
        this.hiloDisco = this.app
          .tween({ x: 0 })
          .to({ x: 45 }, 0.45, pc.SineOut)
          .onComplete(() => {
            (this.loadingMC.enabled = !0),
              this.loadingMC.script.alphaConVelocidad.fadeIn(
                function () {
                  this.mataEndingLoose(),
                    (this.stages.enabled = !0),
                    cargaMusica(
                      urlBaseAssets,
                      currentCancion + 1,
                      this.callBackStart.bind(this)
                    );
                }.bind(this)
              );
          })
          .start();
        for (var e = 0; e < totalCanciones; e++)
          this.discosMC.children[e].script.text.text = "";
      })();
    }
  }),
  (Menu.prototype.clickRestartSongWin = function (e, n) {
    if (
      !this.stages.enabled &&
      0 != arrayCanciones[currentCancion][4] &&
      !this.enAnim
    ) {
      this.enAnim = !0;
      (() => {
        var e = this.endingWinPanelMC.findByName("complete");
        (this.izqb.enabled = !1),
          (this.derb.enabled = !1),
          _musicas.slot(currentMusic).stop(),
          (this.skinbMC.enabled = !1),
          playSound("start"),
          (this.discosMC.enabled = !0),
          reproduceAnim(this.discosMC, 2, 1, null, null, !1),
          null != this.hiloMano && this.hiloMano.stop();
        for (var n = 0; n < this.stages.children.length; n++)
          this.stages.children[n].enabled = !1;
        console.log("Stage" + (currentCancion + 1)),
          (this.stages.findByName("Stage" + (currentCancion + 1)).enabled = !0);
        (e.enabled = !1),
          (this.hiloDisco = this.app
            .tween({ x: 0 })
            .to({ x: 45 }, 0.45, pc.SineOut)
            .onComplete(() => {
              (this.loadingMC.enabled = !0),
                this.loadingMC.script.alphaConVelocidad.fadeIn(
                  function () {
                    this.mataEndingWin(),
                      (this.stages.enabled = !0),
                      cargaMusica(
                        urlBaseAssets,
                        currentCancion + 1,
                        this.callBackStart.bind(this)
                      );
                  }.bind(this)
                );
            })
            .start());
        for (n = 0; n < totalCanciones; n++)
          this.discosMC.children[n].script.text.text = "";
      })();
    }
  }),
  (Menu.prototype.mataEndingLoose = function () {
    this.endingLoosePanelMC.findByName("songName"),
      this.endingLoosePanelMC.findByName("completet"),
      this.endingLoosePanelMC.findByName("gemast");
    var e = this.endingLoosePanelMC.findByName("homeb"),
      n = this.endingLoosePanelMC.findByName("restartb"),
      t = this.endingLoosePanelMC.findByName("discb");
    this.getCancion();
    addEventFunction(e, !1),
      addEventFunction(n, !1),
      addEventFunction(t, !1),
      (this.skinbMC.enabled = !1),
      (this.endingLoosePanelMC.enabled = !1),
      (this.endingFondo3D.enabled = !1);
  }),
  (Menu.prototype.mataEndingWin = function () {
    this.endingWinPanelMC.findByName("songName"),
      this.endingWinPanelMC.findByName("score"),
      this.endingWinPanelMC.findByName("gemast"),
      this.endingWinPanelMC.findByName("streakt");
    var e = this.endingWinPanelMC.findByName("complete"),
      n = this.endingWinPanelMC.findByName("homeb"),
      t = this.endingWinPanelMC.findByName("restartb"),
      i = this.endingWinPanelMC.findByName("discb");
    this.getCancion();
    (e.enabled = !1),
      addEventFunction(n, !1),
      addEventFunction(t, !1),
      addEventFunction(i, !1),
      (this.skinbMC.enabled = !1),
      (this.endingWinPanelMC.enabled = !1),
      (this.endingFondo3D.enabled = !1);
  }),
  (Menu.prototype.getCancion = function () {
    return -1 == currentCancionAux
      ? currentCancion
      : 0 == _coreSystem.cancionFase ||
        1 == _coreSystem.cancionFase ||
        _coreSystem.cancionFase >= 2
      ? currentCancionAux
      : void 0;
  }),
  (Menu.prototype.poneContinue = function () {
    (permitirPause = !1), (this.continuePanelMC.enabled = !0);
    var e = this.continuePanelMC.findByName("botonYes"),
      n = this.continuePanelMC.findByName("fill"),
      t = this.continuePanelMC.findByName("botonNo");
    (this.continuePanelMC.findByName("price").element.text =
      "" + continueCost * (continues + 1)),
      addEventFunction(e, !0, 1, this.clickReviveButton.bind(this)),
      addEventFunction(t, !0, 1, this.clickNOReviveButton.bind(this, !0)),
      n.script.reproduceAnimSprite.Play(
        this.clickNOReviveButton.bind(this, !1),
        0,
        103
      );
  }),
  (Menu.prototype.clickReviveButton = function () {
    playSound("start"),
      (_coreSystem.gemas = _coreSystem.gemas - continueCost * (continues + 1)),
      this.setGema(_coreSystem.gemas),
      (continues += 1),
      this.killMethodRevive(),
      (permitirPause = !1),
      this.setCounter(
        0,
        3,
        function () {
          _rebote.revivir(),
            (permitirPause = !0),
            (pause = !1),
            this.poneTutoFast(!1);
        }.bind(this)
      ),
      clearInterval(this.hiloSwipeMano),
      this.poneTutoFast(!0),
      (enPausa = !1),
      (currentVidas += 3),
      currentVidas > totalVidas && (currentVidas = totalVidas),
      this.configVidas(),
      _rebote.parpadear(3500);
  }),
  (Menu.prototype.setCounter = function (e, n, t) {
    if (0 == e) {
      this.countMC.enabled = !0;
      for (var i = 0; i < this.countMC.children.length; i++)
        this.countMC.children[i].enabled = !1;
      (this.countMC.children[n - 1].enabled = !0), playSound("click");
    }
    var a = setInterval(
      function () {
        if (!pauseFlag) {
          for (var i = 0; i < this.countMC.children.length; i++)
            this.countMC.children[i].enabled = !1;
          if ((e += 1) == n)
            return clearInterval(a), t(), void (this.countMC.enabled = !1);
          (this.countMC.children[n - e - 1].enabled = !0),
            playSound("click"),
            this.setCounter(e, n, t);
        }
      }.bind(this),
      1e3
    );
  }),
  (Menu.prototype.clickNOReviveButton = function (e) {
    playSound("click"),
      (continues = posiblesContinues),
      this.killMethodRevive(),
      (_rebote.empezo = !0),
      (pause = !1),
      (enPausa = !1),
      _rebote.matarBola(!0);
  }),
  (Menu.prototype.killMethodRevive = function (e) {
    var n = this.continuePanelMC.findByName("botonYes"),
      t = this.continuePanelMC.findByName("fill"),
      i = this.continuePanelMC.findByName("botonNo");
    t.script.reproduceAnimSprite.Stop(),
      addEventFunction(n, !1),
      addEventFunction(i, !1),
      (this.continuePanelMC.enabled = !1);
  }),
  (Menu.prototype.audioChange = function () {
    if (enGoogle ? GameSnacks.audio.isEnabled() : volumeMaster) {
      currentMute = 0;
      var e = this.pausePanelMC.findByName("muteb");
      mutear(0, e, !1),
        (e = this.settingsPanelMC.findByName("muteb_settings")),
        mutear(0, e, !1);
    } else {
      currentMute = 1;
      e = this.pausePanelMC.findByName("muteb");
      mutear(1, e, !1),
        (e = this.settingsPanelMC.findByName("muteb_settings")),
        mutear(1, e, !1);
    }
  });
var CoreSystem = pc.createScript("coreSystem");
CoreSystem.attributes.add("NOTAS_ARRAY", { type: "entity" }),
  CoreSystem.attributes.add("player", { type: "entity" }),
  CoreSystem.attributes.add("pisos", { type: "entity", array: !0 }),
  CoreSystem.attributes.add("mandalas", { type: "entity", array: !0 }),
  CoreSystem.attributes.add("camara", { type: "entity" }),
  CoreSystem.attributes.add("stages", { type: "entity" }),
  CoreSystem.attributes.add("hitPiso", { type: "entity" }),
  (CoreSystem.prototype.initialize = function () {
    this.app.keyboard.on(pc.EVENT_KEYDOWN, this.onKeyDown, this),
      (_coreSystem = this),
      (this.posInicial = this.player.getPosition().clone()),
      (this.ordenSaltosIndex = []),
      (this.currentPorcentaje = 0),
      (this.deltaCamaraZ =
        this.player.getPosition().z - this.camara.getPosition().z),
      this.creaNotasMov(),
      (this.stagesPosInitial = this.stages.getPosition().clone()),
      (this.start = !1),
      (this.finCancion = !1),
      (this.combo = 0),
      (this.score = 0),
      (this.gemas = gemas),
      (this.gemasInGame = 0),
      (this.player.enabled = !1),
      (this.maximoStreak = 0),
      (this.cancionFase = 0),
      _menu.hideInGame(),
      _menu.setMenu();
  }),
  (CoreSystem.prototype.creaNotasMov = function () {
    for (var t = 0; t < 12; t++) {
      (this.ordenSaltosIndex[t] = []),
        (this.cancion = window[arrayCanciones[t][1] + "_array"]),
        (this.cancion[0][3] = 0),
        (this.cancion[this.cancion.length - 1][3] = 0),
        (this.cancion[0][4] = 0),
        (this.cancion[this.cancion.length - 1][4] = 0),
        (this.cancion[0][5] = 0),
        (this.cancion[this.cancion.length - 1][5] = 0);
      var e = (gameSpeed + extraSpeedSongs[t]) * this.cancion[0][0];
      (this.cancion[0][6] = e), this.ordenSaltosIndex[t].push(0);
      for (var n = 0, i = 1, s = 1; s < this.cancion.length - 1; s++) {
        if (
          ((this.cancion[s][3] = 0),
          (this.cancion[s][4] = 0),
          (this.cancion[s][5] = 0),
          n < limiteGemas)
        )
          for (var a = 0; a < arrayGemas.length; a++)
            if (arrayGemas[a] == s && 0 == this.cancion[s][2]) {
              (this.cancion[s][5] = 1), (n += 1);
              break;
            }
        e = (gameSpeed + extraSpeedSongs[t]) * this.cancion[s][0];
        (this.cancion[s][6] = e),
          this.cancion[s][0] != this.cancion[s - 1][0] &&
            this.ordenSaltosIndex[t].push(s),
          (t >= 2 || s >= 30) &&
            0 == this.cancion[s][2] &&
            this.cancion[s][0] != this.cancion[s - 1][0] &&
            this.cancion[s][0] != this.cancion[s + 1][0] &&
            0 == this.cancion[s - 1][3] &&
            this.cancion[s][0] - this.cancion[s - 1][0] >= toleranciaNotasMov &&
            this.cancion[s + 1][0] - this.cancion[s][0] >= toleranciaNotasMov &&
            ((this.cancion[s][3] = 1), (this.cancion[s][4] = i), (i *= -1));
      }
      this.cancion[s][0] != this.cancion[s - 1][0] &&
        this.ordenSaltosIndex[t].push(s);
      e = (gameSpeed + extraSpeedSongs[t]) * this.cancion[s][0];
      this.cancion[s][6] = e;
    }
  }),
  (CoreSystem.prototype.addScore = function (t) {
    (this.score = this.score + t), _menu.setScore(this.score);
  }),
  (CoreSystem.prototype.addCombo = function (t) {
    -1 == t
      ? (this.combo >= 5 && playSound("comboMiss"), (this.combo = 0))
      : (this.combo = this.combo + t),
      this.combo > this.maximoStreak && (this.maximoStreak = this.combo);
  }),
  (CoreSystem.prototype.tocaCancion = function (t) {
    this.tiempoCancionStart = t;
  }),
  (CoreSystem.prototype.restart = function () {
    setTimeout(() => {
      PrepareRewardAd("doubleReward");
    }, 100),
      (this.NOTAS_ARRAY.enabled = !0),
      (this.start = !1),
      (this.player.enabled = !0),
      (this.hitPiso.enabled = !1),
      (currentVidas = totalVidas),
      _menu.configVidas(),
      (enParpadeo = !1),
      (continues = 0),
      _rebote.restartAll(),
      (this.maximoStreak = 0),
      (this.cancionFase = 0),
      (this.finCancion = !1),
      this.player.setPosition(this.posInicial),
      this.player.children[0].setLocalPosition(0, 0, 0),
      this.player.children[0].children[
        currentSkin
      ].children[0].script.ribbon.clearOld(),
      this.player.children[0].children[
        currentSkin
      ].children[0].script.ribbon.reset(),
      this.player.children[0].children[
        currentSkin
      ].children[0].script.ribbon.hideShadder(),
      null == this.player.children[0].children[currentSkin].model
        ? (this.player.children[0].children[
            currentSkin
          ].children[1].model.enabled = !0)
        : (this.player.children[0].children[currentSkin].model.enabled = !0),
      (this.gameInitialized = !1),
      0 == this.cancionFase
        ? currentCancion >= 4 && currentCancion <= 8
          ? ((currentCancionAux = currentCancion), (currentCancion -= 4))
          : (currentCancionAux = -1)
        : 1 == this.cancionFase
        ? (currentCancion = currentCancionAux)
        : 2 == this.cancionFase && (currentCancion += 4),
      -5 == currentCancion &&
        ((currentCancionAux = 4), (currentCancion = 4), (this.cancionFase = 1)),
      this.defaultAnims(),
      (percentajeCompleted = 0),
      (this.currentSong = arrayCanciones[currentCancion][1].toLowerCase()),
      (this.cancion = window[arrayCanciones[currentCancion][1] + "_array"]),
      (this.currentNotaEntity = 0),
      (this.currentNota = 0),
      (this.currentTiempo = 0),
      (this.tiempoCancionStart = -1),
      (this.startMusic = !1),
      (this.currentPorcentaje = 0),
      (this.gemasInGame = 0),
      (this.combo = 0),
      (this.score = 0);
    for (var t = 0; t < this.NOTAS_ARRAY.children.length; t++)
      (this.NOTAS_ARRAY.children[t].script.nota.fase = 0),
        (this.NOTAS_ARRAY.children[t].enabled = !0),
        (this.NOTAS_ARRAY.children[t].script.nota.index = t),
        this.NOTAS_ARRAY.children[t].script.nota.setValues(
          this.cancion[this.currentNota][0],
          this.cancion[this.currentNota][1],
          this.cancion[this.currentNota][2],
          this.currentNota,
          this.cancion[this.currentNota][3],
          this.cancion[this.currentNota][4],
          this.cancion[this.currentNota][5],
          this.cancion[this.currentNota][6]
        ),
        (this.currentNota = this.currentNota + 1);
    _menu.hideMenu(),
      _menu.setInGame(),
      (gameOver = !1),
      setTimeout(
        function () {
          _rebote.empezar(), (this.start = !0);
        }.bind(this),
        120
      );
  }),
  (CoreSystem.prototype.siguienteFase = function () {
    this.apagaMusicas(),
      _controlBola.reset(),
      (this.start = !1),
      (gameOver = !1),
      _rebote.restartAll(),
      (this.finCancion = !1),
      this.player.setPosition(this.posInicial),
      (this.gameInitialized = !1),
      this.player.children[0].children[
        currentSkin
      ].children[0].script.ribbon.clearOld(),
      this.player.children[0].children[
        currentSkin
      ].children[0].script.ribbon.reset(),
      this.player.children[0].children[
        currentSkin
      ].children[0].script.ribbon.hideShadder(),
      0 == this.cancionFase
        ? currentCancion >= 4 && currentCancion <= 8
          ? ((currentCancionAux = currentCancion), (currentCancion -= 4))
          : (currentCancionAux = -1)
        : 1 == this.cancionFase
        ? (currentCancion = currentCancionAux)
        : 2 == this.cancionFase
        ? (currentCancion += 4)
        : (currentCancion = currentCancion),
      this.defaultAnims(),
      (this.currentSong = arrayCanciones[currentCancion][1].toLowerCase()),
      (this.cancion = window[arrayCanciones[currentCancion][1] + "_array"]),
      (this.currentNotaEntity = 0),
      (this.currentNota = 0),
      (this.currentTiempo = 0),
      (this.tiempoCancionStart = -1),
      (this.startMusic = !1),
      (this.currentPorcentaje = 0);
    for (var t = 0; t < this.NOTAS_ARRAY.children.length; t++)
      (this.NOTAS_ARRAY.children[t].script.nota.fase = 0),
        (this.NOTAS_ARRAY.children[t].enabled = !0),
        (this.NOTAS_ARRAY.children[t].script.nota.index = t),
        this.NOTAS_ARRAY.children[t].script.nota.setValues(
          this.cancion[this.currentNota][0],
          this.cancion[this.currentNota][1],
          this.cancion[this.currentNota][2],
          this.currentNota,
          this.cancion[this.currentNota][3],
          this.cancion[this.currentNota][4],
          this.cancion[this.currentNota][5],
          this.cancion[this.currentNota][6]
        ),
        (this.currentNota = this.currentNota + 1);
    null == _rebote.bolaUpDown.model
      ? (_rebote.bolaUpDown.children[1].model.enabled = !0)
      : (_rebote.bolaUpDown.model.enabled = !0),
      _rebote.empezar(),
      (this.start = !0);
  }),
  (CoreSystem.prototype.getCancionFase = function () {
    return this.cancionFase;
  }),
  (CoreSystem.prototype.animEndIni = function () {
    (this.pisos[_menu.getCancion()].script.animaUvs.speed =
      4.8 + 6 * extraSpeedSongsUVS[currentCancion]),
      (this.stages
        .findByName("Stage" + (_menu.getCancion() + 1))
        .findByName("pastos1").script.muevePasto.speed =
        6 *
        this.stages
          .findByName("Stage" + (_menu.getCancion() + 1))
          .findByName("pastos1").script.muevePasto.speed),
      (this.stages
        .findByName("Stage" + (_menu.getCancion() + 1))
        .findByName("pastos2").script.muevePasto.speed =
        6 *
        this.stages
          .findByName("Stage" + (_menu.getCancion() + 1))
          .findByName("pastos2").script.muevePasto.speed);
  }),
  (CoreSystem.prototype.animEndFin = function () {
    (this.pisos[_menu.getCancion()].script.animaUvs.speed = 0),
      (this.stages
        .findByName("Stage" + (_menu.getCancion() + 1))
        .findByName("pastos1").script.muevePasto.speed = 0),
      (this.stages
        .findByName("Stage" + (_menu.getCancion() + 1))
        .findByName("pastos2").script.muevePasto.speed = 0);
  }),
  (CoreSystem.prototype.defaultAnims = function () {
    (this.pisos[_menu.getCancion()].script.animaUvs.speed =
      4.8 + extraSpeedSongsUVS[currentCancion]),
      (this.stages
        .findByName("Stage" + (_menu.getCancion() + 1))
        .findByName("pastos1").script.muevePasto.speed =
        16 + extraSpeedSongsPastos[currentCancion]),
      (this.stages
        .findByName("Stage" + (_menu.getCancion() + 1))
        .findByName("pastos2").script.muevePasto.speed =
        16 + extraSpeedSongsPastos[currentCancion]);
  }),
  (CoreSystem.prototype.update = function (t) {
    (deltaTime = t),
      gameOver ||
        (this.moveCamera(t),
        this.startMusic ||
          pause ||
          (-1 != this.tiempoCancionStart &&
            ((this.currentTiempo = this.currentTiempo + t),
            this.currentTiempo >= this.tiempoCancionStart &&
              (playSound(this.currentSong, !0), (this.startMusic = !0)))));
  }),
  (CoreSystem.prototype.moveCamera = function (t) {
    var e = this.player.children[0].getPosition().x,
      n = this.camara.getPosition().clone(),
      i = this.player.children[0].getPosition().z - n.z - this.deltaCamaraZ,
      s = (1.25 / (pistaAncho / 2 - 0)) * (e - 0) + 0;
    this.stages.translate(0, 0, i), this.camara.setPosition(s, n.y, n.z + i);
  }),
  (CoreSystem.prototype.esGameOver = function () {
    (gameOver = !0),
      this.apagaMusicas(),
      (this.pisos[_menu.getCancion()].script.animaUvs.speed = 0);
    for (var t = 0; t < this.NOTAS_ARRAY.children.length; t++)
      null != this.NOTAS_ARRAY.children[t].script.nota.tweenMov &&
        this.NOTAS_ARRAY.children[t].script.nota.tweenMov.stop();
  }),
  (CoreSystem.prototype.apagaMusicas = function () {
    null != this.currentSong && _musicas.stop(this.currentSong);
  }),
  (CoreSystem.prototype.destruyeTodo = function () {
    this.apagaMusicas(), _controlBola.reset(), _menu.hideMenu();
  }),
  (CoreSystem.prototype.pauseMusic = function (t) {
    "pause" == t && null != this.currentSong
      ? _musicas.pause(this.currentSong)
      : "resume" == t &&
        null != this.currentSong &&
        _musicas.resume(this.currentSong);
  }),
  (CoreSystem.prototype.onKeyDown = function (t) {
    t.key == pc.KEY_0 &&
      cargaMusica(
        urlBaseAssets,
        5,
        function () {
          (currentCancion = -5), this.destruyeTodo();
        }.bind(this)
      ),
      t.key == pc.KEY_P &&
        ((this.app.timeScale = 1 == this.app.timeScale ? 0 : 1),
        1 == this.app.timeScale
          ? _musicas.resume(this.currentSong)
          : _musicas.pause(this.currentSong));
  });
var Song2_array = [];
(Song2_array[0] = [0.15, 2, 0]),
  (Song2_array[1] = [0.65000004, 2, 0]),
  (Song2_array[2] = [0.90000004, 2, 0]),
  (Song2_array[3] = [1.15, 5, 0]),
  (Song2_array[4] = [1.5, 2, 0]),
  (Song2_array[5] = [1.85, 2, 0]),
  (Song2_array[6] = [2.3500001, 4, 0]),
  (Song2_array[7] = [2.95, 4, 0]),
  (Song2_array[8] = [3.25, 5, 0]),
  (Song2_array[9] = [3.55, 3, 0]),
  (Song2_array[10] = [4.1, 2, 0]),
  (Song2_array[11] = [4.7000003, 2, 0]),
  (Song2_array[12] = [5, 2, 0]),
  (Song2_array[13] = [5.2000003, 5, 0]),
  (Song2_array[14] = [5.55, 2, 0]),
  (Song2_array[15] = [5.9, 2, 0]),
  (Song2_array[16] = [6.4, 4, 0]),
  (Song2_array[17] = [6.9, 4, 0]),
  (Song2_array[18] = [7.15, 5, 0]),
  (Song2_array[19] = [7.5, 3, 0]),
  (Song2_array[20] = [8.05, 1, 0]),
  (Song2_array[21] = [8.05, 3, 0.05]),
  (Song2_array[22] = [8.55, 1, 0]),
  (Song2_array[23] = [8.55, 3, 0.05]),
  (Song2_array[24] = [8.8, 1, 0]),
  (Song2_array[25] = [8.8, 3, 0.05]),
  (Song2_array[26] = [9.05, 5, 0]),
  (Song2_array[27] = [9.400001, 1, 0]),
  (Song2_array[28] = [9.400001, 3, 0.05]),
  (Song2_array[29] = [9.75, 1, 0]),
  (Song2_array[30] = [9.75, 3, 0.05]),
  (Song2_array[31] = [10.25, 1, 0]),
  (Song2_array[32] = [10.25, 3, 0.05]),
  (Song2_array[33] = [10.85, 1, 0]),
  (Song2_array[34] = [10.85, 3, 0.05]),
  (Song2_array[35] = [11.150001, 5, 0]),
  (Song2_array[36] = [11.45, 1, 0]),
  (Song2_array[37] = [11.45, 3, 0.05]),
  (Song2_array[38] = [12, 1, 0]),
  (Song2_array[39] = [12, 3, 0.05]),
  (Song2_array[40] = [12.6, 1, 0]),
  (Song2_array[41] = [12.6, 3, 0.05]),
  (Song2_array[42] = [12.900001, 1, 0]),
  (Song2_array[43] = [12.900001, 3, 0.05]),
  (Song2_array[44] = [13.1, 5, 0]),
  (Song2_array[45] = [13.45, 1, 0]),
  (Song2_array[46] = [13.45, 3, 0.05]),
  (Song2_array[47] = [13.8, 1, 0]),
  (Song2_array[48] = [13.8, 3, 0.05]),
  (Song2_array[49] = [14.3, 1, 0]),
  (Song2_array[50] = [14.3, 3, 0.05]),
  (Song2_array[51] = [14.8, 1, 0]),
  (Song2_array[52] = [14.8, 3, 0.05]),
  (Song2_array[53] = [15.05, 5, 0]),
  (Song2_array[54] = [15.400001, 1, 0]),
  (Song2_array[55] = [15.400001, 3, 0.05]),
  (Song2_array[56] = [16.1, 1, 0]),
  (Song2_array[57] = [16.6, 3, 0]),
  (Song2_array[58] = [17.15, 1, 0]),
  (Song2_array[59] = [17.550001, 1, 0]),
  (Song2_array[60] = [17.95, 3, 0]),
  (Song2_array[61] = [18.050001, 3, 0]),
  (Song2_array[62] = [20.050001, 1, 0]),
  (Song2_array[63] = [20.550001, 3, 0]),
  (Song2_array[64] = [21.1, 1, 0]),
  (Song2_array[65] = [21.5, 1, 0]),
  (Song2_array[66] = [21.9, 3, 0]),
  (Song2_array[67] = [22, 3, 0]),
  (Song2_array[68] = [24.1, 1, 0]),
  (Song2_array[69] = [24.6, 3, 0]),
  (Song2_array[70] = [25.15, 1, 0]),
  (Song2_array[71] = [25.550001, 1, 0]),
  (Song2_array[72] = [25.95, 3, 0]),
  (Song2_array[73] = [26.050001, 3, 0]),
  (Song2_array[74] = [28.050001, 1, 0]),
  (Song2_array[75] = [28.550001, 3, 0]),
  (Song2_array[76] = [29.1, 1, 0]),
  (Song2_array[77] = [29.5, 1, 0]),
  (Song2_array[78] = [29.9, 3, 0]),
  (Song2_array[79] = [30, 3, 0]),
  (Song2_array[80] = [32.15, 1, 0]),
  (Song2_array[81] = [32.25, 1, 0]),
  (Song2_array[82] = [32.5, 1, 0]),
  (Song2_array[83] = [32.5, 3, 0.05]),
  (Song2_array[84] = [32.95, 3, 0]),
  (Song2_array[85] = [33.05, 3, 0]),
  (Song2_array[86] = [33.3, 3, 0.05]),
  (Song2_array[87] = [33.3, 5, 0]),
  (Song2_array[88] = [33.95, 3, 0]),
  (Song2_array[89] = [34.15, 4, 0]),
  (Song2_array[90] = [34.600002, 3, 0]),
  (Song2_array[91] = [34.8, 2, 0]),
  (Song2_array[92] = [35, 4, 0]),
  (Song2_array[93] = [35.2, 3, 0]),
  (Song2_array[94] = [35.4, 5, 0]),
  (Song2_array[95] = [35.7, 3, 0]),
  (Song2_array[96] = [35.8, 3, 0]),
  (Song2_array[97] = [36.15, 1, 0]),
  (Song2_array[98] = [36.25, 1, 0]),
  (Song2_array[99] = [36.5, 1, 0]),
  (Song2_array[100] = [36.5, 3, 0.05]),
  (Song2_array[101] = [36.95, 3, 0]),
  (Song2_array[102] = [37.05, 3, 0]),
  (Song2_array[103] = [37.3, 3, 0.05]),
  (Song2_array[104] = [37.3, 5, 0]),
  (Song2_array[105] = [37.95, 3, 0]),
  (Song2_array[106] = [38.15, 4, 0]),
  (Song2_array[107] = [38.600002, 3, 0]),
  (Song2_array[108] = [38.8, 2, 0]),
  (Song2_array[109] = [39, 4, 0]),
  (Song2_array[110] = [39.2, 3, 0]),
  (Song2_array[111] = [39.4, 5, 0]),
  (Song2_array[112] = [39.7, 3, 0]),
  (Song2_array[113] = [39.8, 3, 0]),
  (Song2_array[114] = [40.15, 1, 0]),
  (Song2_array[115] = [40.25, 1, 0]),
  (Song2_array[116] = [40.5, 1, 0]),
  (Song2_array[117] = [40.5, 3, 0.05]),
  (Song2_array[118] = [40.95, 3, 0]),
  (Song2_array[119] = [41.05, 3, 0]),
  (Song2_array[120] = [41.3, 3, 0.05]),
  (Song2_array[121] = [41.3, 5, 0]),
  (Song2_array[122] = [41.95, 3, 0]),
  (Song2_array[123] = [42.15, 4, 0]),
  (Song2_array[124] = [42.600002, 3, 0]),
  (Song2_array[125] = [42.8, 2, 0]),
  (Song2_array[126] = [43, 4, 0]),
  (Song2_array[127] = [43.2, 3, 0]),
  (Song2_array[128] = [43.4, 5, 0]),
  (Song2_array[129] = [43.7, 3, 0]),
  (Song2_array[130] = [43.8, 3, 0]),
  (Song2_array[131] = [44.15, 1, 0]),
  (Song2_array[132] = [44.2, 1, 0]),
  (Song2_array[133] = [44.25, 1, 0]),
  (Song2_array[134] = [44.3, 1, 0]),
  (Song2_array[135] = [44.5, 1, 0.05]),
  (Song2_array[136] = [44.5, 3, 0]),
  (Song2_array[137] = [44.95, 4, 0]),
  (Song2_array[138] = [45, 4, 0]),
  (Song2_array[139] = [45.05, 4, 0]),
  (Song2_array[140] = [45.100002, 4, 0]),
  (Song2_array[141] = [45.3, 3, 0.05]),
  (Song2_array[142] = [45.3, 5, 0]),
  (Song2_array[143] = [45.95, 3, 0]),
  (Song2_array[144] = [46.15, 4, 0]),
  (Song2_array[145] = [46.350002, 5, 0]),
  (Song2_array[146] = [46.600002, 3, 0]),
  (Song2_array[147] = [46.8, 2, 0]),
  (Song2_array[148] = [47, 4, 0]),
  (Song2_array[149] = [47.2, 3, 0]),
  (Song2_array[150] = [47.4, 5, 0]),
  (Song2_array[151] = [47.7, 3, 0]),
  (Song2_array[152] = [47.75, 3, 0]),
  (Song2_array[153] = [47.8, 3, 0]),
  (Song2_array[154] = [47.850002, 3, 0]),
  (Song2_array[155] = [48.05, 3, 0.05]),
  (Song2_array[156] = [48.05, 5, 0]),
  (Song2_array[157] = [48.4, 3, 0]),
  (Song2_array[158] = [48.4, 5, 0.05]),
  (Song2_array[159] = [48.600002, 1, 0]),
  (Song2_array[160] = [48.65, 1, 0]),
  (Song2_array[161] = [48.7, 1, 0]),
  (Song2_array[162] = [49.15, 1, 0]),
  (Song2_array[163] = [49.15, 3, 0.05]),
  (Song2_array[164] = [49.350002, 1, 0]),
  (Song2_array[165] = [49.4, 1, 0]),
  (Song2_array[166] = [49.45, 1, 0]),
  (Song2_array[167] = [49.75, 3, 0]),
  (Song2_array[168] = [49.850002, 3, 0]),
  (Song2_array[169] = [50, 5, 0]),
  (Song2_array[170] = [50.4, 3, 0.05]),
  (Song2_array[171] = [50.4, 5, 0]),
  (Song2_array[172] = [50.65, 3, 0.05]),
  (Song2_array[173] = [50.65, 5, 0]),
  (Song2_array[174] = [50.95, 4, 0]),
  (Song2_array[175] = [51.05, 3, 0]),
  (Song2_array[176] = [51.15, 4, 0]),
  (Song2_array[177] = [51.3, 3, 0]),
  (Song2_array[178] = [51.45, 2, 0]),
  (Song2_array[179] = [51.600002, 1, 0]),
  (Song2_array[180] = [51.850002, 3, 0]),
  (Song2_array[181] = [52.15, 3, 0.05]),
  (Song2_array[182] = [52.15, 5, 0]),
  (Song2_array[183] = [52.5, 3, 0]),
  (Song2_array[184] = [52.5, 5, 0.05]),
  (Song2_array[185] = [52.7, 3, 0]),
  (Song2_array[186] = [52.8, 3, 0]),
  (Song2_array[187] = [53.25, 1, 0]),
  (Song2_array[188] = [53.25, 3, 0.05]),
  (Song2_array[189] = [53.45, 1, 0]),
  (Song2_array[190] = [53.55, 1, 0]),
  (Song2_array[191] = [53.850002, 3, 0]),
  (Song2_array[192] = [54.05, 5, 0]),
  (Song2_array[193] = [54.5, 3, 0]),
  (Song2_array[194] = [54.75, 3, 0]),
  (Song2_array[195] = [55.05, 4, 0]),
  (Song2_array[196] = [55.15, 3, 0]),
  (Song2_array[197] = [55.25, 4, 0]),
  (Song2_array[198] = [55.4, 3, 0]),
  (Song2_array[199] = [55.55, 2, 0]),
  (Song2_array[200] = [55.7, 1, 0]),
  (Song2_array[201] = [55.95, 3, 0]),
  (Song2_array[202] = [56.15, 1, 0]),
  (Song2_array[203] = [56.2, 1, 0]),
  (Song2_array[204] = [56.25, 1, 0]),
  (Song2_array[205] = [56.3, 1, 0]),
  (Song2_array[206] = [56.5, 1, 0.05]),
  (Song2_array[207] = [56.5, 3, 0]),
  (Song2_array[208] = [56.95, 3, 0]),
  (Song2_array[209] = [57, 3, 0]),
  (Song2_array[210] = [57.05, 3, 0]),
  (Song2_array[211] = [57.100002, 3, 0]),
  (Song2_array[212] = [57.3, 3, 0.05]),
  (Song2_array[213] = [57.3, 5, 0]),
  (Song2_array[214] = [57.95, 3, 0]),
  (Song2_array[215] = [58.15, 4, 0]),
  (Song2_array[216] = [58.350002, 5, 0]),
  (Song2_array[217] = [58.600002, 3, 0]),
  (Song2_array[218] = [58.8, 2, 0]),
  (Song2_array[219] = [59, 4, 0]),
  (Song2_array[220] = [59.2, 3, 0]),
  (Song2_array[221] = [59.4, 5, 0]),
  (Song2_array[222] = [59.7, 3, 0]),
  (Song2_array[223] = [59.75, 3, 0]),
  (Song2_array[224] = [59.8, 3, 0]),
  (Song2_array[225] = [59.850002, 3, 0]),
  (Song2_array[226] = [60.100002, 1, 0]),
  (Song2_array[227] = [60.15, 1, 0]),
  (Song2_array[228] = [60.2, 1, 0]),
  (Song2_array[229] = [60.25, 1, 0]),
  (Song2_array[230] = [60.45, 1, 0.05]),
  (Song2_array[231] = [60.45, 3, 0]),
  (Song2_array[232] = [60.9, 3, 0]),
  (Song2_array[233] = [60.95, 3, 0]),
  (Song2_array[234] = [61, 3, 0]),
  (Song2_array[235] = [61.05, 3, 0]),
  (Song2_array[236] = [61.25, 3, 0.05]),
  (Song2_array[237] = [61.25, 5, 0]),
  (Song2_array[238] = [61.9, 3, 0]),
  (Song2_array[239] = [62.100002, 4, 0]),
  (Song2_array[240] = [62.3, 5, 0]),
  (Song2_array[241] = [62.55, 3, 0]),
  (Song2_array[242] = [62.75, 2, 0]),
  (Song2_array[243] = [62.95, 4, 0]),
  (Song2_array[244] = [63.15, 3, 0]),
  (Song2_array[245] = [63.350002, 5, 0]),
  (Song2_array[246] = [63.65, 3, 0]),
  (Song2_array[247] = [63.7, 3, 0]),
  (Song2_array[248] = [63.75, 3, 0]),
  (Song2_array[249] = [63.8, 3, 0]),
  (Song2_array[250] = [64.1, 1, 0]),
  (Song2_array[251] = [64.6, 3, 0]),
  (Song2_array[252] = [65.15, 1, 0]),
  (Song2_array[253] = [65.15, 3, 0.05]),
  (Song2_array[254] = [65.35, 1, 0]),
  (Song2_array[255] = [65.35, 3, 0.05]),
  (Song2_array[256] = [65.55, 1, 0]),
  (Song2_array[257] = [65.55, 3, 0.05]),
  (Song2_array[258] = [65.75, 1, 0]),
  (Song2_array[259] = [65.75, 3, 0.05]),
  (Song2_array[260] = [65.950005, 3, 0]),
  (Song2_array[261] = [66, 3, 0]),
  (Song2_array[262] = [66.05, 3, 0]),
  (Song2_array[263] = [68.05, 1, 0]),
  (Song2_array[264] = [68.55, 3, 0]),
  (Song2_array[265] = [69.1, 1, 0]),
  (Song2_array[266] = [69.1, 3, 0.05]),
  (Song2_array[267] = [69.3, 1, 0]),
  (Song2_array[268] = [69.3, 3, 0.05]),
  (Song2_array[269] = [69.5, 1, 0]),
  (Song2_array[270] = [69.5, 3, 0.05]),
  (Song2_array[271] = [69.700005, 1, 0]),
  (Song2_array[272] = [69.700005, 3, 0.05]),
  (Song2_array[273] = [69.9, 3, 0]),
  (Song2_array[274] = [69.950005, 3, 0]),
  (Song2_array[275] = [70, 3, 0]),
  (Song2_array[276] = [72.05, 1, 0]),
  (Song2_array[277] = [72.55, 3, 0]),
  (Song2_array[278] = [73.1, 1, 0]),
  (Song2_array[279] = [73.1, 3, 0.05]),
  (Song2_array[280] = [73.3, 1, 0]),
  (Song2_array[281] = [73.3, 3, 0.05]),
  (Song2_array[282] = [73.5, 1, 0]),
  (Song2_array[283] = [73.5, 3, 0.05]),
  (Song2_array[284] = [73.700005, 1, 0]),
  (Song2_array[285] = [73.700005, 3, 0.05]),
  (Song2_array[286] = [73.9, 3, 0]),
  (Song2_array[287] = [73.950005, 3, 0]),
  (Song2_array[288] = [74, 3, 0]),
  (Song2_array[289] = [76.05, 1, 0]),
  (Song2_array[290] = [76.55, 3, 0]),
  (Song2_array[291] = [77.1, 1, 0]),
  (Song2_array[292] = [77.1, 3, 0.05]),
  (Song2_array[293] = [77.3, 1, 0]),
  (Song2_array[294] = [77.3, 3, 0.05]),
  (Song2_array[295] = [77.5, 1, 0]),
  (Song2_array[296] = [77.5, 3, 0.05]),
  (Song2_array[297] = [77.700005, 1, 0]),
  (Song2_array[298] = [77.700005, 3, 0.05]),
  (Song2_array[299] = [77.9, 3, 0]),
  (Song2_array[300] = [77.950005, 3, 0]),
  (Song2_array[301] = [78, 3, 0]),
  (Song2_array[302] = [80.05, 1, 0]),
  (Song2_array[303] = [80.55, 3, 0]),
  (Song2_array[304] = [81.1, 1, 0]),
  (Song2_array[305] = [81.1, 3, 0.05]),
  (Song2_array[306] = [81.3, 1, 0]),
  (Song2_array[307] = [81.3, 3, 0.05]),
  (Song2_array[308] = [81.5, 1, 0]),
  (Song2_array[309] = [81.5, 3, 0.05]),
  (Song2_array[310] = [81.700005, 1, 0]),
  (Song2_array[311] = [81.700005, 3, 0.05]),
  (Song2_array[312] = [81.9, 3, 0]),
  (Song2_array[313] = [81.950005, 3, 0]),
  (Song2_array[314] = [82, 3, 0]),
  (Song2_array[315] = [84.1, 1, 0]),
  (Song2_array[316] = [84.6, 3, 0]),
  (Song2_array[317] = [85.15, 1, 0]),
  (Song2_array[318] = [85.15, 3, 0.05]),
  (Song2_array[319] = [85.35, 1, 0]),
  (Song2_array[320] = [85.35, 3, 0.05]),
  (Song2_array[321] = [85.55, 1, 0]),
  (Song2_array[322] = [85.55, 3, 0.05]),
  (Song2_array[323] = [85.75, 1, 0]),
  (Song2_array[324] = [85.75, 3, 0.05]),
  (Song2_array[325] = [85.950005, 3, 0]),
  (Song2_array[326] = [86, 3, 0]),
  (Song2_array[327] = [86.05, 3, 0]),
  (Song2_array[328] = [88.1, 1, 0]),
  (Song2_array[329] = [88.6, 3, 0]),
  (Song2_array[330] = [89.15, 1, 0]),
  (Song2_array[331] = [89.15, 3, 0.05]),
  (Song2_array[332] = [89.35, 1, 0]),
  (Song2_array[333] = [89.35, 3, 0.05]),
  (Song2_array[334] = [89.55, 1, 0]),
  (Song2_array[335] = [89.55, 3, 0.05]),
  (Song2_array[336] = [89.75, 1, 0]),
  (Song2_array[337] = [89.75, 3, 0.05]),
  (Song2_array[338] = [89.950005, 3, 0]),
  (Song2_array[339] = [90, 3, 0]),
  (Song2_array[340] = [90.05, 3, 0]),
  (Song2_array[341] = [92.05, 1, 0]),
  (Song2_array[342] = [92.55, 3, 0]),
  (Song2_array[343] = [93.1, 1, 0]),
  (Song2_array[344] = [93.1, 3, 0.05]),
  (Song2_array[345] = [93.3, 1, 0]),
  (Song2_array[346] = [93.3, 3, 0.05]),
  (Song2_array[347] = [93.5, 1, 0]),
  (Song2_array[348] = [93.5, 3, 0.05]),
  (Song2_array[349] = [93.700005, 1, 0]),
  (Song2_array[350] = [93.700005, 3, 0.05]),
  (Song2_array[351] = [93.9, 3, 0]),
  (Song2_array[352] = [93.950005, 3, 0]),
  (Song2_array[353] = [94, 3, 0]),
  (Song2_array[354] = [96.1, 1, 0]),
  (Song2_array[355] = [96.15, 1, 0]),
  (Song2_array[356] = [96.200005, 1, 0]),
  (Song2_array[357] = [96.25, 1, 0]),
  (Song2_array[358] = [96.450005, 1, 0.05]),
  (Song2_array[359] = [96.450005, 3, 0]),
  (Song2_array[360] = [96.9, 3, 0]),
  (Song2_array[361] = [96.950005, 3, 0]),
  (Song2_array[362] = [97, 3, 0]),
  (Song2_array[363] = [97.05, 3, 0]),
  (Song2_array[364] = [97.25, 3, 0.05]),
  (Song2_array[365] = [97.25, 5, 0]),
  (Song2_array[366] = [97.9, 3, 0]),
  (Song2_array[367] = [98.1, 4, 0]),
  (Song2_array[368] = [98.3, 5, 0]),
  (Song2_array[369] = [98.55, 3, 0]),
  (Song2_array[370] = [98.75, 2, 0]),
  (Song2_array[371] = [98.950005, 4, 0]),
  (Song2_array[372] = [99.15, 3, 0]),
  (Song2_array[373] = [99.35, 5, 0]),
  (Song2_array[374] = [99.65, 3, 0]),
  (Song2_array[375] = [99.700005, 3, 0]),
  (Song2_array[376] = [99.75, 3, 0]),
  (Song2_array[377] = [99.8, 3, 0]),
  (Song2_array[378] = [100.15, 1, 0]),
  (Song2_array[379] = [100.200005, 1, 0]),
  (Song2_array[380] = [100.25, 1, 0]),
  (Song2_array[381] = [100.3, 1, 0]),
  (Song2_array[382] = [100.5, 1, 0.05]),
  (Song2_array[383] = [100.5, 3, 0]),
  (Song2_array[384] = [100.950005, 3, 0]),
  (Song2_array[385] = [101, 3, 0]),
  (Song2_array[386] = [101.05, 3, 0]),
  (Song2_array[387] = [101.1, 3, 0]),
  (Song2_array[388] = [101.3, 3, 0.05]),
  (Song2_array[389] = [101.3, 5, 0]),
  (Song2_array[390] = [101.950005, 3, 0]),
  (Song2_array[391] = [102.15, 4, 0]),
  (Song2_array[392] = [102.35, 5, 0]),
  (Song2_array[393] = [102.6, 3, 0]),
  (Song2_array[394] = [102.8, 2, 0]),
  (Song2_array[395] = [103, 4, 0]),
  (Song2_array[396] = [103.200005, 3, 0]),
  (Song2_array[397] = [103.4, 5, 0]),
  (Song2_array[398] = [103.700005, 3, 0]),
  (Song2_array[399] = [103.75, 3, 0]),
  (Song2_array[400] = [103.8, 3, 0]),
  (Song2_array[401] = [103.85, 3, 0]),
  (Song2_array[402] = [104.15, 1, 0]),
  (Song2_array[403] = [104.200005, 1, 0]),
  (Song2_array[404] = [104.25, 1, 0]),
  (Song2_array[405] = [104.3, 1, 0]),
  (Song2_array[406] = [104.5, 1, 0.05]),
  (Song2_array[407] = [104.5, 3, 0]),
  (Song2_array[408] = [104.950005, 3, 0]),
  (Song2_array[409] = [105, 3, 0]),
  (Song2_array[410] = [105.05, 3, 0]),
  (Song2_array[411] = [105.1, 3, 0]),
  (Song2_array[412] = [105.3, 3, 0.05]),
  (Song2_array[413] = [105.3, 5, 0]),
  (Song2_array[414] = [105.950005, 3, 0]),
  (Song2_array[415] = [106.15, 4, 0]),
  (Song2_array[416] = [106.35, 5, 0]),
  (Song2_array[417] = [106.6, 3, 0]),
  (Song2_array[418] = [106.8, 2, 0]),
  (Song2_array[419] = [107, 4, 0]),
  (Song2_array[420] = [107.200005, 3, 0]),
  (Song2_array[421] = [107.4, 5, 0]),
  (Song2_array[422] = [107.700005, 3, 0]),
  (Song2_array[423] = [107.75, 3, 0]),
  (Song2_array[424] = [107.8, 3, 0]),
  (Song2_array[425] = [107.85, 3, 0]),
  (Song2_array[426] = [108.15, 1, 0]),
  (Song2_array[427] = [108.200005, 1, 0]),
  (Song2_array[428] = [108.25, 1, 0]),
  (Song2_array[429] = [108.3, 1, 0]),
  (Song2_array[430] = [108.5, 1, 0.05]),
  (Song2_array[431] = [108.5, 3, 0]),
  (Song2_array[432] = [108.950005, 3, 0]),
  (Song2_array[433] = [109, 3, 0]),
  (Song2_array[434] = [109.05, 3, 0]),
  (Song2_array[435] = [109.1, 3, 0]),
  (Song2_array[436] = [109.3, 3, 0.05]),
  (Song2_array[437] = [109.3, 5, 0]),
  (Song2_array[438] = [109.950005, 3, 0]),
  (Song2_array[439] = [110.15, 4, 0]),
  (Song2_array[440] = [110.35, 5, 0]),
  (Song2_array[441] = [110.6, 3, 0]),
  (Song2_array[442] = [110.8, 2, 0]),
  (Song2_array[443] = [111, 4, 0]),
  (Song2_array[444] = [111.200005, 3, 0]),
  (Song2_array[445] = [111.4, 5, 0]),
  (Song2_array[446] = [111.700005, 3, 0]),
  (Song2_array[447] = [111.75, 3, 0]),
  (Song2_array[448] = [111.8, 3, 0]),
  (Song2_array[449] = [111.85, 3, 0]),
  (Song2_array[450] = [112.1, 3, 0.05]),
  (Song2_array[451] = [112.1, 5, 0]),
  (Song2_array[452] = [112.450005, 3, 0]),
  (Song2_array[453] = [112.450005, 5, 0.05]),
  (Song2_array[454] = [112.65, 3, 0]),
  (Song2_array[455] = [112.75, 3, 0]),
  (Song2_array[456] = [113.200005, 1, 0]),
  (Song2_array[457] = [113.200005, 3, 0.05]),
  (Song2_array[458] = [113.4, 1, 0]),
  (Song2_array[459] = [113.5, 1, 0]),
  (Song2_array[460] = [113.8, 3, 0]),
  (Song2_array[461] = [114, 5, 0]),
  (Song2_array[462] = [114.450005, 3, 0]),
  (Song2_array[463] = [114.700005, 3, 0]),
  (Song2_array[464] = [115, 4, 0]),
  (Song2_array[465] = [115.1, 3, 0]),
  (Song2_array[466] = [115.200005, 4, 0]),
  (Song2_array[467] = [115.35, 3, 0]),
  (Song2_array[468] = [115.5, 2, 0]),
  (Song2_array[469] = [115.65, 1, 0]),
  (Song2_array[470] = [115.9, 3, 0]),
  (Song2_array[471] = [116.1, 3, 0.05]),
  (Song2_array[472] = [116.1, 5, 0]),
  (Song2_array[473] = [116.450005, 3, 0]),
  (Song2_array[474] = [116.450005, 5, 0.05]),
  (Song2_array[475] = [116.65, 3, 0]),
  (Song2_array[476] = [116.75, 3, 0]),
  (Song2_array[477] = [117.200005, 1, 0]),
  (Song2_array[478] = [117.200005, 3, 0.05]),
  (Song2_array[479] = [117.4, 1, 0]),
  (Song2_array[480] = [117.5, 1, 0]),
  (Song2_array[481] = [117.8, 3, 0]),
  (Song2_array[482] = [118, 5, 0]),
  (Song2_array[483] = [118.450005, 3, 0]),
  (Song2_array[484] = [118.700005, 3, 0]),
  (Song2_array[485] = [119, 4, 0]),
  (Song2_array[486] = [119.1, 3, 0]),
  (Song2_array[487] = [119.200005, 4, 0]),
  (Song2_array[488] = [119.35, 3, 0]),
  (Song2_array[489] = [119.5, 2, 0]),
  (Song2_array[490] = [119.65, 1, 0]),
  (Song2_array[491] = [119.9, 3, 0]),
  (Song2_array[492] = [120.15, 1, 0]),
  (Song2_array[493] = [120.200005, 1, 0]),
  (Song2_array[494] = [120.25, 1, 0]),
  (Song2_array[495] = [120.3, 1, 0]),
  (Song2_array[496] = [120.5, 1, 0.05]),
  (Song2_array[497] = [120.5, 3, 0]),
  (Song2_array[498] = [120.950005, 3, 0]),
  (Song2_array[499] = [121, 3, 0]),
  (Song2_array[500] = [121.05, 3, 0]),
  (Song2_array[501] = [121.1, 3, 0]),
  (Song2_array[502] = [121.3, 3, 0.05]),
  (Song2_array[503] = [121.3, 5, 0]),
  (Song2_array[504] = [121.950005, 3, 0]),
  (Song2_array[505] = [122.15, 4, 0]),
  (Song2_array[506] = [122.35, 5, 0]),
  (Song2_array[507] = [122.6, 3, 0]),
  (Song2_array[508] = [122.8, 2, 0]),
  (Song2_array[509] = [123, 4, 0]),
  (Song2_array[510] = [123.200005, 3, 0]),
  (Song2_array[511] = [123.4, 5, 0]),
  (Song2_array[512] = [123.700005, 3, 0]),
  (Song2_array[513] = [123.75, 3, 0]),
  (Song2_array[514] = [123.8, 3, 0]),
  (Song2_array[515] = [123.85, 3, 0]),
  (Song2_array[516] = [124.1, 1, 0]),
  (Song2_array[517] = [124.15, 1, 0]),
  (Song2_array[518] = [124.200005, 1, 0]),
  (Song2_array[519] = [124.25, 1, 0]),
  (Song2_array[520] = [124.450005, 1, 0.05]),
  (Song2_array[521] = [124.450005, 3, 0]),
  (Song2_array[522] = [124.9, 3, 0]),
  (Song2_array[523] = [124.950005, 3, 0]),
  (Song2_array[524] = [125, 3, 0]),
  (Song2_array[525] = [125.05, 3, 0]),
  (Song2_array[526] = [125.25, 3, 0.05]),
  (Song2_array[527] = [125.25, 5, 0]),
  (Song2_array[528] = [125.9, 3, 0]),
  (Song2_array[529] = [126.1, 4, 0]),
  (Song2_array[530] = [126.3, 5, 0]),
  (Song2_array[531] = [126.55, 3, 0]),
  (Song2_array[532] = [126.75, 2, 0]),
  (Song2_array[533] = [126.950005, 4, 0]),
  (Song2_array[534] = [127.15, 3, 0]),
  (Song2_array[535] = [127.35, 5, 0]),
  (Song2_array[536] = [127.65, 3, 0]),
  (Song2_array[537] = [127.700005, 3, 0]),
  (Song2_array[538] = [127.75, 3, 0]),
  (Song2_array[539] = [127.8, 3, 0]);
var Song4_array = [];
(Song4_array[0] = [0.625, 3, 0]),
  (Song4_array[1] = [0.75, 3, 0]),
  (Song4_array[2] = [0.875, 5, 0]),
  (Song4_array[3] = [1.1875, 3, 0]),
  (Song4_array[4] = [1.375, 3, 0]),
  (Song4_array[5] = [1.5, 3, 0]),
  (Song4_array[6] = [1.625, 1, 0]),
  (Song4_array[7] = [1.9375, 3, 0]),
  (Song4_array[8] = [2.0625, 3, 0]),
  (Song4_array[9] = [2.1875, 3, 0]),
  (Song4_array[10] = [2.3125, 5, 0]),
  (Song4_array[11] = [2.625, 3, 0]),
  (Song4_array[12] = [2.9375, 1, 0]),
  (Song4_array[13] = [2.9375, 3, 0.0625]),
  (Song4_array[14] = [3.5, 3, 0]),
  (Song4_array[15] = [3.625, 3, 0]),
  (Song4_array[16] = [3.75, 5, 0]),
  (Song4_array[17] = [4.0625, 3, 0]),
  (Song4_array[18] = [4.1875, 3, 0]),
  (Song4_array[19] = [4.3125, 3, 0]),
  (Song4_array[20] = [4.4375, 1, 0]),
  (Song4_array[21] = [4.75, 3, 0]),
  (Song4_array[22] = [4.875, 3, 0]),
  (Song4_array[23] = [5, 3, 0]),
  (Song4_array[24] = [5.125, 5, 0]),
  (Song4_array[25] = [5.4375, 3, 0]),
  (Song4_array[26] = [5.8125, 3, 0]),
  (Song4_array[27] = [5.875, 3, 0]),
  (Song4_array[28] = [5.9375, 3, 0]),
  (Song4_array[29] = [6.3125, 3, 0]),
  (Song4_array[30] = [6.4375, 3, 0]),
  (Song4_array[31] = [6.5625, 5, 0]),
  (Song4_array[32] = [6.875, 3, 0]),
  (Song4_array[33] = [7.0625, 3, 0]),
  (Song4_array[34] = [7.1875, 3, 0]),
  (Song4_array[35] = [7.3125, 1, 0]),
  (Song4_array[36] = [7.625, 3, 0]),
  (Song4_array[37] = [7.75, 3, 0]),
  (Song4_array[38] = [7.875, 3, 0]),
  (Song4_array[39] = [8, 5, 0]),
  (Song4_array[40] = [8.3125, 3, 0]),
  (Song4_array[41] = [8.625, 1, 0]),
  (Song4_array[42] = [8.625, 3, 0.0625]),
  (Song4_array[43] = [9.1875, 3, 0]),
  (Song4_array[44] = [9.3125, 3, 0]),
  (Song4_array[45] = [9.4375, 5, 0]),
  (Song4_array[46] = [9.75, 3, 0]),
  (Song4_array[47] = [9.875, 3, 0]),
  (Song4_array[48] = [10, 3, 0]),
  (Song4_array[49] = [10.125, 1, 0]),
  (Song4_array[50] = [10.4375, 3, 0]),
  (Song4_array[51] = [10.5625, 3, 0]),
  (Song4_array[52] = [10.6875, 3, 0]),
  (Song4_array[53] = [10.8125, 5, 0]),
  (Song4_array[54] = [11.125, 3, 0]),
  (Song4_array[55] = [11.375, 3, 0]),
  (Song4_array[56] = [11.4375, 3, 0]),
  (Song4_array[57] = [11.5, 3, 0]),
  (Song4_array[58] = [11.5625, 3, 0]),
  (Song4_array[59] = [11.625, 3, 0]),
  (Song4_array[60] = [11.875, 3, 0]),
  (Song4_array[61] = [12, 3, 0]),
  (Song4_array[62] = [12.125, 5, 0]),
  (Song4_array[63] = [12.4375, 3, 0]),
  (Song4_array[64] = [12.5625, 3, 0]),
  (Song4_array[65] = [12.6875, 3, 0]),
  (Song4_array[66] = [12.8125, 1, 0]),
  (Song4_array[67] = [13.125, 3, 0]),
  (Song4_array[68] = [13.25, 3, 0]),
  (Song4_array[69] = [13.375, 3, 0]),
  (Song4_array[70] = [13.5, 5, 0]),
  (Song4_array[71] = [13.8125, 3, 0]),
  (Song4_array[72] = [14.1875, 3, 0]),
  (Song4_array[73] = [14.25, 3, 0]),
  (Song4_array[74] = [14.3125, 3, 0]),
  (Song4_array[75] = [14.6875, 3, 0]),
  (Song4_array[76] = [14.8125, 3, 0]),
  (Song4_array[77] = [14.9375, 5, 0]),
  (Song4_array[78] = [15.25, 3, 0]),
  (Song4_array[79] = [15.4375, 3, 0]),
  (Song4_array[80] = [15.5625, 3, 0]),
  (Song4_array[81] = [15.6875, 1, 0]),
  (Song4_array[82] = [16, 3, 0]),
  (Song4_array[83] = [16.125, 3, 0]),
  (Song4_array[84] = [16.25, 3, 0]),
  (Song4_array[85] = [16.375, 5, 0]),
  (Song4_array[86] = [16.6875, 3, 0]),
  (Song4_array[87] = [17, 1, 0]),
  (Song4_array[88] = [17, 3, 0.0625]),
  (Song4_array[89] = [17.5625, 3, 0]),
  (Song4_array[90] = [17.6875, 3, 0]),
  (Song4_array[91] = [17.8125, 5, 0]),
  (Song4_array[92] = [18.125, 3, 0]),
  (Song4_array[93] = [18.25, 3, 0]),
  (Song4_array[94] = [18.375, 3, 0]),
  (Song4_array[95] = [18.5, 1, 0]),
  (Song4_array[96] = [18.8125, 3, 0]),
  (Song4_array[97] = [18.9375, 3, 0]),
  (Song4_array[98] = [19.0625, 3, 0]),
  (Song4_array[99] = [19.1875, 5, 0]),
  (Song4_array[100] = [19.5, 3, 0]),
  (Song4_array[101] = [19.75, 3, 0]),
  (Song4_array[102] = [19.8125, 3, 0]),
  (Song4_array[103] = [19.875, 3, 0]),
  (Song4_array[104] = [19.9375, 3, 0]),
  (Song4_array[105] = [20, 3, 0]),
  (Song4_array[106] = [20.4375, 3, 0]),
  (Song4_array[107] = [20.5625, 3, 0]),
  (Song4_array[108] = [20.6875, 5, 0]),
  (Song4_array[109] = [21, 3, 0]),
  (Song4_array[110] = [21.125, 3, 0]),
  (Song4_array[111] = [21.25, 3, 0]),
  (Song4_array[112] = [21.375, 1, 0]),
  (Song4_array[113] = [21.6875, 3, 0]),
  (Song4_array[114] = [21.8125, 3, 0]),
  (Song4_array[115] = [21.9375, 3, 0]),
  (Song4_array[116] = [22.0625, 5, 0]),
  (Song4_array[117] = [22.375, 3, 0]),
  (Song4_array[118] = [22.75, 3, 0]),
  (Song4_array[119] = [22.8125, 3, 0]),
  (Song4_array[120] = [22.875, 3, 0]),
  (Song4_array[121] = [23.25, 3, 0]),
  (Song4_array[122] = [23.375, 3, 0]),
  (Song4_array[123] = [23.5, 5, 0]),
  (Song4_array[124] = [23.8125, 3, 0]),
  (Song4_array[125] = [24, 3, 0]),
  (Song4_array[126] = [24.125, 3, 0]),
  (Song4_array[127] = [24.25, 1, 0]),
  (Song4_array[128] = [24.5625, 3, 0]),
  (Song4_array[129] = [24.6875, 3, 0]),
  (Song4_array[130] = [24.8125, 3, 0]),
  (Song4_array[131] = [24.9375, 5, 0]),
  (Song4_array[132] = [25.25, 3, 0]),
  (Song4_array[133] = [25.5625, 1, 0]),
  (Song4_array[134] = [25.5625, 3, 0.0625]),
  (Song4_array[135] = [26.125, 3, 0]),
  (Song4_array[136] = [26.25, 3, 0]),
  (Song4_array[137] = [26.375, 5, 0]),
  (Song4_array[138] = [26.6875, 3, 0]),
  (Song4_array[139] = [26.8125, 3, 0]),
  (Song4_array[140] = [26.9375, 3, 0]),
  (Song4_array[141] = [27.0625, 1, 0]),
  (Song4_array[142] = [27.375, 3, 0]),
  (Song4_array[143] = [27.5, 3, 0]),
  (Song4_array[144] = [27.625, 3, 0]),
  (Song4_array[145] = [27.75, 5, 0]),
  (Song4_array[146] = [28.0625, 3, 0]),
  (Song4_array[147] = [28.3125, 3, 0]),
  (Song4_array[148] = [28.375, 3, 0]),
  (Song4_array[149] = [28.4375, 3, 0]),
  (Song4_array[150] = [28.5, 3, 0]),
  (Song4_array[151] = [28.5625, 3, 0]),
  (Song4_array[152] = [28.875, 3, 0]),
  (Song4_array[153] = [29, 3, 0]),
  (Song4_array[154] = [29.125, 5, 0]),
  (Song4_array[155] = [29.4375, 3, 0]),
  (Song4_array[156] = [29.5625, 3, 0]),
  (Song4_array[157] = [29.6875, 3, 0]),
  (Song4_array[158] = [29.8125, 1, 0]),
  (Song4_array[159] = [30.125, 3, 0]),
  (Song4_array[160] = [30.25, 3, 0]),
  (Song4_array[161] = [30.375, 3, 0]),
  (Song4_array[162] = [30.5, 5, 0]),
  (Song4_array[163] = [30.8125, 3, 0]),
  (Song4_array[164] = [31.1875, 3, 0]),
  (Song4_array[165] = [31.25, 3, 0]),
  (Song4_array[166] = [31.3125, 3, 0]),
  (Song4_array[167] = [31.6875, 3, 0]),
  (Song4_array[168] = [31.8125, 3, 0]),
  (Song4_array[169] = [31.9375, 5, 0]),
  (Song4_array[170] = [32.25, 3, 0]),
  (Song4_array[171] = [32.4375, 3, 0]),
  (Song4_array[172] = [32.5625, 3, 0]),
  (Song4_array[173] = [32.6875, 1, 0]),
  (Song4_array[174] = [33, 3, 0]),
  (Song4_array[175] = [33.125, 3, 0]),
  (Song4_array[176] = [33.25, 3, 0]),
  (Song4_array[177] = [33.375, 5, 0]),
  (Song4_array[178] = [33.6875, 3, 0]),
  (Song4_array[179] = [34, 1, 0]),
  (Song4_array[180] = [34, 3, 0.0625]),
  (Song4_array[181] = [34.6875, 3, 0]),
  (Song4_array[182] = [34.8125, 5, 0]),
  (Song4_array[183] = [35.1875, 2, 0]),
  (Song4_array[184] = [35.3125, 4, 0]),
  (Song4_array[185] = [35.75, 1, 0]),
  (Song4_array[186] = [35.875, 3, 0]),
  (Song4_array[187] = [36.25, 1, 0]),
  (Song4_array[188] = [36.375, 2, 0]),
  (Song4_array[189] = [36.875, 1, 0]),
  (Song4_array[190] = [37.5625, 3, 0]),
  (Song4_array[191] = [37.6875, 5, 0]),
  (Song4_array[192] = [38.0625, 2, 0]),
  (Song4_array[193] = [38.1875, 4, 0]),
  (Song4_array[194] = [38.625, 1, 0]),
  (Song4_array[195] = [38.75, 3, 0]),
  (Song4_array[196] = [39.125, 1, 0]),
  (Song4_array[197] = [39.25, 2, 0]),
  (Song4_array[198] = [39.75, 1, 0]),
  (Song4_array[199] = [40.375, 3, 0]),
  (Song4_array[200] = [40.5, 5, 0]),
  (Song4_array[201] = [40.875, 2, 0]),
  (Song4_array[202] = [41, 4, 0]),
  (Song4_array[203] = [41.4375, 1, 0]),
  (Song4_array[204] = [41.5625, 3, 0]),
  (Song4_array[205] = [41.9375, 1, 0]),
  (Song4_array[206] = [42.0625, 2, 0]),
  (Song4_array[207] = [42.5625, 1, 0]),
  (Song4_array[208] = [43.1875, 3, 0]),
  (Song4_array[209] = [43.3125, 5, 0]),
  (Song4_array[210] = [43.6875, 2, 0]),
  (Song4_array[211] = [43.8125, 4, 0]),
  (Song4_array[212] = [44.25, 1, 0]),
  (Song4_array[213] = [44.375, 3, 0]),
  (Song4_array[214] = [44.75, 1, 0]),
  (Song4_array[215] = [44.875, 2, 0]),
  (Song4_array[216] = [45.375, 1, 0]),
  (Song4_array[217] = [46, 3, 0]),
  (Song4_array[218] = [46.125, 5, 0]),
  (Song4_array[219] = [46.5, 2, 0]),
  (Song4_array[220] = [46.625, 4, 0]),
  (Song4_array[221] = [47.0625, 1, 0]),
  (Song4_array[222] = [47.1875, 3, 0]),
  (Song4_array[223] = [47.5625, 1, 0]),
  (Song4_array[224] = [47.6875, 2, 0]),
  (Song4_array[225] = [48.1875, 1, 0]),
  (Song4_array[226] = [48.8125, 3, 0]),
  (Song4_array[227] = [48.9375, 5, 0]),
  (Song4_array[228] = [49.3125, 2, 0]),
  (Song4_array[229] = [49.4375, 4, 0]),
  (Song4_array[230] = [49.875, 1, 0]),
  (Song4_array[231] = [50, 3, 0]),
  (Song4_array[232] = [50.375, 1, 0]),
  (Song4_array[233] = [50.5, 2, 0]),
  (Song4_array[234] = [51, 1, 0]),
  (Song4_array[235] = [51.625, 3, 0]),
  (Song4_array[236] = [51.75, 5, 0]),
  (Song4_array[237] = [52.125, 2, 0]),
  (Song4_array[238] = [52.25, 4, 0]),
  (Song4_array[239] = [52.6875, 1, 0]),
  (Song4_array[240] = [52.8125, 3, 0]),
  (Song4_array[241] = [53.1875, 1, 0]),
  (Song4_array[242] = [53.3125, 2, 0]),
  (Song4_array[243] = [53.8125, 1, 0]),
  (Song4_array[244] = [54.4375, 3, 0]),
  (Song4_array[245] = [54.5625, 5, 0]),
  (Song4_array[246] = [54.9375, 2, 0]),
  (Song4_array[247] = [55.0625, 4, 0]),
  (Song4_array[248] = [55.5, 1, 0]),
  (Song4_array[249] = [55.625, 3, 0]),
  (Song4_array[250] = [56, 1, 0]),
  (Song4_array[251] = [56.125, 2, 0]),
  (Song4_array[252] = [56.625, 1, 0]),
  (Song4_array[253] = [57.3125, 3, 0.0625]),
  (Song4_array[254] = [57.3125, 5, 0]),
  (Song4_array[255] = [58, 1, 0.0625]),
  (Song4_array[256] = [58, 3, 0]),
  (Song4_array[257] = [58.75, 3, 0.0625]),
  (Song4_array[258] = [58.75, 5, 0]),
  (Song4_array[259] = [59.4375, 1, 0]),
  (Song4_array[260] = [59.4375, 3, 0.0625]),
  (Song4_array[261] = [60.0625, 1, 0.0625]),
  (Song4_array[262] = [60.0625, 3, 0]),
  (Song4_array[263] = [60.0625, 5, 0.0625]),
  (Song4_array[264] = [60.8125, 1, 0]),
  (Song4_array[265] = [60.8125, 3, 0.0625]),
  (Song4_array[266] = [61.5, 3, 0.0625]),
  (Song4_array[267] = [61.5, 5, 0]),
  (Song4_array[268] = [62.1875, 2, 0]),
  (Song4_array[269] = [62.9375, 1, 0.0625]),
  (Song4_array[270] = [62.9375, 3, 0.0625]),
  (Song4_array[271] = [62.9375, 5, 0]),
  (Song4_array[272] = [63.6875, 3, 0]),
  (Song4_array[273] = [63.6875, 5, 0.0625]),
  (Song4_array[274] = [64.375, 1, 0]),
  (Song4_array[275] = [64.375, 3, 0.0625]),
  (Song4_array[276] = [65, 4, 0]),
  (Song4_array[277] = [65.6875, 2, 0]),
  (Song4_array[278] = [66.4375, 3, 0.0625]),
  (Song4_array[279] = [66.4375, 5, 0]),
  (Song4_array[280] = [67.125, 1, 0.0625]),
  (Song4_array[281] = [67.125, 3, 0]),
  (Song4_array[282] = [67.125, 5, 0.0625]),
  (Song4_array[283] = [67.8125, 1, 0]),
  (Song4_array[284] = [67.8125, 3, 0.0625]),
  (Song4_array[285] = [68.5, 4, 0]),
  (Song4_array[286] = [69.25, 3, 0.0625]),
  (Song4_array[287] = [69.25, 5, 0]),
  (Song4_array[288] = [69.9375, 2, 0]),
  (Song4_array[289] = [70.6875, 1, 0.0625]),
  (Song4_array[290] = [70.6875, 3, 0]),
  (Song4_array[291] = [71.375, 2, 0]),
  (Song4_array[292] = [72.125, 1, 0.0625]),
  (Song4_array[293] = [72.125, 5, 0]),
  (Song4_array[294] = [72.8125, 1, 0]),
  (Song4_array[295] = [72.8125, 3, 0.0625]),
  (Song4_array[296] = [73.5, 4, 0]),
  (Song4_array[297] = [74.1875, 2, 0]),
  (Song4_array[298] = [74.875, 3, 0.0625]),
  (Song4_array[299] = [74.875, 5, 0]),
  (Song4_array[300] = [75.5625, 1, 0]),
  (Song4_array[301] = [75.5625, 3, 0.0625]),
  (Song4_array[302] = [76.375, 4, 0]),
  (Song4_array[303] = [77.0625, 2, 0]),
  (Song4_array[304] = [77.75, 4, 0]),
  (Song4_array[305] = [78.4375, 3, 0.0625]),
  (Song4_array[306] = [78.4375, 5, 0]),
  (Song4_array[307] = [79.6875, 3, 0]),
  (Song4_array[308] = [79.8125, 3, 0]),
  (Song4_array[309] = [79.9375, 5, 0]),
  (Song4_array[310] = [80.25, 3, 0]),
  (Song4_array[311] = [80.4375, 3, 0]),
  (Song4_array[312] = [80.5625, 3, 0]),
  (Song4_array[313] = [80.6875, 1, 0]),
  (Song4_array[314] = [81, 3, 0]),
  (Song4_array[315] = [81.125, 3, 0]),
  (Song4_array[316] = [81.25, 3, 0]),
  (Song4_array[317] = [81.375, 5, 0]),
  (Song4_array[318] = [81.6875, 3, 0]),
  (Song4_array[319] = [82, 1, 0]),
  (Song4_array[320] = [82.5625, 3, 0]),
  (Song4_array[321] = [82.6875, 3, 0]),
  (Song4_array[322] = [82.8125, 5, 0]),
  (Song4_array[323] = [83.125, 3, 0]),
  (Song4_array[324] = [83.25, 3, 0]),
  (Song4_array[325] = [83.375, 3, 0]),
  (Song4_array[326] = [83.5, 1, 0]),
  (Song4_array[327] = [83.8125, 3, 0]),
  (Song4_array[328] = [83.9375, 3, 0]),
  (Song4_array[329] = [84.0625, 3, 0]),
  (Song4_array[330] = [84.1875, 5, 0]),
  (Song4_array[331] = [84.5, 3, 0]),
  (Song4_array[332] = [84.875, 3, 0]),
  (Song4_array[333] = [84.9375, 3, 0]),
  (Song4_array[334] = [85, 3, 0]),
  (Song4_array[335] = [85.375, 3, 0]),
  (Song4_array[336] = [85.5, 3, 0]),
  (Song4_array[337] = [85.625, 5, 0]),
  (Song4_array[338] = [85.9375, 3, 0]),
  (Song4_array[339] = [86.125, 3, 0]),
  (Song4_array[340] = [86.25, 3, 0]),
  (Song4_array[341] = [86.375, 1, 0]),
  (Song4_array[342] = [86.6875, 3, 0]),
  (Song4_array[343] = [86.8125, 3, 0]),
  (Song4_array[344] = [86.9375, 3, 0]),
  (Song4_array[345] = [87.0625, 5, 0]),
  (Song4_array[346] = [87.375, 3, 0]),
  (Song4_array[347] = [87.6875, 1, 0]),
  (Song4_array[348] = [88.25, 3, 0]),
  (Song4_array[349] = [88.375, 3, 0]),
  (Song4_array[350] = [88.5, 5, 0]),
  (Song4_array[351] = [88.8125, 3, 0]),
  (Song4_array[352] = [88.9375, 3, 0]),
  (Song4_array[353] = [89.0625, 3, 0]),
  (Song4_array[354] = [89.1875, 1, 0]),
  (Song4_array[355] = [89.5, 3, 0]),
  (Song4_array[356] = [89.625, 3, 0]),
  (Song4_array[357] = [89.75, 3, 0]),
  (Song4_array[358] = [89.875, 5, 0]),
  (Song4_array[359] = [90.1875, 3, 0]),
  (Song4_array[360] = [90.4375, 3, 0]),
  (Song4_array[361] = [90.5, 3, 0]),
  (Song4_array[362] = [90.5625, 3, 0]),
  (Song4_array[363] = [90.625, 3, 0]),
  (Song4_array[364] = [90.6875, 3, 0]),
  (Song4_array[365] = [90.9375, 3, 0]),
  (Song4_array[366] = [91.0625, 3, 0]),
  (Song4_array[367] = [91.1875, 5, 0]),
  (Song4_array[368] = [91.5, 3, 0]),
  (Song4_array[369] = [91.625, 3, 0]),
  (Song4_array[370] = [91.75, 3, 0]),
  (Song4_array[371] = [91.875, 1, 0]),
  (Song4_array[372] = [92.1875, 3, 0]),
  (Song4_array[373] = [92.3125, 3, 0]),
  (Song4_array[374] = [92.4375, 3, 0]),
  (Song4_array[375] = [92.5625, 5, 0]),
  (Song4_array[376] = [92.875, 3, 0]),
  (Song4_array[377] = [93.25, 3, 0]),
  (Song4_array[378] = [93.3125, 3, 0]),
  (Song4_array[379] = [93.375, 3, 0]),
  (Song4_array[380] = [93.75, 3, 0]),
  (Song4_array[381] = [93.875, 3, 0]),
  (Song4_array[382] = [94, 5, 0]),
  (Song4_array[383] = [94.3125, 3, 0]),
  (Song4_array[384] = [94.5, 3, 0]),
  (Song4_array[385] = [94.625, 3, 0]),
  (Song4_array[386] = [94.75, 1, 0]),
  (Song4_array[387] = [95.0625, 3, 0]),
  (Song4_array[388] = [95.1875, 3, 0]),
  (Song4_array[389] = [95.3125, 3, 0]),
  (Song4_array[390] = [95.4375, 5, 0]),
  (Song4_array[391] = [95.75, 3, 0]),
  (Song4_array[392] = [96.0625, 1, 0]),
  (Song4_array[393] = [96.625, 3, 0]),
  (Song4_array[394] = [96.75, 3, 0]),
  (Song4_array[395] = [96.875, 5, 0]),
  (Song4_array[396] = [97.1875, 3, 0]),
  (Song4_array[397] = [97.3125, 3, 0]),
  (Song4_array[398] = [97.4375, 3, 0]),
  (Song4_array[399] = [97.5625, 1, 0]),
  (Song4_array[400] = [97.875, 3, 0]),
  (Song4_array[401] = [98, 3, 0]),
  (Song4_array[402] = [98.125, 3, 0]),
  (Song4_array[403] = [98.25, 5, 0]),
  (Song4_array[404] = [98.5625, 3, 0]),
  (Song4_array[405] = [98.8125, 3, 0]),
  (Song4_array[406] = [98.875, 3, 0]),
  (Song4_array[407] = [98.9375, 3, 0]),
  (Song4_array[408] = [99, 3, 0]),
  (Song4_array[409] = [99.0625, 3, 0]),
  (Song4_array[410] = [99.5, 3, 0]),
  (Song4_array[411] = [99.625, 3, 0]),
  (Song4_array[412] = [99.75, 5, 0]),
  (Song4_array[413] = [100.0625, 3, 0]),
  (Song4_array[414] = [100.1875, 3, 0]),
  (Song4_array[415] = [100.3125, 3, 0]),
  (Song4_array[416] = [100.4375, 1, 0]),
  (Song4_array[417] = [100.75, 3, 0]),
  (Song4_array[418] = [100.875, 3, 0]),
  (Song4_array[419] = [101, 3, 0]),
  (Song4_array[420] = [101.125, 5, 0]),
  (Song4_array[421] = [101.4375, 3, 0]),
  (Song4_array[422] = [101.8125, 3, 0]),
  (Song4_array[423] = [101.875, 3, 0]),
  (Song4_array[424] = [101.9375, 3, 0]),
  (Song4_array[425] = [102.4375, 1, 0]),
  (Song4_array[426] = [102.625, 3, 0]),
  (Song4_array[427] = [102.8125, 2, 0]),
  (Song4_array[428] = [103.1875, 4, 0]),
  (Song4_array[429] = [103.875, 1, 0]),
  (Song4_array[430] = [104.125, 3, 0]),
  (Song4_array[431] = [104.25, 4, 0]),
  (Song4_array[432] = [104.375, 3, 0]),
  (Song4_array[433] = [104.625, 5, 0]),
  (Song4_array[434] = [104.8125, 4, 0]),
  (Song4_array[435] = [105.3125, 1, 0]),
  (Song4_array[436] = [105.5, 3, 0]),
  (Song4_array[437] = [105.6875, 2, 0]),
  (Song4_array[438] = [106.0625, 4, 0]),
  (Song4_array[439] = [106.75, 1, 0]),
  (Song4_array[440] = [107, 3, 0]),
  (Song4_array[441] = [107.125, 4, 0]),
  (Song4_array[442] = [107.25, 3, 0]),
  (Song4_array[443] = [107.5, 5, 0]),
  (Song4_array[444] = [107.6875, 4, 0]),
  (Song4_array[445] = [108.125, 2, 0]),
  (Song4_array[446] = [109.6875, 3, 0]),
  (Song4_array[447] = [109.875, 1, 0]),
  (Song4_array[448] = [110.0625, 3, 0]),
  (Song4_array[449] = [110.5, 4, 0]),
  (Song4_array[450] = [110.6875, 4, 0]),
  (Song4_array[451] = [111, 2, 0]),
  (Song4_array[452] = [111.375, 4, 0]),
  (Song4_array[453] = [112.4375, 5, 0]),
  (Song4_array[454] = [112.625, 5, 0]),
  (Song4_array[455] = [112.75, 4, 0]),
  (Song4_array[456] = [112.9375, 4, 0]),
  (Song4_array[457] = [113.125, 3, 0]),
  (Song4_array[458] = [113.4375, 2, 0]),
  (Song4_array[459] = [113.8125, 1, 0]),
  (Song4_array[460] = [114, 3, 0]),
  (Song4_array[461] = [114.1875, 2, 0]),
  (Song4_array[462] = [114.5625, 4, 0]),
  (Song4_array[463] = [115.25, 1, 0]),
  (Song4_array[464] = [115.5, 3, 0]),
  (Song4_array[465] = [115.625, 4, 0]),
  (Song4_array[466] = [115.75, 3, 0]),
  (Song4_array[467] = [116, 5, 0]),
  (Song4_array[468] = [116.1875, 4, 0]),
  (Song4_array[469] = [116.6875, 1, 0]),
  (Song4_array[470] = [116.875, 3, 0]),
  (Song4_array[471] = [117.0625, 2, 0]),
  (Song4_array[472] = [117.4375, 4, 0]),
  (Song4_array[473] = [118.125, 1, 0]),
  (Song4_array[474] = [118.375, 3, 0]),
  (Song4_array[475] = [118.5, 4, 0]),
  (Song4_array[476] = [118.625, 3, 0]),
  (Song4_array[477] = [118.875, 5, 0]),
  (Song4_array[478] = [119.0625, 4, 0]),
  (Song4_array[479] = [119.5, 2, 0]),
  (Song4_array[480] = [121.0625, 3, 0]),
  (Song4_array[481] = [121.25, 1, 0]),
  (Song4_array[482] = [121.4375, 3, 0]),
  (Song4_array[483] = [121.875, 4, 0]),
  (Song4_array[484] = [122.0625, 4, 0]),
  (Song4_array[485] = [122.375, 2, 0]),
  (Song4_array[486] = [122.75, 4, 0]),
  (Song4_array[487] = [123.8125, 5, 0]),
  (Song4_array[488] = [124, 5, 0]),
  (Song4_array[489] = [124.125, 4, 0]),
  (Song4_array[490] = [124.3125, 4, 0]),
  (Song4_array[491] = [124.5, 3, 0]),
  (Song4_array[492] = [124.8125, 2, 0]),
  (Song4_array[493] = [124.9375, 3, 0]),
  (Song4_array[494] = [125.0625, 3, 0]),
  (Song4_array[495] = [125.1875, 5, 0]),
  (Song4_array[496] = [125.5, 3, 0]),
  (Song4_array[497] = [125.6875, 3, 0]),
  (Song4_array[498] = [125.8125, 3, 0]),
  (Song4_array[499] = [125.9375, 1, 0]),
  (Song4_array[500] = [126.25, 3, 0]),
  (Song4_array[501] = [126.375, 3, 0]),
  (Song4_array[502] = [126.5, 3, 0]),
  (Song4_array[503] = [126.625, 5, 0]),
  (Song4_array[504] = [126.9375, 3, 0]),
  (Song4_array[505] = [127.25, 1, 0]),
  (Song4_array[506] = [127.25, 3, 0.0625]),
  (Song4_array[507] = [127.8125, 3, 0]),
  (Song4_array[508] = [127.9375, 3, 0]),
  (Song4_array[509] = [128.0625, 5, 0]),
  (Song4_array[510] = [128.375, 3, 0]),
  (Song4_array[511] = [128.5, 3, 0]),
  (Song4_array[512] = [128.625, 3, 0]),
  (Song4_array[513] = [128.75, 1, 0]),
  (Song4_array[514] = [129.0625, 3, 0]),
  (Song4_array[515] = [129.1875, 3, 0]),
  (Song4_array[516] = [129.3125, 3, 0]),
  (Song4_array[517] = [129.4375, 5, 0]),
  (Song4_array[518] = [129.75, 3, 0]),
  (Song4_array[519] = [130.125, 3, 0]),
  (Song4_array[520] = [130.1875, 3, 0]),
  (Song4_array[521] = [130.25, 3, 0]),
  (Song4_array[522] = [130.625, 3, 0]),
  (Song4_array[523] = [130.75, 3, 0]),
  (Song4_array[524] = [130.875, 5, 0]),
  (Song4_array[525] = [131.1875, 3, 0]),
  (Song4_array[526] = [131.375, 3, 0]),
  (Song4_array[527] = [131.5, 3, 0]),
  (Song4_array[528] = [131.625, 1, 0]),
  (Song4_array[529] = [131.9375, 3, 0]),
  (Song4_array[530] = [132.0625, 3, 0]),
  (Song4_array[531] = [132.1875, 3, 0]),
  (Song4_array[532] = [132.3125, 5, 0]),
  (Song4_array[533] = [132.625, 3, 0]),
  (Song4_array[534] = [132.9375, 1, 0]),
  (Song4_array[535] = [132.9375, 3, 0.0625]),
  (Song4_array[536] = [133.5, 3, 0]),
  (Song4_array[537] = [133.625, 3, 0]),
  (Song4_array[538] = [133.75, 5, 0]),
  (Song4_array[539] = [134.0625, 3, 0]),
  (Song4_array[540] = [134.1875, 3, 0]),
  (Song4_array[541] = [134.3125, 3, 0]),
  (Song4_array[542] = [134.4375, 1, 0]),
  (Song4_array[543] = [134.75, 3, 0]),
  (Song4_array[544] = [134.875, 3, 0]),
  (Song4_array[545] = [135, 3, 0]),
  (Song4_array[546] = [135.125, 5, 0]),
  (Song4_array[547] = [135.4375, 3, 0]),
  (Song4_array[548] = [135.6875, 3, 0]),
  (Song4_array[549] = [135.75, 3, 0]),
  (Song4_array[550] = [135.8125, 3, 0]),
  (Song4_array[551] = [135.875, 3, 0]),
  (Song4_array[552] = [135.9375, 3, 0]),
  (Song4_array[553] = [136.1875, 3, 0]),
  (Song4_array[554] = [136.3125, 3, 0]),
  (Song4_array[555] = [136.4375, 5, 0]),
  (Song4_array[556] = [136.75, 3, 0]),
  (Song4_array[557] = [136.875, 3, 0]),
  (Song4_array[558] = [137, 3, 0]),
  (Song4_array[559] = [137.125, 1, 0]),
  (Song4_array[560] = [137.4375, 3, 0]),
  (Song4_array[561] = [137.5625, 3, 0]),
  (Song4_array[562] = [137.6875, 3, 0]),
  (Song4_array[563] = [137.8125, 5, 0]),
  (Song4_array[564] = [138.125, 3, 0]),
  (Song4_array[565] = [138.5, 3, 0]),
  (Song4_array[566] = [138.5625, 3, 0]),
  (Song4_array[567] = [138.625, 3, 0]),
  (Song4_array[568] = [139, 3, 0]),
  (Song4_array[569] = [139.125, 3, 0]),
  (Song4_array[570] = [139.25, 5, 0]),
  (Song4_array[571] = [139.5625, 3, 0]),
  (Song4_array[572] = [139.75, 3, 0]),
  (Song4_array[573] = [139.875, 3, 0]),
  (Song4_array[574] = [140, 1, 0]),
  (Song4_array[575] = [140.3125, 3, 0]),
  (Song4_array[576] = [140.4375, 3, 0]),
  (Song4_array[577] = [140.5625, 3, 0]),
  (Song4_array[578] = [140.6875, 5, 0]),
  (Song4_array[579] = [141, 3, 0]),
  (Song4_array[580] = [141.3125, 1, 0]),
  (Song4_array[581] = [141.3125, 3, 0.0625]),
  (Song4_array[582] = [141.875, 3, 0]),
  (Song4_array[583] = [142, 3, 0]),
  (Song4_array[584] = [142.125, 5, 0]),
  (Song4_array[585] = [142.4375, 3, 0]),
  (Song4_array[586] = [142.5625, 3, 0]),
  (Song4_array[587] = [142.6875, 3, 0]),
  (Song4_array[588] = [142.8125, 1, 0]),
  (Song4_array[589] = [143.125, 3, 0]),
  (Song4_array[590] = [143.25, 3, 0]),
  (Song4_array[591] = [143.375, 3, 0]),
  (Song4_array[592] = [143.5, 5, 0]),
  (Song4_array[593] = [143.8125, 3, 0]),
  (Song4_array[594] = [144.0625, 3, 0]),
  (Song4_array[595] = [144.125, 3, 0]),
  (Song4_array[596] = [144.1875, 3, 0]),
  (Song4_array[597] = [144.25, 3, 0]),
  (Song4_array[598] = [144.3125, 3, 0]),
  (Song4_array[599] = [144.75, 3, 0]),
  (Song4_array[600] = [144.875, 3, 0]),
  (Song4_array[601] = [145, 5, 0]),
  (Song4_array[602] = [145.3125, 3, 0]),
  (Song4_array[603] = [145.4375, 3, 0]),
  (Song4_array[604] = [145.5625, 3, 0]),
  (Song4_array[605] = [145.6875, 1, 0]),
  (Song4_array[606] = [146, 3, 0]),
  (Song4_array[607] = [146.125, 3, 0]),
  (Song4_array[608] = [146.25, 3, 0]),
  (Song4_array[609] = [146.375, 5, 0]),
  (Song4_array[610] = [146.6875, 3, 0]),
  (Song4_array[611] = [147.0625, 3, 0]),
  (Song4_array[612] = [147.125, 3, 0]),
  (Song4_array[613] = [147.1875, 3, 0]),
  (Song4_array[614] = [147.625, 3, 0]),
  (Song4_array[615] = [147.75, 5, 0]),
  (Song4_array[616] = [148.125, 2, 0]),
  (Song4_array[617] = [148.25, 4, 0]),
  (Song4_array[618] = [148.6875, 1, 0]),
  (Song4_array[619] = [148.8125, 3, 0]),
  (Song4_array[620] = [149.1875, 1, 0]),
  (Song4_array[621] = [149.3125, 2, 0]),
  (Song4_array[622] = [149.8125, 1, 0]),
  (Song4_array[623] = [150.5, 3, 0]),
  (Song4_array[624] = [150.625, 5, 0]),
  (Song4_array[625] = [151, 2, 0]),
  (Song4_array[626] = [151.125, 4, 0]),
  (Song4_array[627] = [151.5625, 1, 0]),
  (Song4_array[628] = [151.6875, 3, 0]),
  (Song4_array[629] = [152.0625, 1, 0]),
  (Song4_array[630] = [152.1875, 2, 0]),
  (Song4_array[631] = [152.6875, 1, 0]),
  (Song4_array[632] = [153.3125, 3, 0]),
  (Song4_array[633] = [153.4375, 5, 0]),
  (Song4_array[634] = [153.8125, 2, 0]),
  (Song4_array[635] = [153.9375, 4, 0]),
  (Song4_array[636] = [154.375, 1, 0]),
  (Song4_array[637] = [154.5, 3, 0]),
  (Song4_array[638] = [154.875, 1, 0]),
  (Song4_array[639] = [155, 2, 0]),
  (Song4_array[640] = [155.5, 1, 0]),
  (Song4_array[641] = [156.125, 3, 0]),
  (Song4_array[642] = [156.25, 5, 0]),
  (Song4_array[643] = [156.625, 2, 0]),
  (Song4_array[644] = [156.75, 4, 0]),
  (Song4_array[645] = [157.1875, 1, 0]),
  (Song4_array[646] = [157.3125, 3, 0]),
  (Song4_array[647] = [157.6875, 1, 0]),
  (Song4_array[648] = [157.8125, 2, 0]),
  (Song4_array[649] = [158.3125, 1, 0]),
  (Song4_array[650] = [158.9375, 3, 0]),
  (Song4_array[651] = [159.0625, 5, 0]),
  (Song4_array[652] = [159.4375, 2, 0]),
  (Song4_array[653] = [159.5625, 4, 0]),
  (Song4_array[654] = [160, 1, 0]),
  (Song4_array[655] = [160.125, 3, 0]),
  (Song4_array[656] = [160.5, 1, 0]),
  (Song4_array[657] = [160.625, 2, 0]),
  (Song4_array[658] = [161.125, 1, 0]),
  (Song4_array[659] = [161.75, 3, 0]),
  (Song4_array[660] = [161.875, 5, 0]),
  (Song4_array[661] = [162.25, 2, 0]),
  (Song4_array[662] = [162.375, 4, 0]),
  (Song4_array[663] = [162.8125, 1, 0]),
  (Song4_array[664] = [162.9375, 3, 0]),
  (Song4_array[665] = [163.3125, 1, 0]),
  (Song4_array[666] = [163.4375, 2, 0]),
  (Song4_array[667] = [163.9375, 1, 0]),
  (Song4_array[668] = [164.5625, 3, 0]),
  (Song4_array[669] = [164.6875, 5, 0]),
  (Song4_array[670] = [165.0625, 2, 0]),
  (Song4_array[671] = [165.1875, 4, 0]),
  (Song4_array[672] = [165.625, 1, 0]),
  (Song4_array[673] = [165.75, 3, 0]),
  (Song4_array[674] = [166.125, 1, 0]),
  (Song4_array[675] = [166.25, 2, 0]),
  (Song4_array[676] = [166.75, 1, 0]),
  (Song4_array[677] = [167.375, 3, 0]),
  (Song4_array[678] = [167.5, 5, 0]),
  (Song4_array[679] = [167.875, 2, 0]),
  (Song4_array[680] = [168, 4, 0]),
  (Song4_array[681] = [168.4375, 1, 0]),
  (Song4_array[682] = [168.5625, 3, 0]),
  (Song4_array[683] = [168.9375, 1, 0]),
  (Song4_array[684] = [169.0625, 2, 0]),
  (Song4_array[685] = [169.5625, 1, 0]),
  (Song4_array[686] = [170.1875, 3, 0]),
  (Song4_array[687] = [170.3125, 5, 0]),
  (Song4_array[688] = [170.6875, 2, 0]),
  (Song4_array[689] = [170.8125, 4, 0]),
  (Song4_array[690] = [171.25, 1, 0]),
  (Song4_array[691] = [171.375, 3, 0]),
  (Song4_array[692] = [171.75, 1, 0]),
  (Song4_array[693] = [171.875, 2, 0]),
  (Song4_array[694] = [172.375, 1, 0]),
  (Song4_array[695] = [173.0625, 3, 0]),
  (Song4_array[696] = [173.1875, 5, 0]),
  (Song4_array[697] = [173.5625, 2, 0]),
  (Song4_array[698] = [173.6875, 4, 0]),
  (Song4_array[699] = [174.125, 1, 0]),
  (Song4_array[700] = [174.25, 3, 0]),
  (Song4_array[701] = [174.625, 1, 0]),
  (Song4_array[702] = [174.75, 2, 0]),
  (Song4_array[703] = [175.25, 1, 0]),
  (Song4_array[704] = [175.875, 3, 0]),
  (Song4_array[705] = [176, 5, 0]),
  (Song4_array[706] = [176.375, 2, 0]),
  (Song4_array[707] = [176.5, 4, 0]),
  (Song4_array[708] = [176.9375, 1, 0]),
  (Song4_array[709] = [177.0625, 3, 0]),
  (Song4_array[710] = [177.4375, 1, 0]),
  (Song4_array[711] = [177.5625, 2, 0]),
  (Song4_array[712] = [178.0625, 1, 0]),
  (Song4_array[713] = [178.6875, 3, 0.0625]),
  (Song4_array[714] = [178.6875, 5, 0]),
  (Song4_array[715] = [179.375, 1, 0.0625]),
  (Song4_array[716] = [179.375, 3, 0]),
  (Song4_array[717] = [180.125, 3, 0.0625]),
  (Song4_array[718] = [180.125, 5, 0]),
  (Song4_array[719] = [180.8125, 1, 0]),
  (Song4_array[720] = [180.8125, 3, 0.0625]),
  (Song4_array[721] = [181.4375, 1, 0.0625]),
  (Song4_array[722] = [181.4375, 3, 0]),
  (Song4_array[723] = [181.4375, 5, 0.0625]),
  (Song4_array[724] = [182.1875, 1, 0]),
  (Song4_array[725] = [182.1875, 3, 0.0625]),
  (Song4_array[726] = [182.875, 3, 0.0625]),
  (Song4_array[727] = [182.875, 5, 0]),
  (Song4_array[728] = [183.5625, 2, 0]),
  (Song4_array[729] = [184.3125, 1, 0.0625]),
  (Song4_array[730] = [184.3125, 3, 0.0625]),
  (Song4_array[731] = [184.3125, 5, 0]),
  (Song4_array[732] = [185.0625, 3, 0]),
  (Song4_array[733] = [185.0625, 5, 0.0625]),
  (Song4_array[734] = [185.75, 1, 0]),
  (Song4_array[735] = [185.75, 3, 0.0625]),
  (Song4_array[736] = [186.375, 4, 0]),
  (Song4_array[737] = [187.0625, 2, 0]),
  (Song4_array[738] = [187.8125, 3, 0.0625]),
  (Song4_array[739] = [187.8125, 5, 0]),
  (Song4_array[740] = [188.5, 1, 0.0625]),
  (Song4_array[741] = [188.5, 3, 0]),
  (Song4_array[742] = [188.5, 5, 0.0625]),
  (Song4_array[743] = [189.1875, 1, 0]),
  (Song4_array[744] = [189.1875, 3, 0.0625]),
  (Song4_array[745] = [189.875, 4, 0]),
  (Song4_array[746] = [190.625, 3, 0.0625]),
  (Song4_array[747] = [190.625, 5, 0]),
  (Song4_array[748] = [191.3125, 3, 0]),
  (Song4_array[749] = [191.875, 1, 0]),
  (Song4_array[750] = [191.9375, 1, 0]),
  (Song4_array[751] = [192, 1, 0]),
  (Song4_array[752] = [192.0625, 1, 0]),
  (Song4_array[753] = [192.125, 1, 0]),
  (Song4_array[754] = [192.1875, 1, 0]),
  (Song4_array[755] = [192.25, 1, 0]),
  (Song4_array[756] = [192.3125, 1, 0]),
  (Song4_array[757] = [192.4375, 2, 0]),
  (Song4_array[758] = [192.8125, 5, 0]),
  (Song4_array[759] = [192.9375, 3, 0]),
  (Song4_array[760] = [193.0625, 4, 0]),
  (Song4_array[761] = [193.3125, 4, 0]),
  (Song4_array[762] = [193.375, 4, 0]),
  (Song4_array[763] = [193.4375, 4, 0]),
  (Song4_array[764] = [193.5, 4, 0]),
  (Song4_array[765] = [193.5625, 4, 0]),
  (Song4_array[766] = [193.625, 4, 0]),
  (Song4_array[767] = [193.6875, 4, 0]),
  (Song4_array[768] = [193.75, 4, 0]),
  (Song4_array[769] = [193.8125, 4, 0]),
  (Song4_array[770] = [193.875, 4, 0]),
  (Song4_array[771] = [193.9375, 4, 0]),
  (Song4_array[772] = [194, 4, 0]),
  (Song4_array[773] = [194.0625, 4, 0]),
  (Song4_array[774] = [194.125, 4, 0]),
  (Song4_array[775] = [194.1875, 4, 0]),
  (Song4_array[776] = [194.25, 4, 0]),
  (Song4_array[777] = [194.3125, 4, 0]),
  (Song4_array[778] = [194.375, 4, 0]);
var Song3_array = [];
(Song3_array[0] = [0.55, 3, 0]),
  (Song3_array[1] = [1.0500001, 3, 0]),
  (Song3_array[2] = [1.65, 1, 0]),
  (Song3_array[3] = [2.05, 1, 0]),
  (Song3_array[4] = [2.2, 1, 0]),
  (Song3_array[5] = [2.3500001, 1, 0]),
  (Song3_array[6] = [2.75, 3, 0]),
  (Song3_array[7] = [3, 3, 0]),
  (Song3_array[8] = [3.2, 3, 0]),
  (Song3_array[9] = [3.45, 1, 0]),
  (Song3_array[10] = [3.55, 1, 0]),
  (Song3_array[11] = [3.65, 1, 0]),
  (Song3_array[12] = [3.8, 3, 0]),
  (Song3_array[13] = [4.3, 3, 0]),
  (Song3_array[14] = [4.9500003, 5, 0]),
  (Song3_array[15] = [5.15, 5, 0]),
  (Song3_array[16] = [5.55, 5, 0]),
  (Song3_array[17] = [5.9, 3, 0]),
  (Song3_array[18] = [6, 3, 0]),
  (Song3_array[19] = [6.1, 3, 0]),
  (Song3_array[20] = [6.2000003, 3, 0]),
  (Song3_array[21] = [6.6, 5, 0]),
  (Song3_array[22] = [6.7000003, 5, 0]),
  (Song3_array[23] = [6.8, 5, 0]),
  (Song3_array[24] = [7.1, 4, 0]),
  (Song3_array[25] = [7.5, 1, 0]),
  (Song3_array[26] = [7.9, 1, 0]),
  (Song3_array[27] = [8.25, 1, 0]),
  (Song3_array[28] = [8.8, 3, 0]),
  (Song3_array[29] = [9.25, 3, 0]),
  (Song3_array[30] = [9.5, 1, 0]),
  (Song3_array[31] = [9.6, 1, 0]),
  (Song3_array[32] = [9.7, 1, 0]),
  (Song3_array[33] = [9.85, 3, 0]),
  (Song3_array[34] = [10.35, 3, 0]),
  (Song3_array[35] = [10.75, 4, 0]),
  (Song3_array[36] = [11.2, 4, 0]),
  (Song3_array[37] = [11.6, 5, 0]),
  (Song3_array[38] = [12.1, 3, 0]),
  (Song3_array[39] = [12.2, 3, 0]),
  (Song3_array[40] = [12.3, 3, 0]),
  (Song3_array[41] = [12.55, 1, 0]),
  (Song3_array[42] = [13.150001, 5, 0]),
  (Song3_array[43] = [13.35, 3, 0]),
  (Song3_array[44] = [13.55, 5, 0]),
  (Song3_array[45] = [14, 3, 0]),
  (Song3_array[46] = [14.3, 5, 0]),
  (Song3_array[47] = [14.6, 3, 0]),
  (Song3_array[48] = [14.900001, 5, 0]),
  (Song3_array[49] = [15.150001, 3, 0]),
  (Song3_array[50] = [15.55, 5, 0]),
  (Song3_array[51] = [15.900001, 3, 0]),
  (Song3_array[52] = [16.35, 1, 0]),
  (Song3_array[53] = [16.75, 3, 0]),
  (Song3_array[54] = [17.2, 1, 0]),
  (Song3_array[55] = [17.4, 3, 0]),
  (Song3_array[56] = [18, 1, 0]),
  (Song3_array[57] = [18.300001, 3, 0]),
  (Song3_array[58] = [18.5, 2, 0]),
  (Song3_array[59] = [18.6, 2, 0]),
  (Song3_array[60] = [18.7, 2, 0]),
  (Song3_array[61] = [19.1, 4, 0]),
  (Song3_array[62] = [19.5, 2, 0]),
  (Song3_array[63] = [20.050001, 1, 0]),
  (Song3_array[64] = [20.2, 3, 0]),
  (Song3_array[65] = [20.5, 1, 0]),
  (Song3_array[66] = [20.95, 3, 0]),
  (Song3_array[67] = [21.300001, 5, 0]),
  (Song3_array[68] = [21.7, 3, 0]),
  (Song3_array[69] = [22.15, 2, 0]),
  (Song3_array[70] = [22.550001, 4, 0]),
  (Song3_array[71] = [22.800001, 2, 0]),
  (Song3_array[72] = [23.1, 4, 0]),
  (Song3_array[73] = [23.6, 2, 0]),
  (Song3_array[74] = [23.85, 5, 0]),
  (Song3_array[75] = [24.15, 2, 0]),
  (Song3_array[76] = [24.6, 2, 0]),
  (Song3_array[77] = [24.85, 5, 0]),
  (Song3_array[78] = [25.1, 2, 0]),
  (Song3_array[79] = [25.7, 5, 0]),
  (Song3_array[80] = [25.9, 3, 0]),
  (Song3_array[81] = [26.15, 4, 0]),
  (Song3_array[82] = [26.65, 5, 0]),
  (Song3_array[83] = [26.85, 3, 0]),
  (Song3_array[84] = [27.1, 4, 0]),
  (Song3_array[85] = [27.65, 5, 0]),
  (Song3_array[86] = [27.85, 3, 0]),
  (Song3_array[87] = [28.1, 4, 0]),
  (Song3_array[88] = [28.75, 5, 0]),
  (Song3_array[89] = [28.95, 3, 0]),
  (Song3_array[90] = [29.2, 5, 0]),
  (Song3_array[91] = [29.65, 1, 0]),
  (Song3_array[92] = [29.9, 3, 0]),
  (Song3_array[93] = [30.2, 1, 0]),
  (Song3_array[94] = [30.5, 1, 0]),
  (Song3_array[95] = [30.75, 3, 0]),
  (Song3_array[96] = [31.050001, 1, 0]),
  (Song3_array[97] = [31.45, 1, 0]),
  (Song3_array[98] = [31.7, 3, 0]),
  (Song3_array[99] = [32, 3, 0]),
  (Song3_array[100] = [32.55, 5, 0]),
  (Song3_array[101] = [33.3, 5, 0]),
  (Song3_array[102] = [34.100002, 5, 0]),
  (Song3_array[103] = [35.15, 5, 0]),
  (Song3_array[104] = [35.350002, 3, 0]),
  (Song3_array[105] = [35.600002, 4, 0]),
  (Song3_array[106] = [36.15, 1, 0]),
  (Song3_array[107] = [36.4, 3, 0]),
  (Song3_array[108] = [36.65, 1, 0]),
  (Song3_array[109] = [37.15, 1, 0]),
  (Song3_array[110] = [37.4, 3, 0]),
  (Song3_array[111] = [37.65, 1, 0]),
  (Song3_array[112] = [38.5, 1, 0.05]),
  (Song3_array[113] = [38.5, 3, 0]),
  (Song3_array[114] = [38.5, 5, 0.05]),
  (Song3_array[115] = [39.15, 1, 0.05]),
  (Song3_array[116] = [39.15, 3, 0]),
  (Song3_array[117] = [39.15, 5, 0.05]),
  (Song3_array[118] = [39.75, 2, 0]),
  (Song3_array[119] = [39.95, 1, 0.05]),
  (Song3_array[120] = [39.95, 3, 0]),
  (Song3_array[121] = [39.95, 5, 0.05]),
  (Song3_array[122] = [40.55, 1, 0.05]),
  (Song3_array[123] = [40.55, 3, 0]),
  (Song3_array[124] = [40.55, 5, 0.05]),
  (Song3_array[125] = [41.350002, 1, 0.05]),
  (Song3_array[126] = [41.350002, 3, 0]),
  (Song3_array[127] = [41.350002, 5, 0.05]),
  (Song3_array[128] = [42.3, 1, 0]),
  (Song3_array[129] = [42.55, 3, 0]),
  (Song3_array[130] = [42.8, 1, 0]),
  (Song3_array[131] = [43.25, 3, 0]),
  (Song3_array[132] = [43.7, 1, 0]),
  (Song3_array[133] = [44.45, 3, 0]),
  (Song3_array[134] = [44.95, 1, 0]),
  (Song3_array[135] = [45.65, 3, 0]),
  (Song3_array[136] = [46.15, 1, 0]),
  (Song3_array[137] = [46.75, 3, 0]),
  (Song3_array[138] = [47.25, 1, 0]),
  (Song3_array[139] = [47.8, 1, 0.05]),
  (Song3_array[140] = [47.8, 3, 0]),
  (Song3_array[141] = [47.8, 5, 0.05]),
  (Song3_array[142] = [48.5, 1, 0.05]),
  (Song3_array[143] = [48.5, 3, 0]),
  (Song3_array[144] = [48.5, 5, 0.05]),
  (Song3_array[145] = [49.3, 1, 0.05]),
  (Song3_array[146] = [49.3, 3, 0]),
  (Song3_array[147] = [49.3, 5, 0.05]),
  (Song3_array[148] = [50, 5, 0]),
  (Song3_array[149] = [50.100002, 5, 0]),
  (Song3_array[150] = [50.2, 5, 0]),
  (Song3_array[151] = [50.3, 5, 0]),
  (Song3_array[152] = [51.4, 1, 0]),
  (Song3_array[153] = [51.65, 3, 0]),
  (Song3_array[154] = [51.9, 4, 0]),
  (Song3_array[155] = [52.2, 3, 0]),
  (Song3_array[156] = [52.5, 1, 0]),
  (Song3_array[157] = [52.8, 3, 0]),
  (Song3_array[158] = [53.05, 4, 0]),
  (Song3_array[159] = [53.3, 3, 0]),
  (Song3_array[160] = [53.55, 1, 0]),
  (Song3_array[161] = [53.8, 3, 0]),
  (Song3_array[162] = [54, 2, 0]),
  (Song3_array[163] = [54.5, 1, 0]),
  (Song3_array[164] = [54.75, 3, 0]),
  (Song3_array[165] = [55, 4, 0]),
  (Song3_array[166] = [55.3, 3, 0]),
  (Song3_array[167] = [55.600002, 1, 0]),
  (Song3_array[168] = [55.9, 3, 0]),
  (Song3_array[169] = [56.15, 4, 0]),
  (Song3_array[170] = [56.4, 3, 0]),
  (Song3_array[171] = [56.65, 1, 0]),
  (Song3_array[172] = [56.9, 3, 0]),
  (Song3_array[173] = [57.100002, 2, 0]),
  (Song3_array[174] = [57.75, 1, 0]),
  (Song3_array[175] = [58, 3, 0]),
  (Song3_array[176] = [58.25, 4, 0]),
  (Song3_array[177] = [58.55, 3, 0]),
  (Song3_array[178] = [58.850002, 1, 0]),
  (Song3_array[179] = [59.15, 3, 0]),
  (Song3_array[180] = [59.4, 4, 0]),
  (Song3_array[181] = [59.65, 3, 0]),
  (Song3_array[182] = [59.9, 1, 0]),
  (Song3_array[183] = [60.15, 3, 0]),
  (Song3_array[184] = [60.350002, 2, 0]),
  (Song3_array[185] = [60.95, 1, 0]),
  (Song3_array[186] = [61.2, 3, 0]),
  (Song3_array[187] = [61.45, 4, 0]),
  (Song3_array[188] = [61.75, 3, 0]),
  (Song3_array[189] = [62.05, 1, 0]),
  (Song3_array[190] = [62.350002, 3, 0]),
  (Song3_array[191] = [62.600002, 4, 0]),
  (Song3_array[192] = [62.850002, 3, 0]),
  (Song3_array[193] = [63.100002, 1, 0]),
  (Song3_array[194] = [63.350002, 3, 0]),
  (Song3_array[195] = [63.55, 2, 0]),
  (Song3_array[196] = [64.3, 5, 0]),
  (Song3_array[197] = [64.5, 3, 0]),
  (Song3_array[198] = [64.75, 2, 0]),
  (Song3_array[199] = [65.05, 5, 0]),
  (Song3_array[200] = [65.25, 3, 0]),
  (Song3_array[201] = [65.5, 5, 0]),
  (Song3_array[202] = [65.8, 3, 0]),
  (Song3_array[203] = [66.05, 5, 0]),
  (Song3_array[204] = [66.4, 3, 0]),
  (Song3_array[205] = [66.65, 5, 0]),
  (Song3_array[206] = [67.05, 3, 0]),
  (Song3_array[207] = [67.3, 5, 0]),
  (Song3_array[208] = [67.6, 2, 0]),
  (Song3_array[209] = [67.85, 4, 0]),
  (Song3_array[210] = [68.450005, 3, 0]),
  (Song3_array[211] = [68.700005, 5, 0]),
  (Song3_array[212] = [69.200005, 3, 0]),
  (Song3_array[213] = [69.450005, 5, 0]),
  (Song3_array[214] = [70.05, 2, 0]),
  (Song3_array[215] = [70.3, 4, 0]),
  (Song3_array[216] = [70.75, 3, 0]),
  (Song3_array[217] = [71.200005, 1, 0]),
  (Song3_array[218] = [71.450005, 3, 0]),
  (Song3_array[219] = [71.75, 1, 0]),
  (Song3_array[220] = [72.35, 3, 0]),
  (Song3_array[221] = [72.6, 5, 0]),
  (Song3_array[222] = [73.1, 3, 0]),
  (Song3_array[223] = [73.35, 5, 0]),
  (Song3_array[224] = [73.950005, 3, 0]),
  (Song3_array[225] = [74.3, 1, 0]),
  (Song3_array[226] = [74.75, 1, 0]),
  (Song3_array[227] = [74.950005, 3, 0]),
  (Song3_array[228] = [75.3, 1, 0]),
  (Song3_array[229] = [75.75, 1, 0]),
  (Song3_array[230] = [75.950005, 3, 0]),
  (Song3_array[231] = [76.3, 1, 0]),
  (Song3_array[232] = [77, 5, 0]),
  (Song3_array[233] = [77.15, 3, 0]),
  (Song3_array[234] = [77.3, 5, 0]),
  (Song3_array[235] = [77.9, 5, 0]),
  (Song3_array[236] = [78.05, 3, 0]),
  (Song3_array[237] = [78.200005, 5, 0]),
  (Song3_array[238] = [78.9, 5, 0]),
  (Song3_array[239] = [79.05, 3, 0]),
  (Song3_array[240] = [79.200005, 5, 0]),
  (Song3_array[241] = [79.9, 5, 0]),
  (Song3_array[242] = [80.05, 3, 0]),
  (Song3_array[243] = [80.200005, 5, 0]),
  (Song3_array[244] = [80.4, 3, 0]),
  (Song3_array[245] = [80.8, 1, 0]),
  (Song3_array[246] = [81, 3, 0]),
  (Song3_array[247] = [81.35, 1, 0]),
  (Song3_array[248] = [81.85, 1, 0]),
  (Song3_array[249] = [82.05, 3, 0]),
  (Song3_array[250] = [82.4, 1, 0]),
  (Song3_array[251] = [82.8, 1, 0]),
  (Song3_array[252] = [83, 3, 0]),
  (Song3_array[253] = [83.35, 1, 0]),
  (Song3_array[254] = [83.700005, 1, 0.05]),
  (Song3_array[255] = [83.700005, 3, 0]),
  (Song3_array[256] = [83.700005, 5, 0.05]),
  (Song3_array[257] = [84.450005, 1, 0.05]),
  (Song3_array[258] = [84.450005, 3, 0]),
  (Song3_array[259] = [84.450005, 5, 0.05]),
  (Song3_array[260] = [85.3, 1, 0.05]),
  (Song3_array[261] = [85.3, 3, 0]),
  (Song3_array[262] = [85.3, 5, 0.05]),
  (Song3_array[263] = [86.35, 5, 0]),
  (Song3_array[264] = [86.5, 3, 0]),
  (Song3_array[265] = [86.65, 5, 0]),
  (Song3_array[266] = [87.200005, 1, 0]),
  (Song3_array[267] = [87.4, 3, 0]),
  (Song3_array[268] = [87.75, 1, 0]),
  (Song3_array[269] = [88.35, 1, 0]),
  (Song3_array[270] = [88.55, 3, 0]),
  (Song3_array[271] = [88.9, 1, 0]),
  (Song3_array[272] = [89.8, 1, 0.05]),
  (Song3_array[273] = [89.8, 3, 0]),
  (Song3_array[274] = [89.8, 5, 0.05]),
  (Song3_array[275] = [90.35, 1, 0.05]),
  (Song3_array[276] = [90.35, 3, 0]),
  (Song3_array[277] = [90.35, 5, 0.05]),
  (Song3_array[278] = [91.1, 1, 0.05]),
  (Song3_array[279] = [91.1, 3, 0]),
  (Song3_array[280] = [91.1, 5, 0.05]),
  (Song3_array[281] = [91.700005, 1, 0.05]),
  (Song3_array[282] = [91.700005, 3, 0]),
  (Song3_array[283] = [91.700005, 5, 0.05]),
  (Song3_array[284] = [92.55, 1, 0.05]),
  (Song3_array[285] = [92.55, 3, 0]),
  (Song3_array[286] = [92.55, 5, 0.05]),
  (Song3_array[287] = [94.35, 1, 0]),
  (Song3_array[288] = [94.55, 3, 0]),
  (Song3_array[289] = [94.9, 1, 0]),
  (Song3_array[290] = [95.6, 1, 0]),
  (Song3_array[291] = [95.8, 3, 0]),
  (Song3_array[292] = [96.15, 1, 0]),
  (Song3_array[293] = [96.75, 1, 0]),
  (Song3_array[294] = [96.950005, 3, 0]),
  (Song3_array[295] = [97.3, 1, 0]),
  (Song3_array[296] = [97.75, 1, 0]),
  (Song3_array[297] = [97.950005, 2, 0]),
  (Song3_array[298] = [98.15, 3, 0]),
  (Song3_array[299] = [98.35, 1, 0]),
  (Song3_array[300] = [99.700005, 1, 0.05]),
  (Song3_array[301] = [99.700005, 3, 0]),
  (Song3_array[302] = [99.700005, 5, 0.05]),
  (Song3_array[303] = [100.5, 1, 0.05]),
  (Song3_array[304] = [100.5, 3, 0]),
  (Song3_array[305] = [100.5, 5, 0.05]),
  (Song3_array[306] = [101.200005, 1, 0]),
  (Song3_array[307] = [101.3, 1, 0]),
  (Song3_array[308] = [101.4, 1, 0]),
  (Song3_array[309] = [101.5, 1, 0]),
  (Song3_array[310] = [101.6, 1, 0]),
  (Song3_array[311] = [101.700005, 1, 0]),
  (Song3_array[312] = [101.8, 1, 0]),
  (Song3_array[313] = [102.5, 5, 0]),
  (Song3_array[314] = [102.6, 5, 0]),
  (Song3_array[315] = [102.700005, 5, 0]),
  (Song3_array[316] = [102.8, 5, 0]),
  (Song3_array[317] = [102.9, 5, 0]),
  (Song3_array[318] = [103, 5, 0]),
  (Song3_array[319] = [103.1, 5, 0]),
  (Song3_array[320] = [103.200005, 5, 0]),
  (Song3_array[321] = [103.3, 5, 0]),
  (Song3_array[322] = [103.4, 5, 0]),
  (Song3_array[323] = [103.5, 5, 0]),
  (Song3_array[324] = [103.6, 5, 0]),
  (Song3_array[325] = [103.700005, 5, 0]),
  (Song3_array[326] = [103.8, 5, 0]),
  (Song3_array[327] = [104.950005, 2, 0]),
  (Song3_array[328] = [105.3, 3, 0]),
  (Song3_array[329] = [105.3, 5, 0.05]),
  (Song3_array[330] = [105.700005, 5, 0]),
  (Song3_array[331] = [105.8, 5, 0]),
  (Song3_array[332] = [105.9, 5, 0]),
  (Song3_array[333] = [106.200005, 3, 0]),
  (Song3_array[334] = [106.3, 3, 0]),
  (Song3_array[335] = [106.4, 3, 0]),
  (Song3_array[336] = [106.5, 3, 0]),
  (Song3_array[337] = [106.6, 3, 0]),
  (Song3_array[338] = [106.700005, 3, 0]),
  (Song3_array[339] = [106.8, 3, 0]),
  (Song3_array[340] = [106.9, 3, 0]),
  (Song3_array[341] = [107, 3, 0]),
  (Song3_array[342] = [107.1, 3, 0]),
  (Song3_array[343] = [107.200005, 3, 0]),
  (Song3_array[344] = [107.3, 3, 0]),
  (Song3_array[345] = [107.4, 3, 0]),
  (Song3_array[346] = [107.5, 3, 0]),
  (Song3_array[347] = [107.6, 3, 0]),
  (Song3_array[348] = [107.700005, 3, 0]),
  (Song3_array[349] = [107.8, 3, 0]),
  (Song3_array[350] = [107.9, 3, 0]),
  (Song3_array[351] = [108, 3, 0]),
  (Song3_array[352] = [108.1, 3, 0]),
  (Song3_array[353] = [108.200005, 3, 0]),
  (Song3_array[354] = [108.3, 3, 0]),
  (Song3_array[355] = [108.4, 3, 0]),
  (Song3_array[356] = [108.5, 3, 0]),
  (Song3_array[357] = [108.6, 3, 0]),
  (Song3_array[358] = [109, 1, 0.05]),
  (Song3_array[359] = [109, 3, 0]),
  (Song3_array[360] = [109.4, 1, 0]),
  (Song3_array[361] = [109.5, 1, 0]),
  (Song3_array[362] = [109.6, 1, 0]),
  (Song3_array[363] = [109.700005, 1, 0]),
  (Song3_array[364] = [109.8, 1, 0]),
  (Song3_array[365] = [109.9, 1, 0]),
  (Song3_array[366] = [110, 1, 0]),
  (Song3_array[367] = [110.1, 1, 0]),
  (Song3_array[368] = [110.200005, 1, 0]),
  (Song3_array[369] = [110.3, 1, 0]),
  (Song3_array[370] = [110.4, 1, 0]),
  (Song3_array[371] = [110.5, 1, 0]),
  (Song3_array[372] = [110.6, 1, 0]),
  (Song3_array[373] = [110.700005, 1, 0]),
  (Song3_array[374] = [110.8, 1, 0]),
  (Song3_array[375] = [110.9, 1, 0]),
  (Song3_array[376] = [111, 1, 0]),
  (Song3_array[377] = [111.1, 1, 0]),
  (Song3_array[378] = [111.200005, 1, 0]),
  (Song3_array[379] = [111.3, 1, 0]),
  (Song3_array[380] = [111.4, 1, 0]),
  (Song3_array[381] = [111.5, 1, 0]),
  (Song3_array[382] = [112.200005, 3, 0]),
  (Song3_array[383] = [112.6, 2, 0]),
  (Song3_array[384] = [112.950005, 4, 0]),
  (Song3_array[385] = [113.75, 2, 0]),
  (Song3_array[386] = [114.1, 4, 0]),
  (Song3_array[387] = [115, 3, 0]),
  (Song3_array[388] = [115.3, 5, 0]),
  (Song3_array[389] = [115.4, 5, 0]),
  (Song3_array[390] = [115.5, 5, 0]),
  (Song3_array[391] = [115.6, 5, 0]),
  (Song3_array[392] = [115.700005, 5, 0]),
  (Song3_array[393] = [115.8, 5, 0]),
  (Song3_array[394] = [115.9, 5, 0]),
  (Song3_array[395] = [116, 5, 0]),
  (Song3_array[396] = [116.1, 5, 0]),
  (Song3_array[397] = [116.200005, 5, 0]),
  (Song3_array[398] = [116.3, 5, 0]),
  (Song3_array[399] = [116.4, 5, 0]),
  (Song3_array[400] = [116.5, 5, 0]),
  (Song3_array[401] = [116.6, 5, 0]),
  (Song3_array[402] = [117.75, 2, 0]),
  (Song3_array[403] = [118.1, 3, 0]),
  (Song3_array[404] = [118.1, 5, 0.05]),
  (Song3_array[405] = [118.5, 5, 0]),
  (Song3_array[406] = [118.6, 5, 0]),
  (Song3_array[407] = [118.700005, 5, 0]),
  (Song3_array[408] = [119, 3, 0]),
  (Song3_array[409] = [119.1, 3, 0]),
  (Song3_array[410] = [119.200005, 3, 0]),
  (Song3_array[411] = [119.3, 3, 0]),
  (Song3_array[412] = [119.4, 3, 0]),
  (Song3_array[413] = [119.5, 3, 0]),
  (Song3_array[414] = [119.6, 3, 0]),
  (Song3_array[415] = [119.700005, 3, 0]),
  (Song3_array[416] = [119.8, 3, 0]),
  (Song3_array[417] = [119.9, 3, 0]),
  (Song3_array[418] = [120, 3, 0]),
  (Song3_array[419] = [120.1, 3, 0]),
  (Song3_array[420] = [120.200005, 3, 0]),
  (Song3_array[421] = [120.3, 3, 0]),
  (Song3_array[422] = [120.4, 3, 0]),
  (Song3_array[423] = [120.5, 3, 0]),
  (Song3_array[424] = [120.6, 3, 0]),
  (Song3_array[425] = [120.700005, 3, 0]),
  (Song3_array[426] = [120.8, 3, 0]),
  (Song3_array[427] = [120.9, 3, 0]),
  (Song3_array[428] = [121, 3, 0]),
  (Song3_array[429] = [121.1, 3, 0]),
  (Song3_array[430] = [121.200005, 3, 0]),
  (Song3_array[431] = [121.3, 3, 0]),
  (Song3_array[432] = [121.4, 3, 0]),
  (Song3_array[433] = [121.8, 1, 0.05]),
  (Song3_array[434] = [121.8, 3, 0]),
  (Song3_array[435] = [122.200005, 1, 0]),
  (Song3_array[436] = [122.3, 1, 0]),
  (Song3_array[437] = [122.4, 1, 0]),
  (Song3_array[438] = [122.5, 1, 0]),
  (Song3_array[439] = [122.6, 1, 0]),
  (Song3_array[440] = [122.700005, 1, 0]),
  (Song3_array[441] = [122.8, 1, 0]),
  (Song3_array[442] = [122.9, 1, 0]),
  (Song3_array[443] = [123, 1, 0]),
  (Song3_array[444] = [123.1, 1, 0]),
  (Song3_array[445] = [123.200005, 1, 0]),
  (Song3_array[446] = [123.3, 1, 0]),
  (Song3_array[447] = [123.4, 1, 0]),
  (Song3_array[448] = [123.5, 1, 0]),
  (Song3_array[449] = [123.6, 1, 0]),
  (Song3_array[450] = [123.700005, 1, 0]),
  (Song3_array[451] = [123.8, 1, 0]),
  (Song3_array[452] = [123.9, 1, 0]),
  (Song3_array[453] = [124, 1, 0]),
  (Song3_array[454] = [124.1, 1, 0]),
  (Song3_array[455] = [124.200005, 1, 0]),
  (Song3_array[456] = [124.3, 1, 0]),
  (Song3_array[457] = [125.05, 3, 0]),
  (Song3_array[458] = [125.3, 1, 0]),
  (Song3_array[459] = [125.55, 3, 0]),
  (Song3_array[460] = [126.05, 3, 0]),
  (Song3_array[461] = [126.450005, 5, 0]),
  (Song3_array[462] = [127, 3, 0]),
  (Song3_array[463] = [127.5, 3, 0]),
  (Song3_array[464] = [127.5, 5, 0.05]),
  (Song3_array[465] = [128.1, 5, 0]),
  (Song3_array[466] = [128.2, 5, 0]),
  (Song3_array[467] = [128.3, 5, 0]),
  (Song3_array[468] = [128.40001, 5, 0]),
  (Song3_array[469] = [128.5, 5, 0]),
  (Song3_array[470] = [128.6, 5, 0]),
  (Song3_array[471] = [128.7, 5, 0]),
  (Song3_array[472] = [128.8, 5, 0]),
  (Song3_array[473] = [128.90001, 5, 0]),
  (Song3_array[474] = [129, 5, 0]),
  (Song3_array[475] = [129.1, 5, 0]),
  (Song3_array[476] = [129.2, 5, 0]),
  (Song3_array[477] = [129.3, 5, 0]),
  (Song3_array[478] = [129.40001, 5, 0]),
  (Song3_array[479] = [130.55, 2, 0]),
  (Song3_array[480] = [130.90001, 3, 0]),
  (Song3_array[481] = [130.90001, 5, 0.05]),
  (Song3_array[482] = [131.3, 5, 0]),
  (Song3_array[483] = [131.40001, 5, 0]),
  (Song3_array[484] = [131.5, 5, 0]),
  (Song3_array[485] = [131.8, 3, 0]),
  (Song3_array[486] = [131.90001, 3, 0]),
  (Song3_array[487] = [132, 3, 0]),
  (Song3_array[488] = [132.1, 3, 0]),
  (Song3_array[489] = [132.2, 3, 0]),
  (Song3_array[490] = [132.3, 3, 0]),
  (Song3_array[491] = [132.40001, 3, 0]),
  (Song3_array[492] = [132.5, 3, 0]),
  (Song3_array[493] = [132.6, 3, 0]),
  (Song3_array[494] = [132.7, 3, 0]),
  (Song3_array[495] = [132.8, 3, 0]),
  (Song3_array[496] = [132.90001, 3, 0]),
  (Song3_array[497] = [133, 3, 0]),
  (Song3_array[498] = [133.1, 3, 0]),
  (Song3_array[499] = [133.2, 3, 0]),
  (Song3_array[500] = [133.3, 3, 0]),
  (Song3_array[501] = [133.40001, 3, 0]),
  (Song3_array[502] = [133.5, 3, 0]),
  (Song3_array[503] = [133.6, 3, 0]),
  (Song3_array[504] = [133.7, 3, 0]),
  (Song3_array[505] = [133.8, 3, 0]),
  (Song3_array[506] = [133.90001, 3, 0]),
  (Song3_array[507] = [134, 3, 0]),
  (Song3_array[508] = [134.1, 3, 0]),
  (Song3_array[509] = [134.2, 3, 0]),
  (Song3_array[510] = [134.6, 1, 0.05]),
  (Song3_array[511] = [134.6, 3, 0]),
  (Song3_array[512] = [135, 1, 0]),
  (Song3_array[513] = [135.1, 1, 0]),
  (Song3_array[514] = [135.2, 1, 0]),
  (Song3_array[515] = [135.3, 1, 0]),
  (Song3_array[516] = [135.40001, 1, 0]),
  (Song3_array[517] = [135.5, 1, 0]),
  (Song3_array[518] = [135.6, 1, 0]),
  (Song3_array[519] = [135.7, 1, 0]),
  (Song3_array[520] = [135.8, 1, 0]),
  (Song3_array[521] = [135.90001, 1, 0]),
  (Song3_array[522] = [136, 1, 0]),
  (Song3_array[523] = [136.1, 1, 0]),
  (Song3_array[524] = [136.2, 1, 0]),
  (Song3_array[525] = [136.3, 1, 0]),
  (Song3_array[526] = [136.40001, 1, 0]),
  (Song3_array[527] = [136.5, 1, 0]),
  (Song3_array[528] = [136.6, 1, 0]),
  (Song3_array[529] = [136.7, 1, 0]),
  (Song3_array[530] = [136.8, 1, 0]),
  (Song3_array[531] = [136.90001, 1, 0]),
  (Song3_array[532] = [137, 1, 0]),
  (Song3_array[533] = [137.1, 1, 0]),
  (Song3_array[534] = [137.55, 3, 0]),
  (Song3_array[535] = [137.90001, 5, 0]),
  (Song3_array[536] = [138.5, 3, 0]),
  (Song3_array[537] = [138.7, 1, 0]),
  (Song3_array[538] = [138.95, 3, 0]),
  (Song3_array[539] = [139.55, 3, 0]),
  (Song3_array[540] = [139.75, 1, 0]),
  (Song3_array[541] = [140.05, 3, 0]),
  (Song3_array[542] = [140.85, 5, 0]),
  (Song3_array[543] = [140.95, 5, 0]),
  (Song3_array[544] = [141.05, 5, 0]),
  (Song3_array[545] = [141.15001, 5, 0]),
  (Song3_array[546] = [141.25, 5, 0]),
  (Song3_array[547] = [141.35, 5, 0]),
  (Song3_array[548] = [141.45, 5, 0]),
  (Song3_array[549] = [141.55, 5, 0]),
  (Song3_array[550] = [141.65001, 5, 0]),
  (Song3_array[551] = [141.75, 5, 0]),
  (Song3_array[552] = [141.85, 5, 0]),
  (Song3_array[553] = [141.95, 5, 0]),
  (Song3_array[554] = [142.05, 5, 0]),
  (Song3_array[555] = [142.15001, 5, 0]),
  (Song3_array[556] = [143.3, 2, 0]),
  (Song3_array[557] = [143.65001, 3, 0]),
  (Song3_array[558] = [143.65001, 5, 0.05]),
  (Song3_array[559] = [144.05, 5, 0]),
  (Song3_array[560] = [144.15001, 5, 0]),
  (Song3_array[561] = [144.25, 5, 0]),
  (Song3_array[562] = [144.55, 3, 0]),
  (Song3_array[563] = [144.65001, 3, 0]),
  (Song3_array[564] = [144.75, 3, 0]),
  (Song3_array[565] = [144.85, 3, 0]),
  (Song3_array[566] = [144.95, 3, 0]),
  (Song3_array[567] = [145.05, 3, 0]),
  (Song3_array[568] = [145.15001, 3, 0]),
  (Song3_array[569] = [145.25, 3, 0]),
  (Song3_array[570] = [145.35, 3, 0]),
  (Song3_array[571] = [145.45, 3, 0]),
  (Song3_array[572] = [145.55, 3, 0]),
  (Song3_array[573] = [145.65001, 3, 0]),
  (Song3_array[574] = [145.75, 3, 0]),
  (Song3_array[575] = [145.85, 3, 0]),
  (Song3_array[576] = [145.95, 3, 0]),
  (Song3_array[577] = [146.05, 3, 0]),
  (Song3_array[578] = [146.15001, 3, 0]),
  (Song3_array[579] = [146.25, 3, 0]),
  (Song3_array[580] = [146.35, 3, 0]),
  (Song3_array[581] = [146.45, 3, 0]),
  (Song3_array[582] = [146.55, 3, 0]),
  (Song3_array[583] = [146.65001, 3, 0]),
  (Song3_array[584] = [146.75, 3, 0]),
  (Song3_array[585] = [146.85, 3, 0]),
  (Song3_array[586] = [146.95, 3, 0]),
  (Song3_array[587] = [147.35, 1, 0.05]),
  (Song3_array[588] = [147.35, 3, 0]),
  (Song3_array[589] = [147.75, 1, 0]),
  (Song3_array[590] = [147.85, 1, 0]),
  (Song3_array[591] = [147.95, 1, 0]),
  (Song3_array[592] = [148.05, 1, 0]),
  (Song3_array[593] = [148.15001, 1, 0]),
  (Song3_array[594] = [148.25, 1, 0]),
  (Song3_array[595] = [148.35, 1, 0]),
  (Song3_array[596] = [148.45, 1, 0]),
  (Song3_array[597] = [148.55, 1, 0]),
  (Song3_array[598] = [148.65001, 1, 0]),
  (Song3_array[599] = [148.75, 1, 0]),
  (Song3_array[600] = [148.85, 1, 0]),
  (Song3_array[601] = [148.95, 1, 0]),
  (Song3_array[602] = [149.05, 1, 0]),
  (Song3_array[603] = [149.15001, 1, 0]),
  (Song3_array[604] = [149.25, 1, 0]),
  (Song3_array[605] = [149.35, 1, 0]),
  (Song3_array[606] = [149.45, 1, 0]),
  (Song3_array[607] = [149.55, 1, 0]),
  (Song3_array[608] = [149.65001, 1, 0]),
  (Song3_array[609] = [149.75, 1, 0]),
  (Song3_array[610] = [149.85, 1, 0]),
  (Song3_array[611] = [150.2, 3, 0]),
  (Song3_array[612] = [150.5, 1, 0]),
  (Song3_array[613] = [150.95, 3, 0]),
  (Song3_array[614] = [151.05, 3, 0]),
  (Song3_array[615] = [151.15001, 3, 0]),
  (Song3_array[616] = [151.25, 3, 0]),
  (Song3_array[617] = [151.35, 3, 0]),
  (Song3_array[618] = [151.45, 3, 0]),
  (Song3_array[619] = [151.55, 3, 0]),
  (Song3_array[620] = [151.65001, 3, 0]),
  (Song3_array[621] = [151.75, 3, 0]),
  (Song3_array[622] = [151.85, 3, 0]),
  (Song3_array[623] = [151.95, 3, 0]),
  (Song3_array[624] = [152.05, 3, 0]),
  (Song3_array[625] = [152.15001, 3, 0]),
  (Song3_array[626] = [152.25, 3, 0]),
  (Song3_array[627] = [152.35, 3, 0]),
  (Song3_array[628] = [152.45, 3, 0]),
  (Song3_array[629] = [152.55, 3, 0]),
  (Song3_array[630] = [152.65001, 3, 0]),
  (Song3_array[631] = [152.75, 3, 0]),
  (Song3_array[632] = [152.85, 3, 0]),
  (Song3_array[633] = [152.95, 3, 0]);
var ControlBola = pc.createScript("controlBola");
(ControlBola.prototype.initialize = function () {
  (_controlBola = this),
    isMobile.any()
      ? (this.app.touch.on(pc.EVENT_TOUCHSTART, this.onTouchStart, this),
        this.app.touch.on(pc.EVENT_TOUCHMOVE, this.onTouchMove, this),
        this.app.touch.on(pc.EVENT_TOUCHEND, this.onTouchEnd, this))
      : (this.app.mouse.on(pc.EVENT_MOUSEDOWN, this.onMouseDown, this),
        this.app.mouse.on(pc.EVENT_MOUSEMOVE, this.onMouseMove, this),
        this.app.mouse.on(pc.EVENT_MOUSEUP, this.onMouseUp, this),
        document.addEventListener("mouseout", this.onMouseLeave)),
    this.reset();
}),
  (ControlBola.prototype.update = function (o) {
    if ((deltaTime, !_rebote.forzarMover)) {
      if (enPausa) return;
      if (gameOver) return;
      if (enMenu) return;
    }
    null != this.puntoMouseMove && this.calculaMouseMove();
  }),
  (ControlBola.prototype.reset = function () {
    (this.puntoPartida = this.entity.getPosition().clone()),
      (this.bolaY = this.entity.getLocalPosition().clone().y),
      this.iniVars();
  }),
  (ControlBola.prototype.onMouseDown = function (o) {
    this.metodoTouchStart(o.x, o.y);
  }),
  (ControlBola.prototype.onMouseMove = function (o) {
    ControlBola.tap && this.metodoTouchMove(o.x, o.y);
  }),
  (ControlBola.prototype.onMouseUp = function (o) {
    this.metodoTouchUp(o.x, o.y);
  }),
  (ControlBola.prototype.onTouchStart = function (o) {
    var t = o.touches[0];
    this.metodoTouchStart(t.x, t.y);
  }),
  (ControlBola.prototype.onTouchMove = function (o) {
    if (ControlBola.tap) {
      var t = o.touches[0];
      this.metodoTouchMove(t.x, t.y);
    }
  }),
  (ControlBola.prototype.onTouchEnd = function (o) {
    this.metodoTouchUp();
  }),
  (ControlBola.prototype.metodoTouchStart = function (o, t) {
    if (!gameOver) {
      (ControlBola.tap = !0),
        clearInterval(this.hiloSwipe),
        (this.clickInicial = new pc.Vec2(o, t)),
        (this.clickInicialFijo = new pc.Vec2(o, t));
      var i = this.entity.getPosition();
      (this.bolaInicial = new pc.Vec3(i.x, i.y, i.z)),
        (this.bolaInicialFijo = new pc.Vec3(i.x, i.y, i.z));
    }
  }),
  (ControlBola.prototype.metodoTouchMove = function (o, t) {
    this.puntoMouseMove = new pc.Vec2(o, t);
  }),
  (ControlBola.prototype.calculaMouseMove = function () {
    if (!_rebote.forzarMover) {
      if (!ControlBola.tap) return;
      if (gameOver) return;
      if (!gameStart) return;
      if (_coreSystem.finCancion) return;
    }
    if (null != this.clickInicialFijo && null != this.puntoMouseMove) {
      var o = 540,
        t = 960,
        i = (this.entity.getPosition(), window.innerWidth),
        n = window.innerHeight,
        l =
          this.clickInicialFijo.x -
          (this.puntoMouseMove.x - this.clickInicialFijo.x),
        e =
          this.clickInicialFijo.y +
          (this.puntoMouseMove.y - this.clickInicialFijo.y);
      if (
        (isMobile.any() ||
          ((i = this.app.graphicsDevice.width),
          (n = this.app.graphicsDevice.height)),
        i > n)
      ) {
        (n = i = n), t, (o = t = o);
      }
      var a = n / t,
        c = velocidadSwipe * a,
        s = -pistaAncho / 2,
        h = i - velocidadSwipe * a,
        u = pistaAncho / 2,
        r = (u - s) / (h - c),
        p =
          r * (l - c) +
          s -
          ((r = (u - s) / (h - c)) * (this.clickInicialFijo.x - c) + s);
      (p += this.bolaDistXAcomulada) < -pistaAncho / 2
        ? (p = -pistaAncho / 2)
        : p > pistaAncho / 2 && (p = pistaAncho / 2);
      var M = this.entity.getLocalPosition();
      this.entity.setLocalPosition(p, M.y, M.z),
        (this.clickFinal = new pc.Vec2(l, e));
      var y = this.entity.getPosition();
      null != this.bolaInicial &&
        y.z > this.bolaInicial.z &&
        (this.bolaInicial = new pc.Vec3(y.x, y.y, y.z));
    }
  }),
  (ControlBola.prototype.metodoTouchUp = function (o, t) {
    (ControlBola.tap = !1),
      (this.clickFinal = null),
      (this.clickInicial = null),
      (this.clickInicialFijo = null),
      (this.bolaInicialFijo = null),
      (this.bolaInicial = null),
      (this.puntoMouseMove = null),
      (this.bolaDistXAcomulada = this.entity.getLocalPosition().x);
  }),
  (ControlBola.tap = !1),
  (ControlBola.prototype.iniVars = function () {
    this.entity.setPosition(this.puntoPartida),
      (this.clickInicial = null),
      (this.clickInicialFijo = null),
      (this.clickFinal = null),
      (this.bolaInicial = null),
      (this.bolaInicialFijo = null),
      (this.puntoMouseMove = null),
      (this.bolaDistXAcomulada = 0),
      (ControlBola.tap = !1);
  });
var _coreSystem,
  _sonidos,
  _musicas,
  _menu,
  _2dScreen,
  _fps,
  _rebote,
  _controlBola,
  calidad = "alta",
  pause = !1,
  currentMusic = "",
  urlBaseAssets = "music/",
  pauseFlag = !1,
  enMenu = !1,
  enPausa = !1,
  gameOver = !1,
  gameStart = !0,
  tiempoParpadeo = 2500,
  enParpadeo = !1,
  deltaTime = 0,
  gameSpeed = 14,
  notaStart = 50,
  espera = 0,
  totalVidas = 3,
  currentVidas = 0,
  pistaAncho = 7.2,
  velocidadSwipe = 125,
  bolaRadio = 1.5,
  distMataNota = 7,
  velocidadFactor = 1,
  anchoPlataforma = 1.05,
  largoPlataforma = 1.25,
  toleranciaNotasMov = 0.45,
  limiteGemas = 10,
  toleranciaPerfect = 4,
  toleranciaGema = 1.5,
  percentajeCompleted = 0,
  posiblesContinues = 2,
  continues = 0,
  continueCost = 5,
  enGoogle = !0,
  volumeMaster = !0,
  rewardAd = null,
  rewardType = null,
  rewardCallback = null,
  rewardPanelAd = null,
  currentSkin = 0,
  bestScore = 0,
  pelotasInfo = [
    [1, 0],
    [0, 10],
    [0, 15],
    [0, 25],
    [0, 50],
    [0, 75],
    [0, 100],
    [0, 150],
    [0, 200],
  ],
  numSkins = 9,
  arrayGemas = [
    20, 35, 69, 150, 180, 234, 275, 319, 363, 398, 429, 457, 91, 135, 297, 341,
    54, 407, 197, 444,
  ],
  totalCanciones = 8,
  extraSpeedSongs = [0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2],
  extraSpeedSongsUVS = [
    0.1, 0.1, 0.1, 0.1, 0.4, 0.4, 0.4, 0.4, 0.8, 0.8, 0.8, 0.8,
  ],
  extraSpeedSongsPastos = [1, 1, 1, 1, 3, 3, 3, 3, 6, 6, 6, 6],
  currentCancion = 0,
  currentCancionAux = -1,
  arrayCanciones = [
    [0, "Song1", "Tandoori Nights", 0, 1],
    [1, "Song2", "Indian Hiphopper", 0, 1],
    [2, "Song3", "Punjabi Beat", 0, 1],
    [3, "Song4", "Desi Trance", 0, 1],
    [4, "Song5", "Tandoori Nights Endless", 0, 0],
    [5, "Song6", "Indian Hiphopper Endless", 0, 0],
    [6, "Song7", "Punjabi Beat Endless", 0, 0],
    [7, "Song8", "Desi Trance Endless", 0, 0],
    [8, "Song9", "Desi Trance Endless", 0, 0],
    [9, "Song10", "Desi Trance Endless", 0, 0],
    [10, "Song11", "Desi Trance Endless", 0, 0],
    [11, "Song12", "Desi Trance Endless", 0, 0],
  ],
  permitirPause = !1,
  currentMute = 0;
function onPause() {
  console.log("en pause!! MOBILE"), musicPause();
}
function musicPause() {
  console.log("en pause! music!"),
    _musicas.pause(currentMusic),
    setTimeout(() => {
      pauseFlag || pause || _musicas.resume(currentMusic);
    }, 40);
}
function musicUnpause() {
  pause || _musicas.resume(currentMusic);
}
function onResume() {
  musicUnpause();
}
function MetodoPause() {
  console.log("en pause! Visibility!"),
    console.log(
      "ESTO ES? permitirPause: " + permitirPause + " y en pasue " + enPausa
    ),
    (pauseFlag = !0),
    permitirPause && _menu.clickPause();
}
function MetodoUnpause() {
  console.log("en resumen!!"),
    (pauseFlag = !1),
    console.log("ESTO ES? enPausa: " + enPausa + " Y PASUE FLAG " + pauseFlag);
}
function PrepareRewardAd(e) {
  enGoogle &&
    (console.log("Se llama al ad break! " + e),
    null == rewardAd
      ? (console.log("Reward ad no existe!! se crea evento reward ad"),
        GameSnacks.ad.break({
          type: "reward",
          name: "button_doubleReward",
          beforeAd: () => {
            BeforeVideoAd();
          },
          beforeReward: (a) => {
            console.log("funcion before Reward q pasa ?? " + e),
              console.log(a),
              (rewardAd = a);
          },
          adDismissed: () => {
            console.log("AD WAS CLOSED NOT VIEWED");
          },
          adViewed: () => {
            console.log("AD WAS VIEWED and CLOSED");
          },
          adBreakDone: (e) => {
            AfterVideoAd(e);
          },
        }))
      : console.log("Reward ad ya existe, solo se arregla el boton"));
}
(window.onblur = function () {
  musicPause();
}),
  (window.onclick = function () {
    this.focus();
  }),
  document.addEventListener("visibilitychange", function () {
    document.hidden
      ? MetodoPause()
      : (isMobile.iOS() && alert("Press OK to return to the game"),
        MetodoUnpause());
  }),
  (window.onfocus = function () {
    musicUnpause();
  });
var desmutearDespuesDeAd = !1;
function BeforeVideoAd() {
  console.log("ANTES DE VER EL AD!!! "),
    (enGoogle ? GameSnacks.audio.isEnabled() : volumeMaster) &&
      0 == mute &&
      (mutear(1, null, !1), (desmutearDespuesDeAd = !0));
}
function AfterVideoAd(e) {
  ((rewardAd = null),
  console.log("DESPUES  DE VER EL AD!!! " + e),
  console.log(e),
  desmutearDespuesDeAd) &&
    (enGoogle ? GameSnacks.audio.isEnabled() : volumeMaster) &&
    1 == mute &&
    (mutear(0, null, !1), (desmutearDespuesDeAd = !1));
  var a = rewardType;
  (rewardType = null),
    "viewed" == e.breakStatus
      ? (console.log("DESPUES  DE VER EL AD!!! PERO SI VI EL AD"),
        "doubleReward" == a && AfterAd(2))
      : AfterAd(1);
}
function PrepareInterstitital(e) {
  e();
}
function AfterInterstitialAd(e, a) {
  (console.log("DESPUES  DE VER EL INTERSTITIAL AD!!! "),
  console.log(e),
  desmutearDespuesDeAd) &&
    (enGoogle ? GameSnacks.audio.isEnabled() : volumeMaster) &&
    1 == mute &&
    (mutear(0, null, !1), (desmutearDespuesDeAd = !1));
  a();
}
function ShowRewardPanel(e, a) {
  console.log("SE PONE EL PANEL REWARD con currency " + e);
  var n = rewardPanelAd.children[3],
    o = rewardPanelAd.children[2];
  (rewardPanelAd.children[1].children[0].element.text = "+" + e),
    (rewardCallback = a),
    (rewardPanelAd.enabled = !0),
    addEventFunction(n, !0, 1, () => {
      playSound("click"),
        addEventFunction(n, !1),
        addEventFunction(o, !1),
        (rewardType = "doubleReward"),
        console.log("llamaremos a rewardAd con type " + rewardType),
        enGoogle ? rewardAd() : AfterAd(2);
    }),
    addEventFunction(o, !0, 1, () => {
      console.log("se cancela  rewardAd con type " + rewardType),
        playSound("click"),
        addEventFunction(n, !1),
        addEventFunction(o, !1),
        AfterAd(1);
    });
}
function AfterAd(e) {
  (rewardPanelAd.enabled = !1),
    setTimeout(() => {
      PrepareRewardAd("doubleReward");
    }, 100),
    rewardCallback(e),
    (rewardCallback = null);
}
var Trail = pc.createScript("trail");
(Trail.prototype.initialize = function () {}),
  (Trail.prototype.update = function (i) {});
var Ribbon = pc.createScript("ribbon");
Ribbon.attributes.add("lifetime", { type: "number", default: 0.5 }),
  Ribbon.attributes.add("xoffset", { type: "number", default: -0.8 }),
  Ribbon.attributes.add("yoffset", { type: "number", default: 1 }),
  Ribbon.attributes.add("height", { type: "number", default: 0.4 }),
  Ribbon.attributes.add("material", {
    type: "asset",
    assetType: "material",
    array: !1,
  });
var MAX_VERTICES = 600,
  VERTEX_SIZE = 4;
(Ribbon.prototype.create = function (e) {
  (this.timer = 0),
    (this.node = null),
    (this.vertices = []),
    (this.vertexData = new Float32Array(MAX_VERTICES * VERTEX_SIZE)),
    (this.entity.model = null);
}),
  (Ribbon.prototype.initialize = function () {
    this.create();
    var e = {
        attributes: { aPositionAge: pc.SEMANTIC_POSITION },
        vshader: [
          "attribute vec4 aPositionAge;",
          "",
          "uniform mat4 matrix_viewProjection;",
          "uniform float trail_time;",
          "",
          "varying float vAge;",
          "",
          "void main(void)",
          "{",
          "    vAge = trail_time - aPositionAge.w;",
          "    gl_Position = matrix_viewProjection * vec4(aPositionAge.xyz, 1.0);",
          "}",
        ].join("\n"),
        fshader: [
          "precision mediump float;",
          "",
          "varying float vAge;",
          "",
          "uniform float trail_lifetime;",
          "",
          "vec3 rainbow(float x)",
          "{",
          "float level = floor(x * 6.0);",
          "float r = float(level <= 2.0) + float(level > 4.0) * 0.5;",
          "float g = max(1.0 - abs(level - 2.0) * 0.5, 0.0);",
          "float b = (1.0 - (level - 4.0) * 0.5) * float(level >= 4.0);",
          "return vec3(255, 255, 255);",
          "}",
          "void main(void)",
          "{",
          "    gl_FragColor = vec4(rainbow(vAge / trail_lifetime), (1.0 - (vAge / trail_lifetime)) * 0.5);",
          "}",
        ].join("\n"),
      },
      t = new pc.Shader(this.app.graphicsDevice, e),
      i = null;
    null != this.material
      ? (i = this.material.resource)
      : ((i = new pc.scene.Material()).setShader(t),
        i.setParameter("trail_time", 0),
        i.setParameter("trail_lifetime", this.lifetime),
        (i.cull = pc.CULLFACE_NONE),
        (i.blend = !0),
        (i.blendSrc = pc.BLENDMODE_SRC_ALPHA),
        (i.blendDst = pc.BLENDMODE_ONE_MINUS_SRC_ALPHA),
        (i.blendEquation = pc.BLENDEQUATION_ADD),
        (i.depthWrite = !1));
    var r = new pc.VertexFormat(this.app.context.graphicsDevice, [
        {
          semantic: pc.SEMANTIC_POSITION,
          components: 4,
          type: pc.ELEMENTTYPE_FLOAT32,
        },
      ]),
      a = new pc.VertexBuffer(
        this.app.context.graphicsDevice,
        r,
        MAX_VERTICES * VERTEX_SIZE,
        pc.USAGE_DYNAMIC
      ),
      s = new pc.scene.Mesh();
    (s.vertexBuffer = a),
      (s.indexBuffer[0] = null),
      (s.primitive[0].type = pc.PRIMITIVE_TRISTRIP),
      (s.primitive[0].base = 0),
      (s.primitive[0].count = 0),
      (s.primitive[0].indexed = !1);
    var o = new pc.scene.GraphNode(),
      n = new pc.scene.MeshInstance(o, s, i);
    (n.cull = !1),
      (n.layer = pc.scene.LAYER_WORLD),
      n.updateKey(),
      (this.entity.model = new pc.scene.Model()),
      (this.entity.model.graph = o),
      this.entity.model.meshInstances.push(n),
      (this.model = this.entity.model),
      this.setNode(this.entity);
  }),
  (Ribbon.prototype.hideShadder = function (e) {
    if (null != this.model && e)
      for (var t = this.vertices.length - 1; t >= 0; t--) {
        this.vertices[t];
        this.vertices.pop();
      }
  }),
  (Ribbon.prototype.reset = function () {
    (this.timer = 0), (this.vertices = []);
  }),
  (Ribbon.prototype.spawn = function () {
    var e = this.node,
      t = e.getPosition(),
      i = e.up.clone().scale(this.height),
      r = this.xoffset,
      a = this.yoffset;
    this.vertices.unshift({
      spawnTime: this.timer,
      vertexPair: [
        t.x + i.x * r,
        t.y + i.y * r,
        t.z + i.z * r,
        t.x + i.x * a,
        t.y + i.y * a,
        t.z + i.z * a,
      ],
    });
  }),
  (Ribbon.prototype.clearOld = function () {
    for (var e = this.vertices.length - 1; e >= 0; e--) {
      var t = this.vertices[e];
      if (!(this.timer - t.spawnTime >= this.lifetime)) return;
      this.vertices.pop();
    }
  }),
  (Ribbon.prototype.copyToArrayBuffer = function () {
    for (var e = 0; e < this.vertices.length; e++) {
      var t = this.vertices[e];
      (this.vertexData[8 * e + 0] = t.vertexPair[0]),
        (this.vertexData[8 * e + 1] = t.vertexPair[1]),
        (this.vertexData[8 * e + 2] = t.vertexPair[2]),
        (this.vertexData[8 * e + 3] = t.spawnTime),
        (this.vertexData[8 * e + 4] = t.vertexPair[3]),
        (this.vertexData[8 * e + 5] = t.vertexPair[4]),
        (this.vertexData[8 * e + 6] = t.vertexPair[5]),
        (this.vertexData[8 * e + 7] = t.spawnTime);
    }
  }),
  (Ribbon.prototype.updateNumActive = function () {
    this.model.meshInstances[0].mesh.primitive[0].count =
      2 * this.vertices.length;
  }),
  (Ribbon.prototype.update = function (e) {
    if (
      ((this.timer += e),
      this.model.meshInstances[0].material.setParameter(
        "trail_time",
        this.timer
      ),
      this.clearOld(),
      this.spawn(),
      this.vertices.length > 1)
    ) {
      this.copyToArrayBuffer(), this.updateNumActive();
      var t = this.model.meshInstances[0].mesh.vertexBuffer;
      new Float32Array(t.lock()).set(this.vertexData),
        t.unlock(),
        this.app.scene.containsModel(this.model) ||
          (console.log("Added model"), this.app.scene.addModel(this.model));
    } else
      this.app.scene.containsModel(this.model) &&
        (console.log("Removed model"), this.app.scene.removeModel(this.model));
  }),
  (Ribbon.prototype.setNode = function (e) {
    this.node = e;
  });
var Song5_array = [];
(Song5_array[0] = [0.35, 2, 0]),
  (Song5_array[1] = [0.6, 1, 0]),
  (Song5_array[2] = [0.90000004, 2, 0]),
  (Song5_array[3] = [1.2, 1, 0]),
  (Song5_array[4] = [1.5500001, 5, 0]),
  (Song5_array[5] = [1.9, 4, 0]),
  (Song5_array[6] = [2.25, 5, 0]),
  (Song5_array[7] = [2.5, 5, 0]),
  (Song5_array[8] = [2.8, 4, 0]),
  (Song5_array[9] = [3.1000001, 5, 0]),
  (Song5_array[10] = [3.5, 2, 0]),
  (Song5_array[11] = [3.75, 1, 0]),
  (Song5_array[12] = [4.05, 2, 0]),
  (Song5_array[13] = [4.4, 1, 0]),
  (Song5_array[14] = [4.75, 2, 0]),
  (Song5_array[15] = [5.1, 5, 0]),
  (Song5_array[16] = [5.4500003, 5, 0]),
  (Song5_array[17] = [5.75, 3, 0]),
  (Song5_array[18] = [6.05, 2, 0]),
  (Song5_array[19] = [6.35, 3, 0]),
  (Song5_array[20] = [6.6, 2, 0]),
  (Song5_array[21] = [6.85, 4, 0]),
  (Song5_array[22] = [7.1, 5, 0]),
  (Song5_array[23] = [7.4, 4, 0]),
  (Song5_array[24] = [7.7000003, 5, 0]),
  (Song5_array[25] = [7.9500003, 4, 0]),
  (Song5_array[26] = [8.2, 3, 0]),
  (Song5_array[27] = [8.45, 1, 0]),
  (Song5_array[28] = [8.45, 3, 0.05]),
  (Song5_array[29] = [8.55, 1, 0]),
  (Song5_array[30] = [8.55, 3, 0.05]),
  (Song5_array[31] = [8.650001, 1, 0]),
  (Song5_array[32] = [8.650001, 3, 0.05]),
  (Song5_array[33] = [8.900001, 1, 0.05]),
  (Song5_array[34] = [8.900001, 3, 0]),
  (Song5_array[35] = [9, 1, 0.05]),
  (Song5_array[36] = [9, 3, 0]),
  (Song5_array[37] = [9.1, 1, 0.05]),
  (Song5_array[38] = [9.1, 3, 0]),
  (Song5_array[39] = [9.3, 1, 0.05]),
  (Song5_array[40] = [9.3, 3, 0]),
  (Song5_array[41] = [9.400001, 1, 0.05]),
  (Song5_array[42] = [9.400001, 3, 0]),
  (Song5_array[43] = [9.5, 5, 0]),
  (Song5_array[44] = [9.7, 5, 0]),
  (Song5_array[45] = [9.900001, 3, 0]),
  (Song5_array[46] = [10.150001, 4, 0]),
  (Song5_array[47] = [10.2, 4, 0]),
  (Song5_array[48] = [10.25, 4, 0]),
  (Song5_array[49] = [10.3, 4, 0]),
  (Song5_array[50] = [10.35, 4, 0]),
  (Song5_array[51] = [10.5, 3, 0]),
  (Song5_array[52] = [10.900001, 3, 0]),
  (Song5_array[53] = [11.150001, 4, 0]),
  (Song5_array[54] = [11.6, 3, 0]),
  (Song5_array[55] = [11.650001, 3, 0]),
  (Song5_array[56] = [11.7, 3, 0]),
  (Song5_array[57] = [11.900001, 5, 0]),
  (Song5_array[58] = [12.25, 5, 0]),
  (Song5_array[59] = [12.5, 3, 0]),
  (Song5_array[60] = [12.55, 3, 0]),
  (Song5_array[61] = [12.6, 3, 0]),
  (Song5_array[62] = [12.650001, 3, 0]),
  (Song5_array[63] = [12.7, 3, 0]),
  (Song5_array[64] = [12.75, 3, 0]),
  (Song5_array[65] = [12.8, 3, 0]),
  (Song5_array[66] = [12.85, 3, 0]),
  (Song5_array[67] = [13.1, 1, 0]),
  (Song5_array[68] = [13.400001, 2, 0]),
  (Song5_array[69] = [13.7, 1, 0]),
  (Song5_array[70] = [14.05, 2, 0]),
  (Song5_array[71] = [14.400001, 4, 0]),
  (Song5_array[72] = [14.650001, 4, 0]),
  (Song5_array[73] = [15, 1, 0]),
  (Song5_array[74] = [15.3, 2, 0]),
  (Song5_array[75] = [15.650001, 1, 0]),
  (Song5_array[76] = [16, 2, 0]),
  (Song5_array[77] = [16.25, 4, 0]),
  (Song5_array[78] = [16.5, 4, 0]),
  (Song5_array[79] = [16.75, 1, 0]),
  (Song5_array[80] = [17.050001, 2, 0]),
  (Song5_array[81] = [17.4, 1, 0]),
  (Song5_array[82] = [17.75, 2, 0]),
  (Song5_array[83] = [18, 4, 0]),
  (Song5_array[84] = [18.25, 4, 0]),
  (Song5_array[85] = [18.5, 1, 0]),
  (Song5_array[86] = [18.800001, 2, 0]),
  (Song5_array[87] = [19.15, 1, 0]),
  (Song5_array[88] = [19.5, 2, 0]),
  (Song5_array[89] = [19.75, 4, 0]),
  (Song5_array[90] = [20, 4, 0]),
  (Song5_array[91] = [20.25, 1, 0]),
  (Song5_array[92] = [20.550001, 2, 0]),
  (Song5_array[93] = [20.9, 1, 0]),
  (Song5_array[94] = [21.300001, 1, 0.05]),
  (Song5_array[95] = [21.300001, 3, 0]),
  (Song5_array[96] = [21.4, 3, 0]),
  (Song5_array[97] = [21.5, 1, 0.05]),
  (Song5_array[98] = [21.5, 3, 0]),
  (Song5_array[99] = [21.6, 3, 0]),
  (Song5_array[100] = [21.75, 1, 0]),
  (Song5_array[101] = [21.75, 3, 0.05]),
  (Song5_array[102] = [21.85, 1, 0]),
  (Song5_array[103] = [21.85, 3, 0.05]),
  (Song5_array[104] = [21.95, 1, 0]),
  (Song5_array[105] = [22.1, 3, 0]),
  (Song5_array[106] = [22.1, 5, 0.05]),
  (Song5_array[107] = [22.2, 3, 0]),
  (Song5_array[108] = [22.2, 5, 0.05]),
  (Song5_array[109] = [22.300001, 3, 0]),
  (Song5_array[110] = [22.300001, 5, 0.05]),
  (Song5_array[111] = [22.45, 1, 0]),
  (Song5_array[112] = [22.7, 2, 0]),
  (Song5_array[113] = [22.85, 4, 0]),
  (Song5_array[114] = [22.9, 4, 0]),
  (Song5_array[115] = [22.95, 4, 0]),
  (Song5_array[116] = [23, 4, 0]),
  (Song5_array[117] = [23.050001, 4, 0]),
  (Song5_array[118] = [23.1, 4, 0]),
  (Song5_array[119] = [23.45, 2, 0]),
  (Song5_array[120] = [23.65, 2, 0]),
  (Song5_array[121] = [23.9, 5, 0]),
  (Song5_array[122] = [24.050001, 5, 0]),
  (Song5_array[123] = [24.1, 5, 0]),
  (Song5_array[124] = [24.15, 5, 0]),
  (Song5_array[125] = [24.300001, 3, 0]),
  (Song5_array[126] = [24.550001, 5, 0]),
  (Song5_array[127] = [24.85, 5, 0]),
  (Song5_array[128] = [25.300001, 3, 0]),
  (Song5_array[129] = [25.35, 3, 0]),
  (Song5_array[130] = [25.4, 3, 0]),
  (Song5_array[131] = [25.45, 3, 0]),
  (Song5_array[132] = [25.5, 3, 0]),
  (Song5_array[133] = [25.7, 5, 0]),
  (Song5_array[134] = [25.75, 5, 0]),
  (Song5_array[135] = [25.800001, 5, 0]),
  (Song5_array[136] = [25.95, 3, 0]),
  (Song5_array[137] = [26.1, 5, 0]),
  (Song5_array[138] = [26.35, 3, 0]),
  (Song5_array[139] = [26.65, 5, 0]),
  (Song5_array[140] = [27.6, 3, 0]),
  (Song5_array[141] = [27.9, 3, 0]),
  (Song5_array[142] = [28.2, 5, 0]),
  (Song5_array[143] = [29.300001, 5, 0]),
  (Song5_array[144] = [29.550001, 3, 0]),
  (Song5_array[145] = [29.85, 5, 0]),
  (Song5_array[146] = [30.2, 3, 0]),
  (Song5_array[147] = [30.6, 1, 0]),
  (Song5_array[148] = [30.85, 3, 0]),
  (Song5_array[149] = [31.45, 2, 0]),
  (Song5_array[150] = [32.3, 3, 0]),
  (Song5_array[151] = [32.45, 5, 0]),
  (Song5_array[152] = [32.7, 3, 0]),
  (Song5_array[153] = [32.95, 5, 0]),
  (Song5_array[154] = [34.05, 3, 0]),
  (Song5_array[155] = [34.05, 5, 0.05]),
  (Song5_array[156] = [34.15, 3, 0]),
  (Song5_array[157] = [34.15, 5, 0.05]),
  (Song5_array[158] = [34.25, 3, 0]),
  (Song5_array[159] = [34.25, 5, 0.05]),
  (Song5_array[160] = [34.4, 2, 0]),
  (Song5_array[161] = [34.55, 2, 0.05]),
  (Song5_array[162] = [34.55, 4, 0]),
  (Song5_array[163] = [34.65, 2, 0.05]),
  (Song5_array[164] = [34.65, 4, 0]),
  (Song5_array[165] = [34.75, 2, 0.05]),
  (Song5_array[166] = [34.75, 4, 0]),
  (Song5_array[167] = [34.95, 3, 0.05]),
  (Song5_array[168] = [34.95, 5, 0]),
  (Song5_array[169] = [35.05, 5, 0]),
  (Song5_array[170] = [35.15, 3, 0.05]),
  (Song5_array[171] = [35.15, 5, 0]),
  (Song5_array[172] = [35.7, 3, 0]),
  (Song5_array[173] = [35.850002, 5, 0]),
  (Song5_array[174] = [35.9, 5, 0]),
  (Song5_array[175] = [35.95, 5, 0]),
  (Song5_array[176] = [36, 5, 0]),
  (Song5_array[177] = [36.05, 5, 0]),
  (Song5_array[178] = [36.3, 3, 0]),
  (Song5_array[179] = [36.600002, 5, 0]),
  (Song5_array[180] = [36.9, 3, 0]),
  (Song5_array[181] = [36.95, 3, 0]),
  (Song5_array[182] = [37, 3, 0]),
  (Song5_array[183] = [37.2, 4, 0]),
  (Song5_array[184] = [37.4, 2, 0.05]),
  (Song5_array[185] = [37.4, 4, 0]),
  (Song5_array[186] = [37.5, 4, 0]),
  (Song5_array[187] = [37.600002, 4, 0]),
  (Song5_array[188] = [37.8, 1, 0]),
  (Song5_array[189] = [37.8, 3, 0.05]),
  (Song5_array[190] = [37.9, 1, 0]),
  (Song5_array[191] = [37.9, 3, 0.05]),
  (Song5_array[192] = [38, 1, 0]),
  (Song5_array[193] = [38.8, 3, 0]),
  (Song5_array[194] = [38.95, 5, 0]),
  (Song5_array[195] = [39.2, 3, 0]),
  (Song5_array[196] = [39.5, 5, 0]),
  (Song5_array[197] = [40.45, 3, 0]),
  (Song5_array[198] = [40.75, 3, 0]),
  (Song5_array[199] = [41.05, 5, 0]),
  (Song5_array[200] = [42.15, 5, 0]),
  (Song5_array[201] = [42.4, 3, 0]),
  (Song5_array[202] = [42.7, 5, 0]),
  (Song5_array[203] = [43.05, 3, 0]),
  (Song5_array[204] = [43.45, 1, 0]),
  (Song5_array[205] = [43.7, 3, 0]),
  (Song5_array[206] = [44.3, 2, 0]),
  (Song5_array[207] = [45.15, 3, 0]),
  (Song5_array[208] = [45.3, 5, 0]),
  (Song5_array[209] = [45.55, 3, 0]),
  (Song5_array[210] = [45.8, 5, 0]),
  (Song5_array[211] = [46.9, 1, 0]),
  (Song5_array[212] = [46.9, 3, 0.05]),
  (Song5_array[213] = [47, 1, 0]),
  (Song5_array[214] = [47, 3, 0.05]),
  (Song5_array[215] = [47.100002, 1, 0]),
  (Song5_array[216] = [47.100002, 3, 0.05]),
  (Song5_array[217] = [47.25, 3, 0]),
  (Song5_array[218] = [47.4, 2, 0.05]),
  (Song5_array[219] = [47.4, 4, 0]),
  (Song5_array[220] = [47.5, 2, 0.05]),
  (Song5_array[221] = [47.5, 4, 0]),
  (Song5_array[222] = [47.600002, 2, 0.05]),
  (Song5_array[223] = [47.600002, 4, 0]),
  (Song5_array[224] = [47.8, 3, 0.05]),
  (Song5_array[225] = [47.8, 5, 0]),
  (Song5_array[226] = [47.9, 5, 0]),
  (Song5_array[227] = [48, 3, 0.05]),
  (Song5_array[228] = [48, 5, 0]),
  (Song5_array[229] = [48.55, 3, 0]),
  (Song5_array[230] = [48.7, 5, 0]),
  (Song5_array[231] = [48.75, 5, 0]),
  (Song5_array[232] = [48.8, 5, 0]),
  (Song5_array[233] = [48.850002, 5, 0]),
  (Song5_array[234] = [48.9, 5, 0]),
  (Song5_array[235] = [49.15, 3, 0]),
  (Song5_array[236] = [49.45, 2, 0]),
  (Song5_array[237] = [49.75, 1, 0]),
  (Song5_array[238] = [49.8, 1, 0]),
  (Song5_array[239] = [49.850002, 1, 0]),
  (Song5_array[240] = [50.05, 3, 0]),
  (Song5_array[241] = [50.25, 2, 0.05]),
  (Song5_array[242] = [50.25, 4, 0]),
  (Song5_array[243] = [50.350002, 4, 0]),
  (Song5_array[244] = [50.45, 4, 0]),
  (Song5_array[245] = [50.65, 3, 0]),
  (Song5_array[246] = [50.65, 5, 0.05]),
  (Song5_array[247] = [50.75, 3, 0]),
  (Song5_array[248] = [50.75, 5, 0.05]),
  (Song5_array[249] = [50.850002, 3, 0]),
  (Song5_array[250] = [51, 5, 0]),
  (Song5_array[251] = [51.05, 5, 0]),
  (Song5_array[252] = [51.100002, 5, 0]),
  (Song5_array[253] = [51.15, 5, 0]),
  (Song5_array[254] = [51.2, 5, 0]),
  (Song5_array[255] = [51.350002, 5, 0]),
  (Song5_array[256] = [51.4, 5, 0]),
  (Song5_array[257] = [51.45, 5, 0]),
  (Song5_array[258] = [51.600002, 3, 0]),
  (Song5_array[259] = [52, 1, 0]),
  (Song5_array[260] = [52.25, 3, 0]),
  (Song5_array[261] = [52.600002, 1, 0]),
  (Song5_array[262] = [53.05, 5, 0]),
  (Song5_array[263] = [53.5, 3, 0]),
  (Song5_array[264] = [53.95, 5, 0]),
  (Song5_array[265] = [54.350002, 3, 0]),
  (Song5_array[266] = [54.75, 1, 0]),
  (Song5_array[267] = [55.2, 3, 0]),
  (Song5_array[268] = [56.2, 1, 0]),
  (Song5_array[269] = [56.8, 3, 0]),
  (Song5_array[270] = [57.25, 1, 0]),
  (Song5_array[271] = [57.7, 3, 0]),
  (Song5_array[272] = [58.3, 3, 0]),
  (Song5_array[273] = [58.55, 5, 0]),
  (Song5_array[274] = [58.9, 3, 0]),
  (Song5_array[275] = [59.350002, 4, 0]),
  (Song5_array[276] = [59.7, 3, 0.05]),
  (Song5_array[277] = [59.7, 5, 0]),
  (Song5_array[278] = [59.8, 3, 0.05]),
  (Song5_array[279] = [59.8, 5, 0]),
  (Song5_array[280] = [59.9, 3, 0.05]),
  (Song5_array[281] = [59.9, 5, 0]),
  (Song5_array[282] = [60.05, 4, 0]),
  (Song5_array[283] = [60.2, 1, 0.05]),
  (Song5_array[284] = [60.2, 3, 0]),
  (Song5_array[285] = [60.3, 3, 0]),
  (Song5_array[286] = [60.4, 1, 0.05]),
  (Song5_array[287] = [60.4, 3, 0]),
  (Song5_array[288] = [60.600002, 3, 0.05]),
  (Song5_array[289] = [60.600002, 5, 0]),
  (Song5_array[290] = [60.7, 3, 0.05]),
  (Song5_array[291] = [60.7, 5, 0]),
  (Song5_array[292] = [60.8, 5, 0]),
  (Song5_array[293] = [61.2, 3, 0]),
  (Song5_array[294] = [61.4, 1, 0]),
  (Song5_array[295] = [61.45, 1, 0]),
  (Song5_array[296] = [61.5, 1, 0]),
  (Song5_array[297] = [61.55, 1, 0]),
  (Song5_array[298] = [61.600002, 1, 0]),
  (Song5_array[299] = [61.850002, 3, 0]),
  (Song5_array[300] = [62.25, 2, 0]),
  (Song5_array[301] = [62.5, 5, 0]),
  (Song5_array[302] = [62.55, 5, 0]),
  (Song5_array[303] = [62.600002, 5, 0]),
  (Song5_array[304] = [62.850002, 2, 0]),
  (Song5_array[305] = [63, 1, 0.05]),
  (Song5_array[306] = [63, 3, 0]),
  (Song5_array[307] = [63.100002, 1, 0.05]),
  (Song5_array[308] = [63.100002, 3, 0]),
  (Song5_array[309] = [63.2, 1, 0.05]),
  (Song5_array[310] = [63.2, 3, 0]),
  (Song5_array[311] = [63.4, 3, 0]),
  (Song5_array[312] = [63.4, 5, 0.05]),
  (Song5_array[313] = [63.5, 3, 0]),
  (Song5_array[314] = [63.5, 5, 0.05]),
  (Song5_array[315] = [63.600002, 3, 0]),
  (Song5_array[316] = [63.600002, 5, 0.05]),
  (Song5_array[317] = [63.75, 5, 0]),
  (Song5_array[318] = [63.8, 5, 0]),
  (Song5_array[319] = [63.850002, 5, 0]),
  (Song5_array[320] = [63.9, 5, 0]),
  (Song5_array[321] = [63.95, 5, 0]),
  (Song5_array[322] = [64.1, 3, 0]),
  (Song5_array[323] = [64.15, 3, 0]),
  (Song5_array[324] = [64.200005, 3, 0]),
  (Song5_array[325] = [64.4, 1, 0]),
  (Song5_array[326] = [64.55, 3, 0]),
  (Song5_array[327] = [64.8, 1, 0]),
  (Song5_array[328] = [65.1, 3, 0]),
  (Song5_array[329] = [66.05, 3, 0]),
  (Song5_array[330] = [66.35, 3, 0]),
  (Song5_array[331] = [66.65, 5, 0]),
  (Song5_array[332] = [67.75, 3, 0]),
  (Song5_array[333] = [68, 5, 0]),
  (Song5_array[334] = [68.3, 3, 0]),
  (Song5_array[335] = [68.65, 5, 0]),
  (Song5_array[336] = [69.05, 3, 0]),
  (Song5_array[337] = [69.3, 1, 0]),
  (Song5_array[338] = [69.9, 3, 0]),
  (Song5_array[339] = [70.75, 3, 0]),
  (Song5_array[340] = [70.9, 5, 0]),
  (Song5_array[341] = [71.15, 3, 0]),
  (Song5_array[342] = [71.4, 5, 0]),
  (Song5_array[343] = [72.5, 1, 0]),
  (Song5_array[344] = [72.5, 3, 0.05]),
  (Song5_array[345] = [72.6, 1, 0]),
  (Song5_array[346] = [72.6, 3, 0.05]),
  (Song5_array[347] = [72.700005, 1, 0]),
  (Song5_array[348] = [72.700005, 3, 0.05]),
  (Song5_array[349] = [72.85, 3, 0]),
  (Song5_array[350] = [73, 3, 0.05]),
  (Song5_array[351] = [73, 5, 0]),
  (Song5_array[352] = [73.1, 3, 0.05]),
  (Song5_array[353] = [73.1, 5, 0]),
  (Song5_array[354] = [73.200005, 3, 0.05]),
  (Song5_array[355] = [73.200005, 5, 0]),
  (Song5_array[356] = [73.4, 1, 0.05]),
  (Song5_array[357] = [73.4, 3, 0]),
  (Song5_array[358] = [73.5, 3, 0]),
  (Song5_array[359] = [73.6, 1, 0.05]),
  (Song5_array[360] = [73.6, 3, 0]),
  (Song5_array[361] = [74.15, 3, 0]),
  (Song5_array[362] = [74.3, 5, 0]),
  (Song5_array[363] = [74.35, 5, 0]),
  (Song5_array[364] = [74.4, 5, 0]),
  (Song5_array[365] = [74.450005, 5, 0]),
  (Song5_array[366] = [74.5, 5, 0]),
  (Song5_array[367] = [74.75, 3, 0]),
  (Song5_array[368] = [75.05, 2, 0]),
  (Song5_array[369] = [75.35, 1, 0]),
  (Song5_array[370] = [75.4, 1, 0]),
  (Song5_array[371] = [75.450005, 1, 0]),
  (Song5_array[372] = [75.65, 4, 0]),
  (Song5_array[373] = [75.85, 3, 0.05]),
  (Song5_array[374] = [75.85, 5, 0]),
  (Song5_array[375] = [75.950005, 5, 0]),
  (Song5_array[376] = [76.05, 5, 0]),
  (Song5_array[377] = [76.25, 1, 0.05]),
  (Song5_array[378] = [76.25, 3, 0]),
  (Song5_array[379] = [76.35, 1, 0.05]),
  (Song5_array[380] = [76.35, 3, 0]),
  (Song5_array[381] = [76.450005, 3, 0]),
  (Song5_array[382] = [77.1, 3, 0]),
  (Song5_array[383] = [77.5, 5, 0]),
  (Song5_array[384] = [77.75, 3, 0]),
  (Song5_array[385] = [78.1, 5, 0]),
  (Song5_array[386] = [78.55, 3, 0]),
  (Song5_array[387] = [79, 5, 0]),
  (Song5_array[388] = [79.450005, 3, 0]),
  (Song5_array[389] = [79.85, 3, 0]),
  (Song5_array[390] = [80.25, 5, 0]),
  (Song5_array[391] = [80.700005, 3, 0]),
  (Song5_array[392] = [81.700005, 3, 0]),
  (Song5_array[393] = [82.3, 5, 0]),
  (Song5_array[394] = [82.75, 3, 0]),
  (Song5_array[395] = [83.200005, 5, 0]),
  (Song5_array[396] = [83.8, 3, 0]),
  (Song5_array[397] = [84.05, 5, 0]),
  (Song5_array[398] = [84.4, 3, 0]),
  (Song5_array[399] = [84.85, 2, 0]),
  (Song5_array[400] = [85.200005, 2, 0.05]),
  (Song5_array[401] = [85.200005, 4, 0]),
  (Song5_array[402] = [85.3, 2, 0.05]),
  (Song5_array[403] = [85.3, 4, 0]),
  (Song5_array[404] = [85.4, 2, 0.05]),
  (Song5_array[405] = [85.4, 4, 0]),
  (Song5_array[406] = [85.55, 5, 0]),
  (Song5_array[407] = [85.700005, 1, 0.05]),
  (Song5_array[408] = [85.700005, 3, 0]),
  (Song5_array[409] = [85.8, 3, 0]),
  (Song5_array[410] = [85.9, 1, 0.05]),
  (Song5_array[411] = [85.9, 3, 0]),
  (Song5_array[412] = [86.1, 2, 0.05]),
  (Song5_array[413] = [86.1, 4, 0]),
  (Song5_array[414] = [86.200005, 2, 0.05]),
  (Song5_array[415] = [86.200005, 4, 0]),
  (Song5_array[416] = [86.3, 4, 0]),
  (Song5_array[417] = [86.700005, 3, 0]),
  (Song5_array[418] = [86.9, 1, 0]),
  (Song5_array[419] = [86.950005, 1, 0]),
  (Song5_array[420] = [87, 1, 0]),
  (Song5_array[421] = [87.05, 1, 0]),
  (Song5_array[422] = [87.1, 1, 0]),
  (Song5_array[423] = [87.35, 3, 0]),
  (Song5_array[424] = [87.75, 1, 0]),
  (Song5_array[425] = [88, 3, 0]),
  (Song5_array[426] = [88.05, 3, 0]),
  (Song5_array[427] = [88.1, 3, 0]),
  (Song5_array[428] = [88.35, 2, 0]),
  (Song5_array[429] = [88.5, 3, 0.05]),
  (Song5_array[430] = [88.5, 5, 0]),
  (Song5_array[431] = [88.6, 3, 0.05]),
  (Song5_array[432] = [88.6, 5, 0]),
  (Song5_array[433] = [88.700005, 3, 0.05]),
  (Song5_array[434] = [88.700005, 5, 0]),
  (Song5_array[435] = [88.9, 1, 0.05]),
  (Song5_array[436] = [88.9, 3, 0]),
  (Song5_array[437] = [89, 1, 0.05]),
  (Song5_array[438] = [89, 3, 0]),
  (Song5_array[439] = [89.1, 1, 0.05]),
  (Song5_array[440] = [89.1, 3, 0]),
  (Song5_array[441] = [89.25, 1, 0]),
  (Song5_array[442] = [89.3, 1, 0]),
  (Song5_array[443] = [89.35, 1, 0]),
  (Song5_array[444] = [89.4, 1, 0]),
  (Song5_array[445] = [89.450005, 1, 0]),
  (Song5_array[446] = [89.6, 1, 0]),
  (Song5_array[447] = [89.65, 1, 0]),
  (Song5_array[448] = [89.700005, 1, 0]),
  (Song5_array[449] = [89.950005, 5, 0]),
  (Song5_array[450] = [90.35, 3, 0]),
  (Song5_array[451] = [90.6, 5, 0]),
  (Song5_array[452] = [90.950005, 3, 0]),
  (Song5_array[453] = [91.4, 5, 0]),
  (Song5_array[454] = [91.85, 3, 0]),
  (Song5_array[455] = [92.3, 5, 0]),
  (Song5_array[456] = [92.700005, 5, 0]),
  (Song5_array[457] = [93.1, 3, 0]),
  (Song5_array[458] = [93.55, 5, 0]),
  (Song5_array[459] = [94.55, 3, 0]),
  (Song5_array[460] = [95.15, 5, 0]),
  (Song5_array[461] = [95.6, 3, 0]),
  (Song5_array[462] = [96.05, 5, 0]),
  (Song5_array[463] = [96.65, 3, 0]),
  (Song5_array[464] = [96.9, 5, 0]),
  (Song5_array[465] = [97.25, 3, 0]),
  (Song5_array[466] = [97.700005, 5, 0]),
  (Song5_array[467] = [98.05, 1, 0.05]),
  (Song5_array[468] = [98.05, 3, 0]),
  (Song5_array[469] = [98.15, 1, 0.05]),
  (Song5_array[470] = [98.15, 3, 0]),
  (Song5_array[471] = [98.25, 1, 0.05]),
  (Song5_array[472] = [98.25, 3, 0]),
  (Song5_array[473] = [98.4, 4, 0]),
  (Song5_array[474] = [98.55, 1, 0.05]),
  (Song5_array[475] = [98.55, 3, 0]),
  (Song5_array[476] = [98.65, 3, 0]),
  (Song5_array[477] = [98.75, 1, 0.05]),
  (Song5_array[478] = [98.75, 3, 0]),
  (Song5_array[479] = [98.950005, 3, 0.05]),
  (Song5_array[480] = [98.950005, 5, 0]),
  (Song5_array[481] = [99.05, 3, 0.05]),
  (Song5_array[482] = [99.05, 5, 0]),
  (Song5_array[483] = [99.15, 5, 0]),
  (Song5_array[484] = [99.55, 3, 0]),
  (Song5_array[485] = [99.75, 1, 0]),
  (Song5_array[486] = [99.8, 1, 0]),
  (Song5_array[487] = [99.85, 1, 0]),
  (Song5_array[488] = [99.9, 1, 0]),
  (Song5_array[489] = [99.950005, 1, 0]),
  (Song5_array[490] = [100.200005, 3, 0]),
  (Song5_array[491] = [100.6, 1, 0]),
  (Song5_array[492] = [100.85, 3, 0]),
  (Song5_array[493] = [100.9, 3, 0]),
  (Song5_array[494] = [100.950005, 3, 0]),
  (Song5_array[495] = [101.200005, 4, 0]),
  (Song5_array[496] = [101.35, 1, 0.05]),
  (Song5_array[497] = [101.35, 3, 0]),
  (Song5_array[498] = [101.450005, 1, 0.05]),
  (Song5_array[499] = [101.450005, 3, 0]),
  (Song5_array[500] = [101.55, 1, 0.05]),
  (Song5_array[501] = [101.55, 3, 0]),
  (Song5_array[502] = [101.75, 3, 0.05]),
  (Song5_array[503] = [101.75, 5, 0]),
  (Song5_array[504] = [101.85, 3, 0.05]),
  (Song5_array[505] = [101.85, 5, 0]),
  (Song5_array[506] = [101.950005, 3, 0.05]),
  (Song5_array[507] = [101.950005, 5, 0]),
  (Song5_array[508] = [102.1, 1, 0]),
  (Song5_array[509] = [102.15, 1, 0]),
  (Song5_array[510] = [102.200005, 1, 0]),
  (Song5_array[511] = [102.25, 1, 0]),
  (Song5_array[512] = [102.3, 1, 0]),
  (Song5_array[513] = [102.450005, 1, 0]),
  (Song5_array[514] = [102.5, 1, 0]),
  (Song5_array[515] = [102.55, 1, 0]),
  (Song5_array[516] = [102.75, 5, 0]),
  (Song5_array[517] = [103.15, 3, 0]),
  (Song5_array[518] = [103.4, 5, 0]),
  (Song5_array[519] = [103.75, 3, 0]),
  (Song5_array[520] = [104.200005, 5, 0]),
  (Song5_array[521] = [104.65, 3, 0]),
  (Song5_array[522] = [105.1, 5, 0]),
  (Song5_array[523] = [105.5, 5, 0]),
  (Song5_array[524] = [105.9, 3, 0]),
  (Song5_array[525] = [106.35, 5, 0]),
  (Song5_array[526] = [107.35, 1, 0]),
  (Song5_array[527] = [107.950005, 3, 0]),
  (Song5_array[528] = [108.4, 1, 0]),
  (Song5_array[529] = [108.85, 3, 0]),
  (Song5_array[530] = [109.450005, 1, 0]),
  (Song5_array[531] = [109.700005, 3, 0]),
  (Song5_array[532] = [110.05, 1, 0]),
  (Song5_array[533] = [110.5, 5, 0]),
  (Song5_array[534] = [110.85, 1, 0.05]),
  (Song5_array[535] = [110.85, 3, 0]),
  (Song5_array[536] = [110.950005, 1, 0.05]),
  (Song5_array[537] = [110.950005, 3, 0]),
  (Song5_array[538] = [111.05, 1, 0.05]),
  (Song5_array[539] = [111.05, 3, 0]),
  (Song5_array[540] = [111.200005, 4, 0]),
  (Song5_array[541] = [111.35, 3, 0.05]),
  (Song5_array[542] = [111.35, 5, 0]),
  (Song5_array[543] = [111.450005, 5, 0]),
  (Song5_array[544] = [111.55, 3, 0.05]),
  (Song5_array[545] = [111.55, 5, 0]),
  (Song5_array[546] = [111.75, 1, 0.05]),
  (Song5_array[547] = [111.75, 3, 0]),
  (Song5_array[548] = [111.85, 1, 0.05]),
  (Song5_array[549] = [111.85, 3, 0]),
  (Song5_array[550] = [111.950005, 3, 0]),
  (Song5_array[551] = [112.35, 3, 0]),
  (Song5_array[552] = [112.55, 1, 0]),
  (Song5_array[553] = [112.6, 1, 0]),
  (Song5_array[554] = [112.65, 1, 0]),
  (Song5_array[555] = [112.700005, 1, 0]),
  (Song5_array[556] = [112.75, 1, 0]),
  (Song5_array[557] = [113, 3, 0]),
  (Song5_array[558] = [113.4, 1, 0]),
  (Song5_array[559] = [113.65, 3, 0]),
  (Song5_array[560] = [113.700005, 3, 0]),
  (Song5_array[561] = [113.75, 3, 0]),
  (Song5_array[562] = [114, 5, 0]),
  (Song5_array[563] = [114.15, 1, 0.05]),
  (Song5_array[564] = [114.15, 3, 0]),
  (Song5_array[565] = [114.25, 1, 0.05]),
  (Song5_array[566] = [114.25, 3, 0]),
  (Song5_array[567] = [114.35, 1, 0.05]),
  (Song5_array[568] = [114.35, 3, 0]),
  (Song5_array[569] = [114.55, 3, 0.05]),
  (Song5_array[570] = [114.55, 5, 0]),
  (Song5_array[571] = [114.65, 3, 0.05]),
  (Song5_array[572] = [114.65, 5, 0]),
  (Song5_array[573] = [114.75, 3, 0.05]),
  (Song5_array[574] = [114.75, 5, 0]),
  (Song5_array[575] = [114.9, 3, 0]),
  (Song5_array[576] = [114.950005, 3, 0]),
  (Song5_array[577] = [115, 3, 0]),
  (Song5_array[578] = [115.05, 3, 0]),
  (Song5_array[579] = [115.1, 3, 0]),
  (Song5_array[580] = [115.25, 3, 0]),
  (Song5_array[581] = [115.3, 3, 0]),
  (Song5_array[582] = [115.35, 3, 0]);
var Song6_array = [];
(Song6_array[0] = [0.1, 1, 0]),
  (Song6_array[1] = [0.35, 3, 0]),
  (Song6_array[2] = [0.6, 1, 0]),
  (Song6_array[3] = [0.85, 3, 0]),
  (Song6_array[4] = [1.0500001, 5, 0]),
  (Song6_array[5] = [1.35, 3, 0]),
  (Song6_array[6] = [1.7, 4, 0]),
  (Song6_array[7] = [2.15, 3, 0]),
  (Song6_array[8] = [2.4, 1, 0]),
  (Song6_array[9] = [2.65, 3, 0]),
  (Song6_array[10] = [2.8500001, 5, 0]),
  (Song6_array[11] = [3.15, 3, 0]),
  (Song6_array[12] = [3.7, 1, 0]),
  (Song6_array[13] = [3.95, 3, 0]),
  (Song6_array[14] = [4.2000003, 1, 0]),
  (Song6_array[15] = [4.4500003, 3, 0]),
  (Song6_array[16] = [4.65, 5, 0]),
  (Song6_array[17] = [4.9500003, 3, 0]),
  (Song6_array[18] = [5.3, 2, 0]),
  (Song6_array[19] = [5.75, 3, 0]),
  (Song6_array[20] = [6, 1, 0]),
  (Song6_array[21] = [6.25, 3, 0]),
  (Song6_array[22] = [6.4500003, 5, 0]),
  (Song6_array[23] = [6.75, 3, 0]),
  (Song6_array[24] = [7.35, 2, 0]),
  (Song6_array[25] = [7.35, 4, 0.05]),
  (Song6_array[26] = [7.6, 2, 0]),
  (Song6_array[27] = [7.6, 4, 0.05]),
  (Song6_array[28] = [7.85, 2, 0]),
  (Song6_array[29] = [7.85, 4, 0.05]),
  (Song6_array[30] = [8.1, 2, 0]),
  (Song6_array[31] = [8.1, 4, 0.05]),
  (Song6_array[32] = [8.3, 5, 0]),
  (Song6_array[33] = [8.6, 1, 0]),
  (Song6_array[34] = [8.6, 3, 0.05]),
  (Song6_array[35] = [8.95, 1, 0]),
  (Song6_array[36] = [8.95, 3, 0.05]),
  (Song6_array[37] = [9.400001, 2, 0]),
  (Song6_array[38] = [9.400001, 4, 0.05]),
  (Song6_array[39] = [9.650001, 2, 0]),
  (Song6_array[40] = [9.650001, 4, 0.05]),
  (Song6_array[41] = [9.900001, 2, 0]),
  (Song6_array[42] = [9.900001, 4, 0.05]),
  (Song6_array[43] = [10.1, 5, 0]),
  (Song6_array[44] = [10.400001, 1, 0]),
  (Song6_array[45] = [10.400001, 3, 0.05]),
  (Song6_array[46] = [11, 2, 0]),
  (Song6_array[47] = [11, 4, 0.05]),
  (Song6_array[48] = [11.25, 2, 0]),
  (Song6_array[49] = [11.25, 4, 0.05]),
  (Song6_array[50] = [11.5, 2, 0]),
  (Song6_array[51] = [11.5, 4, 0.05]),
  (Song6_array[52] = [11.75, 2, 0]),
  (Song6_array[53] = [11.75, 4, 0.05]),
  (Song6_array[54] = [11.95, 5, 0]),
  (Song6_array[55] = [12.25, 1, 0]),
  (Song6_array[56] = [12.25, 3, 0.05]),
  (Song6_array[57] = [12.6, 1, 0]),
  (Song6_array[58] = [12.6, 3, 0.05]),
  (Song6_array[59] = [13.05, 2, 0]),
  (Song6_array[60] = [13.05, 4, 0.05]),
  (Song6_array[61] = [13.3, 2, 0]),
  (Song6_array[62] = [13.3, 4, 0.05]),
  (Song6_array[63] = [13.55, 2, 0]),
  (Song6_array[64] = [13.55, 4, 0.05]),
  (Song6_array[65] = [13.75, 5, 0]),
  (Song6_array[66] = [14.05, 1, 0]),
  (Song6_array[67] = [14.05, 3, 0.05]),
  (Song6_array[68] = [14.6, 5, 0]),
  (Song6_array[69] = [15.1, 1, 0]),
  (Song6_array[70] = [15.5, 2, 0]),
  (Song6_array[71] = [15.7, 1, 0]),
  (Song6_array[72] = [15.900001, 2, 0]),
  (Song6_array[73] = [16.1, 1, 0]),
  (Song6_array[74] = [16.300001, 4, 0]),
  (Song6_array[75] = [16.35, 4, 0]),
  (Song6_array[76] = [16.4, 4, 0]),
  (Song6_array[77] = [18.25, 5, 0]),
  (Song6_array[78] = [18.75, 1, 0]),
  (Song6_array[79] = [19.15, 2, 0]),
  (Song6_array[80] = [19.35, 1, 0]),
  (Song6_array[81] = [19.550001, 2, 0]),
  (Song6_array[82] = [19.75, 1, 0]),
  (Song6_array[83] = [19.95, 4, 0]),
  (Song6_array[84] = [20, 4, 0]),
  (Song6_array[85] = [20.050001, 4, 0]),
  (Song6_array[86] = [21.9, 5, 0]),
  (Song6_array[87] = [22.4, 1, 0]),
  (Song6_array[88] = [22.800001, 2, 0]),
  (Song6_array[89] = [23, 1, 0]),
  (Song6_array[90] = [23.2, 2, 0]),
  (Song6_array[91] = [23.4, 1, 0]),
  (Song6_array[92] = [23.6, 4, 0]),
  (Song6_array[93] = [23.65, 4, 0]),
  (Song6_array[94] = [23.7, 4, 0]),
  (Song6_array[95] = [25.5, 5, 0]),
  (Song6_array[96] = [26, 1, 0]),
  (Song6_array[97] = [26.4, 2, 0]),
  (Song6_array[98] = [26.6, 1, 0]),
  (Song6_array[99] = [26.800001, 2, 0]),
  (Song6_array[100] = [27, 1, 0]),
  (Song6_array[101] = [27.2, 4, 0]),
  (Song6_array[102] = [27.25, 4, 0]),
  (Song6_array[103] = [27.300001, 4, 0]),
  (Song6_array[104] = [29.2, 3, 0]),
  (Song6_array[105] = [29.25, 3, 0]),
  (Song6_array[106] = [29.300001, 3, 0]),
  (Song6_array[107] = [29.35, 3, 0]),
  (Song6_array[108] = [29.550001, 3, 0]),
  (Song6_array[109] = [29.550001, 5, 0.05]),
  (Song6_array[110] = [29.9, 1, 0]),
  (Song6_array[111] = [29.95, 1, 0]),
  (Song6_array[112] = [30, 1, 0]),
  (Song6_array[113] = [30.050001, 1, 0]),
  (Song6_array[114] = [30.25, 1, 0.05]),
  (Song6_array[115] = [30.25, 3, 0]),
  (Song6_array[116] = [30.9, 1, 0]),
  (Song6_array[117] = [31.1, 3, 0]),
  (Song6_array[118] = [31.300001, 5, 0]),
  (Song6_array[119] = [31.5, 3, 0]),
  (Song6_array[120] = [31.7, 2, 0]),
  (Song6_array[121] = [31.9, 4, 0]),
  (Song6_array[122] = [32.100002, 3, 0]),
  (Song6_array[123] = [32.25, 5, 0]),
  (Song6_array[124] = [32.45, 2, 0]),
  (Song6_array[125] = [32.5, 2, 0]),
  (Song6_array[126] = [32.55, 2, 0]),
  (Song6_array[127] = [32.600002, 2, 0]),
  (Song6_array[128] = [32.850002, 3, 0]),
  (Song6_array[129] = [32.9, 3, 0]),
  (Song6_array[130] = [32.95, 3, 0]),
  (Song6_array[131] = [33, 3, 0]),
  (Song6_array[132] = [33.2, 3, 0]),
  (Song6_array[133] = [33.2, 5, 0.05]),
  (Song6_array[134] = [33.55, 1, 0]),
  (Song6_array[135] = [33.600002, 1, 0]),
  (Song6_array[136] = [33.65, 1, 0]),
  (Song6_array[137] = [33.7, 1, 0]),
  (Song6_array[138] = [33.9, 1, 0.05]),
  (Song6_array[139] = [33.9, 3, 0]),
  (Song6_array[140] = [34.55, 1, 0]),
  (Song6_array[141] = [34.75, 3, 0]),
  (Song6_array[142] = [34.95, 5, 0]),
  (Song6_array[143] = [35.15, 3, 0]),
  (Song6_array[144] = [35.350002, 2, 0]),
  (Song6_array[145] = [35.55, 4, 0]),
  (Song6_array[146] = [35.75, 3, 0]),
  (Song6_array[147] = [35.9, 5, 0]),
  (Song6_array[148] = [36.100002, 2, 0]),
  (Song6_array[149] = [36.15, 2, 0]),
  (Song6_array[150] = [36.2, 2, 0]),
  (Song6_array[151] = [36.25, 2, 0]),
  (Song6_array[152] = [36.5, 3, 0]),
  (Song6_array[153] = [36.55, 3, 0]),
  (Song6_array[154] = [36.600002, 3, 0]),
  (Song6_array[155] = [36.65, 3, 0]),
  (Song6_array[156] = [36.850002, 3, 0]),
  (Song6_array[157] = [36.850002, 5, 0.05]),
  (Song6_array[158] = [37.2, 1, 0]),
  (Song6_array[159] = [37.25, 1, 0]),
  (Song6_array[160] = [37.3, 1, 0]),
  (Song6_array[161] = [37.350002, 1, 0]),
  (Song6_array[162] = [37.55, 1, 0.05]),
  (Song6_array[163] = [37.55, 3, 0]),
  (Song6_array[164] = [38.2, 1, 0]),
  (Song6_array[165] = [38.4, 3, 0]),
  (Song6_array[166] = [38.600002, 5, 0]),
  (Song6_array[167] = [38.8, 3, 0]),
  (Song6_array[168] = [39, 2, 0]),
  (Song6_array[169] = [39.2, 4, 0]),
  (Song6_array[170] = [39.4, 3, 0]),
  (Song6_array[171] = [39.55, 5, 0]),
  (Song6_array[172] = [39.75, 2, 0]),
  (Song6_array[173] = [39.8, 2, 0]),
  (Song6_array[174] = [39.850002, 2, 0]),
  (Song6_array[175] = [39.9, 2, 0]),
  (Song6_array[176] = [40.15, 3, 0]),
  (Song6_array[177] = [40.2, 3, 0]),
  (Song6_array[178] = [40.25, 3, 0]),
  (Song6_array[179] = [40.3, 3, 0]),
  (Song6_array[180] = [40.5, 3, 0]),
  (Song6_array[181] = [40.5, 5, 0.05]),
  (Song6_array[182] = [40.850002, 1, 0]),
  (Song6_array[183] = [40.9, 1, 0]),
  (Song6_array[184] = [40.95, 1, 0]),
  (Song6_array[185] = [41, 1, 0]),
  (Song6_array[186] = [41.2, 1, 0.05]),
  (Song6_array[187] = [41.2, 3, 0]),
  (Song6_array[188] = [41.850002, 1, 0]),
  (Song6_array[189] = [42.05, 3, 0]),
  (Song6_array[190] = [42.25, 5, 0]),
  (Song6_array[191] = [42.45, 3, 0]),
  (Song6_array[192] = [42.65, 2, 0]),
  (Song6_array[193] = [42.850002, 4, 0]),
  (Song6_array[194] = [43.05, 3, 0]),
  (Song6_array[195] = [43.2, 5, 0]),
  (Song6_array[196] = [43.4, 2, 0]),
  (Song6_array[197] = [43.45, 2, 0]),
  (Song6_array[198] = [43.5, 2, 0]),
  (Song6_array[199] = [43.55, 2, 0]),
  (Song6_array[200] = [43.75, 3, 0.05]),
  (Song6_array[201] = [43.75, 5, 0]),
  (Song6_array[202] = [44.100002, 3, 0]),
  (Song6_array[203] = [44.100002, 5, 0.05]),
  (Song6_array[204] = [44.3, 2, 0]),
  (Song6_array[205] = [44.350002, 2, 0]),
  (Song6_array[206] = [44.4, 2, 0]),
  (Song6_array[207] = [44.75, 3, 0]),
  (Song6_array[208] = [44.75, 5, 0.05]),
  (Song6_array[209] = [44.95, 3, 0]),
  (Song6_array[210] = [45, 3, 0]),
  (Song6_array[211] = [45.05, 3, 0]),
  (Song6_array[212] = [45.3, 2, 0]),
  (Song6_array[213] = [45.4, 2, 0]),
  (Song6_array[214] = [45.55, 5, 0]),
  (Song6_array[215] = [45.850002, 2, 0.05]),
  (Song6_array[216] = [45.850002, 4, 0]),
  (Song6_array[217] = [46.100002, 2, 0.05]),
  (Song6_array[218] = [46.100002, 4, 0]),
  (Song6_array[219] = [46.350002, 3, 0]),
  (Song6_array[220] = [46.45, 2, 0]),
  (Song6_array[221] = [46.55, 3, 0]),
  (Song6_array[222] = [46.7, 4, 0]),
  (Song6_array[223] = [46.850002, 3, 0]),
  (Song6_array[224] = [47, 2, 0]),
  (Song6_array[225] = [47.2, 3, 0]),
  (Song6_array[226] = [47.4, 3, 0.05]),
  (Song6_array[227] = [47.4, 5, 0]),
  (Song6_array[228] = [47.75, 3, 0]),
  (Song6_array[229] = [47.75, 5, 0.05]),
  (Song6_array[230] = [47.95, 2, 0]),
  (Song6_array[231] = [48, 2, 0]),
  (Song6_array[232] = [48.05, 2, 0]),
  (Song6_array[233] = [48.4, 3, 0]),
  (Song6_array[234] = [48.4, 5, 0.05]),
  (Song6_array[235] = [48.600002, 3, 0]),
  (Song6_array[236] = [48.65, 3, 0]),
  (Song6_array[237] = [48.7, 3, 0]),
  (Song6_array[238] = [48.95, 2, 0]),
  (Song6_array[239] = [49.05, 2, 0]),
  (Song6_array[240] = [49.2, 5, 0]),
  (Song6_array[241] = [49.5, 2, 0.05]),
  (Song6_array[242] = [49.5, 4, 0]),
  (Song6_array[243] = [49.75, 2, 0.05]),
  (Song6_array[244] = [49.75, 4, 0]),
  (Song6_array[245] = [50, 3, 0]),
  (Song6_array[246] = [50.100002, 2, 0]),
  (Song6_array[247] = [50.2, 3, 0]),
  (Song6_array[248] = [50.350002, 4, 0]),
  (Song6_array[249] = [50.5, 3, 0]),
  (Song6_array[250] = [50.65, 2, 0]),
  (Song6_array[251] = [50.850002, 3, 0]),
  (Song6_array[252] = [51.05, 3, 0]),
  (Song6_array[253] = [51.100002, 3, 0]),
  (Song6_array[254] = [51.15, 3, 0]),
  (Song6_array[255] = [51.2, 3, 0]),
  (Song6_array[256] = [51.4, 3, 0]),
  (Song6_array[257] = [51.4, 5, 0.05]),
  (Song6_array[258] = [51.75, 1, 0]),
  (Song6_array[259] = [51.8, 1, 0]),
  (Song6_array[260] = [51.850002, 1, 0]),
  (Song6_array[261] = [51.9, 1, 0]),
  (Song6_array[262] = [52.100002, 1, 0.05]),
  (Song6_array[263] = [52.100002, 3, 0]),
  (Song6_array[264] = [52.75, 1, 0]),
  (Song6_array[265] = [52.95, 3, 0]),
  (Song6_array[266] = [53.15, 5, 0]),
  (Song6_array[267] = [53.350002, 3, 0]),
  (Song6_array[268] = [53.55, 2, 0]),
  (Song6_array[269] = [53.75, 4, 0]),
  (Song6_array[270] = [53.95, 3, 0]),
  (Song6_array[271] = [54.100002, 5, 0]),
  (Song6_array[272] = [54.3, 2, 0]),
  (Song6_array[273] = [54.350002, 2, 0]),
  (Song6_array[274] = [54.4, 2, 0]),
  (Song6_array[275] = [54.45, 2, 0]),
  (Song6_array[276] = [54.65, 3, 0]),
  (Song6_array[277] = [54.7, 3, 0]),
  (Song6_array[278] = [54.75, 3, 0]),
  (Song6_array[279] = [54.8, 3, 0]),
  (Song6_array[280] = [55, 3, 0]),
  (Song6_array[281] = [55, 5, 0.05]),
  (Song6_array[282] = [55.350002, 1, 0]),
  (Song6_array[283] = [55.4, 1, 0]),
  (Song6_array[284] = [55.45, 1, 0]),
  (Song6_array[285] = [55.5, 1, 0]),
  (Song6_array[286] = [55.7, 1, 0.05]),
  (Song6_array[287] = [55.7, 3, 0]),
  (Song6_array[288] = [56.350002, 1, 0]),
  (Song6_array[289] = [56.55, 3, 0]),
  (Song6_array[290] = [56.75, 5, 0]),
  (Song6_array[291] = [56.95, 3, 0]),
  (Song6_array[292] = [57.15, 2, 0]),
  (Song6_array[293] = [57.350002, 4, 0]),
  (Song6_array[294] = [57.55, 3, 0]),
  (Song6_array[295] = [57.7, 5, 0]),
  (Song6_array[296] = [57.9, 2, 0]),
  (Song6_array[297] = [57.95, 2, 0]),
  (Song6_array[298] = [58, 2, 0]),
  (Song6_array[299] = [58.05, 2, 0]),
  (Song6_array[300] = [58.25, 3, 0]),
  (Song6_array[301] = [58.75, 1, 0]),
  (Song6_array[302] = [59.2, 2, 0]),
  (Song6_array[303] = [59.2, 4, 0.05]),
  (Song6_array[304] = [59.4, 1, 0]),
  (Song6_array[305] = [59.4, 3, 0.05]),
  (Song6_array[306] = [59.600002, 2, 0]),
  (Song6_array[307] = [59.600002, 4, 0.05]),
  (Song6_array[308] = [59.8, 1, 0]),
  (Song6_array[309] = [59.8, 3, 0.05]),
  (Song6_array[310] = [60, 4, 0]),
  (Song6_array[311] = [60.05, 4, 0]),
  (Song6_array[312] = [60.100002, 4, 0]),
  (Song6_array[313] = [61.95, 3, 0]),
  (Song6_array[314] = [62.45, 1, 0]),
  (Song6_array[315] = [62.9, 2, 0]),
  (Song6_array[316] = [62.9, 4, 0.05]),
  (Song6_array[317] = [63.100002, 1, 0]),
  (Song6_array[318] = [63.100002, 3, 0.05]),
  (Song6_array[319] = [63.3, 2, 0]),
  (Song6_array[320] = [63.3, 4, 0.05]),
  (Song6_array[321] = [63.5, 1, 0]),
  (Song6_array[322] = [63.5, 3, 0.05]),
  (Song6_array[323] = [63.7, 4, 0]),
  (Song6_array[324] = [63.75, 4, 0]),
  (Song6_array[325] = [63.8, 4, 0]),
  (Song6_array[326] = [65.55, 3, 0]),
  (Song6_array[327] = [66.05, 1, 0]),
  (Song6_array[328] = [66.5, 2, 0]),
  (Song6_array[329] = [66.5, 4, 0.05]),
  (Song6_array[330] = [66.700005, 1, 0]),
  (Song6_array[331] = [66.700005, 3, 0.05]),
  (Song6_array[332] = [66.9, 2, 0]),
  (Song6_array[333] = [66.9, 4, 0.05]),
  (Song6_array[334] = [67.1, 1, 0]),
  (Song6_array[335] = [67.1, 3, 0.05]),
  (Song6_array[336] = [67.3, 4, 0]),
  (Song6_array[337] = [67.35, 4, 0]),
  (Song6_array[338] = [67.4, 4, 0]),
  (Song6_array[339] = [69.200005, 3, 0]),
  (Song6_array[340] = [69.700005, 1, 0]),
  (Song6_array[341] = [70.15, 2, 0]),
  (Song6_array[342] = [70.15, 4, 0.05]),
  (Song6_array[343] = [70.35, 1, 0]),
  (Song6_array[344] = [70.35, 3, 0.05]),
  (Song6_array[345] = [70.55, 2, 0]),
  (Song6_array[346] = [70.55, 4, 0.05]),
  (Song6_array[347] = [70.75, 1, 0]),
  (Song6_array[348] = [70.75, 3, 0.05]),
  (Song6_array[349] = [70.950005, 4, 0]),
  (Song6_array[350] = [71, 4, 0]),
  (Song6_array[351] = [71.05, 4, 0]),
  (Song6_array[352] = [72.75, 3, 0]),
  (Song6_array[353] = [73.25, 1, 0]),
  (Song6_array[354] = [73.700005, 2, 0]),
  (Song6_array[355] = [73.700005, 4, 0.05]),
  (Song6_array[356] = [73.9, 1, 0]),
  (Song6_array[357] = [73.9, 3, 0.05]),
  (Song6_array[358] = [74.1, 2, 0]),
  (Song6_array[359] = [74.1, 4, 0.05]),
  (Song6_array[360] = [74.3, 1, 0]),
  (Song6_array[361] = [74.3, 3, 0.05]),
  (Song6_array[362] = [74.5, 4, 0]),
  (Song6_array[363] = [74.55, 4, 0]),
  (Song6_array[364] = [74.6, 4, 0]),
  (Song6_array[365] = [76.5, 3, 0]),
  (Song6_array[366] = [77, 1, 0]),
  (Song6_array[367] = [77.450005, 2, 0]),
  (Song6_array[368] = [77.450005, 4, 0.05]),
  (Song6_array[369] = [77.65, 1, 0]),
  (Song6_array[370] = [77.65, 3, 0.05]),
  (Song6_array[371] = [77.85, 2, 0]),
  (Song6_array[372] = [77.85, 4, 0.05]),
  (Song6_array[373] = [78.05, 1, 0]),
  (Song6_array[374] = [78.05, 3, 0.05]),
  (Song6_array[375] = [78.25, 4, 0]),
  (Song6_array[376] = [78.3, 4, 0]),
  (Song6_array[377] = [78.35, 4, 0]),
  (Song6_array[378] = [80.05, 3, 0]),
  (Song6_array[379] = [80.55, 1, 0]),
  (Song6_array[380] = [81, 2, 0]),
  (Song6_array[381] = [81, 4, 0.05]),
  (Song6_array[382] = [81.200005, 1, 0]),
  (Song6_array[383] = [81.200005, 3, 0.05]),
  (Song6_array[384] = [81.4, 2, 0]),
  (Song6_array[385] = [81.4, 4, 0.05]),
  (Song6_array[386] = [81.6, 1, 0]),
  (Song6_array[387] = [81.6, 3, 0.05]),
  (Song6_array[388] = [81.8, 4, 0]),
  (Song6_array[389] = [81.85, 4, 0]),
  (Song6_array[390] = [81.9, 4, 0]),
  (Song6_array[391] = [83.700005, 3, 0]),
  (Song6_array[392] = [84.200005, 1, 0]),
  (Song6_array[393] = [84.65, 2, 0]),
  (Song6_array[394] = [84.65, 4, 0.05]),
  (Song6_array[395] = [84.85, 1, 0]),
  (Song6_array[396] = [84.85, 3, 0.05]),
  (Song6_array[397] = [85.05, 2, 0]),
  (Song6_array[398] = [85.05, 4, 0.05]),
  (Song6_array[399] = [85.25, 1, 0]),
  (Song6_array[400] = [85.25, 3, 0.05]),
  (Song6_array[401] = [85.450005, 4, 0]),
  (Song6_array[402] = [85.5, 4, 0]),
  (Song6_array[403] = [85.55, 4, 0]),
  (Song6_array[404] = [87.35, 3, 0]),
  (Song6_array[405] = [87.4, 3, 0]),
  (Song6_array[406] = [87.450005, 3, 0]),
  (Song6_array[407] = [87.5, 3, 0]),
  (Song6_array[408] = [87.700005, 3, 0]),
  (Song6_array[409] = [87.700005, 5, 0.05]),
  (Song6_array[410] = [88.05, 1, 0]),
  (Song6_array[411] = [88.1, 1, 0]),
  (Song6_array[412] = [88.15, 1, 0]),
  (Song6_array[413] = [88.200005, 1, 0]),
  (Song6_array[414] = [88.4, 1, 0.05]),
  (Song6_array[415] = [88.4, 3, 0]),
  (Song6_array[416] = [89.05, 1, 0]),
  (Song6_array[417] = [89.25, 3, 0]),
  (Song6_array[418] = [89.450005, 5, 0]),
  (Song6_array[419] = [89.65, 3, 0]),
  (Song6_array[420] = [89.85, 2, 0]),
  (Song6_array[421] = [90.05, 4, 0]),
  (Song6_array[422] = [90.25, 3, 0]),
  (Song6_array[423] = [90.4, 5, 0]),
  (Song6_array[424] = [90.6, 2, 0]),
  (Song6_array[425] = [90.65, 2, 0]),
  (Song6_array[426] = [90.700005, 2, 0]),
  (Song6_array[427] = [90.75, 2, 0]),
  (Song6_array[428] = [91, 3, 0]),
  (Song6_array[429] = [91.05, 3, 0]),
  (Song6_array[430] = [91.1, 3, 0]),
  (Song6_array[431] = [91.15, 3, 0]),
  (Song6_array[432] = [91.35, 3, 0]),
  (Song6_array[433] = [91.35, 5, 0.05]),
  (Song6_array[434] = [91.700005, 1, 0]),
  (Song6_array[435] = [91.75, 1, 0]),
  (Song6_array[436] = [91.8, 1, 0]),
  (Song6_array[437] = [91.85, 1, 0]),
  (Song6_array[438] = [92.05, 1, 0.05]),
  (Song6_array[439] = [92.05, 3, 0]),
  (Song6_array[440] = [92.700005, 1, 0]),
  (Song6_array[441] = [92.9, 3, 0]),
  (Song6_array[442] = [93.1, 5, 0]),
  (Song6_array[443] = [93.3, 3, 0]),
  (Song6_array[444] = [93.5, 2, 0]),
  (Song6_array[445] = [93.700005, 4, 0]),
  (Song6_array[446] = [93.9, 3, 0]),
  (Song6_array[447] = [94.05, 5, 0]),
  (Song6_array[448] = [94.25, 2, 0]),
  (Song6_array[449] = [94.3, 2, 0]),
  (Song6_array[450] = [94.35, 2, 0]),
  (Song6_array[451] = [94.4, 2, 0]),
  (Song6_array[452] = [94.700005, 3, 0]),
  (Song6_array[453] = [94.75, 3, 0]),
  (Song6_array[454] = [94.8, 3, 0]),
  (Song6_array[455] = [94.85, 3, 0]),
  (Song6_array[456] = [95.05, 3, 0]),
  (Song6_array[457] = [95.05, 5, 0.05]),
  (Song6_array[458] = [95.4, 1, 0]),
  (Song6_array[459] = [95.450005, 1, 0]),
  (Song6_array[460] = [95.5, 1, 0]),
  (Song6_array[461] = [95.55, 1, 0]),
  (Song6_array[462] = [95.75, 1, 0.05]),
  (Song6_array[463] = [95.75, 3, 0]),
  (Song6_array[464] = [96.4, 1, 0]),
  (Song6_array[465] = [96.6, 3, 0]),
  (Song6_array[466] = [96.8, 5, 0]),
  (Song6_array[467] = [97, 3, 0]),
  (Song6_array[468] = [97.200005, 2, 0]),
  (Song6_array[469] = [97.4, 4, 0]),
  (Song6_array[470] = [97.6, 3, 0]),
  (Song6_array[471] = [97.75, 5, 0]),
  (Song6_array[472] = [97.950005, 2, 0]),
  (Song6_array[473] = [98, 2, 0]),
  (Song6_array[474] = [98.05, 2, 0]),
  (Song6_array[475] = [98.1, 2, 0]),
  (Song6_array[476] = [98.3, 3, 0]),
  (Song6_array[477] = [98.35, 3, 0]),
  (Song6_array[478] = [98.4, 3, 0]),
  (Song6_array[479] = [98.450005, 3, 0]),
  (Song6_array[480] = [98.65, 3, 0]),
  (Song6_array[481] = [98.65, 5, 0.05]),
  (Song6_array[482] = [99, 1, 0]),
  (Song6_array[483] = [99.05, 1, 0]),
  (Song6_array[484] = [99.1, 1, 0]),
  (Song6_array[485] = [99.15, 1, 0]),
  (Song6_array[486] = [99.35, 1, 0.05]),
  (Song6_array[487] = [99.35, 3, 0]),
  (Song6_array[488] = [100, 1, 0]),
  (Song6_array[489] = [100.200005, 3, 0]),
  (Song6_array[490] = [100.4, 5, 0]),
  (Song6_array[491] = [100.6, 3, 0]),
  (Song6_array[492] = [100.8, 2, 0]),
  (Song6_array[493] = [101, 4, 0]),
  (Song6_array[494] = [101.200005, 3, 0]),
  (Song6_array[495] = [101.35, 5, 0]),
  (Song6_array[496] = [101.55, 2, 0]),
  (Song6_array[497] = [101.6, 2, 0]),
  (Song6_array[498] = [101.65, 2, 0]),
  (Song6_array[499] = [101.700005, 2, 0]),
  (Song6_array[500] = [101.950005, 3, 0.05]),
  (Song6_array[501] = [101.950005, 5, 0]),
  (Song6_array[502] = [102.3, 3, 0]),
  (Song6_array[503] = [102.3, 5, 0.05]),
  (Song6_array[504] = [102.5, 2, 0]),
  (Song6_array[505] = [102.55, 2, 0]),
  (Song6_array[506] = [102.6, 2, 0]),
  (Song6_array[507] = [102.950005, 1, 0]),
  (Song6_array[508] = [102.950005, 3, 0.05]),
  (Song6_array[509] = [103.15, 1, 0]),
  (Song6_array[510] = [103.200005, 1, 0]),
  (Song6_array[511] = [103.25, 1, 0]),
  (Song6_array[512] = [103.5, 3, 0]),
  (Song6_array[513] = [103.6, 3, 0]),
  (Song6_array[514] = [103.75, 5, 0]),
  (Song6_array[515] = [104.05, 3, 0.05]),
  (Song6_array[516] = [104.05, 5, 0]),
  (Song6_array[517] = [104.3, 3, 0.05]),
  (Song6_array[518] = [104.3, 5, 0]),
  (Song6_array[519] = [104.55, 3, 0]),
  (Song6_array[520] = [104.65, 2, 0]),
  (Song6_array[521] = [104.75, 3, 0]),
  (Song6_array[522] = [104.9, 4, 0]),
  (Song6_array[523] = [105.05, 3, 0]),
  (Song6_array[524] = [105.200005, 2, 0]),
  (Song6_array[525] = [105.4, 3, 0]),
  (Song6_array[526] = [105.65, 3, 0.05]),
  (Song6_array[527] = [105.65, 5, 0]),
  (Song6_array[528] = [106, 3, 0]),
  (Song6_array[529] = [106, 5, 0.05]),
  (Song6_array[530] = [106.200005, 2, 0]),
  (Song6_array[531] = [106.25, 2, 0]),
  (Song6_array[532] = [106.3, 2, 0]),
  (Song6_array[533] = [106.65, 1, 0]),
  (Song6_array[534] = [106.65, 3, 0.05]),
  (Song6_array[535] = [106.85, 1, 0]),
  (Song6_array[536] = [106.9, 1, 0]),
  (Song6_array[537] = [106.950005, 1, 0]),
  (Song6_array[538] = [107.200005, 3, 0]),
  (Song6_array[539] = [107.3, 3, 0]),
  (Song6_array[540] = [107.450005, 5, 0]),
  (Song6_array[541] = [107.75, 3, 0.05]),
  (Song6_array[542] = [107.75, 5, 0]),
  (Song6_array[543] = [108, 3, 0.05]),
  (Song6_array[544] = [108, 5, 0]),
  (Song6_array[545] = [108.25, 3, 0]),
  (Song6_array[546] = [108.35, 2, 0]),
  (Song6_array[547] = [108.450005, 3, 0]),
  (Song6_array[548] = [108.6, 4, 0]),
  (Song6_array[549] = [108.75, 3, 0]),
  (Song6_array[550] = [108.9, 2, 0]),
  (Song6_array[551] = [109.1, 4, 0]),
  (Song6_array[552] = [109.25, 3, 0]),
  (Song6_array[553] = [109.3, 3, 0]),
  (Song6_array[554] = [109.35, 3, 0]),
  (Song6_array[555] = [109.4, 3, 0]),
  (Song6_array[556] = [109.6, 3, 0]),
  (Song6_array[557] = [109.6, 5, 0.05]),
  (Song6_array[558] = [109.950005, 1, 0]),
  (Song6_array[559] = [110, 1, 0]),
  (Song6_array[560] = [110.05, 1, 0]),
  (Song6_array[561] = [110.1, 1, 0]),
  (Song6_array[562] = [110.3, 1, 0.05]),
  (Song6_array[563] = [110.3, 3, 0]),
  (Song6_array[564] = [110.950005, 1, 0]),
  (Song6_array[565] = [111.15, 3, 0]),
  (Song6_array[566] = [111.35, 5, 0]),
  (Song6_array[567] = [111.55, 3, 0]),
  (Song6_array[568] = [111.75, 2, 0]),
  (Song6_array[569] = [111.950005, 4, 0]),
  (Song6_array[570] = [112.15, 3, 0]),
  (Song6_array[571] = [112.3, 5, 0]),
  (Song6_array[572] = [112.5, 2, 0]),
  (Song6_array[573] = [112.55, 2, 0]),
  (Song6_array[574] = [112.6, 2, 0]),
  (Song6_array[575] = [112.65, 2, 0]),
  (Song6_array[576] = [112.85, 3, 0]),
  (Song6_array[577] = [112.9, 3, 0]),
  (Song6_array[578] = [112.950005, 3, 0]),
  (Song6_array[579] = [113, 3, 0]),
  (Song6_array[580] = [113.200005, 3, 0]),
  (Song6_array[581] = [113.200005, 5, 0.05]),
  (Song6_array[582] = [113.55, 1, 0]),
  (Song6_array[583] = [113.6, 1, 0]),
  (Song6_array[584] = [113.65, 1, 0]),
  (Song6_array[585] = [113.700005, 1, 0]),
  (Song6_array[586] = [113.9, 1, 0.05]),
  (Song6_array[587] = [113.9, 3, 0]),
  (Song6_array[588] = [114.55, 1, 0]),
  (Song6_array[589] = [114.75, 3, 0]),
  (Song6_array[590] = [114.950005, 5, 0]),
  (Song6_array[591] = [115.15, 3, 0]),
  (Song6_array[592] = [115.35, 2, 0]),
  (Song6_array[593] = [115.55, 4, 0]),
  (Song6_array[594] = [115.75, 3, 0]),
  (Song6_array[595] = [115.9, 5, 0]),
  (Song6_array[596] = [116.1, 2, 0]),
  (Song6_array[597] = [116.15, 2, 0]),
  (Song6_array[598] = [116.200005, 2, 0]),
  (Song6_array[599] = [116.25, 2, 0]);
var Song1_array = [];
(Song1_array[0] = [0.35, 1, 0]),
  (Song1_array[1] = [1.0500001, 1, 0]),
  (Song1_array[2] = [1.75, 1, 0]),
  (Song1_array[3] = [2, 1, 0]),
  (Song1_array[4] = [2.3, 3, 0]),
  (Song1_array[5] = [2.95, 5, 0]),
  (Song1_array[6] = [3.75, 5, 0]),
  (Song1_array[7] = [4, 5, 0]),
  (Song1_array[8] = [4.2000003, 3, 0]),
  (Song1_array[9] = [4.9, 3, 0]),
  (Song1_array[10] = [5.6, 3, 0]),
  (Song1_array[11] = [5.85, 3, 0]),
  (Song1_array[12] = [6.1, 5, 0]),
  (Song1_array[13] = [6.8, 3, 0]),
  (Song1_array[14] = [7.5, 3, 0]),
  (Song1_array[15] = [7.75, 3, 0]),
  (Song1_array[16] = [8, 1, 0]),
  (Song1_array[17] = [8.7, 1, 0]),
  (Song1_array[18] = [9.400001, 1, 0]),
  (Song1_array[19] = [9.650001, 1, 0]),
  (Song1_array[20] = [9.95, 3, 0]),
  (Song1_array[21] = [10.150001, 1, 0.05]),
  (Song1_array[22] = [10.150001, 3, 0]),
  (Song1_array[23] = [10.150001, 5, 0.05]),
  (Song1_array[24] = [10.35, 1, 0.05]),
  (Song1_array[25] = [10.35, 3, 0]),
  (Song1_array[26] = [10.35, 5, 0.05]),
  (Song1_array[27] = [10.6, 3, 0.05]),
  (Song1_array[28] = [10.6, 5, 0]),
  (Song1_array[29] = [10.8, 3, 0.05]),
  (Song1_array[30] = [10.8, 5, 0]),
  (Song1_array[31] = [11, 3, 0.05]),
  (Song1_array[32] = [11, 5, 0]),
  (Song1_array[33] = [11.2, 3, 0.05]),
  (Song1_array[34] = [11.2, 5, 0]),
  (Song1_array[35] = [11.650001, 5, 0]),
  (Song1_array[36] = [11.85, 3, 0]),
  (Song1_array[37] = [12.1, 3, 0]),
  (Song1_array[38] = [12.2, 3, 0]),
  (Song1_array[39] = [12.3, 3, 0]),
  (Song1_array[40] = [12.55, 3, 0]),
  (Song1_array[41] = [13.25, 3, 0]),
  (Song1_array[42] = [13.45, 3, 0]),
  (Song1_array[43] = [13.55, 3, 0]),
  (Song1_array[44] = [13.75, 5, 0]),
  (Song1_array[45] = [14.1, 5, 0]),
  (Song1_array[46] = [14.45, 3, 0]),
  (Song1_array[47] = [15.05, 3, 0]),
  (Song1_array[48] = [15.150001, 3, 0]),
  (Song1_array[49] = [15.25, 3, 0]),
  (Song1_array[50] = [15.400001, 3, 0]),
  (Song1_array[51] = [15.5, 3, 0]),
  (Song1_array[52] = [15.7, 1, 0]),
  (Song1_array[53] = [16.4, 1, 0]),
  (Song1_array[54] = [16.75, 1, 0]),
  (Song1_array[55] = [17.1, 3, 0]),
  (Song1_array[56] = [17.65, 1, 0]),
  (Song1_array[57] = [18.35, 1, 0]),
  (Song1_array[58] = [18.7, 1, 0]),
  (Song1_array[59] = [19, 3, 0]),
  (Song1_array[60] = [19.550001, 1, 0]),
  (Song1_array[61] = [20.25, 1, 0]),
  (Song1_array[62] = [20.6, 1, 0]),
  (Song1_array[63] = [20.95, 3, 0]),
  (Song1_array[64] = [21.45, 1, 0]),
  (Song1_array[65] = [22.2, 1, 0]),
  (Song1_array[66] = [22.550001, 1, 0]),
  (Song1_array[67] = [22.9, 3, 0]),
  (Song1_array[68] = [23.45, 1, 0]),
  (Song1_array[69] = [24.15, 1, 0]),
  (Song1_array[70] = [24.5, 1, 0]),
  (Song1_array[71] = [24.85, 3, 0]),
  (Song1_array[72] = [25.4, 1, 0]),
  (Song1_array[73] = [25.4, 3, 0.05]),
  (Song1_array[74] = [25.6, 1, 0]),
  (Song1_array[75] = [25.6, 3, 0.05]),
  (Song1_array[76] = [26.050001, 1, 0]),
  (Song1_array[77] = [26.050001, 3, 0.05]),
  (Song1_array[78] = [26.25, 1, 0]),
  (Song1_array[79] = [26.25, 3, 0.05]),
  (Song1_array[80] = [26.45, 1, 0]),
  (Song1_array[81] = [26.45, 3, 0.05]),
  (Song1_array[82] = [26.65, 1, 0]),
  (Song1_array[83] = [26.65, 3, 0.05]),
  (Song1_array[84] = [27.050001, 4, 0]),
  (Song1_array[85] = [27.35, 2, 0]),
  (Song1_array[86] = [27.45, 2, 0]),
  (Song1_array[87] = [27.550001, 2, 0]),
  (Song1_array[88] = [27.65, 2, 0]),
  (Song1_array[89] = [27.800001, 2, 0]),
  (Song1_array[90] = [28.4, 2, 0]),
  (Song1_array[91] = [28.7, 4, 0]),
  (Song1_array[92] = [28.85, 4, 0]),
  (Song1_array[93] = [28.95, 4, 0]),
  (Song1_array[94] = [29.2, 3, 0]),
  (Song1_array[95] = [29.4, 4, 0]),
  (Song1_array[96] = [29.5, 4, 0]),
  (Song1_array[97] = [29.9, 4, 0]),
  (Song1_array[98] = [30, 4, 0]),
  (Song1_array[99] = [30.300001, 2, 0]),
  (Song1_array[100] = [30.4, 2, 0]),
  (Song1_array[101] = [30.5, 2, 0]),
  (Song1_array[102] = [30.6, 2, 0]),
  (Song1_array[103] = [30.800001, 2, 0]),
  (Song1_array[104] = [30.9, 2, 0]),
  (Song1_array[105] = [31.15, 5, 0]),
  (Song1_array[106] = [31.35, 3, 0]),
  (Song1_array[107] = [31.6, 5, 0]),
  (Song1_array[108] = [31.9, 3, 0]),
  (Song1_array[109] = [33.100002, 1, 0]),
  (Song1_array[110] = [33.45, 3, 0]),
  (Song1_array[111] = [33.8, 5, 0]),
  (Song1_array[112] = [34.95, 2, 0]),
  (Song1_array[113] = [35.25, 4, 0]),
  (Song1_array[114] = [35.55, 2, 0]),
  (Song1_array[115] = [36.15, 3, 0]),
  (Song1_array[116] = [36.600002, 1, 0]),
  (Song1_array[117] = [36.850002, 4, 0]),
  (Song1_array[118] = [37.75, 2, 0]),
  (Song1_array[119] = [38.75, 2, 0]),
  (Song1_array[120] = [39, 4, 0]),
  (Song1_array[121] = [39.3, 2, 0]),
  (Song1_array[122] = [39.600002, 4, 0]),
  (Song1_array[123] = [40.8, 2, 0]),
  (Song1_array[124] = [40.8, 4, 0.05]),
  (Song1_array[125] = [40.9, 2, 0]),
  (Song1_array[126] = [40.9, 4, 0.05]),
  (Song1_array[127] = [41, 2, 0]),
  (Song1_array[128] = [41, 4, 0.05]),
  (Song1_array[129] = [41.15, 3, 0]),
  (Song1_array[130] = [41.4, 2, 0.05]),
  (Song1_array[131] = [41.4, 4, 0]),
  (Song1_array[132] = [41.5, 2, 0.05]),
  (Song1_array[133] = [41.5, 4, 0]),
  (Song1_array[134] = [41.600002, 2, 0.05]),
  (Song1_array[135] = [41.600002, 4, 0]),
  (Song1_array[136] = [41.9, 1, 0.05]),
  (Song1_array[137] = [41.9, 3, 0]),
  (Song1_array[138] = [42, 1, 0.05]),
  (Song1_array[139] = [42, 3, 0]),
  (Song1_array[140] = [42.100002, 1, 0.05]),
  (Song1_array[141] = [42.100002, 3, 0]),
  (Song1_array[142] = [42.65, 1, 0]),
  (Song1_array[143] = [42.8, 3, 0]),
  (Song1_array[144] = [42.850002, 3, 0]),
  (Song1_array[145] = [42.9, 3, 0]),
  (Song1_array[146] = [42.95, 3, 0]),
  (Song1_array[147] = [43, 3, 0]),
  (Song1_array[148] = [43.25, 1, 0]),
  (Song1_array[149] = [43.850002, 3, 0]),
  (Song1_array[150] = [44.15, 1, 0]),
  (Song1_array[151] = [44.2, 1, 0]),
  (Song1_array[152] = [44.25, 1, 0]),
  (Song1_array[153] = [44.55, 3, 0]),
  (Song1_array[154] = [44.8, 3, 0.05]),
  (Song1_array[155] = [44.8, 5, 0]),
  (Song1_array[156] = [44.9, 3, 0.05]),
  (Song1_array[157] = [44.9, 5, 0]),
  (Song1_array[158] = [45, 3, 0.05]),
  (Song1_array[159] = [45, 5, 0]),
  (Song1_array[160] = [45.25, 1, 0.05]),
  (Song1_array[161] = [45.25, 3, 0]),
  (Song1_array[162] = [45.25, 5, 0.05]),
  (Song1_array[163] = [45.350002, 1, 0.05]),
  (Song1_array[164] = [45.350002, 3, 0]),
  (Song1_array[165] = [45.350002, 5, 0.05]),
  (Song1_array[166] = [45.45, 1, 0.05]),
  (Song1_array[167] = [45.45, 3, 0]),
  (Song1_array[168] = [45.45, 5, 0.05]),
  (Song1_array[169] = [46.45, 2, 0]),
  (Song1_array[170] = [46.65, 5, 0]),
  (Song1_array[171] = [46.9, 2, 0]),
  (Song1_array[172] = [47.2, 5, 0]),
  (Song1_array[173] = [48.4, 1, 0]),
  (Song1_array[174] = [48.75, 3, 0]),
  (Song1_array[175] = [49.100002, 5, 0]),
  (Song1_array[176] = [50.25, 1, 0]),
  (Song1_array[177] = [50.55, 3, 0]),
  (Song1_array[178] = [50.850002, 1, 0]),
  (Song1_array[179] = [51.45, 3, 0]),
  (Song1_array[180] = [51.9, 1, 0]),
  (Song1_array[181] = [52.15, 4, 0]),
  (Song1_array[182] = [53.05, 2, 0]),
  (Song1_array[183] = [54.15, 1, 0]),
  (Song1_array[184] = [54.350002, 3, 0]),
  (Song1_array[185] = [54.600002, 1, 0]),
  (Song1_array[186] = [54.9, 3, 0]),
  (Song1_array[187] = [56.100002, 2, 0]),
  (Song1_array[188] = [56.100002, 4, 0.05]),
  (Song1_array[189] = [56.2, 2, 0]),
  (Song1_array[190] = [56.2, 4, 0.05]),
  (Song1_array[191] = [56.3, 2, 0]),
  (Song1_array[192] = [56.3, 4, 0.05]),
  (Song1_array[193] = [56.45, 3, 0]),
  (Song1_array[194] = [56.7, 2, 0.05]),
  (Song1_array[195] = [56.7, 4, 0]),
  (Song1_array[196] = [56.8, 2, 0.05]),
  (Song1_array[197] = [56.8, 4, 0]),
  (Song1_array[198] = [56.9, 2, 0.05]),
  (Song1_array[199] = [56.9, 4, 0]),
  (Song1_array[200] = [57.2, 1, 0.05]),
  (Song1_array[201] = [57.2, 3, 0]),
  (Song1_array[202] = [57.3, 1, 0.05]),
  (Song1_array[203] = [57.3, 3, 0]),
  (Song1_array[204] = [57.4, 1, 0.05]),
  (Song1_array[205] = [57.4, 3, 0]),
  (Song1_array[206] = [57.95, 1, 0]),
  (Song1_array[207] = [58.100002, 3, 0]),
  (Song1_array[208] = [58.15, 3, 0]),
  (Song1_array[209] = [58.2, 3, 0]),
  (Song1_array[210] = [58.25, 3, 0]),
  (Song1_array[211] = [58.3, 3, 0]),
  (Song1_array[212] = [58.55, 1, 0]),
  (Song1_array[213] = [59.15, 3, 0]),
  (Song1_array[214] = [59.45, 1, 0]),
  (Song1_array[215] = [59.5, 1, 0]),
  (Song1_array[216] = [59.55, 1, 0]),
  (Song1_array[217] = [59.850002, 4, 0]),
  (Song1_array[218] = [60.100002, 3, 0.05]),
  (Song1_array[219] = [60.100002, 5, 0]),
  (Song1_array[220] = [60.2, 3, 0.05]),
  (Song1_array[221] = [60.2, 5, 0]),
  (Song1_array[222] = [60.3, 3, 0.05]),
  (Song1_array[223] = [60.3, 5, 0]),
  (Song1_array[224] = [60.55, 1, 0.05]),
  (Song1_array[225] = [60.55, 3, 0]),
  (Song1_array[226] = [60.55, 5, 0.05]),
  (Song1_array[227] = [60.65, 1, 0.05]),
  (Song1_array[228] = [60.65, 3, 0]),
  (Song1_array[229] = [60.65, 5, 0.05]),
  (Song1_array[230] = [60.75, 1, 0.05]),
  (Song1_array[231] = [60.75, 3, 0]),
  (Song1_array[232] = [60.75, 5, 0.05]),
  (Song1_array[233] = [61.100002, 2, 0]),
  (Song1_array[234] = [61.15, 2, 0]),
  (Song1_array[235] = [61.2, 2, 0]),
  (Song1_array[236] = [61.25, 2, 0]),
  (Song1_array[237] = [61.3, 2, 0]),
  (Song1_array[238] = [61.45, 2, 0]),
  (Song1_array[239] = [61.5, 2, 0]),
  (Song1_array[240] = [61.55, 2, 0]),
  (Song1_array[241] = [61.9, 4, 0]),
  (Song1_array[242] = [62.3, 2, 0]),
  (Song1_array[243] = [62.55, 4, 0]),
  (Song1_array[244] = [62.95, 2, 0]),
  (Song1_array[245] = [63.45, 4, 0]),
  (Song1_array[246] = [63.8, 2, 0]),
  (Song1_array[247] = [64.35, 4, 0]),
  (Song1_array[248] = [64.75, 4, 0]),
  (Song1_array[249] = [65.200005, 2, 0]),
  (Song1_array[250] = [65.65, 4, 0]),
  (Song1_array[251] = [66.05, 2, 0]),
  (Song1_array[252] = [66.3, 4, 0]),
  (Song1_array[253] = [66.700005, 2, 0]),
  (Song1_array[254] = [67.200005, 4, 0]),
  (Song1_array[255] = [67.55, 2, 0]),
  (Song1_array[256] = [68.1, 4, 0]),
  (Song1_array[257] = [68.5, 5, 0]),
  (Song1_array[258] = [68.950005, 3, 0]),
  (Song1_array[259] = [69.5, 4, 0]),
  (Song1_array[260] = [69.9, 2, 0]),
  (Song1_array[261] = [70.15, 4, 0]),
  (Song1_array[262] = [71.05, 2, 0]),
  (Song1_array[263] = [71.4, 3, 0]),
  (Song1_array[264] = [71.6, 3, 0.05]),
  (Song1_array[265] = [71.6, 5, 0]),
  (Song1_array[266] = [71.700005, 3, 0.05]),
  (Song1_array[267] = [71.700005, 5, 0]),
  (Song1_array[268] = [71.8, 3, 0.05]),
  (Song1_array[269] = [71.8, 5, 0]),
  (Song1_array[270] = [71.950005, 4, 0]),
  (Song1_array[271] = [72.25, 3, 0.05]),
  (Song1_array[272] = [72.25, 5, 0]),
  (Song1_array[273] = [72.35, 3, 0.05]),
  (Song1_array[274] = [72.35, 5, 0]),
  (Song1_array[275] = [72.450005, 3, 0.05]),
  (Song1_array[276] = [72.450005, 5, 0]),
  (Song1_array[277] = [72.700005, 1, 0.05]),
  (Song1_array[278] = [72.700005, 3, 0]),
  (Song1_array[279] = [72.700005, 5, 0.05]),
  (Song1_array[280] = [72.8, 1, 0.05]),
  (Song1_array[281] = [72.8, 3, 0]),
  (Song1_array[282] = [72.8, 5, 0.05]),
  (Song1_array[283] = [72.9, 1, 0.05]),
  (Song1_array[284] = [72.9, 3, 0]),
  (Song1_array[285] = [72.9, 5, 0.05]),
  (Song1_array[286] = [73.3, 4, 0]),
  (Song1_array[287] = [73.5, 2, 0]),
  (Song1_array[288] = [73.55, 2, 0]),
  (Song1_array[289] = [73.6, 2, 0]),
  (Song1_array[290] = [73.65, 2, 0]),
  (Song1_array[291] = [73.700005, 2, 0]),
  (Song1_array[292] = [73.950005, 4, 0]),
  (Song1_array[293] = [74.35, 2, 0]),
  (Song1_array[294] = [74.85, 4, 0]),
  (Song1_array[295] = [74.9, 4, 0]),
  (Song1_array[296] = [74.950005, 4, 0]),
  (Song1_array[297] = [75.200005, 2, 0]),
  (Song1_array[298] = [75.5, 1, 0.05]),
  (Song1_array[299] = [75.5, 3, 0]),
  (Song1_array[300] = [75.5, 5, 0.05]),
  (Song1_array[301] = [75.6, 1, 0.05]),
  (Song1_array[302] = [75.6, 3, 0]),
  (Song1_array[303] = [75.6, 5, 0.05]),
  (Song1_array[304] = [75.700005, 1, 0.05]),
  (Song1_array[305] = [75.700005, 3, 0]),
  (Song1_array[306] = [75.700005, 5, 0.05]),
  (Song1_array[307] = [75.950005, 1, 0.05]),
  (Song1_array[308] = [75.950005, 3, 0]),
  (Song1_array[309] = [75.950005, 5, 0.05]),
  (Song1_array[310] = [76.05, 1, 0.05]),
  (Song1_array[311] = [76.05, 3, 0]),
  (Song1_array[312] = [76.05, 5, 0.05]),
  (Song1_array[313] = [76.15, 1, 0.05]),
  (Song1_array[314] = [76.15, 3, 0]),
  (Song1_array[315] = [76.15, 5, 0.05]),
  (Song1_array[316] = [76.450005, 5, 0]),
  (Song1_array[317] = [76.5, 5, 0]),
  (Song1_array[318] = [76.55, 5, 0]),
  (Song1_array[319] = [76.6, 5, 0]),
  (Song1_array[320] = [76.65, 5, 0]),
  (Song1_array[321] = [76.8, 5, 0]),
  (Song1_array[322] = [76.85, 5, 0]),
  (Song1_array[323] = [76.9, 5, 0]),
  (Song1_array[324] = [77.15, 1, 0]),
  (Song1_array[325] = [77.35, 3, 0]),
  (Song1_array[326] = [77.6, 1, 0]),
  (Song1_array[327] = [77.9, 3, 0]),
  (Song1_array[328] = [79.1, 1, 0]),
  (Song1_array[329] = [79.450005, 3, 0]),
  (Song1_array[330] = [79.8, 5, 0]),
  (Song1_array[331] = [80.950005, 1, 0]),
  (Song1_array[332] = [81.25, 3, 0]),
  (Song1_array[333] = [81.55, 1, 0]),
  (Song1_array[334] = [82.15, 3, 0]),
  (Song1_array[335] = [82.6, 1, 0]),
  (Song1_array[336] = [82.85, 4, 0]),
  (Song1_array[337] = [83.75, 2, 0]),
  (Song1_array[338] = [84.85, 1, 0]),
  (Song1_array[339] = [85.05, 3, 0]),
  (Song1_array[340] = [85.3, 1, 0]),
  (Song1_array[341] = [85.6, 3, 0]),
  (Song1_array[342] = [86.8, 2, 0]),
  (Song1_array[343] = [86.8, 4, 0.05]),
  (Song1_array[344] = [86.9, 2, 0]),
  (Song1_array[345] = [86.9, 4, 0.05]),
  (Song1_array[346] = [87, 2, 0]),
  (Song1_array[347] = [87, 4, 0.05]),
  (Song1_array[348] = [87.15, 3, 0]),
  (Song1_array[349] = [87.4, 2, 0.05]),
  (Song1_array[350] = [87.4, 4, 0]),
  (Song1_array[351] = [87.5, 2, 0.05]),
  (Song1_array[352] = [87.5, 4, 0]),
  (Song1_array[353] = [87.6, 2, 0.05]),
  (Song1_array[354] = [87.6, 4, 0]),
  (Song1_array[355] = [87.9, 1, 0.05]),
  (Song1_array[356] = [87.9, 3, 0]),
  (Song1_array[357] = [88, 1, 0.05]),
  (Song1_array[358] = [88, 3, 0]),
  (Song1_array[359] = [88.1, 1, 0.05]),
  (Song1_array[360] = [88.1, 3, 0]),
  (Song1_array[361] = [88.65, 1, 0]),
  (Song1_array[362] = [88.8, 3, 0]),
  (Song1_array[363] = [88.85, 3, 0]),
  (Song1_array[364] = [88.9, 3, 0]),
  (Song1_array[365] = [88.950005, 3, 0]),
  (Song1_array[366] = [89, 3, 0]),
  (Song1_array[367] = [89.25, 1, 0]),
  (Song1_array[368] = [89.85, 3, 0]),
  (Song1_array[369] = [90.15, 1, 0]),
  (Song1_array[370] = [90.200005, 1, 0]),
  (Song1_array[371] = [90.25, 1, 0]),
  (Song1_array[372] = [90.55, 4, 0]),
  (Song1_array[373] = [90.8, 3, 0.05]),
  (Song1_array[374] = [90.8, 5, 0]),
  (Song1_array[375] = [90.9, 3, 0.05]),
  (Song1_array[376] = [90.9, 5, 0]),
  (Song1_array[377] = [91, 3, 0.05]),
  (Song1_array[378] = [91, 5, 0]),
  (Song1_array[379] = [91.25, 1, 0.05]),
  (Song1_array[380] = [91.25, 3, 0]),
  (Song1_array[381] = [91.25, 5, 0.05]),
  (Song1_array[382] = [91.35, 1, 0.05]),
  (Song1_array[383] = [91.35, 3, 0]),
  (Song1_array[384] = [91.35, 5, 0.05]),
  (Song1_array[385] = [91.450005, 1, 0.05]),
  (Song1_array[386] = [91.450005, 3, 0]),
  (Song1_array[387] = [91.450005, 5, 0.05]),
  (Song1_array[388] = [92.6, 4, 0]),
  (Song1_array[389] = [93, 2, 0]),
  (Song1_array[390] = [93.25, 4, 0]),
  (Song1_array[391] = [93.65, 2, 0]),
  (Song1_array[392] = [94.15, 4, 0]),
  (Song1_array[393] = [94.5, 2, 0]),
  (Song1_array[394] = [95.05, 4, 0]),
  (Song1_array[395] = [95.450005, 4, 0]),
  (Song1_array[396] = [95.9, 2, 0]),
  (Song1_array[397] = [96.35, 4, 0]),
  (Song1_array[398] = [96.75, 2, 0]),
  (Song1_array[399] = [97, 4, 0]),
  (Song1_array[400] = [97.4, 2, 0]),
  (Song1_array[401] = [97.9, 4, 0]),
  (Song1_array[402] = [98.25, 2, 0]),
  (Song1_array[403] = [98.8, 4, 0]),
  (Song1_array[404] = [99.200005, 5, 0]),
  (Song1_array[405] = [99.65, 2, 0]),
  (Song1_array[406] = [100.200005, 4, 0]),
  (Song1_array[407] = [100.6, 2, 0]),
  (Song1_array[408] = [100.85, 4, 0]),
  (Song1_array[409] = [101.75, 1, 0]),
  (Song1_array[410] = [102.1, 3, 0]),
  (Song1_array[411] = [102.3, 3, 0.05]),
  (Song1_array[412] = [102.3, 5, 0]),
  (Song1_array[413] = [102.4, 3, 0.05]),
  (Song1_array[414] = [102.4, 5, 0]),
  (Song1_array[415] = [102.5, 3, 0.05]),
  (Song1_array[416] = [102.5, 5, 0]),
  (Song1_array[417] = [102.65, 4, 0]),
  (Song1_array[418] = [102.950005, 3, 0.05]),
  (Song1_array[419] = [102.950005, 5, 0]),
  (Song1_array[420] = [103.05, 3, 0.05]),
  (Song1_array[421] = [103.05, 5, 0]),
  (Song1_array[422] = [103.15, 3, 0.05]),
  (Song1_array[423] = [103.15, 5, 0]),
  (Song1_array[424] = [103.4, 1, 0.05]),
  (Song1_array[425] = [103.4, 3, 0]),
  (Song1_array[426] = [103.4, 5, 0.05]),
  (Song1_array[427] = [103.5, 1, 0.05]),
  (Song1_array[428] = [103.5, 3, 0]),
  (Song1_array[429] = [103.5, 5, 0.05]),
  (Song1_array[430] = [103.6, 1, 0.05]),
  (Song1_array[431] = [103.6, 3, 0]),
  (Song1_array[432] = [103.6, 5, 0.05]),
  (Song1_array[433] = [104, 4, 0]),
  (Song1_array[434] = [104.15, 2, 0]),
  (Song1_array[435] = [104.200005, 2, 0]),
  (Song1_array[436] = [104.25, 2, 0]),
  (Song1_array[437] = [104.3, 2, 0]),
  (Song1_array[438] = [104.35, 2, 0]),
  (Song1_array[439] = [104.65, 4, 0]),
  (Song1_array[440] = [105.05, 2, 0]),
  (Song1_array[441] = [105.55, 4, 0]),
  (Song1_array[442] = [105.6, 4, 0]),
  (Song1_array[443] = [105.65, 4, 0]),
  (Song1_array[444] = [105.9, 2, 0]),
  (Song1_array[445] = [106.200005, 1, 0.05]),
  (Song1_array[446] = [106.200005, 3, 0]),
  (Song1_array[447] = [106.200005, 5, 0.05]),
  (Song1_array[448] = [106.3, 1, 0.05]),
  (Song1_array[449] = [106.3, 3, 0]),
  (Song1_array[450] = [106.3, 5, 0.05]),
  (Song1_array[451] = [106.4, 1, 0.05]),
  (Song1_array[452] = [106.4, 3, 0]),
  (Song1_array[453] = [106.4, 5, 0.05]),
  (Song1_array[454] = [106.65, 1, 0.05]),
  (Song1_array[455] = [106.65, 3, 0]),
  (Song1_array[456] = [106.65, 5, 0.05]),
  (Song1_array[457] = [106.75, 1, 0.05]),
  (Song1_array[458] = [106.75, 3, 0]),
  (Song1_array[459] = [106.75, 5, 0.05]),
  (Song1_array[460] = [106.85, 1, 0.05]),
  (Song1_array[461] = [106.85, 3, 0]),
  (Song1_array[462] = [106.85, 5, 0.05]),
  (Song1_array[463] = [107.15, 5, 0]),
  (Song1_array[464] = [107.200005, 5, 0]),
  (Song1_array[465] = [107.25, 5, 0]),
  (Song1_array[466] = [107.3, 5, 0]),
  (Song1_array[467] = [107.35, 5, 0]),
  (Song1_array[468] = [107.5, 5, 0]),
  (Song1_array[469] = [107.55, 5, 0]),
  (Song1_array[470] = [107.6, 5, 0]),
  (Song1_array[471] = [107.950005, 4, 0]),
  (Song1_array[472] = [108.35, 2, 0]),
  (Song1_array[473] = [108.6, 4, 0]),
  (Song1_array[474] = [109, 2, 0]),
  (Song1_array[475] = [109.5, 4, 0]),
  (Song1_array[476] = [109.85, 2, 0]),
  (Song1_array[477] = [110.4, 4, 0]),
  (Song1_array[478] = [110.8, 4, 0]),
  (Song1_array[479] = [111.25, 2, 0]),
  (Song1_array[480] = [111.700005, 4, 0]),
  (Song1_array[481] = [112.1, 2, 0]),
  (Song1_array[482] = [112.35, 4, 0]),
  (Song1_array[483] = [112.75, 2, 0]),
  (Song1_array[484] = [113.25, 4, 0]),
  (Song1_array[485] = [113.6, 2, 0]),
  (Song1_array[486] = [114.15, 4, 0]),
  (Song1_array[487] = [114.55, 5, 0]),
  (Song1_array[488] = [115, 2, 0]),
  (Song1_array[489] = [115.55, 4, 0]),
  (Song1_array[490] = [115.950005, 2, 0]),
  (Song1_array[491] = [116.200005, 4, 0]),
  (Song1_array[492] = [117.1, 2, 0]),
  (Song1_array[493] = [117.450005, 3, 0]),
  (Song1_array[494] = [117.65, 3, 0.05]),
  (Song1_array[495] = [117.65, 5, 0]),
  (Song1_array[496] = [117.75, 3, 0.05]),
  (Song1_array[497] = [117.75, 5, 0]),
  (Song1_array[498] = [117.85, 3, 0.05]),
  (Song1_array[499] = [117.85, 5, 0]),
  (Song1_array[500] = [118, 4, 0]),
  (Song1_array[501] = [118.3, 3, 0.05]),
  (Song1_array[502] = [118.3, 5, 0]),
  (Song1_array[503] = [118.4, 3, 0.05]),
  (Song1_array[504] = [118.4, 5, 0]),
  (Song1_array[505] = [118.5, 3, 0.05]),
  (Song1_array[506] = [118.5, 5, 0]),
  (Song1_array[507] = [118.75, 1, 0.05]),
  (Song1_array[508] = [118.75, 3, 0]),
  (Song1_array[509] = [118.75, 5, 0.05]),
  (Song1_array[510] = [118.85, 1, 0.05]),
  (Song1_array[511] = [118.85, 3, 0]),
  (Song1_array[512] = [118.85, 5, 0.05]),
  (Song1_array[513] = [118.950005, 1, 0.05]),
  (Song1_array[514] = [118.950005, 3, 0]),
  (Song1_array[515] = [118.950005, 5, 0.05]),
  (Song1_array[516] = [119.35, 4, 0]),
  (Song1_array[517] = [119.55, 2, 0]),
  (Song1_array[518] = [119.6, 2, 0]),
  (Song1_array[519] = [119.65, 2, 0]),
  (Song1_array[520] = [119.700005, 2, 0]),
  (Song1_array[521] = [119.75, 2, 0]),
  (Song1_array[522] = [120, 4, 0]),
  (Song1_array[523] = [120.4, 2, 0]),
  (Song1_array[524] = [120.9, 4, 0]),
  (Song1_array[525] = [120.950005, 4, 0]),
  (Song1_array[526] = [121, 4, 0]),
  (Song1_array[527] = [121.25, 2, 0]),
  (Song1_array[528] = [121.55, 1, 0.05]),
  (Song1_array[529] = [121.55, 3, 0]),
  (Song1_array[530] = [121.55, 5, 0.05]),
  (Song1_array[531] = [121.65, 1, 0.05]),
  (Song1_array[532] = [121.65, 3, 0]),
  (Song1_array[533] = [121.65, 5, 0.05]),
  (Song1_array[534] = [121.75, 1, 0.05]),
  (Song1_array[535] = [121.75, 3, 0]),
  (Song1_array[536] = [121.75, 5, 0.05]),
  (Song1_array[537] = [122, 1, 0.05]),
  (Song1_array[538] = [122, 3, 0]),
  (Song1_array[539] = [122, 5, 0.05]),
  (Song1_array[540] = [122.1, 1, 0.05]),
  (Song1_array[541] = [122.1, 3, 0]),
  (Song1_array[542] = [122.1, 5, 0.05]),
  (Song1_array[543] = [122.200005, 1, 0.05]),
  (Song1_array[544] = [122.200005, 3, 0]),
  (Song1_array[545] = [122.200005, 5, 0.05]),
  (Song1_array[546] = [122.5, 5, 0]),
  (Song1_array[547] = [122.55, 5, 0]),
  (Song1_array[548] = [122.6, 5, 0]),
  (Song1_array[549] = [122.65, 5, 0]),
  (Song1_array[550] = [122.700005, 5, 0]),
  (Song1_array[551] = [122.85, 5, 0]),
  (Song1_array[552] = [122.9, 5, 0]),
  (Song1_array[553] = [122.950005, 5, 0]),
  (Song1_array[554] = [123.3, 4, 0]),
  (Song1_array[555] = [123.700005, 2, 0]),
  (Song1_array[556] = [123.950005, 4, 0]),
  (Song1_array[557] = [124.35, 2, 0]),
  (Song1_array[558] = [124.85, 4, 0]),
  (Song1_array[559] = [125.200005, 2, 0]),
  (Song1_array[560] = [125.75, 4, 0]),
  (Song1_array[561] = [126.15, 4, 0]),
  (Song1_array[562] = [126.6, 2, 0]),
  (Song1_array[563] = [127.05, 4, 0]),
  (Song1_array[564] = [127.450005, 2, 0]),
  (Song1_array[565] = [127.700005, 4, 0]),
  (Song1_array[566] = [128.1, 2, 0]),
  (Song1_array[567] = [128.6, 4, 0]),
  (Song1_array[568] = [128.95, 2, 0]),
  (Song1_array[569] = [129.5, 4, 0]),
  (Song1_array[570] = [129.90001, 5, 0]),
  (Song1_array[571] = [130.35, 2, 0]),
  (Song1_array[572] = [130.90001, 4, 0]),
  (Song1_array[573] = [131.3, 2, 0]),
  (Song1_array[574] = [131.55, 4, 0]),
  (Song1_array[575] = [132.45, 2, 0]),
  (Song1_array[576] = [132.8, 3, 0]),
  (Song1_array[577] = [133, 3, 0.05]),
  (Song1_array[578] = [133, 5, 0]),
  (Song1_array[579] = [133.1, 3, 0.05]),
  (Song1_array[580] = [133.1, 5, 0]),
  (Song1_array[581] = [133.2, 3, 0.05]),
  (Song1_array[582] = [133.2, 5, 0]),
  (Song1_array[583] = [133.35, 4, 0]),
  (Song1_array[584] = [133.65001, 3, 0.05]),
  (Song1_array[585] = [133.65001, 5, 0]),
  (Song1_array[586] = [133.75, 3, 0.05]),
  (Song1_array[587] = [133.75, 5, 0]),
  (Song1_array[588] = [133.85, 3, 0.05]),
  (Song1_array[589] = [133.85, 5, 0]),
  (Song1_array[590] = [134.1, 1, 0.05]),
  (Song1_array[591] = [134.1, 3, 0]),
  (Song1_array[592] = [134.1, 5, 0.05]),
  (Song1_array[593] = [134.2, 1, 0.05]),
  (Song1_array[594] = [134.2, 3, 0]),
  (Song1_array[595] = [134.2, 5, 0.05]),
  (Song1_array[596] = [134.3, 1, 0.05]),
  (Song1_array[597] = [134.3, 3, 0]),
  (Song1_array[598] = [134.3, 5, 0.05]),
  (Song1_array[599] = [134.7, 4, 0]),
  (Song1_array[600] = [134.90001, 2, 0]),
  (Song1_array[601] = [134.95, 2, 0]),
  (Song1_array[602] = [135, 2, 0]),
  (Song1_array[603] = [135.05, 2, 0]),
  (Song1_array[604] = [135.1, 2, 0]),
  (Song1_array[605] = [135.35, 4, 0]),
  (Song1_array[606] = [135.75, 2, 0]),
  (Song1_array[607] = [136.25, 4, 0]),
  (Song1_array[608] = [136.3, 4, 0]),
  (Song1_array[609] = [136.35, 4, 0]),
  (Song1_array[610] = [136.6, 2, 0]),
  (Song1_array[611] = [136.90001, 1, 0.05]),
  (Song1_array[612] = [136.90001, 3, 0]),
  (Song1_array[613] = [136.90001, 5, 0.05]),
  (Song1_array[614] = [137, 1, 0.05]),
  (Song1_array[615] = [137, 3, 0]),
  (Song1_array[616] = [137, 5, 0.05]),
  (Song1_array[617] = [137.1, 1, 0.05]),
  (Song1_array[618] = [137.1, 3, 0]),
  (Song1_array[619] = [137.1, 5, 0.05]),
  (Song1_array[620] = [137.35, 1, 0.05]),
  (Song1_array[621] = [137.35, 3, 0]),
  (Song1_array[622] = [137.35, 5, 0.05]),
  (Song1_array[623] = [137.45, 1, 0.05]),
  (Song1_array[624] = [137.45, 3, 0]),
  (Song1_array[625] = [137.45, 5, 0.05]),
  (Song1_array[626] = [137.55, 1, 0.05]),
  (Song1_array[627] = [137.55, 3, 0]),
  (Song1_array[628] = [137.55, 5, 0.05]),
  (Song1_array[629] = [137.85, 5, 0]),
  (Song1_array[630] = [137.90001, 5, 0]),
  (Song1_array[631] = [137.95, 5, 0]),
  (Song1_array[632] = [138, 5, 0]),
  (Song1_array[633] = [138.05, 5, 0]),
  (Song1_array[634] = [138.2, 5, 0]),
  (Song1_array[635] = [138.25, 5, 0]),
  (Song1_array[636] = [138.3, 5, 0]),
  (Song1_array[637] = [138.6, 3, 0]);
var Song7_array = [];
(Song7_array[0] = [0.4, 3, 0]),
  (Song7_array[1] = [0.90000004, 2, 0]),
  (Song7_array[2] = [1.7, 3, 0]),
  (Song7_array[3] = [1.9, 1, 0]),
  (Song7_array[4] = [2.05, 3, 0]),
  (Song7_array[5] = [2.2, 1, 0]),
  (Song7_array[6] = [2.55, 4, 0]),
  (Song7_array[7] = [2.7, 4, 0]),
  (Song7_array[8] = [2.8500001, 4, 0]),
  (Song7_array[9] = [3, 2, 0]),
  (Song7_array[10] = [3.1000001, 2, 0]),
  (Song7_array[11] = [3.2, 2, 0]),
  (Song7_array[12] = [3.3500001, 3, 0]),
  (Song7_array[13] = [3.55, 3, 0]),
  (Song7_array[14] = [4.05, 5, 0]),
  (Song7_array[15] = [4.25, 3, 0]),
  (Song7_array[16] = [4.55, 5, 0]),
  (Song7_array[17] = [5, 4, 0]),
  (Song7_array[18] = [5.1, 4, 0]),
  (Song7_array[19] = [5.2000003, 4, 0]),
  (Song7_array[20] = [5.3, 4, 0]),
  (Song7_array[21] = [5.6, 5, 0]),
  (Song7_array[22] = [5.7000003, 5, 0]),
  (Song7_array[23] = [5.8, 5, 0]),
  (Song7_array[24] = [6.05, 3, 0]),
  (Song7_array[25] = [6.35, 1, 0]),
  (Song7_array[26] = [6.65, 3, 0]),
  (Song7_array[27] = [6.9500003, 1, 0]),
  (Song7_array[28] = [7.35, 3, 0]),
  (Song7_array[29] = [7.6, 3, 0]),
  (Song7_array[30] = [7.85, 1, 0]),
  (Song7_array[31] = [7.9500003, 1, 0]),
  (Song7_array[32] = [8.05, 1, 0]),
  (Song7_array[33] = [8.6, 4, 0]),
  (Song7_array[34] = [9, 4, 0]),
  (Song7_array[35] = [9.6, 3, 0]),
  (Song7_array[36] = [9.95, 3, 0]),
  (Song7_array[37] = [10.150001, 1, 0]),
  (Song7_array[38] = [10.35, 3, 0]),
  (Song7_array[39] = [10.45, 3, 0]),
  (Song7_array[40] = [10.55, 3, 0]),
  (Song7_array[41] = [10.75, 5, 0]),
  (Song7_array[42] = [10.95, 3, 0]),
  (Song7_array[43] = [11.150001, 5, 0]),
  (Song7_array[44] = [11.35, 3, 0]),
  (Song7_array[45] = [11.7, 5, 0]),
  (Song7_array[46] = [11.95, 3, 0]),
  (Song7_array[47] = [12.25, 5, 0]),
  (Song7_array[48] = [12.55, 3, 0]),
  (Song7_array[49] = [12.8, 5, 0]),
  (Song7_array[50] = [13.150001, 2, 0]),
  (Song7_array[51] = [13.35, 5, 0]),
  (Song7_array[52] = [13.6, 2, 0]),
  (Song7_array[53] = [13.95, 4, 0]),
  (Song7_array[54] = [14.3, 2, 0]),
  (Song7_array[55] = [14.5, 4, 0]),
  (Song7_array[56] = [14.900001, 2, 0]),
  (Song7_array[57] = [15.2, 5, 0]),
  (Song7_array[58] = [15.400001, 3, 0]),
  (Song7_array[59] = [15.5, 3, 0]),
  (Song7_array[60] = [15.6, 3, 0]),
  (Song7_array[61] = [15.900001, 5, 0]),
  (Song7_array[62] = [16.25, 2, 0]),
  (Song7_array[63] = [16.7, 3, 0]),
  (Song7_array[64] = [16.85, 5, 0]),
  (Song7_array[65] = [17.15, 3, 0]),
  (Song7_array[66] = [17.5, 5, 0]),
  (Song7_array[67] = [17.800001, 3, 0]),
  (Song7_array[68] = [18.2, 2, 0]),
  (Song7_array[69] = [18.6, 1, 0]),
  (Song7_array[70] = [18.9, 5, 0]),
  (Song7_array[71] = [19.15, 2, 0]),
  (Song7_array[72] = [19.4, 5, 0]),
  (Song7_array[73] = [19.65, 3, 0]),
  (Song7_array[74] = [19.85, 5, 0]),
  (Song7_array[75] = [20.1, 3, 0]),
  (Song7_array[76] = [20.4, 3, 0]),
  (Song7_array[77] = [20.6, 5, 0]),
  (Song7_array[78] = [20.800001, 3, 0]),
  (Song7_array[79] = [21.45, 5, 0]),
  (Song7_array[80] = [21.6, 2, 0]),
  (Song7_array[81] = [21.800001, 3, 0]),
  (Song7_array[82] = [22.25, 5, 0]),
  (Song7_array[83] = [22.4, 2, 0]),
  (Song7_array[84] = [22.6, 3, 0]),
  (Song7_array[85] = [23.050001, 5, 0]),
  (Song7_array[86] = [23.2, 2, 0]),
  (Song7_array[87] = [23.4, 3, 0]),
  (Song7_array[88] = [23.9, 3, 0]),
  (Song7_array[89] = [24.1, 5, 0]),
  (Song7_array[90] = [24.300001, 3, 0]),
  (Song7_array[91] = [24.65, 2, 0]),
  (Song7_array[92] = [24.85, 4, 0]),
  (Song7_array[93] = [25.050001, 2, 0]),
  (Song7_array[94] = [25.45, 2, 0]),
  (Song7_array[95] = [25.65, 4, 0]),
  (Song7_array[96] = [25.85, 2, 0]),
  (Song7_array[97] = [26.25, 3, 0]),
  (Song7_array[98] = [26.5, 5, 0]),
  (Song7_array[99] = [26.800001, 5, 0]),
  (Song7_array[100] = [27.15, 3, 0]),
  (Song7_array[101] = [27.75, 3, 0]),
  (Song7_array[102] = [28.45, 2, 0]),
  (Song7_array[103] = [28.65, 4, 0]),
  (Song7_array[104] = [28.85, 2, 0]),
  (Song7_array[105] = [29.25, 2, 0]),
  (Song7_array[106] = [29.45, 4, 0]),
  (Song7_array[107] = [29.65, 2, 0]),
  (Song7_array[108] = [30.050001, 5, 0]),
  (Song7_array[109] = [30.2, 2, 0]),
  (Song7_array[110] = [30.4, 3, 0]),
  (Song7_array[111] = [31.050001, 5, 0]),
  (Song7_array[112] = [31.2, 2, 0]),
  (Song7_array[113] = [31.4, 3, 0]),
  (Song7_array[114] = [32.100002, 2, 0]),
  (Song7_array[115] = [32.65, 4, 0]),
  (Song7_array[116] = [32.850002, 2, 0]),
  (Song7_array[117] = [33.3, 1, 0.05]),
  (Song7_array[118] = [33.3, 3, 0.05]),
  (Song7_array[119] = [33.3, 5, 0]),
  (Song7_array[120] = [33.75, 1, 0.05]),
  (Song7_array[121] = [33.75, 3, 0.05]),
  (Song7_array[122] = [33.75, 5, 0]),
  (Song7_array[123] = [34.350002, 4, 0]),
  (Song7_array[124] = [34.55, 1, 0.05]),
  (Song7_array[125] = [34.55, 3, 0]),
  (Song7_array[126] = [34.55, 5, 0.05]),
  (Song7_array[127] = [35.15, 1, 0.05]),
  (Song7_array[128] = [35.15, 3, 0]),
  (Song7_array[129] = [35.15, 5, 0.05]),
  (Song7_array[130] = [36.100002, 5, 0]),
  (Song7_array[131] = [36.45, 3, 0]),
  (Song7_array[132] = [37.100002, 5, 0]),
  (Song7_array[133] = [37.45, 3, 0]),
  (Song7_array[134] = [38.05, 5, 0]),
  (Song7_array[135] = [38.4, 3, 0]),
  (Song7_array[136] = [38.95, 5, 0]),
  (Song7_array[137] = [39.3, 3, 0]),
  (Song7_array[138] = [39.75, 1, 0]),
  (Song7_array[139] = [39.75, 3, 0.05]),
  (Song7_array[140] = [39.75, 5, 0.05]),
  (Song7_array[141] = [40.45, 1, 0]),
  (Song7_array[142] = [40.45, 3, 0.05]),
  (Song7_array[143] = [40.45, 5, 0.05]),
  (Song7_array[144] = [41.15, 1, 0.05]),
  (Song7_array[145] = [41.15, 3, 0]),
  (Song7_array[146] = [41.15, 5, 0.05]),
  (Song7_array[147] = [41.7, 1, 0]),
  (Song7_array[148] = [41.8, 1, 0]),
  (Song7_array[149] = [41.9, 1, 0]),
  (Song7_array[150] = [42, 1, 0]),
  (Song7_array[151] = [42.8, 5, 0]),
  (Song7_array[152] = [43.05, 3, 0]),
  (Song7_array[153] = [43.25, 4, 0]),
  (Song7_array[154] = [43.45, 3, 0]),
  (Song7_array[155] = [43.65, 5, 0]),
  (Song7_array[156] = [43.9, 3, 0]),
  (Song7_array[157] = [44.15, 4, 0]),
  (Song7_array[158] = [44.4, 3, 0]),
  (Song7_array[159] = [44.600002, 5, 0]),
  (Song7_array[160] = [44.850002, 3, 0]),
  (Song7_array[161] = [45.05, 2, 0]),
  (Song7_array[162] = [45.45, 5, 0]),
  (Song7_array[163] = [45.7, 3, 0]),
  (Song7_array[164] = [45.9, 4, 0]),
  (Song7_array[165] = [46.100002, 3, 0]),
  (Song7_array[166] = [46.3, 5, 0]),
  (Song7_array[167] = [46.55, 3, 0]),
  (Song7_array[168] = [46.8, 4, 0]),
  (Song7_array[169] = [47.05, 3, 0]),
  (Song7_array[170] = [47.25, 5, 0]),
  (Song7_array[171] = [47.5, 3, 0]),
  (Song7_array[172] = [47.7, 2, 0]),
  (Song7_array[173] = [48.100002, 5, 0]),
  (Song7_array[174] = [48.350002, 3, 0]),
  (Song7_array[175] = [48.55, 4, 0]),
  (Song7_array[176] = [48.75, 3, 0]),
  (Song7_array[177] = [48.95, 5, 0]),
  (Song7_array[178] = [49.2, 3, 0]),
  (Song7_array[179] = [49.45, 4, 0]),
  (Song7_array[180] = [49.7, 3, 0]),
  (Song7_array[181] = [49.9, 5, 0]),
  (Song7_array[182] = [50.15, 3, 0]),
  (Song7_array[183] = [50.350002, 2, 0]),
  (Song7_array[184] = [50.75, 5, 0]),
  (Song7_array[185] = [51, 3, 0]),
  (Song7_array[186] = [51.2, 4, 0]),
  (Song7_array[187] = [51.4, 3, 0]),
  (Song7_array[188] = [51.600002, 5, 0]),
  (Song7_array[189] = [51.850002, 3, 0]),
  (Song7_array[190] = [52.100002, 4, 0]),
  (Song7_array[191] = [52.350002, 3, 0]),
  (Song7_array[192] = [52.55, 5, 0]),
  (Song7_array[193] = [52.8, 3, 0]),
  (Song7_array[194] = [53, 2, 0]),
  (Song7_array[195] = [53.600002, 3, 0]),
  (Song7_array[196] = [53.8, 5, 0]),
  (Song7_array[197] = [54.05, 2, 0]),
  (Song7_array[198] = [54.25, 5, 0]),
  (Song7_array[199] = [54.4, 2, 0]),
  (Song7_array[200] = [54.55, 4, 0]),
  (Song7_array[201] = [54.75, 2, 0]),
  (Song7_array[202] = [54.9, 4, 0]),
  (Song7_array[203] = [55.100002, 2, 0]),
  (Song7_array[204] = [55.3, 4, 0]),
  (Song7_array[205] = [55.5, 2, 0]),
  (Song7_array[206] = [55.65, 4, 0]),
  (Song7_array[207] = [56.2, 3, 0]),
  (Song7_array[208] = [56.45, 1, 0]),
  (Song7_array[209] = [56.95, 5, 0]),
  (Song7_array[210] = [57.2, 3, 0]),
  (Song7_array[211] = [57.7, 5, 0]),
  (Song7_array[212] = [57.95, 3, 0]),
  (Song7_array[213] = [58.55, 1, 0]),
  (Song7_array[214] = [58.8, 4, 0]),
  (Song7_array[215] = [59.25, 3, 0]),
  (Song7_array[216] = [59.45, 1, 0]),
  (Song7_array[217] = [59.8, 4, 0]),
  (Song7_array[218] = [60.25, 2, 0]),
  (Song7_array[219] = [60.5, 5, 0]),
  (Song7_array[220] = [61, 2, 0]),
  (Song7_array[221] = [61.25, 5, 0]),
  (Song7_array[222] = [61.65, 3, 0]),
  (Song7_array[223] = [62.3, 1, 0]),
  (Song7_array[224] = [62.5, 4, 0]),
  (Song7_array[225] = [62.7, 1, 0]),
  (Song7_array[226] = [63.100002, 1, 0]),
  (Song7_array[227] = [63.3, 4, 0]),
  (Song7_array[228] = [63.5, 1, 0]),
  (Song7_array[229] = [63.9, 2, 0]),
  (Song7_array[230] = [64.15, 4, 0]),
  (Song7_array[231] = [64.450005, 4, 0]),
  (Song7_array[232] = [64.950005, 5, 0]),
  (Song7_array[233] = [65.1, 2, 0]),
  (Song7_array[234] = [65.3, 3, 0]),
  (Song7_array[235] = [65.950005, 5, 0]),
  (Song7_array[236] = [66.1, 2, 0]),
  (Song7_array[237] = [66.3, 3, 0]),
  (Song7_array[238] = [66.700005, 5, 0]),
  (Song7_array[239] = [66.9, 2, 0]),
  (Song7_array[240] = [67.1, 5, 0]),
  (Song7_array[241] = [67.450005, 2, 0]),
  (Song7_array[242] = [67.8, 4, 0]),
  (Song7_array[243] = [68.25, 2, 0]),
  (Song7_array[244] = [68.6, 4, 0]),
  (Song7_array[245] = [69.05, 3, 0]),
  (Song7_array[246] = [69.4, 1, 0]),
  (Song7_array[247] = [69.75, 1, 0.05]),
  (Song7_array[248] = [69.75, 3, 0]),
  (Song7_array[249] = [69.75, 5, 0.05]),
  (Song7_array[250] = [70.450005, 1, 0.05]),
  (Song7_array[251] = [70.450005, 3, 0.05]),
  (Song7_array[252] = [70.450005, 5, 0]),
  (Song7_array[253] = [71.1, 5, 0]),
  (Song7_array[254] = [71.25, 2, 0]),
  (Song7_array[255] = [71.450005, 3, 0]),
  (Song7_array[256] = [72.1, 5, 0]),
  (Song7_array[257] = [72.25, 2, 0]),
  (Song7_array[258] = [72.450005, 3, 0]),
  (Song7_array[259] = [72.85, 5, 0]),
  (Song7_array[260] = [73.05, 2, 0]),
  (Song7_array[261] = [73.25, 5, 0]),
  (Song7_array[262] = [73.75, 5, 0]),
  (Song7_array[263] = [73.950005, 2, 0]),
  (Song7_array[264] = [74.15, 5, 0]),
  (Song7_array[265] = [74.8, 1, 0.05]),
  (Song7_array[266] = [74.8, 3, 0]),
  (Song7_array[267] = [74.8, 5, 0.05]),
  (Song7_array[268] = [75.3, 1, 0.05]),
  (Song7_array[269] = [75.3, 3, 0.05]),
  (Song7_array[270] = [75.3, 5, 0]),
  (Song7_array[271] = [76, 1, 0.05]),
  (Song7_array[272] = [76, 3, 0]),
  (Song7_array[273] = [76, 5, 0.05]),
  (Song7_array[274] = [76.55, 1, 0.05]),
  (Song7_array[275] = [76.55, 3, 0]),
  (Song7_array[276] = [76.55, 5, 0.05]),
  (Song7_array[277] = [77.15, 1, 0.05]),
  (Song7_array[278] = [77.15, 3, 0.05]),
  (Song7_array[279] = [77.15, 5, 0]),
  (Song7_array[280] = [77.950005, 1, 0.05]),
  (Song7_array[281] = [77.950005, 3, 0]),
  (Song7_array[282] = [77.950005, 5, 0.05]),
  (Song7_array[283] = [78.75, 1, 0]),
  (Song7_array[284] = [78.950005, 4, 0]),
  (Song7_array[285] = [79.15, 1, 0]),
  (Song7_array[286] = [79.75, 1, 0]),
  (Song7_array[287] = [79.950005, 4, 0]),
  (Song7_array[288] = [80.15, 1, 0]),
  (Song7_array[289] = [80.75, 1, 0]),
  (Song7_array[290] = [80.950005, 4, 0]),
  (Song7_array[291] = [81.15, 1, 0]),
  (Song7_array[292] = [81.6, 1, 0]),
  (Song7_array[293] = [81.8, 3, 0]),
  (Song7_array[294] = [82, 5, 0]),
  (Song7_array[295] = [82.3, 1, 0]),
  (Song7_array[296] = [83.05, 1, 0.05]),
  (Song7_array[297] = [83.05, 3, 0]),
  (Song7_array[298] = [83.05, 5, 0.05]),
  (Song7_array[299] = [83.700005, 1, 0]),
  (Song7_array[300] = [83.700005, 3, 0.05]),
  (Song7_array[301] = [83.700005, 5, 0.05]),
  (Song7_array[302] = [84.25, 3, 0]),
  (Song7_array[303] = [84.35, 3, 0]),
  (Song7_array[304] = [84.450005, 3, 0]),
  (Song7_array[305] = [84.55, 3, 0]),
  (Song7_array[306] = [84.65, 3, 0]),
  (Song7_array[307] = [84.75, 3, 0]),
  (Song7_array[308] = [84.85, 3, 0]),
  (Song7_array[309] = [85.450005, 1, 0]),
  (Song7_array[310] = [85.55, 1, 0]),
  (Song7_array[311] = [85.65, 1, 0]),
  (Song7_array[312] = [85.75, 1, 0]),
  (Song7_array[313] = [85.85, 1, 0]),
  (Song7_array[314] = [85.950005, 1, 0]),
  (Song7_array[315] = [86.05, 1, 0]),
  (Song7_array[316] = [86.15, 1, 0]),
  (Song7_array[317] = [86.25, 1, 0]),
  (Song7_array[318] = [86.35, 1, 0]),
  (Song7_array[319] = [86.450005, 1, 0]),
  (Song7_array[320] = [86.55, 1, 0]),
  (Song7_array[321] = [86.65, 1, 0]),
  (Song7_array[322] = [86.75, 1, 0]),
  (Song7_array[323] = [87.4, 3, 0]),
  (Song7_array[324] = [87.75, 3, 0.05]),
  (Song7_array[325] = [87.75, 5, 0]),
  (Song7_array[326] = [88.1, 5, 0]),
  (Song7_array[327] = [88.200005, 5, 0]),
  (Song7_array[328] = [88.3, 5, 0]),
  (Song7_array[329] = [88.5, 2, 0]),
  (Song7_array[330] = [88.6, 2, 0]),
  (Song7_array[331] = [88.700005, 2, 0]),
  (Song7_array[332] = [88.8, 2, 0]),
  (Song7_array[333] = [88.9, 2, 0]),
  (Song7_array[334] = [89, 2, 0]),
  (Song7_array[335] = [89.1, 2, 0]),
  (Song7_array[336] = [89.200005, 2, 0]),
  (Song7_array[337] = [89.3, 2, 0]),
  (Song7_array[338] = [89.4, 2, 0]),
  (Song7_array[339] = [89.5, 2, 0]),
  (Song7_array[340] = [89.6, 2, 0]),
  (Song7_array[341] = [89.700005, 2, 0]),
  (Song7_array[342] = [89.8, 2, 0]),
  (Song7_array[343] = [89.9, 2, 0]),
  (Song7_array[344] = [90, 2, 0]),
  (Song7_array[345] = [90.1, 2, 0]),
  (Song7_array[346] = [90.200005, 2, 0]),
  (Song7_array[347] = [90.3, 2, 0]),
  (Song7_array[348] = [90.4, 2, 0]),
  (Song7_array[349] = [90.5, 2, 0]),
  (Song7_array[350] = [90.6, 2, 0]),
  (Song7_array[351] = [90.700005, 2, 0]),
  (Song7_array[352] = [91, 2, 0.05]),
  (Song7_array[353] = [91, 4, 0]),
  (Song7_array[354] = [91.25, 1, 0]),
  (Song7_array[355] = [91.35, 1, 0]),
  (Song7_array[356] = [91.450005, 1, 0]),
  (Song7_array[357] = [91.55, 1, 0]),
  (Song7_array[358] = [91.65, 1, 0]),
  (Song7_array[359] = [91.75, 1, 0]),
  (Song7_array[360] = [91.85, 1, 0]),
  (Song7_array[361] = [91.950005, 1, 0]),
  (Song7_array[362] = [92.05, 1, 0]),
  (Song7_array[363] = [92.15, 1, 0]),
  (Song7_array[364] = [92.25, 1, 0]),
  (Song7_array[365] = [92.35, 1, 0]),
  (Song7_array[366] = [92.450005, 1, 0]),
  (Song7_array[367] = [92.55, 1, 0]),
  (Song7_array[368] = [92.65, 1, 0]),
  (Song7_array[369] = [92.75, 1, 0]),
  (Song7_array[370] = [92.85, 1, 0]),
  (Song7_array[371] = [92.950005, 1, 0]),
  (Song7_array[372] = [93.05, 1, 0]),
  (Song7_array[373] = [93.15, 1, 0]),
  (Song7_array[374] = [93.5, 4, 0]),
  (Song7_array[375] = [93.950005, 2, 0]),
  (Song7_array[376] = [94.05, 2, 0]),
  (Song7_array[377] = [94.15, 2, 0]),
  (Song7_array[378] = [94.25, 2, 0]),
  (Song7_array[379] = [94.35, 2, 0]),
  (Song7_array[380] = [94.450005, 2, 0]),
  (Song7_array[381] = [94.55, 2, 0]),
  (Song7_array[382] = [94.65, 2, 0]),
  (Song7_array[383] = [96.1, 4, 0]),
  (Song7_array[384] = [96.200005, 4, 0]),
  (Song7_array[385] = [96.3, 4, 0]),
  (Song7_array[386] = [96.4, 4, 0]),
  (Song7_array[387] = [96.5, 4, 0]),
  (Song7_array[388] = [96.6, 4, 0]),
  (Song7_array[389] = [96.700005, 4, 0]),
  (Song7_array[390] = [96.8, 4, 0]),
  (Song7_array[391] = [96.9, 4, 0]),
  (Song7_array[392] = [97, 4, 0]),
  (Song7_array[393] = [97.1, 4, 0]),
  (Song7_array[394] = [97.200005, 4, 0]),
  (Song7_array[395] = [97.3, 4, 0]),
  (Song7_array[396] = [97.4, 4, 0]),
  (Song7_array[397] = [98.05, 1, 0]),
  (Song7_array[398] = [98.4, 3, 0]),
  (Song7_array[399] = [98.4, 5, 0.05]),
  (Song7_array[400] = [98.75, 5, 0]),
  (Song7_array[401] = [98.85, 5, 0]),
  (Song7_array[402] = [98.950005, 5, 0]),
  (Song7_array[403] = [99.15, 2, 0]),
  (Song7_array[404] = [99.25, 2, 0]),
  (Song7_array[405] = [99.35, 2, 0]),
  (Song7_array[406] = [99.450005, 2, 0]),
  (Song7_array[407] = [99.55, 2, 0]),
  (Song7_array[408] = [99.65, 2, 0]),
  (Song7_array[409] = [99.75, 2, 0]),
  (Song7_array[410] = [99.85, 2, 0]),
  (Song7_array[411] = [99.950005, 2, 0]),
  (Song7_array[412] = [100.05, 2, 0]),
  (Song7_array[413] = [100.15, 2, 0]),
  (Song7_array[414] = [100.25, 2, 0]),
  (Song7_array[415] = [100.35, 2, 0]),
  (Song7_array[416] = [100.450005, 2, 0]),
  (Song7_array[417] = [100.55, 2, 0]),
  (Song7_array[418] = [100.65, 2, 0]),
  (Song7_array[419] = [100.75, 2, 0]),
  (Song7_array[420] = [100.85, 2, 0]),
  (Song7_array[421] = [100.950005, 2, 0]),
  (Song7_array[422] = [101.05, 2, 0]),
  (Song7_array[423] = [101.15, 2, 0]),
  (Song7_array[424] = [101.25, 2, 0]),
  (Song7_array[425] = [101.35, 2, 0]),
  (Song7_array[426] = [101.65, 3, 0.05]),
  (Song7_array[427] = [101.65, 5, 0]),
  (Song7_array[428] = [101.9, 3, 0]),
  (Song7_array[429] = [102, 3, 0]),
  (Song7_array[430] = [102.1, 3, 0]),
  (Song7_array[431] = [102.200005, 3, 0]),
  (Song7_array[432] = [102.3, 3, 0]),
  (Song7_array[433] = [102.4, 3, 0]),
  (Song7_array[434] = [102.5, 3, 0]),
  (Song7_array[435] = [102.6, 3, 0]),
  (Song7_array[436] = [102.700005, 3, 0]),
  (Song7_array[437] = [102.8, 3, 0]),
  (Song7_array[438] = [102.9, 3, 0]),
  (Song7_array[439] = [103, 3, 0]),
  (Song7_array[440] = [103.1, 3, 0]),
  (Song7_array[441] = [103.200005, 3, 0]),
  (Song7_array[442] = [103.3, 3, 0]),
  (Song7_array[443] = [103.4, 3, 0]),
  (Song7_array[444] = [103.5, 3, 0]),
  (Song7_array[445] = [103.6, 3, 0]),
  (Song7_array[446] = [103.700005, 3, 0]),
  (Song7_array[447] = [103.8, 3, 0]),
  (Song7_array[448] = [104.15, 5, 0]),
  (Song7_array[449] = [104.6, 2, 0]),
  (Song7_array[450] = [104.700005, 2, 0]),
  (Song7_array[451] = [104.8, 2, 0]),
  (Song7_array[452] = [104.9, 2, 0]),
  (Song7_array[453] = [105, 2, 0]),
  (Song7_array[454] = [105.1, 2, 0]),
  (Song7_array[455] = [105.200005, 2, 0]),
  (Song7_array[456] = [105.3, 2, 0]),
  (Song7_array[457] = [106.700005, 4, 0]),
  (Song7_array[458] = [106.8, 4, 0]),
  (Song7_array[459] = [106.9, 4, 0]),
  (Song7_array[460] = [107, 4, 0]),
  (Song7_array[461] = [107.1, 4, 0]),
  (Song7_array[462] = [107.200005, 4, 0]),
  (Song7_array[463] = [107.3, 4, 0]),
  (Song7_array[464] = [107.4, 4, 0]),
  (Song7_array[465] = [107.5, 4, 0]),
  (Song7_array[466] = [107.6, 4, 0]),
  (Song7_array[467] = [107.700005, 4, 0]),
  (Song7_array[468] = [107.8, 4, 0]),
  (Song7_array[469] = [107.9, 4, 0]),
  (Song7_array[470] = [108, 4, 0]),
  (Song7_array[471] = [108.65, 1, 0]),
  (Song7_array[472] = [109, 2, 0]),
  (Song7_array[473] = [109, 4, 0.05]),
  (Song7_array[474] = [109.35, 4, 0]),
  (Song7_array[475] = [109.450005, 4, 0]),
  (Song7_array[476] = [109.55, 4, 0]),
  (Song7_array[477] = [109.75, 2, 0]),
  (Song7_array[478] = [109.85, 2, 0]),
  (Song7_array[479] = [109.950005, 2, 0]),
  (Song7_array[480] = [110.05, 2, 0]),
  (Song7_array[481] = [110.15, 2, 0]),
  (Song7_array[482] = [110.25, 2, 0]),
  (Song7_array[483] = [110.35, 2, 0]),
  (Song7_array[484] = [110.450005, 2, 0]),
  (Song7_array[485] = [110.55, 2, 0]),
  (Song7_array[486] = [110.65, 2, 0]),
  (Song7_array[487] = [110.75, 2, 0]),
  (Song7_array[488] = [110.85, 2, 0]),
  (Song7_array[489] = [110.950005, 2, 0]),
  (Song7_array[490] = [111.05, 2, 0]),
  (Song7_array[491] = [111.15, 2, 0]),
  (Song7_array[492] = [111.25, 2, 0]),
  (Song7_array[493] = [111.35, 4, 0]),
  (Song7_array[494] = [111.450005, 4, 0]),
  (Song7_array[495] = [111.55, 4, 0]),
  (Song7_array[496] = [111.65, 4, 0]),
  (Song7_array[497] = [111.75, 4, 0]),
  (Song7_array[498] = [111.85, 4, 0]),
  (Song7_array[499] = [111.950005, 4, 0]),
  (Song7_array[500] = [112.25, 3, 0.05]),
  (Song7_array[501] = [112.25, 5, 0]),
  (Song7_array[502] = [112.5, 1, 0]),
  (Song7_array[503] = [112.6, 1, 0]),
  (Song7_array[504] = [112.700005, 1, 0]),
  (Song7_array[505] = [112.8, 1, 0]),
  (Song7_array[506] = [112.9, 1, 0]),
  (Song7_array[507] = [113, 1, 0]),
  (Song7_array[508] = [113.1, 1, 0]),
  (Song7_array[509] = [113.200005, 1, 0]),
  (Song7_array[510] = [113.3, 1, 0]),
  (Song7_array[511] = [113.4, 1, 0]),
  (Song7_array[512] = [113.5, 1, 0]),
  (Song7_array[513] = [113.6, 1, 0]),
  (Song7_array[514] = [113.700005, 1, 0]),
  (Song7_array[515] = [113.8, 1, 0]),
  (Song7_array[516] = [113.9, 1, 0]),
  (Song7_array[517] = [114, 1, 0]),
  (Song7_array[518] = [114.1, 1, 0]),
  (Song7_array[519] = [114.200005, 1, 0]),
  (Song7_array[520] = [114.3, 1, 0]),
  (Song7_array[521] = [114.4, 1, 0]),
  (Song7_array[522] = [114.75, 4, 0]),
  (Song7_array[523] = [115.200005, 2, 0]),
  (Song7_array[524] = [115.3, 2, 0]),
  (Song7_array[525] = [115.4, 2, 0]),
  (Song7_array[526] = [115.5, 2, 0]),
  (Song7_array[527] = [115.6, 2, 0]),
  (Song7_array[528] = [115.700005, 2, 0]),
  (Song7_array[529] = [115.8, 2, 0]),
  (Song7_array[530] = [115.9, 2, 0]),
  (Song7_array[531] = [117.4, 4, 0]),
  (Song7_array[532] = [117.5, 4, 0]),
  (Song7_array[533] = [117.6, 4, 0]),
  (Song7_array[534] = [117.700005, 4, 0]),
  (Song7_array[535] = [117.8, 4, 0]),
  (Song7_array[536] = [117.9, 4, 0]),
  (Song7_array[537] = [118, 4, 0]),
  (Song7_array[538] = [118.1, 4, 0]),
  (Song7_array[539] = [118.200005, 4, 0]),
  (Song7_array[540] = [118.3, 4, 0]),
  (Song7_array[541] = [118.4, 4, 0]),
  (Song7_array[542] = [118.5, 4, 0]),
  (Song7_array[543] = [118.6, 4, 0]),
  (Song7_array[544] = [118.700005, 4, 0]),
  (Song7_array[545] = [119.35, 2, 0]),
  (Song7_array[546] = [119.700005, 3, 0]),
  (Song7_array[547] = [119.700005, 5, 0.05]),
  (Song7_array[548] = [120.05, 4, 0]),
  (Song7_array[549] = [120.15, 4, 0]),
  (Song7_array[550] = [120.25, 4, 0]),
  (Song7_array[551] = [120.450005, 2, 0]),
  (Song7_array[552] = [120.55, 2, 0]),
  (Song7_array[553] = [120.65, 2, 0]),
  (Song7_array[554] = [120.75, 2, 0]),
  (Song7_array[555] = [120.85, 2, 0]),
  (Song7_array[556] = [120.950005, 2, 0]),
  (Song7_array[557] = [121.05, 2, 0]),
  (Song7_array[558] = [121.15, 2, 0]),
  (Song7_array[559] = [121.25, 2, 0]),
  (Song7_array[560] = [121.35, 2, 0]),
  (Song7_array[561] = [121.450005, 2, 0]),
  (Song7_array[562] = [121.55, 2, 0]),
  (Song7_array[563] = [121.65, 2, 0]),
  (Song7_array[564] = [121.75, 2, 0]),
  (Song7_array[565] = [121.85, 2, 0]),
  (Song7_array[566] = [121.950005, 2, 0]),
  (Song7_array[567] = [122.05, 2, 0]),
  (Song7_array[568] = [122.15, 2, 0]),
  (Song7_array[569] = [122.25, 2, 0]),
  (Song7_array[570] = [122.35, 2, 0]),
  (Song7_array[571] = [122.450005, 2, 0]),
  (Song7_array[572] = [122.55, 2, 0]),
  (Song7_array[573] = [122.65, 2, 0]),
  (Song7_array[574] = [122.950005, 3, 0.05]),
  (Song7_array[575] = [122.950005, 5, 0]),
  (Song7_array[576] = [123.200005, 2, 0]),
  (Song7_array[577] = [123.3, 2, 0]),
  (Song7_array[578] = [123.4, 2, 0]),
  (Song7_array[579] = [123.5, 2, 0]),
  (Song7_array[580] = [123.6, 2, 0]),
  (Song7_array[581] = [123.700005, 2, 0]),
  (Song7_array[582] = [123.8, 2, 0]),
  (Song7_array[583] = [123.9, 2, 0]),
  (Song7_array[584] = [124, 2, 0]),
  (Song7_array[585] = [124.1, 2, 0]),
  (Song7_array[586] = [124.200005, 2, 0]),
  (Song7_array[587] = [124.3, 2, 0]),
  (Song7_array[588] = [124.4, 2, 0]),
  (Song7_array[589] = [124.5, 2, 0]),
  (Song7_array[590] = [124.6, 2, 0]),
  (Song7_array[591] = [124.700005, 2, 0]),
  (Song7_array[592] = [124.8, 2, 0]),
  (Song7_array[593] = [124.9, 2, 0]),
  (Song7_array[594] = [125, 2, 0]),
  (Song7_array[595] = [125.1, 2, 0]),
  (Song7_array[596] = [125.450005, 4, 0]),
  (Song7_array[597] = [125.9, 3, 0]),
  (Song7_array[598] = [126, 3, 0]),
  (Song7_array[599] = [126.1, 3, 0]),
  (Song7_array[600] = [126.200005, 3, 0]),
  (Song7_array[601] = [126.3, 3, 0]),
  (Song7_array[602] = [126.4, 3, 0]),
  (Song7_array[603] = [126.5, 3, 0]),
  (Song7_array[604] = [126.6, 3, 0]);
var Song8_array = [];
(Song8_array[0] = [0.625, 2, 0]),
  (Song8_array[1] = [0.75, 2, 0]),
  (Song8_array[2] = [0.875, 5, 0]),
  (Song8_array[3] = [1, 3, 0]),
  (Song8_array[4] = [1.1875, 4, 0]),
  (Song8_array[5] = [1.3125, 4, 0]),
  (Song8_array[6] = [1.4375, 1, 0]),
  (Song8_array[7] = [1.5625, 4, 0]),
  (Song8_array[8] = [1.6875, 4, 0]),
  (Song8_array[9] = [1.8125, 3, 0]),
  (Song8_array[10] = [1.9375, 5, 0]),
  (Song8_array[11] = [2.1875, 2, 0]),
  (Song8_array[12] = [2.4375, 1, 0]),
  (Song8_array[13] = [2.4375, 3, 0.0625]),
  (Song8_array[14] = [2.875, 2, 0]),
  (Song8_array[15] = [3, 2, 0]),
  (Song8_array[16] = [3.125, 5, 0]),
  (Song8_array[17] = [3.25, 3, 0]),
  (Song8_array[18] = [3.375, 4, 0]),
  (Song8_array[19] = [3.5, 4, 0]),
  (Song8_array[20] = [3.625, 1, 0]),
  (Song8_array[21] = [3.75, 4, 0]),
  (Song8_array[22] = [3.875, 4, 0]),
  (Song8_array[23] = [4, 3, 0]),
  (Song8_array[24] = [4.125, 5, 0]),
  (Song8_array[25] = [4.25, 3, 0]),
  (Song8_array[26] = [4.625, 2, 0]),
  (Song8_array[27] = [4.6875, 2, 0]),
  (Song8_array[28] = [4.75, 2, 0]),
  (Song8_array[29] = [5.0625, 3, 0]),
  (Song8_array[30] = [5.1875, 3, 0]),
  (Song8_array[31] = [5.3125, 5, 0]),
  (Song8_array[32] = [5.4375, 3, 0]),
  (Song8_array[33] = [5.625, 4, 0]),
  (Song8_array[34] = [5.75, 4, 0]),
  (Song8_array[35] = [5.875, 1, 0]),
  (Song8_array[36] = [6, 4, 0]),
  (Song8_array[37] = [6.125, 4, 0]),
  (Song8_array[38] = [6.25, 3, 0]),
  (Song8_array[39] = [6.375, 5, 0]),
  (Song8_array[40] = [6.625, 2, 0]),
  (Song8_array[41] = [6.9375, 1, 0]),
  (Song8_array[42] = [6.9375, 3, 0.0625]),
  (Song8_array[43] = [7.3125, 3, 0]),
  (Song8_array[44] = [7.4375, 3, 0]),
  (Song8_array[45] = [7.5625, 5, 0]),
  (Song8_array[46] = [7.6875, 3, 0]),
  (Song8_array[47] = [7.8125, 4, 0]),
  (Song8_array[48] = [7.9375, 4, 0]),
  (Song8_array[49] = [8.0625, 1, 0]),
  (Song8_array[50] = [8.1875, 4, 0]),
  (Song8_array[51] = [8.3125, 4, 0]),
  (Song8_array[52] = [8.4375, 3, 0]),
  (Song8_array[53] = [8.5625, 5, 0]),
  (Song8_array[54] = [8.875, 3, 0]),
  (Song8_array[55] = [9.125, 2, 0]),
  (Song8_array[56] = [9.1875, 2, 0]),
  (Song8_array[57] = [9.25, 2, 0]),
  (Song8_array[58] = [9.3125, 2, 0]),
  (Song8_array[59] = [9.375, 2, 0]),
  (Song8_array[60] = [9.5625, 3, 0]),
  (Song8_array[61] = [9.6875, 3, 0]),
  (Song8_array[62] = [9.8125, 5, 0]),
  (Song8_array[63] = [9.9375, 3, 0]),
  (Song8_array[64] = [10.125, 4, 0]),
  (Song8_array[65] = [10.25, 4, 0]),
  (Song8_array[66] = [10.375, 1, 0]),
  (Song8_array[67] = [10.5, 4, 0]),
  (Song8_array[68] = [10.625, 4, 0]),
  (Song8_array[69] = [10.75, 3, 0]),
  (Song8_array[70] = [10.875, 5, 0]),
  (Song8_array[71] = [11.125, 3, 0]),
  (Song8_array[72] = [11.375, 1, 0]),
  (Song8_array[73] = [11.375, 3, 0.0625]),
  (Song8_array[74] = [11.8125, 3, 0]),
  (Song8_array[75] = [11.9375, 3, 0]),
  (Song8_array[76] = [12.0625, 5, 0]),
  (Song8_array[77] = [12.1875, 3, 0]),
  (Song8_array[78] = [12.3125, 4, 0]),
  (Song8_array[79] = [12.4375, 4, 0]),
  (Song8_array[80] = [12.5625, 1, 0]),
  (Song8_array[81] = [12.6875, 4, 0]),
  (Song8_array[82] = [12.8125, 4, 0]),
  (Song8_array[83] = [12.9375, 3, 0]),
  (Song8_array[84] = [13.0625, 5, 0]),
  (Song8_array[85] = [13.1875, 3, 0]),
  (Song8_array[86] = [13.5625, 2, 0]),
  (Song8_array[87] = [13.625, 2, 0]),
  (Song8_array[88] = [13.6875, 2, 0]),
  (Song8_array[89] = [14, 3, 0]),
  (Song8_array[90] = [14.125, 3, 0]),
  (Song8_array[91] = [14.25, 5, 0]),
  (Song8_array[92] = [14.375, 3, 0]),
  (Song8_array[93] = [14.5625, 4, 0]),
  (Song8_array[94] = [14.6875, 4, 0]),
  (Song8_array[95] = [14.8125, 1, 0]),
  (Song8_array[96] = [14.9375, 4, 0]),
  (Song8_array[97] = [15.0625, 4, 0]),
  (Song8_array[98] = [15.1875, 3, 0]),
  (Song8_array[99] = [15.3125, 5, 0]),
  (Song8_array[100] = [15.5625, 3, 0]),
  (Song8_array[101] = [15.875, 1, 0]),
  (Song8_array[102] = [15.875, 3, 0.0625]),
  (Song8_array[103] = [16.25, 3, 0]),
  (Song8_array[104] = [16.375, 3, 0]),
  (Song8_array[105] = [16.5, 5, 0]),
  (Song8_array[106] = [16.625, 3, 0]),
  (Song8_array[107] = [16.75, 4, 0]),
  (Song8_array[108] = [16.875, 4, 0]),
  (Song8_array[109] = [17, 1, 0]),
  (Song8_array[110] = [17.125, 4, 0]),
  (Song8_array[111] = [17.25, 4, 0]),
  (Song8_array[112] = [17.375, 3, 0]),
  (Song8_array[113] = [17.5, 5, 0]),
  (Song8_array[114] = [17.8125, 3, 0]),
  (Song8_array[115] = [18.0625, 2, 0]),
  (Song8_array[116] = [18.125, 2, 0]),
  (Song8_array[117] = [18.1875, 2, 0]),
  (Song8_array[118] = [18.25, 2, 0]),
  (Song8_array[119] = [18.3125, 2, 0]),
  (Song8_array[120] = [18.5625, 3, 0]),
  (Song8_array[121] = [18.6875, 3, 0]),
  (Song8_array[122] = [18.8125, 5, 0]),
  (Song8_array[123] = [18.9375, 3, 0]),
  (Song8_array[124] = [19.125, 4, 0]),
  (Song8_array[125] = [19.25, 4, 0]),
  (Song8_array[126] = [19.375, 1, 0]),
  (Song8_array[127] = [19.5, 4, 0]),
  (Song8_array[128] = [19.625, 4, 0]),
  (Song8_array[129] = [19.75, 3, 0]),
  (Song8_array[130] = [19.875, 5, 0]),
  (Song8_array[131] = [20.125, 3, 0]),
  (Song8_array[132] = [20.375, 1, 0]),
  (Song8_array[133] = [20.375, 3, 0.0625]),
  (Song8_array[134] = [20.8125, 3, 0]),
  (Song8_array[135] = [20.9375, 3, 0]),
  (Song8_array[136] = [21.0625, 5, 0]),
  (Song8_array[137] = [21.1875, 3, 0]),
  (Song8_array[138] = [21.3125, 4, 0]),
  (Song8_array[139] = [21.4375, 4, 0]),
  (Song8_array[140] = [21.5625, 1, 0]),
  (Song8_array[141] = [21.6875, 4, 0]),
  (Song8_array[142] = [21.8125, 4, 0]),
  (Song8_array[143] = [21.9375, 3, 0]),
  (Song8_array[144] = [22.0625, 5, 0]),
  (Song8_array[145] = [22.1875, 3, 0]),
  (Song8_array[146] = [22.5625, 2, 0]),
  (Song8_array[147] = [22.625, 2, 0]),
  (Song8_array[148] = [22.6875, 2, 0]),
  (Song8_array[149] = [23, 3, 0]),
  (Song8_array[150] = [23.125, 3, 0]),
  (Song8_array[151] = [23.25, 5, 0]),
  (Song8_array[152] = [23.375, 3, 0]),
  (Song8_array[153] = [23.5625, 4, 0]),
  (Song8_array[154] = [23.6875, 4, 0]),
  (Song8_array[155] = [23.8125, 1, 0]),
  (Song8_array[156] = [23.9375, 4, 0]),
  (Song8_array[157] = [24.0625, 4, 0]),
  (Song8_array[158] = [24.1875, 3, 0]),
  (Song8_array[159] = [24.3125, 5, 0]),
  (Song8_array[160] = [24.5625, 3, 0]),
  (Song8_array[161] = [24.875, 1, 0]),
  (Song8_array[162] = [24.875, 3, 0.0625]),
  (Song8_array[163] = [25.25, 3, 0]),
  (Song8_array[164] = [25.375, 3, 0]),
  (Song8_array[165] = [25.5, 5, 0]),
  (Song8_array[166] = [25.625, 3, 0]),
  (Song8_array[167] = [25.75, 4, 0]),
  (Song8_array[168] = [25.875, 4, 0]),
  (Song8_array[169] = [26, 1, 0]),
  (Song8_array[170] = [26.125, 4, 0]),
  (Song8_array[171] = [26.25, 4, 0]),
  (Song8_array[172] = [26.375, 3, 0]),
  (Song8_array[173] = [26.5, 5, 0]),
  (Song8_array[174] = [26.8125, 3, 0]),
  (Song8_array[175] = [27.0625, 2, 0]),
  (Song8_array[176] = [27.125, 2, 0]),
  (Song8_array[177] = [27.1875, 2, 0]),
  (Song8_array[178] = [27.25, 2, 0]),
  (Song8_array[179] = [27.3125, 2, 0]),
  (Song8_array[180] = [27.75, 2, 0]),
  (Song8_array[181] = [27.875, 5, 0]),
  (Song8_array[182] = [28.1875, 1, 0]),
  (Song8_array[183] = [28.3125, 4, 0]),
  (Song8_array[184] = [28.6875, 1, 0]),
  (Song8_array[185] = [28.8125, 3, 0]),
  (Song8_array[186] = [29.125, 1, 0]),
  (Song8_array[187] = [29.25, 3, 0]),
  (Song8_array[188] = [29.5625, 1, 0]),
  (Song8_array[189] = [30.0625, 2, 0]),
  (Song8_array[190] = [30.1875, 5, 0]),
  (Song8_array[191] = [30.5, 1, 0]),
  (Song8_array[192] = [30.625, 4, 0]),
  (Song8_array[193] = [31, 1, 0]),
  (Song8_array[194] = [31.125, 3, 0]),
  (Song8_array[195] = [31.4375, 1, 0]),
  (Song8_array[196] = [31.5625, 3, 0]),
  (Song8_array[197] = [31.875, 1, 0]),
  (Song8_array[198] = [32.25, 2, 0]),
  (Song8_array[199] = [32.375, 5, 0]),
  (Song8_array[200] = [32.6875, 1, 0]),
  (Song8_array[201] = [32.8125, 4, 0]),
  (Song8_array[202] = [33.1875, 1, 0]),
  (Song8_array[203] = [33.3125, 3, 0]),
  (Song8_array[204] = [33.625, 1, 0]),
  (Song8_array[205] = [33.75, 3, 0]),
  (Song8_array[206] = [34.0625, 1, 0]),
  (Song8_array[207] = [34.5625, 2, 0]),
  (Song8_array[208] = [34.6875, 5, 0]),
  (Song8_array[209] = [35, 1, 0]),
  (Song8_array[210] = [35.125, 4, 0]),
  (Song8_array[211] = [35.5, 1, 0]),
  (Song8_array[212] = [35.625, 3, 0]),
  (Song8_array[213] = [35.9375, 1, 0]),
  (Song8_array[214] = [36.0625, 3, 0]),
  (Song8_array[215] = [36.375, 1, 0]),
  (Song8_array[216] = [36.8125, 2, 0]),
  (Song8_array[217] = [36.9375, 5, 0]),
  (Song8_array[218] = [37.25, 1, 0]),
  (Song8_array[219] = [37.375, 4, 0]),
  (Song8_array[220] = [37.75, 1, 0]),
  (Song8_array[221] = [37.875, 3, 0]),
  (Song8_array[222] = [38.1875, 1, 0]),
  (Song8_array[223] = [38.3125, 3, 0]),
  (Song8_array[224] = [38.625, 1, 0]),
  (Song8_array[225] = [39.0625, 2, 0]),
  (Song8_array[226] = [39.1875, 5, 0]),
  (Song8_array[227] = [39.5, 1, 0]),
  (Song8_array[228] = [39.625, 4, 0]),
  (Song8_array[229] = [40, 1, 0]),
  (Song8_array[230] = [40.125, 3, 0]),
  (Song8_array[231] = [40.4375, 1, 0]),
  (Song8_array[232] = [40.5625, 3, 0]),
  (Song8_array[233] = [40.875, 1, 0]),
  (Song8_array[234] = [41.3125, 2, 0]),
  (Song8_array[235] = [41.4375, 5, 0]),
  (Song8_array[236] = [41.75, 1, 0]),
  (Song8_array[237] = [41.875, 4, 0]),
  (Song8_array[238] = [42.25, 1, 0]),
  (Song8_array[239] = [42.375, 3, 0]),
  (Song8_array[240] = [42.6875, 1, 0]),
  (Song8_array[241] = [42.8125, 3, 0]),
  (Song8_array[242] = [43.125, 1, 0]),
  (Song8_array[243] = [43.5625, 2, 0]),
  (Song8_array[244] = [43.6875, 5, 0]),
  (Song8_array[245] = [44, 1, 0]),
  (Song8_array[246] = [44.125, 4, 0]),
  (Song8_array[247] = [44.5, 1, 0]),
  (Song8_array[248] = [44.625, 3, 0]),
  (Song8_array[249] = [44.9375, 1, 0]),
  (Song8_array[250] = [45.0625, 3, 0]),
  (Song8_array[251] = [45.375, 1, 0]),
  (Song8_array[252] = [45.8125, 2, 0]),
  (Song8_array[253] = [45.9375, 5, 0]),
  (Song8_array[254] = [46.25, 1, 0]),
  (Song8_array[255] = [46.375, 4, 0]),
  (Song8_array[256] = [46.75, 1, 0]),
  (Song8_array[257] = [46.875, 3, 0]),
  (Song8_array[258] = [47.1875, 1, 0]),
  (Song8_array[259] = [47.3125, 3, 0]),
  (Song8_array[260] = [47.625, 1, 0]),
  (Song8_array[261] = [48.125, 2, 0]),
  (Song8_array[262] = [48.25, 5, 0]),
  (Song8_array[263] = [48.5625, 1, 0]),
  (Song8_array[264] = [48.6875, 4, 0]),
  (Song8_array[265] = [49.0625, 1, 0]),
  (Song8_array[266] = [49.1875, 3, 0]),
  (Song8_array[267] = [49.5, 1, 0]),
  (Song8_array[268] = [49.625, 3, 0]),
  (Song8_array[269] = [49.9375, 1, 0]),
  (Song8_array[270] = [50.375, 1, 0.0625]),
  (Song8_array[271] = [50.375, 3, 0]),
  (Song8_array[272] = [50.875, 3, 0.0625]),
  (Song8_array[273] = [50.875, 5, 0]),
  (Song8_array[274] = [51.5, 1, 0.0625]),
  (Song8_array[275] = [51.5, 3, 0]),
  (Song8_array[276] = [52.0625, 3, 0]),
  (Song8_array[277] = [52.0625, 5, 0.0625]),
  (Song8_array[278] = [52.625, 1, 0.0625]),
  (Song8_array[279] = [52.625, 3, 0.0625]),
  (Song8_array[280] = [52.625, 5, 0]),
  (Song8_array[281] = [53.1875, 1, 0]),
  (Song8_array[282] = [53.1875, 3, 0.0625]),
  (Song8_array[283] = [53.8125, 3, 0.0625]),
  (Song8_array[284] = [53.8125, 5, 0]),
  (Song8_array[285] = [54.3125, 1, 0]),
  (Song8_array[286] = [54.875, 1, 0.0625]),
  (Song8_array[287] = [54.875, 3, 0.0625]),
  (Song8_array[288] = [54.875, 5, 0]),
  (Song8_array[289] = [55.4375, 1, 0]),
  (Song8_array[290] = [55.4375, 3, 0.0625]),
  (Song8_array[291] = [56, 3, 0]),
  (Song8_array[292] = [56, 5, 0.0625]),
  (Song8_array[293] = [56.625, 4, 0]),
  (Song8_array[294] = [57.125, 1, 0]),
  (Song8_array[295] = [57.6875, 3, 0.0625]),
  (Song8_array[296] = [57.6875, 5, 0]),
  (Song8_array[297] = [58.25, 1, 0.0625]),
  (Song8_array[298] = [58.25, 3, 0]),
  (Song8_array[299] = [58.25, 5, 0.0625]),
  (Song8_array[300] = [58.875, 1, 0]),
  (Song8_array[301] = [58.875, 3, 0.0625]),
  (Song8_array[302] = [59.4375, 4, 0]),
  (Song8_array[303] = [59.9375, 1, 0.0625]),
  (Song8_array[304] = [59.9375, 3, 0]),
  (Song8_array[305] = [60.5, 1, 0]),
  (Song8_array[306] = [61.0625, 1, 0.0625]),
  (Song8_array[307] = [61.0625, 3, 0]),
  (Song8_array[308] = [61.625, 1, 0]),
  (Song8_array[309] = [62.1875, 1, 0.0625]),
  (Song8_array[310] = [62.1875, 5, 0]),
  (Song8_array[311] = [63.875, 3, 0]),
  (Song8_array[312] = [63.875, 5, 0.0625]),
  (Song8_array[313] = [64.4375, 1, 0]),
  (Song8_array[314] = [65, 3, 0]),
  (Song8_array[315] = [65.5625, 3, 0.0625]),
  (Song8_array[316] = [65.5625, 5, 0]),
  (Song8_array[317] = [66.125, 1, 0]),
  (Song8_array[318] = [66.125, 3, 0.0625]),
  (Song8_array[319] = [66.6875, 4, 0]),
  (Song8_array[320] = [67.3125, 1, 0]),
  (Song8_array[321] = [67.875, 4, 0]),
  (Song8_array[322] = [68.3125, 3, 0]),
  (Song8_array[323] = [68.4375, 3, 0]),
  (Song8_array[324] = [68.5625, 5, 0]),
  (Song8_array[325] = [68.6875, 3, 0]),
  (Song8_array[326] = [68.8125, 4, 0]),
  (Song8_array[327] = [68.9375, 4, 0]),
  (Song8_array[328] = [69.0625, 1, 0]),
  (Song8_array[329] = [69.1875, 4, 0]),
  (Song8_array[330] = [69.3125, 4, 0]),
  (Song8_array[331] = [69.4375, 3, 0]),
  (Song8_array[332] = [69.5625, 5, 0]),
  (Song8_array[333] = [69.8125, 3, 0]),
  (Song8_array[334] = [70.125, 1, 0]),
  (Song8_array[335] = [70.5625, 3, 0]),
  (Song8_array[336] = [70.6875, 3, 0]),
  (Song8_array[337] = [70.8125, 5, 0]),
  (Song8_array[338] = [70.9375, 3, 0]),
  (Song8_array[339] = [71.0625, 4, 0]),
  (Song8_array[340] = [71.1875, 4, 0]),
  (Song8_array[341] = [71.3125, 1, 0]),
  (Song8_array[342] = [71.4375, 3, 0]),
  (Song8_array[343] = [71.5625, 4, 0]),
  (Song8_array[344] = [71.6875, 4, 0]),
  (Song8_array[345] = [71.8125, 5, 0]),
  (Song8_array[346] = [71.9375, 3, 0]),
  (Song8_array[347] = [72.1875, 2, 0]),
  (Song8_array[348] = [72.25, 2, 0]),
  (Song8_array[349] = [72.3125, 2, 0]),
  (Song8_array[350] = [72.375, 2, 0]),
  (Song8_array[351] = [72.4375, 2, 0]),
  (Song8_array[352] = [72.6875, 3, 0]),
  (Song8_array[353] = [72.8125, 3, 0]),
  (Song8_array[354] = [72.9375, 5, 0]),
  (Song8_array[355] = [73.0625, 3, 0]),
  (Song8_array[356] = [73.1875, 4, 0]),
  (Song8_array[357] = [73.3125, 4, 0]),
  (Song8_array[358] = [73.4375, 1, 0]),
  (Song8_array[359] = [73.5625, 3, 0]),
  (Song8_array[360] = [73.6875, 4, 0]),
  (Song8_array[361] = [73.8125, 4, 0]),
  (Song8_array[362] = [73.9375, 5, 0]),
  (Song8_array[363] = [74.375, 3, 0]),
  (Song8_array[364] = [74.6875, 2, 0]),
  (Song8_array[365] = [74.75, 2, 0]),
  (Song8_array[366] = [74.8125, 2, 0]),
  (Song8_array[367] = [75.125, 3, 0]),
  (Song8_array[368] = [75.25, 3, 0]),
  (Song8_array[369] = [75.375, 5, 0]),
  (Song8_array[370] = [75.5, 3, 0]),
  (Song8_array[371] = [75.625, 4, 0]),
  (Song8_array[372] = [75.75, 4, 0]),
  (Song8_array[373] = [75.875, 1, 0]),
  (Song8_array[374] = [76, 3, 0]),
  (Song8_array[375] = [76.125, 4, 0]),
  (Song8_array[376] = [76.25, 4, 0]),
  (Song8_array[377] = [76.375, 5, 0]),
  (Song8_array[378] = [76.75, 3, 0]),
  (Song8_array[379] = [76.9375, 2, 0]),
  (Song8_array[380] = [77, 2, 0]),
  (Song8_array[381] = [77.0625, 2, 0]),
  (Song8_array[382] = [77.125, 2, 0]),
  (Song8_array[383] = [77.1875, 2, 0]),
  (Song8_array[384] = [77.4375, 3, 0]),
  (Song8_array[385] = [77.5625, 3, 0]),
  (Song8_array[386] = [77.6875, 5, 0]),
  (Song8_array[387] = [77.8125, 3, 0]),
  (Song8_array[388] = [77.9375, 4, 0]),
  (Song8_array[389] = [78.0625, 4, 0]),
  (Song8_array[390] = [78.1875, 1, 0]),
  (Song8_array[391] = [78.3125, 3, 0]),
  (Song8_array[392] = [78.4375, 4, 0]),
  (Song8_array[393] = [78.5625, 4, 0]),
  (Song8_array[394] = [78.6875, 5, 0]),
  (Song8_array[395] = [78.875, 3, 0]),
  (Song8_array[396] = [79.125, 1, 0]),
  (Song8_array[397] = [79.5625, 3, 0]),
  (Song8_array[398] = [79.6875, 3, 0]),
  (Song8_array[399] = [79.8125, 5, 0]),
  (Song8_array[400] = [79.9375, 3, 0]),
  (Song8_array[401] = [80.0625, 4, 0]),
  (Song8_array[402] = [80.1875, 4, 0]),
  (Song8_array[403] = [80.3125, 1, 0]),
  (Song8_array[404] = [80.4375, 3, 0]),
  (Song8_array[405] = [80.5625, 4, 0]),
  (Song8_array[406] = [80.6875, 4, 0]),
  (Song8_array[407] = [80.8125, 5, 0]),
  (Song8_array[408] = [81.125, 3, 0]),
  (Song8_array[409] = [81.4375, 2, 0]),
  (Song8_array[410] = [81.5, 2, 0]),
  (Song8_array[411] = [81.5625, 2, 0]),
  (Song8_array[412] = [81.625, 2, 0]),
  (Song8_array[413] = [81.6875, 2, 0]),
  (Song8_array[414] = [82, 1, 0]),
  (Song8_array[415] = [82.125, 4, 0]),
  (Song8_array[416] = [82.3125, 3, 0]),
  (Song8_array[417] = [82.5625, 5, 0]),
  (Song8_array[418] = [83.125, 1, 0]),
  (Song8_array[419] = [83.3125, 3, 0]),
  (Song8_array[420] = [83.4375, 5, 0]),
  (Song8_array[421] = [83.5625, 3, 0]),
  (Song8_array[422] = [83.8125, 5, 0]),
  (Song8_array[423] = [84, 4, 0]),
  (Song8_array[424] = [84.1875, 1, 0]),
  (Song8_array[425] = [84.375, 4, 0]),
  (Song8_array[426] = [84.5625, 3, 0]),
  (Song8_array[427] = [84.9375, 5, 0]),
  (Song8_array[428] = [85.375, 1, 0]),
  (Song8_array[429] = [85.625, 3, 0]),
  (Song8_array[430] = [85.75, 5, 0]),
  (Song8_array[431] = [85.875, 3, 0]),
  (Song8_array[432] = [86.125, 5, 0]),
  (Song8_array[433] = [86.3125, 4, 0]),
  (Song8_array[434] = [86.6875, 2, 0]),
  (Song8_array[435] = [87.8125, 3, 0]),
  (Song8_array[436] = [88, 1, 0]),
  (Song8_array[437] = [88.1875, 3, 0]),
  (Song8_array[438] = [88.5, 5, 0]),
  (Song8_array[439] = [88.6875, 5, 0]),
  (Song8_array[440] = [88.9375, 2, 0]),
  (Song8_array[441] = [89.1875, 4, 0]),
  (Song8_array[442] = [89.875, 5, 0]),
  (Song8_array[443] = [90, 5, 0]),
  (Song8_array[444] = [90.1875, 3, 0]),
  (Song8_array[445] = [90.3125, 3, 0]),
  (Song8_array[446] = [90.5, 1, 0]),
  (Song8_array[447] = [90.8125, 2, 0]),
  (Song8_array[448] = [91, 1, 0]),
  (Song8_array[449] = [91.125, 4, 0]),
  (Song8_array[450] = [91.3125, 3, 0]),
  (Song8_array[451] = [91.5625, 5, 0]),
  (Song8_array[452] = [92.125, 1, 0]),
  (Song8_array[453] = [92.3125, 3, 0]),
  (Song8_array[454] = [92.4375, 5, 0]),
  (Song8_array[455] = [92.5625, 3, 0]),
  (Song8_array[456] = [92.8125, 5, 0]),
  (Song8_array[457] = [93, 4, 0]),
  (Song8_array[458] = [93.1875, 1, 0]),
  (Song8_array[459] = [93.375, 4, 0]),
  (Song8_array[460] = [93.5625, 3, 0]),
  (Song8_array[461] = [93.9375, 5, 0]),
  (Song8_array[462] = [94.375, 1, 0]),
  (Song8_array[463] = [94.625, 3, 0]),
  (Song8_array[464] = [94.75, 5, 0]),
  (Song8_array[465] = [94.875, 3, 0]),
  (Song8_array[466] = [95.125, 5, 0]),
  (Song8_array[467] = [95.3125, 4, 0]),
  (Song8_array[468] = [95.6875, 2, 0]),
  (Song8_array[469] = [96.8125, 3, 0]),
  (Song8_array[470] = [97, 1, 0]),
  (Song8_array[471] = [97.1875, 3, 0]),
  (Song8_array[472] = [97.5, 5, 0]),
  (Song8_array[473] = [97.6875, 5, 0]),
  (Song8_array[474] = [97.9375, 2, 0]),
  (Song8_array[475] = [98.1875, 4, 0]),
  (Song8_array[476] = [98.9375, 5, 0]),
  (Song8_array[477] = [99.0625, 5, 0]),
  (Song8_array[478] = [99.25, 3, 0]),
  (Song8_array[479] = [99.375, 3, 0]),
  (Song8_array[480] = [99.5625, 1, 0]),
  (Song8_array[481] = [99.8125, 2, 0]),
  (Song8_array[482] = [100, 3, 0]),
  (Song8_array[483] = [100.125, 3, 0]),
  (Song8_array[484] = [100.25, 5, 0]),
  (Song8_array[485] = [100.375, 3, 0]),
  (Song8_array[486] = [100.5, 4, 0]),
  (Song8_array[487] = [100.625, 4, 0]),
  (Song8_array[488] = [100.75, 1, 0]),
  (Song8_array[489] = [100.875, 3, 0]),
  (Song8_array[490] = [101, 4, 0]),
  (Song8_array[491] = [101.125, 4, 0]),
  (Song8_array[492] = [101.25, 5, 0]),
  (Song8_array[493] = [101.5, 3, 0]),
  (Song8_array[494] = [101.8125, 1, 0]),
  (Song8_array[495] = [102.25, 3, 0]),
  (Song8_array[496] = [102.375, 3, 0]),
  (Song8_array[497] = [102.5, 5, 0]),
  (Song8_array[498] = [102.625, 3, 0]),
  (Song8_array[499] = [102.75, 4, 0]),
  (Song8_array[500] = [102.875, 4, 0]),
  (Song8_array[501] = [103, 1, 0]),
  (Song8_array[502] = [103.125, 3, 0]),
  (Song8_array[503] = [103.25, 4, 0]),
  (Song8_array[504] = [103.375, 4, 0]),
  (Song8_array[505] = [103.5, 5, 0]),
  (Song8_array[506] = [103.625, 3, 0]),
  (Song8_array[507] = [103.875, 2, 0]),
  (Song8_array[508] = [103.9375, 2, 0]),
  (Song8_array[509] = [104, 2, 0]),
  (Song8_array[510] = [104.0625, 2, 0]),
  (Song8_array[511] = [104.125, 2, 0]),
  (Song8_array[512] = [104.375, 3, 0]),
  (Song8_array[513] = [104.5, 3, 0]),
  (Song8_array[514] = [104.625, 5, 0]),
  (Song8_array[515] = [104.75, 3, 0]),
  (Song8_array[516] = [104.875, 4, 0]),
  (Song8_array[517] = [105, 4, 0]),
  (Song8_array[518] = [105.125, 1, 0]),
  (Song8_array[519] = [105.25, 3, 0]),
  (Song8_array[520] = [105.375, 4, 0]),
  (Song8_array[521] = [105.5, 4, 0]),
  (Song8_array[522] = [105.625, 5, 0]),
  (Song8_array[523] = [106.0625, 3, 0]),
  (Song8_array[524] = [106.375, 2, 0]),
  (Song8_array[525] = [106.4375, 2, 0]),
  (Song8_array[526] = [106.5, 2, 0]),
  (Song8_array[527] = [106.8125, 3, 0]),
  (Song8_array[528] = [106.9375, 3, 0]),
  (Song8_array[529] = [107.0625, 5, 0]),
  (Song8_array[530] = [107.1875, 3, 0]),
  (Song8_array[531] = [107.3125, 4, 0]),
  (Song8_array[532] = [107.4375, 4, 0]),
  (Song8_array[533] = [107.5625, 1, 0]),
  (Song8_array[534] = [107.6875, 3, 0]),
  (Song8_array[535] = [107.8125, 4, 0]),
  (Song8_array[536] = [107.9375, 4, 0]),
  (Song8_array[537] = [108.0625, 5, 0]),
  (Song8_array[538] = [108.4375, 3, 0]),
  (Song8_array[539] = [108.625, 2, 0]),
  (Song8_array[540] = [108.6875, 2, 0]),
  (Song8_array[541] = [108.75, 2, 0]),
  (Song8_array[542] = [108.8125, 2, 0]),
  (Song8_array[543] = [108.875, 2, 0]),
  (Song8_array[544] = [109.125, 3, 0]),
  (Song8_array[545] = [109.25, 3, 0]),
  (Song8_array[546] = [109.375, 5, 0]),
  (Song8_array[547] = [109.5, 3, 0]),
  (Song8_array[548] = [109.625, 4, 0]),
  (Song8_array[549] = [109.75, 4, 0]),
  (Song8_array[550] = [109.875, 1, 0]),
  (Song8_array[551] = [110, 3, 0]),
  (Song8_array[552] = [110.125, 4, 0]),
  (Song8_array[553] = [110.25, 4, 0]),
  (Song8_array[554] = [110.375, 5, 0]),
  (Song8_array[555] = [110.5625, 3, 0]),
  (Song8_array[556] = [110.8125, 1, 0]),
  (Song8_array[557] = [111.25, 3, 0]),
  (Song8_array[558] = [111.375, 3, 0]),
  (Song8_array[559] = [111.5, 5, 0]),
  (Song8_array[560] = [111.625, 3, 0]),
  (Song8_array[561] = [111.75, 4, 0]),
  (Song8_array[562] = [111.875, 4, 0]),
  (Song8_array[563] = [112, 1, 0]),
  (Song8_array[564] = [112.125, 3, 0]),
  (Song8_array[565] = [112.25, 4, 0]),
  (Song8_array[566] = [112.375, 4, 0]),
  (Song8_array[567] = [112.5, 5, 0]),
  (Song8_array[568] = [112.8125, 3, 0]),
  (Song8_array[569] = [113.125, 2, 0]),
  (Song8_array[570] = [113.1875, 2, 0]),
  (Song8_array[571] = [113.25, 2, 0]),
  (Song8_array[572] = [113.3125, 2, 0]),
  (Song8_array[573] = [113.375, 2, 0]),
  (Song8_array[574] = [113.625, 3, 0]),
  (Song8_array[575] = [113.75, 3, 0]),
  (Song8_array[576] = [113.875, 5, 0]),
  (Song8_array[577] = [114, 3, 0]),
  (Song8_array[578] = [114.125, 4, 0]),
  (Song8_array[579] = [114.25, 4, 0]),
  (Song8_array[580] = [114.375, 1, 0]),
  (Song8_array[581] = [114.5, 3, 0]),
  (Song8_array[582] = [114.625, 4, 0]),
  (Song8_array[583] = [114.75, 4, 0]),
  (Song8_array[584] = [114.875, 5, 0]),
  (Song8_array[585] = [115.0625, 3, 0]),
  (Song8_array[586] = [115.3125, 1, 0]),
  (Song8_array[587] = [115.75, 3, 0]),
  (Song8_array[588] = [115.875, 3, 0]),
  (Song8_array[589] = [116, 5, 0]),
  (Song8_array[590] = [116.125, 3, 0]),
  (Song8_array[591] = [116.25, 4, 0]),
  (Song8_array[592] = [116.375, 4, 0]),
  (Song8_array[593] = [116.5, 1, 0]),
  (Song8_array[594] = [116.625, 3, 0]),
  (Song8_array[595] = [116.75, 4, 0]),
  (Song8_array[596] = [116.875, 4, 0]),
  (Song8_array[597] = [117, 5, 0]),
  (Song8_array[598] = [117.3125, 3, 0]),
  (Song8_array[599] = [117.625, 2, 0]),
  (Song8_array[600] = [117.6875, 2, 0]),
  (Song8_array[601] = [117.75, 2, 0]),
  (Song8_array[602] = [117.8125, 2, 0]),
  (Song8_array[603] = [117.875, 2, 0]),
  (Song8_array[604] = [118.125, 3, 0]),
  (Song8_array[605] = [118.25, 5, 0]),
  (Song8_array[606] = [118.5625, 1, 0]),
  (Song8_array[607] = [118.6875, 4, 0]),
  (Song8_array[608] = [119.0625, 1, 0]),
  (Song8_array[609] = [119.1875, 4, 0]),
  (Song8_array[610] = [119.5, 1, 0]),
  (Song8_array[611] = [119.625, 3, 0]),
  (Song8_array[612] = [119.9375, 1, 0]),
  (Song8_array[613] = [120.375, 3, 0]),
  (Song8_array[614] = [120.5, 5, 0]),
  (Song8_array[615] = [120.8125, 1, 0]),
  (Song8_array[616] = [120.9375, 4, 0]),
  (Song8_array[617] = [121.3125, 1, 0]),
  (Song8_array[618] = [121.4375, 4, 0]),
  (Song8_array[619] = [121.75, 1, 0]),
  (Song8_array[620] = [121.875, 3, 0]),
  (Song8_array[621] = [122.1875, 1, 0]),
  (Song8_array[622] = [122.625, 3, 0]),
  (Song8_array[623] = [122.75, 5, 0]),
  (Song8_array[624] = [123.0625, 1, 0]),
  (Song8_array[625] = [123.1875, 4, 0]),
  (Song8_array[626] = [123.5625, 1, 0]),
  (Song8_array[627] = [123.6875, 4, 0]),
  (Song8_array[628] = [124, 1, 0]),
  (Song8_array[629] = [124.125, 3, 0]),
  (Song8_array[630] = [124.4375, 1, 0]),
  (Song8_array[631] = [124.875, 3, 0]),
  (Song8_array[632] = [125, 5, 0]),
  (Song8_array[633] = [125.3125, 1, 0]),
  (Song8_array[634] = [125.4375, 4, 0]),
  (Song8_array[635] = [125.8125, 1, 0]),
  (Song8_array[636] = [125.9375, 3, 0]),
  (Song8_array[637] = [126.25, 1, 0]),
  (Song8_array[638] = [126.375, 3, 0]),
  (Song8_array[639] = [126.6875, 1, 0]),
  (Song8_array[640] = [127.125, 3, 0]),
  (Song8_array[641] = [127.25, 5, 0]),
  (Song8_array[642] = [127.5625, 1, 0]),
  (Song8_array[643] = [127.6875, 4, 0]),
  (Song8_array[644] = [128.0625, 1, 0]),
  (Song8_array[645] = [128.1875, 3, 0]),
  (Song8_array[646] = [128.5, 1, 0]),
  (Song8_array[647] = [128.625, 3, 0]),
  (Song8_array[648] = [128.9375, 1, 0]),
  (Song8_array[649] = [129.4375, 3, 0]),
  (Song8_array[650] = [129.5625, 5, 0]),
  (Song8_array[651] = [129.875, 1, 0]),
  (Song8_array[652] = [130, 4, 0]),
  (Song8_array[653] = [130.375, 1, 0]),
  (Song8_array[654] = [130.5, 3, 0]),
  (Song8_array[655] = [130.8125, 1, 0]),
  (Song8_array[656] = [130.9375, 3, 0]),
  (Song8_array[657] = [131.25, 1, 0]),
  (Song8_array[658] = [131.6875, 3, 0]),
  (Song8_array[659] = [131.8125, 5, 0]),
  (Song8_array[660] = [132.125, 1, 0]),
  (Song8_array[661] = [132.25, 4, 0]),
  (Song8_array[662] = [132.625, 1, 0]),
  (Song8_array[663] = [132.75, 4, 0]),
  (Song8_array[664] = [133.0625, 1, 0]),
  (Song8_array[665] = [133.1875, 3, 0]),
  (Song8_array[666] = [133.5, 1, 0]),
  (Song8_array[667] = [133.9375, 3, 0]),
  (Song8_array[668] = [134.0625, 5, 0]),
  (Song8_array[669] = [134.375, 1, 0]),
  (Song8_array[670] = [134.5, 4, 0]),
  (Song8_array[671] = [134.875, 1, 0]),
  (Song8_array[672] = [135, 3, 0]),
  (Song8_array[673] = [135.3125, 1, 0]),
  (Song8_array[674] = [135.4375, 3, 0]),
  (Song8_array[675] = [135.75, 1, 0]),
  (Song8_array[676] = [136.1875, 3, 0]),
  (Song8_array[677] = [136.3125, 5, 0]),
  (Song8_array[678] = [136.625, 1, 0]),
  (Song8_array[679] = [136.75, 4, 0]),
  (Song8_array[680] = [137.125, 1, 0]),
  (Song8_array[681] = [137.25, 3, 0]),
  (Song8_array[682] = [137.5625, 1, 0]),
  (Song8_array[683] = [137.6875, 3, 0]),
  (Song8_array[684] = [138, 1, 0]),
  (Song8_array[685] = [138.4375, 1, 0.0625]),
  (Song8_array[686] = [138.4375, 3, 0]),
  (Song8_array[687] = [138.9375, 3, 0.0625]),
  (Song8_array[688] = [138.9375, 5, 0]),
  (Song8_array[689] = [139.5625, 1, 0.0625]),
  (Song8_array[690] = [139.5625, 3, 0]),
  (Song8_array[691] = [140.125, 1, 0]),
  (Song8_array[692] = [140.125, 3, 0.0625]),
  (Song8_array[693] = [140.6875, 1, 0.0625]),
  (Song8_array[694] = [140.6875, 3, 0]),
  (Song8_array[695] = [140.6875, 5, 0.0625]),
  (Song8_array[696] = [141.25, 1, 0]),
  (Song8_array[697] = [141.25, 3, 0.0625]),
  (Song8_array[698] = [141.875, 3, 0.0625]),
  (Song8_array[699] = [141.875, 5, 0]),
  (Song8_array[700] = [142.375, 1, 0]),
  (Song8_array[701] = [142.9375, 1, 0.0625]),
  (Song8_array[702] = [142.9375, 3, 0.0625]),
  (Song8_array[703] = [142.9375, 5, 0]),
  (Song8_array[704] = [143.5, 3, 0]),
  (Song8_array[705] = [143.5, 5, 0.0625]),
  (Song8_array[706] = [144.0625, 1, 0]),
  (Song8_array[707] = [144.0625, 3, 0.0625]),
  (Song8_array[708] = [144.6875, 5, 0]),
  (Song8_array[709] = [145.1875, 2, 0]),
  (Song8_array[710] = [145.75, 3, 0.0625]),
  (Song8_array[711] = [145.75, 5, 0]),
  (Song8_array[712] = [146.3125, 1, 0.0625]),
  (Song8_array[713] = [146.3125, 3, 0]),
  (Song8_array[714] = [146.3125, 5, 0.0625]),
  (Song8_array[715] = [146.9375, 3, 0.0625]),
  (Song8_array[716] = [146.9375, 5, 0]),
  (Song8_array[717] = [147.5, 3, 0]),
  (Song8_array[718] = [148, 3, 0.0625]),
  (Song8_array[719] = [148, 5, 0]),
  (Song8_array[720] = [148.5625, 2, 0]),
  (Song8_array[721] = [149.125, 2, 0.0625]),
  (Song8_array[722] = [149.125, 4, 0]),
  (Song8_array[723] = [149.6875, 1, 0]),
  (Song8_array[724] = [150.25, 3, 0.0625]),
  (Song8_array[725] = [150.25, 5, 0]),
  (Song8_array[726] = [150.875, 1, 0.0625]),
  (Song8_array[727] = [150.875, 3, 0]),
  (Song8_array[728] = [151.375, 3, 0.0625]),
  (Song8_array[729] = [151.375, 5, 0]),
  (Song8_array[730] = [152, 1, 0.0625]),
  (Song8_array[731] = [152, 3, 0]),
  (Song8_array[732] = [152.5625, 1, 0]),
  (Song8_array[733] = [152.5625, 3, 0.0625]),
  (Song8_array[734] = [153.125, 1, 0.0625]),
  (Song8_array[735] = [153.125, 3, 0]),
  (Song8_array[736] = [153.125, 5, 0.0625]),
  (Song8_array[737] = [153.5625, 1, 0]),
  (Song8_array[738] = [153.625, 1, 0]),
  (Song8_array[739] = [153.6875, 1, 0]),
  (Song8_array[740] = [153.75, 1, 0]),
  (Song8_array[741] = [153.8125, 1, 0]),
  (Song8_array[742] = [153.875, 1, 0]),
  (Song8_array[743] = [153.9375, 1, 0]),
  (Song8_array[744] = [154.0625, 5, 0]),
  (Song8_array[745] = [154.25, 2, 0]),
  (Song8_array[746] = [154.4375, 4, 0]),
  (Song8_array[747] = [154.6875, 2, 0]),
  (Song8_array[748] = [154.75, 2, 0]),
  (Song8_array[749] = [154.8125, 2, 0]),
  (Song8_array[750] = [154.875, 2, 0]),
  (Song8_array[751] = [154.9375, 2, 0]),
  (Song8_array[752] = [155, 2, 0]),
  (Song8_array[753] = [155.0625, 2, 0]),
  (Song8_array[754] = [155.125, 2, 0]),
  (Song8_array[755] = [155.1875, 2, 0]),
  (Song8_array[756] = [155.25, 2, 0]),
  (Song8_array[757] = [155.3125, 2, 0]),
  (Song8_array[758] = [155.375, 2, 0]),
  (Song8_array[759] = [155.4375, 2, 0]),
  (Song8_array[760] = [155.5, 2, 0]),
  (Song8_array[761] = [155.5625, 2, 0]),
  (Song8_array[762] = [155.625, 2, 0]),
  (Song8_array[763] = [155.6875, 2, 0]),
  (Song8_array[764] = [155.75, 2, 0]),
  (Song8_array[765] = [155.8125, 2, 0]),
  (Song8_array[766] = [155.875, 2, 0]),
  (Song8_array[767] = [155.9375, 2, 0]);
var Song10_array = [];
(Song10_array[0] = [0.05, 3, 0]),
  (Song10_array[1] = [0.25, 1, 0]),
  (Song10_array[2] = [0.45000002, 3, 0]),
  (Song10_array[3] = [0.65000004, 1, 0]),
  (Song10_array[4] = [0.90000004, 5, 0]),
  (Song10_array[5] = [1.25, 3, 0]),
  (Song10_array[6] = [1.5500001, 5, 0]),
  (Song10_array[7] = [2, 3, 0]),
  (Song10_array[8] = [2.2, 1, 0]),
  (Song10_array[9] = [2.4, 3, 0]),
  (Song10_array[10] = [2.55, 5, 0]),
  (Song10_array[11] = [2.8, 3, 0]),
  (Song10_array[12] = [3.3500001, 3, 0]),
  (Song10_array[13] = [3.55, 1, 0]),
  (Song10_array[14] = [3.75, 3, 0]),
  (Song10_array[15] = [3.95, 1, 0]),
  (Song10_array[16] = [4.2000003, 5, 0]),
  (Song10_array[17] = [4.55, 3, 0]),
  (Song10_array[18] = [4.85, 5, 0]),
  (Song10_array[19] = [5.3, 3, 0]),
  (Song10_array[20] = [5.5, 1, 0]),
  (Song10_array[21] = [5.7000003, 3, 0]),
  (Song10_array[22] = [5.85, 5, 0]),
  (Song10_array[23] = [6.1, 3, 0]),
  (Song10_array[24] = [6.55, 1, 0]),
  (Song10_array[25] = [6.55, 3, 0.05]),
  (Song10_array[26] = [6.75, 3, 0]),
  (Song10_array[27] = [6.75, 5, 0.05]),
  (Song10_array[28] = [6.9500003, 1, 0]),
  (Song10_array[29] = [6.9500003, 3, 0.05]),
  (Song10_array[30] = [7.15, 3, 0]),
  (Song10_array[31] = [7.15, 5, 0.05]),
  (Song10_array[32] = [7.4, 4, 0]),
  (Song10_array[33] = [7.75, 1, 0]),
  (Song10_array[34] = [7.75, 3, 0.05]),
  (Song10_array[35] = [8.05, 2, 0]),
  (Song10_array[36] = [8.05, 4, 0.05]),
  (Song10_array[37] = [8.5, 1, 0]),
  (Song10_array[38] = [8.5, 3, 0.05]),
  (Song10_array[39] = [8.7, 3, 0]),
  (Song10_array[40] = [8.7, 5, 0.05]),
  (Song10_array[41] = [8.900001, 1, 0]),
  (Song10_array[42] = [8.900001, 3, 0.05]),
  (Song10_array[43] = [9.05, 4, 0]),
  (Song10_array[44] = [9.3, 1, 0]),
  (Song10_array[45] = [9.3, 3, 0.05]),
  (Song10_array[46] = [9.75, 1, 0]),
  (Song10_array[47] = [9.75, 3, 0.05]),
  (Song10_array[48] = [9.95, 3, 0]),
  (Song10_array[49] = [9.95, 5, 0.05]),
  (Song10_array[50] = [10.150001, 1, 0]),
  (Song10_array[51] = [10.150001, 3, 0.05]),
  (Song10_array[52] = [10.35, 3, 0]),
  (Song10_array[53] = [10.35, 5, 0.05]),
  (Song10_array[54] = [10.6, 4, 0]),
  (Song10_array[55] = [10.95, 1, 0]),
  (Song10_array[56] = [10.95, 3, 0.05]),
  (Song10_array[57] = [11.25, 2, 0]),
  (Song10_array[58] = [11.25, 4, 0.05]),
  (Song10_array[59] = [11.7, 3, 0]),
  (Song10_array[60] = [11.7, 5, 0.05]),
  (Song10_array[61] = [11.900001, 1, 0]),
  (Song10_array[62] = [11.900001, 3, 0.05]),
  (Song10_array[63] = [12.1, 3, 0]),
  (Song10_array[64] = [12.1, 5, 0.05]),
  (Song10_array[65] = [12.25, 4, 0]),
  (Song10_array[66] = [12.5, 1, 0]),
  (Song10_array[67] = [12.5, 3, 0.05]),
  (Song10_array[68] = [12.95, 5, 0]),
  (Song10_array[69] = [13.35, 1, 0]),
  (Song10_array[70] = [13.75, 3, 0]),
  (Song10_array[71] = [13.900001, 5, 0]),
  (Song10_array[72] = [14.05, 2, 0]),
  (Song10_array[73] = [14.2, 4, 0]),
  (Song10_array[74] = [14.400001, 2, 0]),
  (Song10_array[75] = [14.45, 2, 0]),
  (Song10_array[76] = [14.5, 2, 0]),
  (Song10_array[77] = [16.15, 5, 0]),
  (Song10_array[78] = [16.550001, 1, 0]),
  (Song10_array[79] = [16.95, 3, 0]),
  (Song10_array[80] = [17.1, 5, 0]),
  (Song10_array[81] = [17.25, 2, 0]),
  (Song10_array[82] = [17.4, 4, 0]),
  (Song10_array[83] = [17.6, 2, 0]),
  (Song10_array[84] = [17.65, 2, 0]),
  (Song10_array[85] = [17.7, 2, 0]),
  (Song10_array[86] = [19.35, 5, 0]),
  (Song10_array[87] = [19.75, 1, 0]),
  (Song10_array[88] = [20.15, 3, 0]),
  (Song10_array[89] = [20.300001, 5, 0]),
  (Song10_array[90] = [20.45, 2, 0]),
  (Song10_array[91] = [20.6, 4, 0]),
  (Song10_array[92] = [20.800001, 2, 0]),
  (Song10_array[93] = [20.85, 2, 0]),
  (Song10_array[94] = [20.9, 2, 0]),
  (Song10_array[95] = [22.550001, 5, 0]),
  (Song10_array[96] = [22.95, 1, 0]),
  (Song10_array[97] = [23.35, 3, 0]),
  (Song10_array[98] = [23.5, 5, 0]),
  (Song10_array[99] = [23.65, 2, 0]),
  (Song10_array[100] = [23.800001, 4, 0]),
  (Song10_array[101] = [24, 2, 0]),
  (Song10_array[102] = [24.050001, 2, 0]),
  (Song10_array[103] = [24.1, 2, 0]),
  (Song10_array[104] = [25.85, 3, 0]),
  (Song10_array[105] = [25.9, 3, 0]),
  (Song10_array[106] = [25.95, 3, 0]),
  (Song10_array[107] = [26, 3, 0]),
  (Song10_array[108] = [26.15, 1, 0]),
  (Song10_array[109] = [26.15, 3, 0.05]),
  (Song10_array[110] = [26.5, 5, 0]),
  (Song10_array[111] = [26.550001, 5, 0]),
  (Song10_array[112] = [26.6, 5, 0]),
  (Song10_array[113] = [26.65, 5, 0]),
  (Song10_array[114] = [26.800001, 3, 0]),
  (Song10_array[115] = [26.800001, 5, 0.05]),
  (Song10_array[116] = [27.35, 5, 0]),
  (Song10_array[117] = [27.5, 3, 0]),
  (Song10_array[118] = [27.65, 1, 0]),
  (Song10_array[119] = [27.85, 3, 0]),
  (Song10_array[120] = [28.050001, 2, 0]),
  (Song10_array[121] = [28.25, 4, 0]),
  (Song10_array[122] = [28.45, 3, 0]),
  (Song10_array[123] = [28.6, 5, 0]),
  (Song10_array[124] = [28.800001, 1, 0]),
  (Song10_array[125] = [28.85, 1, 0]),
  (Song10_array[126] = [28.9, 1, 0]),
  (Song10_array[127] = [28.95, 1, 0]),
  (Song10_array[128] = [29.1, 3, 0]),
  (Song10_array[129] = [29.15, 3, 0]),
  (Song10_array[130] = [29.2, 3, 0]),
  (Song10_array[131] = [29.25, 3, 0]),
  (Song10_array[132] = [29.4, 1, 0]),
  (Song10_array[133] = [29.4, 3, 0.05]),
  (Song10_array[134] = [29.75, 5, 0]),
  (Song10_array[135] = [29.800001, 5, 0]),
  (Song10_array[136] = [29.85, 5, 0]),
  (Song10_array[137] = [29.9, 5, 0]),
  (Song10_array[138] = [30.050001, 3, 0]),
  (Song10_array[139] = [30.050001, 5, 0.05]),
  (Song10_array[140] = [30.6, 5, 0]),
  (Song10_array[141] = [30.75, 3, 0]),
  (Song10_array[142] = [30.9, 1, 0]),
  (Song10_array[143] = [31.1, 3, 0]),
  (Song10_array[144] = [31.300001, 2, 0]),
  (Song10_array[145] = [31.5, 4, 0]),
  (Song10_array[146] = [31.7, 3, 0]),
  (Song10_array[147] = [31.85, 5, 0]),
  (Song10_array[148] = [32.05, 1, 0]),
  (Song10_array[149] = [32.100002, 1, 0]),
  (Song10_array[150] = [32.15, 1, 0]),
  (Song10_array[151] = [32.2, 1, 0]),
  (Song10_array[152] = [32.350002, 3, 0]),
  (Song10_array[153] = [32.4, 3, 0]),
  (Song10_array[154] = [32.45, 3, 0]),
  (Song10_array[155] = [32.5, 3, 0]),
  (Song10_array[156] = [32.65, 1, 0]),
  (Song10_array[157] = [32.65, 3, 0.05]),
  (Song10_array[158] = [33, 5, 0]),
  (Song10_array[159] = [33.05, 5, 0]),
  (Song10_array[160] = [33.100002, 5, 0]),
  (Song10_array[161] = [33.15, 5, 0]),
  (Song10_array[162] = [33.3, 3, 0]),
  (Song10_array[163] = [33.3, 5, 0.05]),
  (Song10_array[164] = [33.850002, 5, 0]),
  (Song10_array[165] = [34, 3, 0]),
  (Song10_array[166] = [34.15, 1, 0]),
  (Song10_array[167] = [34.350002, 3, 0]),
  (Song10_array[168] = [34.55, 2, 0]),
  (Song10_array[169] = [34.75, 4, 0]),
  (Song10_array[170] = [34.95, 3, 0]),
  (Song10_array[171] = [35.100002, 5, 0]),
  (Song10_array[172] = [35.3, 1, 0]),
  (Song10_array[173] = [35.350002, 1, 0]),
  (Song10_array[174] = [35.4, 1, 0]),
  (Song10_array[175] = [35.45, 1, 0]),
  (Song10_array[176] = [35.600002, 3, 0]),
  (Song10_array[177] = [35.65, 3, 0]),
  (Song10_array[178] = [35.7, 3, 0]),
  (Song10_array[179] = [35.75, 3, 0]),
  (Song10_array[180] = [35.9, 1, 0]),
  (Song10_array[181] = [35.9, 3, 0.05]),
  (Song10_array[182] = [36.25, 5, 0]),
  (Song10_array[183] = [36.3, 5, 0]),
  (Song10_array[184] = [36.350002, 5, 0]),
  (Song10_array[185] = [36.4, 5, 0]),
  (Song10_array[186] = [36.55, 3, 0]),
  (Song10_array[187] = [36.55, 5, 0.05]),
  (Song10_array[188] = [37.100002, 5, 0]),
  (Song10_array[189] = [37.25, 3, 0]),
  (Song10_array[190] = [37.4, 1, 0]),
  (Song10_array[191] = [37.600002, 3, 0]),
  (Song10_array[192] = [37.8, 2, 0]),
  (Song10_array[193] = [38, 4, 0]),
  (Song10_array[194] = [38.2, 3, 0]),
  (Song10_array[195] = [38.350002, 5, 0]),
  (Song10_array[196] = [38.7, 1, 0.05]),
  (Song10_array[197] = [38.7, 3, 0]),
  (Song10_array[198] = [39, 3, 0.05]),
  (Song10_array[199] = [39, 5, 0]),
  (Song10_array[200] = [39.25, 3, 0]),
  (Song10_array[201] = [39.3, 3, 0]),
  (Song10_array[202] = [39.350002, 3, 0]),
  (Song10_array[203] = [39.600002, 1, 0]),
  (Song10_array[204] = [39.600002, 3, 0.05]),
  (Song10_array[205] = [39.850002, 1, 0]),
  (Song10_array[206] = [39.9, 1, 0]),
  (Song10_array[207] = [39.95, 1, 0]),
  (Song10_array[208] = [40.15, 3, 0]),
  (Song10_array[209] = [40.3, 5, 0]),
  (Song10_array[210] = [40.45, 3, 0]),
  (Song10_array[211] = [40.65, 3, 0.05]),
  (Song10_array[212] = [40.65, 5, 0]),
  (Song10_array[213] = [40.850002, 3, 0.05]),
  (Song10_array[214] = [40.850002, 5, 0]),
  (Song10_array[215] = [41, 2, 0]),
  (Song10_array[216] = [41.100002, 1, 0]),
  (Song10_array[217] = [41.2, 2, 0]),
  (Song10_array[218] = [41.350002, 1, 0]),
  (Song10_array[219] = [41.5, 3, 0]),
  (Song10_array[220] = [41.65, 5, 0]),
  (Song10_array[221] = [41.75, 3, 0]),
  (Song10_array[222] = [41.95, 3, 0.05]),
  (Song10_array[223] = [41.95, 5, 0]),
  (Song10_array[224] = [42.25, 3, 0.05]),
  (Song10_array[225] = [42.25, 5, 0]),
  (Song10_array[226] = [42.5, 3, 0]),
  (Song10_array[227] = [42.55, 3, 0]),
  (Song10_array[228] = [42.600002, 3, 0]),
  (Song10_array[229] = [42.850002, 1, 0]),
  (Song10_array[230] = [42.850002, 3, 0.05]),
  (Song10_array[231] = [43.100002, 1, 0]),
  (Song10_array[232] = [43.15, 1, 0]),
  (Song10_array[233] = [43.2, 1, 0]),
  (Song10_array[234] = [43.4, 3, 0]),
  (Song10_array[235] = [43.55, 3, 0]),
  (Song10_array[236] = [43.7, 5, 0]),
  (Song10_array[237] = [43.9, 3, 0.05]),
  (Song10_array[238] = [43.9, 5, 0]),
  (Song10_array[239] = [44.100002, 3, 0.05]),
  (Song10_array[240] = [44.100002, 5, 0]),
  (Song10_array[241] = [44.25, 2, 0]),
  (Song10_array[242] = [44.350002, 1, 0]),
  (Song10_array[243] = [44.45, 2, 0]),
  (Song10_array[244] = [44.600002, 1, 0]),
  (Song10_array[245] = [44.75, 3, 0]),
  (Song10_array[246] = [44.9, 5, 0]),
  (Song10_array[247] = [45, 3, 0]),
  (Song10_array[248] = [45.2, 3, 0]),
  (Song10_array[249] = [45.25, 3, 0]),
  (Song10_array[250] = [45.3, 3, 0]),
  (Song10_array[251] = [45.350002, 3, 0]),
  (Song10_array[252] = [45.5, 1, 0]),
  (Song10_array[253] = [45.5, 3, 0.05]),
  (Song10_array[254] = [45.850002, 5, 0]),
  (Song10_array[255] = [45.9, 5, 0]),
  (Song10_array[256] = [45.95, 5, 0]),
  (Song10_array[257] = [46, 5, 0]),
  (Song10_array[258] = [46.15, 3, 0]),
  (Song10_array[259] = [46.15, 5, 0.05]),
  (Song10_array[260] = [46.7, 5, 0]),
  (Song10_array[261] = [46.850002, 3, 0]),
  (Song10_array[262] = [47, 1, 0]),
  (Song10_array[263] = [47.2, 3, 0]),
  (Song10_array[264] = [47.4, 2, 0]),
  (Song10_array[265] = [47.600002, 4, 0]),
  (Song10_array[266] = [47.8, 3, 0]),
  (Song10_array[267] = [47.95, 5, 0]),
  (Song10_array[268] = [48.15, 1, 0]),
  (Song10_array[269] = [48.2, 1, 0]),
  (Song10_array[270] = [48.25, 1, 0]),
  (Song10_array[271] = [48.3, 1, 0]),
  (Song10_array[272] = [48.45, 3, 0]),
  (Song10_array[273] = [48.5, 3, 0]),
  (Song10_array[274] = [48.55, 3, 0]),
  (Song10_array[275] = [48.600002, 3, 0]),
  (Song10_array[276] = [48.75, 1, 0]),
  (Song10_array[277] = [48.75, 3, 0.05]),
  (Song10_array[278] = [49.100002, 5, 0]),
  (Song10_array[279] = [49.15, 5, 0]),
  (Song10_array[280] = [49.2, 5, 0]),
  (Song10_array[281] = [49.25, 5, 0]),
  (Song10_array[282] = [49.4, 3, 0]),
  (Song10_array[283] = [49.4, 5, 0.05]),
  (Song10_array[284] = [49.95, 5, 0]),
  (Song10_array[285] = [50.100002, 3, 0]),
  (Song10_array[286] = [50.25, 1, 0]),
  (Song10_array[287] = [50.45, 3, 0]),
  (Song10_array[288] = [50.65, 2, 0]),
  (Song10_array[289] = [50.850002, 4, 0]),
  (Song10_array[290] = [51.05, 3, 0]),
  (Song10_array[291] = [51.2, 5, 0]),
  (Song10_array[292] = [51.55, 1, 0]),
  (Song10_array[293] = [51.95, 5, 0]),
  (Song10_array[294] = [52.350002, 3, 0]),
  (Song10_array[295] = [52.350002, 5, 0.05]),
  (Song10_array[296] = [52.55, 1, 0]),
  (Song10_array[297] = [52.55, 3, 0.05]),
  (Song10_array[298] = [52.75, 3, 0]),
  (Song10_array[299] = [52.75, 5, 0.05]),
  (Song10_array[300] = [52.95, 1, 0]),
  (Song10_array[301] = [52.95, 3, 0.05]),
  (Song10_array[302] = [53.15, 4, 0]),
  (Song10_array[303] = [53.2, 4, 0]),
  (Song10_array[304] = [53.25, 4, 0]),
  (Song10_array[305] = [54.75, 5, 0]),
  (Song10_array[306] = [55.25, 1, 0]),
  (Song10_array[307] = [55.7, 3, 0]),
  (Song10_array[308] = [55.7, 5, 0.05]),
  (Song10_array[309] = [55.9, 1, 0]),
  (Song10_array[310] = [55.9, 3, 0.05]),
  (Song10_array[311] = [56.100002, 3, 0]),
  (Song10_array[312] = [56.100002, 5, 0.05]),
  (Song10_array[313] = [56.3, 1, 0]),
  (Song10_array[314] = [56.3, 3, 0.05]),
  (Song10_array[315] = [56.5, 4, 0]),
  (Song10_array[316] = [56.55, 4, 0]),
  (Song10_array[317] = [56.600002, 4, 0]),
  (Song10_array[318] = [58, 5, 0]),
  (Song10_array[319] = [58.5, 1, 0]),
  (Song10_array[320] = [58.95, 3, 0]),
  (Song10_array[321] = [58.95, 5, 0.05]),
  (Song10_array[322] = [59.15, 1, 0]),
  (Song10_array[323] = [59.15, 3, 0.05]),
  (Song10_array[324] = [59.350002, 3, 0]),
  (Song10_array[325] = [59.350002, 5, 0.05]),
  (Song10_array[326] = [59.55, 1, 0]),
  (Song10_array[327] = [59.55, 3, 0.05]),
  (Song10_array[328] = [59.75, 4, 0]),
  (Song10_array[329] = [59.8, 4, 0]),
  (Song10_array[330] = [59.850002, 4, 0]),
  (Song10_array[331] = [61.2, 5, 0]),
  (Song10_array[332] = [61.7, 1, 0]),
  (Song10_array[333] = [62.15, 3, 0]),
  (Song10_array[334] = [62.15, 5, 0.05]),
  (Song10_array[335] = [62.350002, 1, 0]),
  (Song10_array[336] = [62.350002, 3, 0.05]),
  (Song10_array[337] = [62.55, 3, 0]),
  (Song10_array[338] = [62.55, 5, 0.05]),
  (Song10_array[339] = [62.75, 1, 0]),
  (Song10_array[340] = [62.75, 3, 0.05]),
  (Song10_array[341] = [62.95, 4, 0]),
  (Song10_array[342] = [63, 4, 0]),
  (Song10_array[343] = [63.05, 4, 0]),
  (Song10_array[344] = [64.4, 5, 0]),
  (Song10_array[345] = [64.9, 1, 0]),
  (Song10_array[346] = [65.35, 3, 0]),
  (Song10_array[347] = [65.35, 5, 0.05]),
  (Song10_array[348] = [65.55, 1, 0]),
  (Song10_array[349] = [65.55, 3, 0.05]),
  (Song10_array[350] = [65.75, 3, 0]),
  (Song10_array[351] = [65.75, 5, 0.05]),
  (Song10_array[352] = [65.950005, 1, 0]),
  (Song10_array[353] = [65.950005, 3, 0.05]),
  (Song10_array[354] = [66.15, 4, 0]),
  (Song10_array[355] = [66.200005, 4, 0]),
  (Song10_array[356] = [66.25, 4, 0]),
  (Song10_array[357] = [67.65, 5, 0]),
  (Song10_array[358] = [68.15, 1, 0]),
  (Song10_array[359] = [68.6, 3, 0]),
  (Song10_array[360] = [68.6, 5, 0.05]),
  (Song10_array[361] = [68.8, 1, 0]),
  (Song10_array[362] = [68.8, 3, 0.05]),
  (Song10_array[363] = [69, 3, 0]),
  (Song10_array[364] = [69, 5, 0.05]),
  (Song10_array[365] = [69.200005, 1, 0]),
  (Song10_array[366] = [69.200005, 3, 0.05]),
  (Song10_array[367] = [69.4, 4, 0]),
  (Song10_array[368] = [69.450005, 4, 0]),
  (Song10_array[369] = [69.5, 4, 0]),
  (Song10_array[370] = [70.85, 5, 0]),
  (Song10_array[371] = [71.35, 1, 0]),
  (Song10_array[372] = [71.8, 3, 0]),
  (Song10_array[373] = [71.8, 5, 0.05]),
  (Song10_array[374] = [72, 1, 0]),
  (Song10_array[375] = [72, 3, 0.05]),
  (Song10_array[376] = [72.200005, 3, 0]),
  (Song10_array[377] = [72.200005, 5, 0.05]),
  (Song10_array[378] = [72.4, 1, 0]),
  (Song10_array[379] = [72.4, 3, 0.05]),
  (Song10_array[380] = [72.6, 4, 0]),
  (Song10_array[381] = [72.65, 4, 0]),
  (Song10_array[382] = [72.700005, 4, 0]),
  (Song10_array[383] = [74.1, 5, 0]),
  (Song10_array[384] = [74.6, 1, 0]),
  (Song10_array[385] = [75.05, 3, 0]),
  (Song10_array[386] = [75.05, 5, 0.05]),
  (Song10_array[387] = [75.25, 1, 0]),
  (Song10_array[388] = [75.25, 3, 0.05]),
  (Song10_array[389] = [75.450005, 3, 0]),
  (Song10_array[390] = [75.450005, 5, 0.05]),
  (Song10_array[391] = [75.65, 1, 0]),
  (Song10_array[392] = [75.65, 3, 0.05]),
  (Song10_array[393] = [75.85, 4, 0]),
  (Song10_array[394] = [75.9, 4, 0]),
  (Song10_array[395] = [75.950005, 4, 0]),
  (Song10_array[396] = [77.3, 3, 0]),
  (Song10_array[397] = [77.35, 3, 0]),
  (Song10_array[398] = [77.4, 3, 0]),
  (Song10_array[399] = [77.450005, 3, 0]),
  (Song10_array[400] = [77.6, 1, 0]),
  (Song10_array[401] = [77.6, 3, 0.05]),
  (Song10_array[402] = [77.950005, 5, 0]),
  (Song10_array[403] = [78, 5, 0]),
  (Song10_array[404] = [78.05, 5, 0]),
  (Song10_array[405] = [78.1, 5, 0]),
  (Song10_array[406] = [78.25, 3, 0]),
  (Song10_array[407] = [78.25, 5, 0.05]),
  (Song10_array[408] = [78.8, 5, 0]),
  (Song10_array[409] = [78.950005, 3, 0]),
  (Song10_array[410] = [79.1, 1, 0]),
  (Song10_array[411] = [79.3, 3, 0]),
  (Song10_array[412] = [79.5, 2, 0]),
  (Song10_array[413] = [79.700005, 4, 0]),
  (Song10_array[414] = [79.9, 3, 0]),
  (Song10_array[415] = [80.05, 5, 0]),
  (Song10_array[416] = [80.25, 1, 0]),
  (Song10_array[417] = [80.3, 1, 0]),
  (Song10_array[418] = [80.35, 1, 0]),
  (Song10_array[419] = [80.4, 1, 0]),
  (Song10_array[420] = [80.55, 3, 0]),
  (Song10_array[421] = [80.6, 3, 0]),
  (Song10_array[422] = [80.65, 3, 0]),
  (Song10_array[423] = [80.700005, 3, 0]),
  (Song10_array[424] = [80.85, 1, 0]),
  (Song10_array[425] = [80.85, 3, 0.05]),
  (Song10_array[426] = [81.200005, 5, 0]),
  (Song10_array[427] = [81.25, 5, 0]),
  (Song10_array[428] = [81.3, 5, 0]),
  (Song10_array[429] = [81.35, 5, 0]),
  (Song10_array[430] = [81.5, 3, 0]),
  (Song10_array[431] = [81.5, 5, 0.05]),
  (Song10_array[432] = [82.05, 5, 0]),
  (Song10_array[433] = [82.200005, 3, 0]),
  (Song10_array[434] = [82.35, 1, 0]),
  (Song10_array[435] = [82.55, 3, 0]),
  (Song10_array[436] = [82.75, 2, 0]),
  (Song10_array[437] = [82.950005, 4, 0]),
  (Song10_array[438] = [83.15, 3, 0]),
  (Song10_array[439] = [83.3, 5, 0]),
  (Song10_array[440] = [83.5, 1, 0]),
  (Song10_array[441] = [83.55, 1, 0]),
  (Song10_array[442] = [83.6, 1, 0]),
  (Song10_array[443] = [83.65, 1, 0]),
  (Song10_array[444] = [83.8, 3, 0]),
  (Song10_array[445] = [83.85, 3, 0]),
  (Song10_array[446] = [83.9, 3, 0]),
  (Song10_array[447] = [83.950005, 3, 0]),
  (Song10_array[448] = [84.1, 1, 0]),
  (Song10_array[449] = [84.1, 3, 0.05]),
  (Song10_array[450] = [84.450005, 5, 0]),
  (Song10_array[451] = [84.5, 5, 0]),
  (Song10_array[452] = [84.55, 5, 0]),
  (Song10_array[453] = [84.6, 5, 0]),
  (Song10_array[454] = [84.75, 3, 0]),
  (Song10_array[455] = [84.75, 5, 0.05]),
  (Song10_array[456] = [85.3, 5, 0]),
  (Song10_array[457] = [85.450005, 3, 0]),
  (Song10_array[458] = [85.6, 1, 0]),
  (Song10_array[459] = [85.8, 3, 0]),
  (Song10_array[460] = [86, 2, 0]),
  (Song10_array[461] = [86.200005, 4, 0]),
  (Song10_array[462] = [86.4, 3, 0]),
  (Song10_array[463] = [86.55, 5, 0]),
  (Song10_array[464] = [86.75, 1, 0]),
  (Song10_array[465] = [86.8, 1, 0]),
  (Song10_array[466] = [86.85, 1, 0]),
  (Song10_array[467] = [86.9, 1, 0]),
  (Song10_array[468] = [87.05, 3, 0]),
  (Song10_array[469] = [87.1, 3, 0]),
  (Song10_array[470] = [87.15, 3, 0]),
  (Song10_array[471] = [87.200005, 3, 0]),
  (Song10_array[472] = [87.35, 1, 0]),
  (Song10_array[473] = [87.35, 3, 0.05]),
  (Song10_array[474] = [87.700005, 5, 0]),
  (Song10_array[475] = [87.75, 5, 0]),
  (Song10_array[476] = [87.8, 5, 0]),
  (Song10_array[477] = [87.85, 5, 0]),
  (Song10_array[478] = [88, 3, 0]),
  (Song10_array[479] = [88, 5, 0.05]),
  (Song10_array[480] = [88.55, 5, 0]),
  (Song10_array[481] = [88.700005, 3, 0]),
  (Song10_array[482] = [88.85, 1, 0]),
  (Song10_array[483] = [89.05, 3, 0]),
  (Song10_array[484] = [89.25, 2, 0]),
  (Song10_array[485] = [89.450005, 4, 0]),
  (Song10_array[486] = [89.65, 3, 0]),
  (Song10_array[487] = [89.8, 5, 0]),
  (Song10_array[488] = [90.25, 1, 0.05]),
  (Song10_array[489] = [90.25, 3, 0]),
  (Song10_array[490] = [90.55, 3, 0.05]),
  (Song10_array[491] = [90.55, 5, 0]),
  (Song10_array[492] = [90.8, 2, 0]),
  (Song10_array[493] = [90.85, 2, 0]),
  (Song10_array[494] = [90.9, 2, 0]),
  (Song10_array[495] = [91.15, 1, 0.05]),
  (Song10_array[496] = [91.15, 3, 0]),
  (Song10_array[497] = [91.4, 1, 0]),
  (Song10_array[498] = [91.450005, 1, 0]),
  (Song10_array[499] = [91.5, 1, 0]),
  (Song10_array[500] = [91.700005, 3, 0]),
  (Song10_array[501] = [91.85, 2, 0]),
  (Song10_array[502] = [92, 5, 0]),
  (Song10_array[503] = [92.200005, 3, 0]),
  (Song10_array[504] = [92.200005, 5, 0.05]),
  (Song10_array[505] = [92.4, 3, 0.05]),
  (Song10_array[506] = [92.4, 5, 0]),
  (Song10_array[507] = [92.55, 2, 0]),
  (Song10_array[508] = [92.65, 1, 0]),
  (Song10_array[509] = [92.75, 2, 0]),
  (Song10_array[510] = [92.9, 4, 0]),
  (Song10_array[511] = [93.05, 3, 0]),
  (Song10_array[512] = [93.200005, 2, 0]),
  (Song10_array[513] = [93.3, 3, 0]),
  (Song10_array[514] = [93.450005, 3, 0.05]),
  (Song10_array[515] = [93.450005, 5, 0]),
  (Song10_array[516] = [93.75, 3, 0]),
  (Song10_array[517] = [93.75, 5, 0.05]),
  (Song10_array[518] = [94, 2, 0]),
  (Song10_array[519] = [94.05, 2, 0]),
  (Song10_array[520] = [94.1, 2, 0]),
  (Song10_array[521] = [94.35, 1, 0.05]),
  (Song10_array[522] = [94.35, 3, 0]),
  (Song10_array[523] = [94.6, 1, 0]),
  (Song10_array[524] = [94.65, 1, 0]),
  (Song10_array[525] = [94.700005, 1, 0]),
  (Song10_array[526] = [94.9, 3, 0]),
  (Song10_array[527] = [95.05, 2, 0]),
  (Song10_array[528] = [95.200005, 5, 0]),
  (Song10_array[529] = [95.4, 3, 0]),
  (Song10_array[530] = [95.4, 5, 0.05]),
  (Song10_array[531] = [95.6, 3, 0.05]),
  (Song10_array[532] = [95.6, 5, 0]),
  (Song10_array[533] = [95.75, 2, 0]),
  (Song10_array[534] = [95.85, 1, 0]),
  (Song10_array[535] = [95.950005, 2, 0]),
  (Song10_array[536] = [96.1, 4, 0]),
  (Song10_array[537] = [96.25, 3, 0]),
  (Song10_array[538] = [96.4, 2, 0]),
  (Song10_array[539] = [96.5, 4, 0]),
  (Song10_array[540] = [96.700005, 3, 0]),
  (Song10_array[541] = [96.75, 3, 0]),
  (Song10_array[542] = [96.8, 3, 0]),
  (Song10_array[543] = [96.85, 3, 0]),
  (Song10_array[544] = [97, 1, 0]),
  (Song10_array[545] = [97, 3, 0.05]),
  (Song10_array[546] = [97.35, 5, 0]),
  (Song10_array[547] = [97.4, 5, 0]),
  (Song10_array[548] = [97.450005, 5, 0]),
  (Song10_array[549] = [97.5, 5, 0]),
  (Song10_array[550] = [97.65, 3, 0]),
  (Song10_array[551] = [97.65, 5, 0.05]),
  (Song10_array[552] = [98.200005, 5, 0]),
  (Song10_array[553] = [98.35, 3, 0]),
  (Song10_array[554] = [98.5, 1, 0]),
  (Song10_array[555] = [98.700005, 3, 0]),
  (Song10_array[556] = [98.9, 2, 0]),
  (Song10_array[557] = [99.1, 4, 0]),
  (Song10_array[558] = [99.3, 3, 0]),
  (Song10_array[559] = [99.450005, 5, 0]),
  (Song10_array[560] = [99.65, 1, 0]),
  (Song10_array[561] = [99.700005, 1, 0]),
  (Song10_array[562] = [99.75, 1, 0]),
  (Song10_array[563] = [99.8, 1, 0]),
  (Song10_array[564] = [99.950005, 3, 0]),
  (Song10_array[565] = [100, 3, 0]),
  (Song10_array[566] = [100.05, 3, 0]),
  (Song10_array[567] = [100.1, 3, 0]),
  (Song10_array[568] = [100.25, 1, 0]),
  (Song10_array[569] = [100.25, 3, 0.05]),
  (Song10_array[570] = [100.6, 5, 0]),
  (Song10_array[571] = [100.65, 5, 0]),
  (Song10_array[572] = [100.700005, 5, 0]),
  (Song10_array[573] = [100.75, 5, 0]),
  (Song10_array[574] = [100.9, 3, 0]),
  (Song10_array[575] = [100.9, 5, 0.05]),
  (Song10_array[576] = [101.450005, 5, 0]),
  (Song10_array[577] = [101.6, 3, 0]),
  (Song10_array[578] = [101.75, 1, 0]),
  (Song10_array[579] = [101.950005, 3, 0]),
  (Song10_array[580] = [102.15, 2, 0]),
  (Song10_array[581] = [102.35, 4, 0]),
  (Song10_array[582] = [102.55, 3, 0]),
  (Song10_array[583] = [102.700005, 5, 0]),
  (Song10_array[584] = [102.9, 1, 0]),
  (Song10_array[585] = [102.950005, 1, 0]),
  (Song10_array[586] = [103, 1, 0]),
  (Song10_array[587] = [103.05, 1, 0]);
var Song9_array = [];
(Song9_array[0] = [0.35, 5, 0]),
  (Song9_array[1] = [0.55, 2, 0]),
  (Song9_array[2] = [0.8, 5, 0]),
  (Song9_array[3] = [1.0500001, 2, 0]),
  (Song9_array[4] = [1.3000001, 2, 0.05]),
  (Song9_array[5] = [1.3000001, 4, 0]),
  (Song9_array[6] = [1.6, 4, 0]),
  (Song9_array[7] = [1.85, 1, 0]),
  (Song9_array[8] = [2.1000001, 3, 0]),
  (Song9_array[9] = [2.3500001, 1, 0]),
  (Song9_array[10] = [2.6000001, 3, 0]),
  (Song9_array[11] = [2.6000001, 5, 0.05]),
  (Song9_array[12] = [2.9, 5, 0]),
  (Song9_array[13] = [3.15, 2, 0]),
  (Song9_array[14] = [3.4, 5, 0]),
  (Song9_array[15] = [3.65, 2, 0]),
  (Song9_array[16] = [3.95, 5, 0]),
  (Song9_array[17] = [4.3, 3, 0]),
  (Song9_array[18] = [4.55, 3, 0]),
  (Song9_array[19] = [4.85, 2, 0.05]),
  (Song9_array[20] = [4.85, 5, 0]),
  (Song9_array[21] = [5.1, 2, 0]),
  (Song9_array[22] = [5.35, 5, 0]),
  (Song9_array[23] = [5.6, 2, 0]),
  (Song9_array[24] = [5.8, 4, 0]),
  (Song9_array[25] = [6, 4, 0]),
  (Song9_array[26] = [6.3, 2, 0]),
  (Song9_array[27] = [6.6, 2, 0]),
  (Song9_array[28] = [6.85, 4, 0]),
  (Song9_array[29] = [7.05, 2, 0]),
  (Song9_array[30] = [7.05, 4, 0.05]),
  (Song9_array[31] = [7.15, 2, 0]),
  (Song9_array[32] = [7.15, 4, 0.05]),
  (Song9_array[33] = [7.25, 2, 0]),
  (Song9_array[34] = [7.25, 4, 0.05]),
  (Song9_array[35] = [7.4500003, 3, 0.05]),
  (Song9_array[36] = [7.4500003, 5, 0]),
  (Song9_array[37] = [7.55, 3, 0.05]),
  (Song9_array[38] = [7.55, 5, 0]),
  (Song9_array[39] = [7.65, 3, 0.05]),
  (Song9_array[40] = [7.65, 5, 0]),
  (Song9_array[41] = [7.85, 1, 0.05]),
  (Song9_array[42] = [7.85, 3, 0]),
  (Song9_array[43] = [7.95, 1, 0.05]),
  (Song9_array[44] = [7.9500003, 3, 0]),
  (Song9_array[45] = [8.05, 1, 0.05]),
  (Song9_array[46] = [8.05, 3, 0]),
  (Song9_array[47] = [8.25, 5, 0]),
  (Song9_array[48] = [8.5, 2, 0]),
  (Song9_array[49] = [8.55, 2, 0]),
  (Song9_array[50] = [8.6, 2, 0]),
  (Song9_array[51] = [8.650001, 2, 0]),
  (Song9_array[52] = [8.7, 2, 0]),
  (Song9_array[53] = [8.85, 5, 0]),
  (Song9_array[54] = [9.05, 4, 0]),
  (Song9_array[55] = [9.25, 5, 0]),
  (Song9_array[56] = [9.45, 2, 0]),
  (Song9_array[57] = [9.5, 2, 0]),
  (Song9_array[58] = [9.55, 2, 0]),
  (Song9_array[59] = [9.75, 5, 0]),
  (Song9_array[60] = [10.1, 2, 0]),
  (Song9_array[61] = [10.1, 5, 0.05]),
  (Song9_array[62] = [10.35, 5, 0]),
  (Song9_array[63] = [10.400001, 5, 0]),
  (Song9_array[64] = [10.45, 5, 0]),
  (Song9_array[65] = [10.5, 5, 0]),
  (Song9_array[66] = [10.55, 5, 0]),
  (Song9_array[67] = [10.6, 5, 0]),
  (Song9_array[68] = [10.650001, 5, 0]),
  (Song9_array[69] = [10.7, 5, 0]),
  (Song9_array[70] = [10.85, 3, 0]),
  (Song9_array[71] = [11.1, 1, 0]),
  (Song9_array[72] = [11.400001, 3, 0]),
  (Song9_array[73] = [11.7, 1, 0]),
  (Song9_array[74] = [11.900001, 4, 0]),
  (Song9_array[75] = [12.05, 4, 0]),
  (Song9_array[76] = [12.3, 2, 0]),
  (Song9_array[77] = [12.55, 2, 0]),
  (Song9_array[78] = [12.85, 5, 0]),
  (Song9_array[79] = [13.150001, 5, 0]),
  (Song9_array[80] = [13.35, 1, 0]),
  (Song9_array[81] = [13.5, 1, 0]),
  (Song9_array[82] = [13.7, 4, 0]),
  (Song9_array[83] = [13.95, 1, 0]),
  (Song9_array[84] = [14.25, 4, 0]),
  (Song9_array[85] = [14.55, 1, 0]),
  (Song9_array[86] = [14.75, 3, 0]),
  (Song9_array[87] = [14.900001, 3, 0]),
  (Song9_array[88] = [15.1, 5, 0]),
  (Song9_array[89] = [15.35, 5, 0]),
  (Song9_array[90] = [15.650001, 1, 0]),
  (Song9_array[91] = [15.95, 5, 0]),
  (Song9_array[92] = [16.15, 2, 0]),
  (Song9_array[93] = [16.300001, 2, 0]),
  (Song9_array[94] = [16.5, 5, 0]),
  (Song9_array[95] = [16.75, 1, 0]),
  (Song9_array[96] = [17.050001, 5, 0]),
  (Song9_array[97] = [17.35, 1, 0]),
  (Song9_array[98] = [17.550001, 3, 0]),
  (Song9_array[99] = [17.7, 3, 0]),
  (Song9_array[100] = [17.85, 1, 0]),
  (Song9_array[101] = [17.85, 3, 0.05]),
  (Song9_array[102] = [17.95, 1, 0]),
  (Song9_array[103] = [18.050001, 1, 0]),
  (Song9_array[104] = [18.050001, 3, 0.05]),
  (Song9_array[105] = [18.15, 3, 0]),
  (Song9_array[106] = [18.15, 5, 0.05]),
  (Song9_array[107] = [18.25, 3, 0]),
  (Song9_array[108] = [18.25, 5, 0.05]),
  (Song9_array[109] = [18.35, 3, 0]),
  (Song9_array[110] = [18.35, 5, 0.05]),
  (Song9_array[111] = [18.45, 3, 0]),
  (Song9_array[112] = [18.45, 5, 0.05]),
  (Song9_array[113] = [18.550001, 1, 0]),
  (Song9_array[114] = [18.550001, 3, 0.05]),
  (Song9_array[115] = [18.65, 1, 0]),
  (Song9_array[116] = [18.65, 3, 0.05]),
  (Song9_array[117] = [18.75, 5, 0]),
  (Song9_array[118] = [18.9, 3, 0]),
  (Song9_array[119] = [19, 1, 0]),
  (Song9_array[120] = [19.050001, 1, 0]),
  (Song9_array[121] = [19.1, 1, 0]),
  (Song9_array[122] = [19.15, 1, 0]),
  (Song9_array[123] = [19.2, 1, 0]),
  (Song9_array[124] = [19.25, 1, 0]),
  (Song9_array[125] = [19.4, 4, 0]),
  (Song9_array[126] = [19.550001, 4, 0]),
  (Song9_array[127] = [19.75, 2, 0]),
  (Song9_array[128] = [19.9, 2, 0]),
  (Song9_array[129] = [19.95, 2, 0]),
  (Song9_array[130] = [20, 2, 0]),
  (Song9_array[131] = [20.1, 5, 0]),
  (Song9_array[132] = [20.25, 2, 0]),
  (Song9_array[133] = [20.4, 2, 0]),
  (Song9_array[134] = [20.550001, 5, 0]),
  (Song9_array[135] = [20.6, 5, 0]),
  (Song9_array[136] = [20.65, 5, 0]),
  (Song9_array[137] = [20.7, 5, 0]),
  (Song9_array[138] = [20.75, 5, 0]),
  (Song9_array[139] = [20.9, 3, 0]),
  (Song9_array[140] = [20.95, 3, 0]),
  (Song9_array[141] = [21, 3, 0]),
  (Song9_array[142] = [21.3, 5, 0.05]),
  (Song9_array[143] = [21.550001, 5, 0]),
  (Song9_array[144] = [21.7, 1, 0]),
  (Song9_array[145] = [21.9, 5, 0]),
  (Song9_array[146] = [22.2, 1, 0]),
  (Song9_array[147] = [23, 1, 0]),
  (Song9_array[148] = [23.25, 5, 0]),
  (Song9_array[149] = [23.5, 1, 0]),
  (Song9_array[150] = [24.35, 5, 0]),
  (Song9_array[151] = [24.6, 1, 0]),
  (Song9_array[152] = [24.85, 5, 0]),
  (Song9_array[153] = [25.15, 3, 0]),
  (Song9_array[154] = [25.6, 5, 0]),
  (Song9_array[155] = [26.300001, 1, 0]),
  (Song9_array[156] = [26.300001, 3, 0.05]),
  (Song9_array[157] = [26.95, 5, 0]),
  (Song9_array[158] = [27.1, 1, 0]),
  (Song9_array[159] = [27.300001, 5, 0]),
  (Song9_array[160] = [27.6, 1, 0]),
  (Song9_array[161] = [28.4, 1, 0]),
  (Song9_array[162] = [28.4, 3, 0.05]),
  (Song9_array[163] = [28.5, 1, 0]),
  (Song9_array[164] = [28.5, 3, 0.05]),
  (Song9_array[165] = [28.6, 1, 0]),
  (Song9_array[166] = [28.6, 3, 0.05]),
  (Song9_array[167] = [28.7, 3, 0]),
  (Song9_array[168] = [28.800001, 3, 0.05]),
  (Song9_array[169] = [28.800001, 5, 0]),
  (Song9_array[170] = [28.9, 3, 0.05]),
  (Song9_array[171] = [28.9, 5, 0]),
  (Song9_array[172] = [29, 3, 0.05]),
  (Song9_array[173] = [29, 5, 0]),
  (Song9_array[174] = [29.15, 1, 0.05]),
  (Song9_array[175] = [29.15, 3, 0]),
  (Song9_array[176] = [29.25, 1, 0.05]),
  (Song9_array[177] = [29.25, 3, 0]),
  (Song9_array[178] = [29.35, 1, 0.05]),
  (Song9_array[179] = [29.35, 3, 0]),
  (Song9_array[180] = [29.550001, 1, 0]),
  (Song9_array[181] = [29.7, 5, 0]),
  (Song9_array[182] = [29.75, 5, 0]),
  (Song9_array[183] = [29.800001, 5, 0]),
  (Song9_array[184] = [29.85, 5, 0]),
  (Song9_array[185] = [29.9, 5, 0]),
  (Song9_array[186] = [30.050001, 1, 0]),
  (Song9_array[187] = [30.35, 5, 0]),
  (Song9_array[188] = [30.65, 1, 0]),
  (Song9_array[189] = [30.7, 1, 0]),
  (Song9_array[190] = [30.75, 1, 0]),
  (Song9_array[191] = [30.95, 5, 0]),
  (Song9_array[192] = [31.15, 1, 0.05]),
  (Song9_array[193] = [31.15, 3, 0]),
  (Song9_array[194] = [31.25, 3, 0]),
  (Song9_array[195] = [31.250002, 1, 0.05]),
  (Song9_array[196] = [31.35, 3, 0]),
  (Song9_array[197] = [31.350002, 1, 0.05]),
  (Song9_array[198] = [31.5, 3, 0.05]),
  (Song9_array[199] = [31.5, 5, 0]),
  (Song9_array[200] = [31.6, 3, 0.05]),
  (Song9_array[201] = [31.6, 5, 0]),
  (Song9_array[202] = [31.7, 5, 0]),
  (Song9_array[203] = [32.25, 5, 0]),
  (Song9_array[204] = [32.4, 1, 0]),
  (Song9_array[205] = [32.600002, 5, 0]),
  (Song9_array[206] = [32.9, 1, 0]),
  (Song9_array[207] = [33.4, 5, 0.05]),
  (Song9_array[208] = [33.7, 5, 0]),
  (Song9_array[209] = [33.95, 1, 0]),
  (Song9_array[210] = [34.2, 5, 0]),
  (Song9_array[211] = [35.05, 2, 0]),
  (Song9_array[212] = [35.3, 5, 0]),
  (Song9_array[213] = [35.55, 2, 0]),
  (Song9_array[214] = [35.850002, 1, 0]),
  (Song9_array[215] = [36.3, 5, 0]),
  (Song9_array[216] = [37, 1, 0]),
  (Song9_array[217] = [37.65, 5, 0]),
  (Song9_array[218] = [37.8, 1, 0]),
  (Song9_array[219] = [38, 5, 0]),
  (Song9_array[220] = [38.3, 1, 0]),
  (Song9_array[221] = [39.100002, 1, 0]),
  (Song9_array[222] = [39.100002, 3, 0.05]),
  (Song9_array[223] = [39.2, 1, 0]),
  (Song9_array[224] = [39.2, 3, 0.05]),
  (Song9_array[225] = [39.3, 1, 0]),
  (Song9_array[226] = [39.3, 3, 0.05]),
  (Song9_array[227] = [39.4, 3, 0]),
  (Song9_array[228] = [39.5, 3, 0.05]),
  (Song9_array[229] = [39.5, 5, 0]),
  (Song9_array[230] = [39.600002, 3, 0.05]),
  (Song9_array[231] = [39.600002, 5, 0]),
  (Song9_array[232] = [39.7, 3, 0.05]),
  (Song9_array[233] = [39.7, 5, 0]),
  (Song9_array[234] = [39.850002, 1, 0.05]),
  (Song9_array[235] = [39.850002, 3, 0]),
  (Song9_array[236] = [39.95, 1, 0.05]),
  (Song9_array[237] = [39.95, 3, 0]),
  (Song9_array[238] = [40.05, 1, 0.05]),
  (Song9_array[239] = [40.05, 3, 0]),
  (Song9_array[240] = [40.25, 1, 0]),
  (Song9_array[241] = [40.4, 5, 0]),
  (Song9_array[242] = [40.45, 5, 0]),
  (Song9_array[243] = [40.5, 5, 0]),
  (Song9_array[244] = [40.55, 5, 0]),
  (Song9_array[245] = [40.600002, 5, 0]),
  (Song9_array[246] = [40.75, 1, 0]),
  (Song9_array[247] = [41.05, 5, 0]),
  (Song9_array[248] = [41.350002, 1, 0]),
  (Song9_array[249] = [41.4, 1, 0]),
  (Song9_array[250] = [41.45, 1, 0]),
  (Song9_array[251] = [41.65, 5, 0]),
  (Song9_array[252] = [41.850002, 1, 0.05]),
  (Song9_array[253] = [41.850002, 3, 0]),
  (Song9_array[254] = [41.95, 1, 0.05]),
  (Song9_array[255] = [41.95, 3, 0]),
  (Song9_array[256] = [42.05, 3, 0]),
  (Song9_array[257] = [42.050003, 1, 0.05]),
  (Song9_array[258] = [42.2, 3, 0.05]),
  (Song9_array[259] = [42.2, 5, 0]),
  (Song9_array[260] = [42.3, 3, 0.05]),
  (Song9_array[261] = [42.3, 5, 0]),
  (Song9_array[262] = [42.4, 5, 0]),
  (Song9_array[263] = [42.5, 3, 0]),
  (Song9_array[264] = [42.55, 3, 0]),
  (Song9_array[265] = [42.600002, 3, 0]),
  (Song9_array[266] = [42.65, 3, 0]),
  (Song9_array[267] = [42.7, 3, 0]),
  (Song9_array[268] = [42.8, 1, 0]),
  (Song9_array[269] = [42.850002, 1, 0]),
  (Song9_array[270] = [42.9, 1, 0]),
  (Song9_array[271] = [43, 5, 0]),
  (Song9_array[272] = [43.3, 1, 0]),
  (Song9_array[273] = [43.75, 4, 0]),
  (Song9_array[274] = [44.100002, 1, 0]),
  (Song9_array[275] = [44.65, 4, 0]),
  (Song9_array[276] = [45, 1, 0]),
  (Song9_array[277] = [45.350002, 4, 0]),
  (Song9_array[278] = [45.7, 1, 0]),
  (Song9_array[279] = [46.15, 3, 0]),
  (Song9_array[280] = [46.95, 5, 0]),
  (Song9_array[281] = [47.350002, 1, 0]),
  (Song9_array[282] = [47.75, 5, 0]),
  (Song9_array[283] = [48.100002, 1, 0]),
  (Song9_array[284] = [48.4, 5, 0]),
  (Song9_array[285] = [48.75, 1, 0]),
  (Song9_array[286] = [49.2, 5, 0]),
  (Song9_array[287] = [49.45, 1, 0]),
  (Song9_array[288] = [49.75, 1, 0.05]),
  (Song9_array[289] = [49.75, 3, 0]),
  (Song9_array[290] = [49.850002, 1, 0.05]),
  (Song9_array[291] = [49.850002, 3, 0]),
  (Song9_array[292] = [49.95, 1, 0.05]),
  (Song9_array[293] = [49.95, 3, 0]),
  (Song9_array[294] = [50.05, 1, 0.05]),
  (Song9_array[295] = [50.05, 3, 0]),
  (Song9_array[296] = [50.15, 3, 0.05]),
  (Song9_array[297] = [50.15, 5, 0]),
  (Song9_array[298] = [50.25, 5, 0]),
  (Song9_array[299] = [50.350002, 3, 0.05]),
  (Song9_array[300] = [50.350002, 5, 0]),
  (Song9_array[301] = [50.5, 1, 0.05]),
  (Song9_array[302] = [50.5, 3, 0]),
  (Song9_array[303] = [50.65, 1, 0.05]),
  (Song9_array[304] = [50.65, 3, 0]),
  (Song9_array[305] = [50.75, 3, 0]),
  (Song9_array[306] = [50.750004, 1, 0.05]),
  (Song9_array[307] = [50.9, 5, 0]),
  (Song9_array[308] = [51.100002, 1, 0]),
  (Song9_array[309] = [51.15, 1, 0]),
  (Song9_array[310] = [51.2, 1, 0]),
  (Song9_array[311] = [51.25, 1, 0]),
  (Song9_array[312] = [51.3, 1, 0]),
  (Song9_array[313] = [51.55, 4, 0]),
  (Song9_array[314] = [51.75, 1, 0]),
  (Song9_array[315] = [52, 5, 0]),
  (Song9_array[316] = [52.05, 5, 0]),
  (Song9_array[317] = [52.100002, 5, 0]),
  (Song9_array[318] = [52.25, 2, 0.05]),
  (Song9_array[319] = [52.25, 4, 0]),
  (Song9_array[320] = [52.350002, 2, 0.05]),
  (Song9_array[321] = [52.350002, 4, 0]),
  (Song9_array[322] = [52.45, 2, 0.05]),
  (Song9_array[323] = [52.45, 4, 0]),
  (Song9_array[324] = [52.55, 2, 0.05]),
  (Song9_array[325] = [52.55, 4, 0]),
  (Song9_array[326] = [52.7, 1, 0.05]),
  (Song9_array[327] = [52.7, 3, 0]),
  (Song9_array[328] = [52.8, 1, 0.05]),
  (Song9_array[329] = [52.8, 3, 0]),
  (Song9_array[330] = [52.9, 1, 0.05]),
  (Song9_array[331] = [52.9, 3, 0]),
  (Song9_array[332] = [53.05, 5, 0]),
  (Song9_array[333] = [53.100002, 5, 0]),
  (Song9_array[334] = [53.15, 5, 0]),
  (Song9_array[335] = [53.2, 5, 0]),
  (Song9_array[336] = [53.25, 5, 0]),
  (Song9_array[337] = [53.350002, 3, 0]),
  (Song9_array[338] = [53.4, 3, 0]),
  (Song9_array[339] = [53.45, 3, 0]),
  (Song9_array[340] = [53.600002, 1, 0]),
  (Song9_array[341] = [53.75, 5, 0]),
  (Song9_array[342] = [53.95, 1, 0]),
  (Song9_array[343] = [54.25, 5, 0]),
  (Song9_array[344] = [54.75, 4, 0.05]),
  (Song9_array[345] = [55.05, 4, 0]),
  (Song9_array[346] = [55.3, 1, 0]),
  (Song9_array[347] = [55.55, 4, 0]),
  (Song9_array[348] = [56.4, 2, 0]),
  (Song9_array[349] = [56.4, 5, 0.05]),
  (Song9_array[350] = [56.65, 5, 0]),
  (Song9_array[351] = [56.9, 2, 0]),
  (Song9_array[352] = [57.2, 5, 0]),
  (Song9_array[353] = [57.65, 2, 0]),
  (Song9_array[354] = [58.350002, 2, 0.05]),
  (Song9_array[355] = [58.350002, 5, 0]),
  (Song9_array[356] = [59, 2, 0]),
  (Song9_array[357] = [59.15, 5, 0]),
  (Song9_array[358] = [59.350002, 2, 0]),
  (Song9_array[359] = [59.65, 5, 0]),
  (Song9_array[360] = [60.45, 1, 0]),
  (Song9_array[361] = [60.45, 3, 0.05]),
  (Song9_array[362] = [60.55, 1, 0]),
  (Song9_array[363] = [60.55, 3, 0.05]),
  (Song9_array[364] = [60.65, 1, 0]),
  (Song9_array[365] = [60.65, 3, 0.05]),
  (Song9_array[366] = [60.75, 3, 0]),
  (Song9_array[367] = [60.850002, 3, 0.05]),
  (Song9_array[368] = [60.850002, 5, 0]),
  (Song9_array[369] = [60.95, 3, 0.05]),
  (Song9_array[370] = [60.95, 5, 0]),
  (Song9_array[371] = [61.05, 3, 0.05]),
  (Song9_array[372] = [61.05, 5, 0]),
  (Song9_array[373] = [61.2, 1, 0.05]),
  (Song9_array[374] = [61.2, 3, 0]),
  (Song9_array[375] = [61.3, 3, 0]),
  (Song9_array[376] = [61.300003, 1, 0.05]),
  (Song9_array[377] = [61.4, 1, 0.05]),
  (Song9_array[378] = [61.4, 3, 0]),
  (Song9_array[379] = [61.600002, 1, 0]),
  (Song9_array[380] = [61.75, 5, 0]),
  (Song9_array[381] = [61.8, 5, 0]),
  (Song9_array[382] = [61.850002, 5, 0]),
  (Song9_array[383] = [61.9, 5, 0]),
  (Song9_array[384] = [61.95, 5, 0]),
  (Song9_array[385] = [62.100002, 1, 0]),
  (Song9_array[386] = [62.4, 5, 0]),
  (Song9_array[387] = [62.7, 1, 0]),
  (Song9_array[388] = [62.75, 1, 0]),
  (Song9_array[389] = [62.8, 1, 0]),
  (Song9_array[390] = [63, 5, 0]),
  (Song9_array[391] = [63.2, 1, 0.05]),
  (Song9_array[392] = [63.2, 3, 0]),
  (Song9_array[393] = [63.3, 3, 0]),
  (Song9_array[394] = [63.300003, 1, 0.05]),
  (Song9_array[395] = [63.4, 1, 0.05]),
  (Song9_array[396] = [63.4, 3, 0]),
  (Song9_array[397] = [63.55, 3, 0.05]),
  (Song9_array[398] = [63.55, 5, 0]),
  (Song9_array[399] = [63.65, 3, 0.05]),
  (Song9_array[400] = [63.65, 5, 0]),
  (Song9_array[401] = [63.75, 3, 0.05]),
  (Song9_array[402] = [63.75, 5, 0]),
  (Song9_array[403] = [64.4, 5, 0]),
  (Song9_array[404] = [64.700005, 1, 0]),
  (Song9_array[405] = [65.15, 5, 0]),
  (Song9_array[406] = [65.5, 1, 0]),
  (Song9_array[407] = [65.75, 5, 0.05]),
  (Song9_array[408] = [66.05, 5, 0]),
  (Song9_array[409] = [66.4, 1, 0]),
  (Song9_array[410] = [66.75, 5, 0]),
  (Song9_array[411] = [67.1, 2, 0]),
  (Song9_array[412] = [67.55, 5, 0]),
  (Song9_array[413] = [68.35, 2, 0]),
  (Song9_array[414] = [68.35, 5, 0.05]),
  (Song9_array[415] = [68.75, 5, 0]),
  (Song9_array[416] = [69.15, 1, 0]),
  (Song9_array[417] = [69.5, 5, 0]),
  (Song9_array[418] = [69.8, 1, 0]),
  (Song9_array[419] = [70.15, 5, 0]),
  (Song9_array[420] = [70.6, 1, 0]),
  (Song9_array[421] = [70.85, 5, 0]),
  (Song9_array[422] = [71.15, 1, 0.05]),
  (Song9_array[423] = [71.15, 3, 0]),
  (Song9_array[424] = [71.25, 1, 0.05]),
  (Song9_array[425] = [71.25, 3, 0]),
  (Song9_array[426] = [71.35, 1, 0.05]),
  (Song9_array[427] = [71.35, 3, 0]),
  (Song9_array[428] = [71.450005, 3, 0]),
  (Song9_array[429] = [71.55, 3, 0.05]),
  (Song9_array[430] = [71.55, 5, 0]),
  (Song9_array[431] = [71.65, 3, 0.05]),
  (Song9_array[432] = [71.65, 5, 0]),
  (Song9_array[433] = [71.75, 3, 0.05]),
  (Song9_array[434] = [71.75, 5, 0]),
  (Song9_array[435] = [71.9, 1, 0.05]),
  (Song9_array[436] = [71.9, 3, 0]),
  (Song9_array[437] = [72.049995, 1, 0.05]),
  (Song9_array[438] = [72.05, 3, 0]),
  (Song9_array[439] = [72.149994, 1, 0.05]),
  (Song9_array[440] = [72.15, 3, 0]),
  (Song9_array[441] = [72.3, 5, 0]),
  (Song9_array[442] = [72.5, 1, 0]),
  (Song9_array[443] = [72.55, 1, 0]),
  (Song9_array[444] = [72.6, 1, 0]),
  (Song9_array[445] = [72.65, 1, 0]),
  (Song9_array[446] = [72.700005, 1, 0]),
  (Song9_array[447] = [72.950005, 5, 0]),
  (Song9_array[448] = [73.15, 1, 0]),
  (Song9_array[449] = [73.4, 3, 0]),
  (Song9_array[450] = [73.450005, 3, 0]),
  (Song9_array[451] = [73.5, 3, 0]),
  (Song9_array[452] = [73.65, 3, 0]),
  (Song9_array[453] = [73.75, 3, 0.05]),
  (Song9_array[454] = [73.75, 5, 0]),
  (Song9_array[455] = [73.85, 3, 0.05]),
  (Song9_array[456] = [73.85, 5, 0]),
  (Song9_array[457] = [73.950005, 3, 0.05]),
  (Song9_array[458] = [73.950005, 5, 0]),
  (Song9_array[459] = [74.1, 1, 0.05]),
  (Song9_array[460] = [74.1, 3, 0]),
  (Song9_array[461] = [74.200005, 1, 0.05]),
  (Song9_array[462] = [74.200005, 3, 0]),
  (Song9_array[463] = [74.3, 1, 0.05]),
  (Song9_array[464] = [74.3, 3, 0]),
  (Song9_array[465] = [74.450005, 5, 0]),
  (Song9_array[466] = [74.5, 5, 0]),
  (Song9_array[467] = [74.55, 5, 0]),
  (Song9_array[468] = [74.6, 5, 0]),
  (Song9_array[469] = [74.65, 5, 0]),
  (Song9_array[470] = [74.75, 2, 0]),
  (Song9_array[471] = [74.8, 2, 0]),
  (Song9_array[472] = [74.85, 2, 0]),
  (Song9_array[473] = [75.05, 5, 0]),
  (Song9_array[474] = [75.35, 1, 0]),
  (Song9_array[475] = [75.8, 5, 0]),
  (Song9_array[476] = [76.15, 1, 0]),
  (Song9_array[477] = [76.450005, 5, 0.05]),
  (Song9_array[478] = [76.700005, 5, 0]),
  (Song9_array[479] = [77.05, 1, 0]),
  (Song9_array[480] = [77.4, 5, 0]),
  (Song9_array[481] = [77.75, 5, 0]),
  (Song9_array[482] = [78.200005, 1, 0]),
  (Song9_array[483] = [79, 2, 0.05]),
  (Song9_array[484] = [79, 5, 0]),
  (Song9_array[485] = [79.4, 1, 0]),
  (Song9_array[486] = [79.8, 5, 0]),
  (Song9_array[487] = [80.15, 1, 0]),
  (Song9_array[488] = [80.450005, 5, 0]),
  (Song9_array[489] = [80.8, 1, 0]),
  (Song9_array[490] = [81.25, 5, 0]),
  (Song9_array[491] = [81.5, 2, 0]),
  (Song9_array[492] = [81.8, 1, 0.05]),
  (Song9_array[493] = [81.8, 3, 0]),
  (Song9_array[494] = [81.9, 1, 0.05]),
  (Song9_array[495] = [81.9, 3, 0]),
  (Song9_array[496] = [82, 1, 0.05]),
  (Song9_array[497] = [82, 3, 0]),
  (Song9_array[498] = [82.1, 3, 0]),
  (Song9_array[499] = [82.200005, 3, 0.05]),
  (Song9_array[500] = [82.200005, 5, 0]),
  (Song9_array[501] = [82.3, 3, 0.05]),
  (Song9_array[502] = [82.3, 5, 0]),
  (Song9_array[503] = [82.4, 3, 0.05]),
  (Song9_array[504] = [82.4, 5, 0]),
  (Song9_array[505] = [82.55, 1, 0.05]),
  (Song9_array[506] = [82.55, 3, 0]),
  (Song9_array[507] = [82.700005, 1, 0.05]),
  (Song9_array[508] = [82.700005, 3, 0]),
  (Song9_array[509] = [82.8, 3, 0]),
  (Song9_array[510] = [82.950005, 5, 0]),
  (Song9_array[511] = [83.15, 1, 0]),
  (Song9_array[512] = [83.200005, 1, 0]),
  (Song9_array[513] = [83.25, 1, 0]),
  (Song9_array[514] = [83.3, 1, 0]),
  (Song9_array[515] = [83.35, 1, 0]),
  (Song9_array[516] = [83.6, 5, 0]),
  (Song9_array[517] = [83.8, 3, 0]),
  (Song9_array[518] = [84.05, 5, 0]),
  (Song9_array[519] = [84.1, 5, 0]),
  (Song9_array[520] = [84.15, 5, 0]),
  (Song9_array[521] = [84.3, 3, 0]),
  (Song9_array[522] = [84.4, 1, 0.05]),
  (Song9_array[523] = [84.4, 3, 0]),
  (Song9_array[524] = [84.4, 5, 0.05]),
  (Song9_array[525] = [84.5, 1, 0.05]),
  (Song9_array[526] = [84.5, 3, 0]),
  (Song9_array[527] = [84.5, 5, 0.05]),
  (Song9_array[528] = [84.6, 1, 0.05]),
  (Song9_array[529] = [84.6, 3, 0]),
  (Song9_array[530] = [84.6, 5, 0.05]),
  (Song9_array[531] = [84.75, 3, 0.05]),
  (Song9_array[532] = [84.75, 5, 0]),
  (Song9_array[533] = [84.85, 3, 0.05]),
  (Song9_array[534] = [84.85, 5, 0]),
  (Song9_array[535] = [84.950005, 3, 0.05]),
  (Song9_array[536] = [84.950005, 5, 0]),
  (Song9_array[537] = [85.1, 3, 0]),
  (Song9_array[538] = [85.15, 3, 0]),
  (Song9_array[539] = [85.200005, 3, 0]),
  (Song9_array[540] = [85.25, 3, 0]),
  (Song9_array[541] = [85.3, 3, 0]),
  (Song9_array[542] = [85.4, 1, 0]),
  (Song9_array[543] = [85.450005, 1, 0]),
  (Song9_array[544] = [85.5, 1, 0]),
  (Song9_array[545] = [85.65, 5, 0]),
  (Song9_array[546] = [85.950005, 1, 0]),
  (Song9_array[547] = [86.4, 3, 0.05]),
  (Song9_array[548] = [86.4, 5, 0]),
  (Song9_array[549] = [86.75, 1, 0]),
  (Song9_array[550] = [87.299995, 3, 0.05]),
  (Song9_array[551] = [87.3, 5, 0]),
  (Song9_array[552] = [87.65, 1, 0]),
  (Song9_array[553] = [88, 5, 0]),
  (Song9_array[554] = [88.35, 3, 0]),
  (Song9_array[555] = [88.8, 1, 0]),
  (Song9_array[556] = [89.6, 5, 0]),
  (Song9_array[557] = [90, 1, 0]),
  (Song9_array[558] = [90.4, 5, 0]),
  (Song9_array[559] = [90.75, 1, 0]),
  (Song9_array[560] = [91.05, 5, 0]),
  (Song9_array[561] = [91.4, 1, 0]),
  (Song9_array[562] = [91.85, 5, 0]),
  (Song9_array[563] = [92.1, 2, 0]),
  (Song9_array[564] = [92.4, 1, 0.05]),
  (Song9_array[565] = [92.4, 3, 0]),
  (Song9_array[566] = [92.5, 1, 0.05]),
  (Song9_array[567] = [92.5, 3, 0]),
  (Song9_array[568] = [92.6, 1, 0.05]),
  (Song9_array[569] = [92.6, 3, 0]),
  (Song9_array[570] = [92.700005, 3, 0]),
  (Song9_array[571] = [92.8, 3, 0.05]),
  (Song9_array[572] = [92.8, 5, 0]),
  (Song9_array[573] = [92.9, 3, 0.05]),
  (Song9_array[574] = [92.9, 5, 0]),
  (Song9_array[575] = [93, 3, 0.05]),
  (Song9_array[576] = [93, 5, 0]),
  (Song9_array[577] = [93.15, 3, 0.05]),
  (Song9_array[578] = [93.15, 5, 0]),
  (Song9_array[579] = [93.3, 3, 0.05]),
  (Song9_array[580] = [93.3, 5, 0]),
  (Song9_array[581] = [93.4, 3, 0.05]),
  (Song9_array[582] = [93.4, 5, 0]),
  (Song9_array[583] = [93.55, 3, 0]),
  (Song9_array[584] = [93.75, 1, 0]),
  (Song9_array[585] = [93.8, 1, 0]),
  (Song9_array[586] = [93.85, 1, 0]),
  (Song9_array[587] = [93.9, 1, 0]),
  (Song9_array[588] = [93.950005, 1, 0]),
  (Song9_array[589] = [94.200005, 5, 0]),
  (Song9_array[590] = [94.4, 2, 0]),
  (Song9_array[591] = [94.65, 5, 0]),
  (Song9_array[592] = [94.700005, 5, 0]),
  (Song9_array[593] = [94.75, 5, 0]),
  (Song9_array[594] = [94.9, 3, 0]),
  (Song9_array[595] = [95, 1, 0.05]),
  (Song9_array[596] = [95, 3, 0]),
  (Song9_array[597] = [95, 5, 0.05]),
  (Song9_array[598] = [95.1, 1, 0.05]),
  (Song9_array[599] = [95.1, 3, 0]),
  (Song9_array[600] = [95.1, 5, 0.05]),
  (Song9_array[601] = [95.200005, 1, 0.05]),
  (Song9_array[602] = [95.200005, 3, 0]),
  (Song9_array[603] = [95.200005, 5, 0.05]),
  (Song9_array[604] = [95.35, 3, 0.05]),
  (Song9_array[605] = [95.35, 5, 0]),
  (Song9_array[606] = [95.450005, 3, 0.05]),
  (Song9_array[607] = [95.450005, 5, 0]),
  (Song9_array[608] = [95.55, 3, 0.05]),
  (Song9_array[609] = [95.55, 5, 0]),
  (Song9_array[610] = [95.700005, 1, 0]),
  (Song9_array[611] = [95.75, 1, 0]),
  (Song9_array[612] = [95.8, 1, 0]),
  (Song9_array[613] = [95.85, 1, 0]),
  (Song9_array[614] = [95.9, 1, 0]),
  (Song9_array[615] = [96, 4, 0]),
  (Song9_array[616] = [96.00001, 2, 0.05]),
  (Song9_array[617] = [96.05, 4, 0]),
  (Song9_array[618] = [96.1, 2, 0.05]),
  (Song9_array[619] = [96.1, 4, 0]);
var Song11_array = [];
(Song11_array[0] = [0.2, 3, 0]),
  (Song11_array[1] = [0.55, 5, 0]),
  (Song11_array[2] = [0.85, 1, 0]),
  (Song11_array[3] = [1.1, 3, 0]),
  (Song11_array[4] = [1.35, 1, 0]),
  (Song11_array[5] = [1.6, 4, 0]),
  (Song11_array[6] = [1.75, 4, 0]),
  (Song11_array[7] = [1.9, 4, 0]),
  (Song11_array[8] = [2.05, 2, 0]),
  (Song11_array[9] = [2.15, 2, 0]),
  (Song11_array[10] = [2.25, 2, 0]),
  (Song11_array[11] = [2.4, 4, 0]),
  (Song11_array[12] = [2.6000001, 4, 0]),
  (Song11_array[13] = [2.95, 2, 0]),
  (Song11_array[14] = [3.1000001, 2, 0]),
  (Song11_array[15] = [3.4, 2, 0]),
  (Song11_array[16] = [3.75, 4, 0]),
  (Song11_array[17] = [3.95, 4, 0]),
  (Song11_array[18] = [4.25, 1, 0]),
  (Song11_array[19] = [4.35, 1, 0]),
  (Song11_array[20] = [4.4500003, 1, 0]),
  (Song11_array[21] = [4.65, 1, 0]),
  (Song11_array[22] = [5, 5, 0]),
  (Song11_array[23] = [5.2000003, 5, 0]),
  (Song11_array[24] = [5.4, 5, 0]),
  (Song11_array[25] = [5.65, 1, 0]),
  (Song11_array[26] = [5.9, 1, 0]),
  (Song11_array[27] = [6.4500003, 3, 0]),
  (Song11_array[28] = [6.55, 3, 0]),
  (Song11_array[29] = [6.65, 3, 0]),
  (Song11_array[30] = [7.05, 5, 0]),
  (Song11_array[31] = [7.4500003, 5, 0]),
  (Song11_array[32] = [7.9500003, 2, 0]),
  (Song11_array[33] = [8.2, 2, 0]),
  (Song11_array[34] = [8.400001, 4, 0]),
  (Song11_array[35] = [8.6, 2, 0]),
  (Song11_array[36] = [8.7, 2, 0]),
  (Song11_array[37] = [8.8, 2, 0]),
  (Song11_array[38] = [9.1, 5, 0]),
  (Song11_array[39] = [9.2, 3, 0]),
  (Song11_array[40] = [9.400001, 5, 0]),
  (Song11_array[41] = [9.6, 3, 0]),
  (Song11_array[42] = [9.95, 1, 0]),
  (Song11_array[43] = [10.2, 5, 0]),
  (Song11_array[44] = [10.5, 1, 0]),
  (Song11_array[45] = [10.8, 5, 0]),
  (Song11_array[46] = [11.05, 1, 0]),
  (Song11_array[47] = [11.35, 3, 0]),
  (Song11_array[48] = [11.6, 1, 0]),
  (Song11_array[49] = [11.900001, 3, 0]),
  (Song11_array[50] = [12.1, 1, 0]),
  (Song11_array[51] = [12.400001, 3, 0]),
  (Song11_array[52] = [12.85, 1, 0]),
  (Song11_array[53] = [12.95, 1, 0]),
  (Song11_array[54] = [13.05, 1, 0]),
  (Song11_array[55] = [13.25, 3, 0]),
  (Song11_array[56] = [13.55, 4, 0]),
  (Song11_array[57] = [13.95, 2, 0]),
  (Song11_array[58] = [14.1, 5, 0]),
  (Song11_array[59] = [14.3, 2, 0]),
  (Song11_array[60] = [14.55, 5, 0]),
  (Song11_array[61] = [14.8, 2, 0]),
  (Song11_array[62] = [15.2, 4, 0]),
  (Song11_array[63] = [15.75, 1, 0]),
  (Song11_array[64] = [15.900001, 4, 0]),
  (Song11_array[65] = [16.15, 1, 0]),
  (Song11_array[66] = [16.45, 1, 0]),
  (Song11_array[67] = [16.65, 4, 0]),
  (Song11_array[68] = [16.85, 1, 0]),
  (Song11_array[69] = [17.15, 1, 0]),
  (Song11_array[70] = [17.300001, 4, 0]),
  (Song11_array[71] = [17.550001, 1, 0]),
  (Song11_array[72] = [17.85, 5, 0]),
  (Song11_array[73] = [18.050001, 1, 0]),
  (Song11_array[74] = [18.25, 2, 0]),
  (Song11_array[75] = [18.6, 5, 0]),
  (Song11_array[76] = [18.800001, 1, 0]),
  (Song11_array[77] = [19, 2, 0]),
  (Song11_array[78] = [19.300001, 5, 0]),
  (Song11_array[79] = [19.5, 1, 0]),
  (Song11_array[80] = [19.7, 2, 0]),
  (Song11_array[81] = [20, 5, 0]),
  (Song11_array[82] = [20.2, 1, 0]),
  (Song11_array[83] = [20.4, 5, 0]),
  (Song11_array[84] = [20.6, 3, 0]),
  (Song11_array[85] = [20.800001, 1, 0]),
  (Song11_array[86] = [21, 3, 0]),
  (Song11_array[87] = [21.300001, 3, 0]),
  (Song11_array[88] = [21.5, 1, 0]),
  (Song11_array[89] = [21.7, 3, 0]),
  (Song11_array[90] = [22, 1, 0]),
  (Song11_array[91] = [22.25, 5, 0]),
  (Song11_array[92] = [22.550001, 5, 0]),
  (Song11_array[93] = [23.1, 3, 0]),
  (Song11_array[94] = [23.65, 5, 0]),
  (Song11_array[95] = [23.85, 2, 0]),
  (Song11_array[96] = [24.050001, 5, 0]),
  (Song11_array[97] = [24.45, 5, 0]),
  (Song11_array[98] = [24.65, 2, 0]),
  (Song11_array[99] = [24.85, 5, 0]),
  (Song11_array[100] = [25.25, 3, 0]),
  (Song11_array[101] = [25.45, 1, 0]),
  (Song11_array[102] = [25.65, 2, 0]),
  (Song11_array[103] = [25.95, 5, 0]),
  (Song11_array[104] = [26.15, 3, 0]),
  (Song11_array[105] = [26.35, 4, 0]),
  (Song11_array[106] = [26.7, 1, 0]),
  (Song11_array[107] = [27.25, 5, 0]),
  (Song11_array[108] = [27.45, 1, 0]),
  (Song11_array[109] = [27.75, 1, 0.05]),
  (Song11_array[110] = [27.75, 3, 0]),
  (Song11_array[111] = [27.75, 5, 0.05]),
  (Song11_array[112] = [28.2, 1, 0.05]),
  (Song11_array[113] = [28.2, 3, 0.05]),
  (Song11_array[114] = [28.2, 5, 0]),
  (Song11_array[115] = [28.7, 1, 0]),
  (Song11_array[116] = [28.9, 1, 0.05]),
  (Song11_array[117] = [28.9, 3, 0]),
  (Song11_array[118] = [28.9, 5, 0.05]),
  (Song11_array[119] = [29.45, 1, 0]),
  (Song11_array[120] = [29.45, 3, 0.05]),
  (Song11_array[121] = [29.45, 5, 0.05]),
  (Song11_array[122] = [30.1, 1, 0]),
  (Song11_array[123] = [30.4, 5, 0]),
  (Song11_array[124] = [30.95, 1, 0]),
  (Song11_array[125] = [31.25, 5, 0]),
  (Song11_array[126] = [31.75, 1, 0]),
  (Song11_array[127] = [32.05, 5, 0]),
  (Song11_array[128] = [32.5, 1, 0]),
  (Song11_array[129] = [32.8, 5, 0]),
  (Song11_array[130] = [33.15, 1, 0.05]),
  (Song11_array[131] = [33.15, 3, 0]),
  (Song11_array[132] = [33.15, 5, 0.05]),
  (Song11_array[133] = [33.65, 1, 0]),
  (Song11_array[134] = [33.65, 3, 0.05]),
  (Song11_array[135] = [33.65, 5, 0.05]),
  (Song11_array[136] = [34.25, 1, 0.05]),
  (Song11_array[137] = [34.25, 3, 0.05]),
  (Song11_array[138] = [34.25, 5, 0]),
  (Song11_array[139] = [35.100002, 2, 0]),
  (Song11_array[140] = [35.2, 2, 0]),
  (Song11_array[141] = [35.3, 2, 0]),
  (Song11_array[142] = [35.4, 2, 0]),
  (Song11_array[143] = [35.7, 1, 0]),
  (Song11_array[144] = [35.850002, 3, 0]),
  (Song11_array[145] = [36.05, 5, 0]),
  (Song11_array[146] = [36.25, 3, 0]),
  (Song11_array[147] = [36.4, 1, 0]),
  (Song11_array[148] = [36.600002, 3, 0]),
  (Song11_array[149] = [36.8, 5, 0]),
  (Song11_array[150] = [37, 3, 0]),
  (Song11_array[151] = [37.2, 1, 0]),
  (Song11_array[152] = [37.4, 3, 0]),
  (Song11_array[153] = [37.600002, 1, 0]),
  (Song11_array[154] = [37.9, 1, 0]),
  (Song11_array[155] = [38.05, 3, 0]),
  (Song11_array[156] = [38.25, 5, 0]),
  (Song11_array[157] = [38.45, 3, 0]),
  (Song11_array[158] = [38.600002, 1, 0]),
  (Song11_array[159] = [38.8, 3, 0]),
  (Song11_array[160] = [39, 5, 0]),
  (Song11_array[161] = [39.2, 3, 0]),
  (Song11_array[162] = [39.4, 1, 0]),
  (Song11_array[163] = [39.600002, 3, 0]),
  (Song11_array[164] = [39.8, 1, 0]),
  (Song11_array[165] = [40.100002, 1, 0]),
  (Song11_array[166] = [40.25, 3, 0]),
  (Song11_array[167] = [40.45, 5, 0]),
  (Song11_array[168] = [40.65, 3, 0]),
  (Song11_array[169] = [40.8, 1, 0]),
  (Song11_array[170] = [41, 3, 0]),
  (Song11_array[171] = [41.2, 5, 0]),
  (Song11_array[172] = [41.4, 3, 0]),
  (Song11_array[173] = [41.600002, 1, 0]),
  (Song11_array[174] = [41.8, 3, 0]),
  (Song11_array[175] = [42, 1, 0]),
  (Song11_array[176] = [42.350002, 1, 0]),
  (Song11_array[177] = [42.5, 3, 0]),
  (Song11_array[178] = [42.7, 5, 0]),
  (Song11_array[179] = [42.9, 3, 0]),
  (Song11_array[180] = [43.05, 1, 0]),
  (Song11_array[181] = [43.25, 3, 0]),
  (Song11_array[182] = [43.45, 5, 0]),
  (Song11_array[183] = [43.65, 3, 0]),
  (Song11_array[184] = [43.850002, 1, 0]),
  (Song11_array[185] = [44.05, 3, 0]),
  (Song11_array[186] = [44.25, 1, 0]),
  (Song11_array[187] = [44.65, 5, 0]),
  (Song11_array[188] = [44.75, 2, 0]),
  (Song11_array[189] = [44.95, 5, 0]),
  (Song11_array[190] = [45.15, 2, 0]),
  (Song11_array[191] = [45.5, 5, 0]),
  (Song11_array[192] = [45.75, 2, 0]),
  (Song11_array[193] = [46.05, 5, 0]),
  (Song11_array[194] = [46.350002, 2, 0]),
  (Song11_array[195] = [46.600002, 4, 0]),
  (Song11_array[196] = [46.850002, 1, 0]),
  (Song11_array[197] = [47.100002, 4, 0]),
  (Song11_array[198] = [47.4, 1, 0]),
  (Song11_array[199] = [47.600002, 4, 0]),
  (Song11_array[200] = [47.9, 1, 0]),
  (Song11_array[201] = [48.350002, 5, 0]),
  (Song11_array[202] = [48.45, 5, 0]),
  (Song11_array[203] = [48.55, 5, 0]),
  (Song11_array[204] = [48.75, 2, 0]),
  (Song11_array[205] = [49.05, 4, 0]),
  (Song11_array[206] = [49.45, 3, 0]),
  (Song11_array[207] = [49.600002, 1, 0]),
  (Song11_array[208] = [49.8, 3, 0]),
  (Song11_array[209] = [50.05, 1, 0]),
  (Song11_array[210] = [50.3, 3, 0]),
  (Song11_array[211] = [50.7, 1, 0]),
  (Song11_array[212] = [51.25, 5, 0]),
  (Song11_array[213] = [51.4, 3, 0]),
  (Song11_array[214] = [51.65, 5, 0]),
  (Song11_array[215] = [51.95, 3, 0]),
  (Song11_array[216] = [52.15, 1, 0]),
  (Song11_array[217] = [52.350002, 3, 0]),
  (Song11_array[218] = [52.65, 3, 0]),
  (Song11_array[219] = [52.8, 1, 0]),
  (Song11_array[220] = [53.05, 3, 0]),
  (Song11_array[221] = [53.350002, 5, 0]),
  (Song11_array[222] = [53.55, 1, 0]),
  (Song11_array[223] = [53.75, 2, 0]),
  (Song11_array[224] = [54.100002, 5, 0]),
  (Song11_array[225] = [54.3, 1, 0]),
  (Song11_array[226] = [54.5, 2, 0]),
  (Song11_array[227] = [54.8, 5, 0]),
  (Song11_array[228] = [55, 1, 0]),
  (Song11_array[229] = [55.2, 2, 0]),
  (Song11_array[230] = [55.5, 5, 0]),
  (Song11_array[231] = [55.7, 2, 0]),
  (Song11_array[232] = [55.9, 5, 0]),
  (Song11_array[233] = [56.100002, 1, 0]),
  (Song11_array[234] = [56.3, 4, 0]),
  (Song11_array[235] = [56.5, 1, 0]),
  (Song11_array[236] = [56.8, 1, 0]),
  (Song11_array[237] = [57, 4, 0]),
  (Song11_array[238] = [57.2, 1, 0]),
  (Song11_array[239] = [57.5, 1, 0]),
  (Song11_array[240] = [57.75, 4, 0]),
  (Song11_array[241] = [58.05, 4, 0]),
  (Song11_array[242] = [58.600002, 1, 0]),
  (Song11_array[243] = [59.15, 1, 0]),
  (Song11_array[244] = [59.350002, 5, 0]),
  (Song11_array[245] = [59.55, 1, 0]),
  (Song11_array[246] = [59.95, 1, 0]),
  (Song11_array[247] = [60.15, 5, 0]),
  (Song11_array[248] = [60.350002, 1, 0]),
  (Song11_array[249] = [60.75, 5, 0]),
  (Song11_array[250] = [60.95, 1, 0]),
  (Song11_array[251] = [61.15, 2, 0]),
  (Song11_array[252] = [61.45, 5, 0]),
  (Song11_array[253] = [61.65, 1, 0]),
  (Song11_array[254] = [61.850002, 2, 0]),
  (Song11_array[255] = [62.2, 5, 0]),
  (Song11_array[256] = [62.75, 4, 0]),
  (Song11_array[257] = [62.95, 1, 0]),
  (Song11_array[258] = [63.25, 1, 0.05]),
  (Song11_array[259] = [63.25, 3, 0]),
  (Song11_array[260] = [63.25, 5, 0.05]),
  (Song11_array[261] = [63.7, 1, 0.05]),
  (Song11_array[262] = [63.7, 3, 0.05]),
  (Song11_array[263] = [63.7, 5, 0]),
  (Song11_array[264] = [64.200005, 2, 0]),
  (Song11_array[265] = [64.4, 1, 0.05]),
  (Song11_array[266] = [64.4, 3, 0.05]),
  (Song11_array[267] = [64.4, 5, 0]),
  (Song11_array[268] = [64.950005, 1, 0.05]),
  (Song11_array[269] = [64.950005, 3, 0]),
  (Song11_array[270] = [64.950005, 5, 0.05]),
  (Song11_array[271] = [65.6, 1, 0]),
  (Song11_array[272] = [65.9, 5, 0]),
  (Song11_array[273] = [66.450005, 1, 0]),
  (Song11_array[274] = [66.75, 5, 0]),
  (Song11_array[275] = [67.25, 1, 0]),
  (Song11_array[276] = [67.55, 5, 0]),
  (Song11_array[277] = [68, 1, 0]),
  (Song11_array[278] = [68.3, 5, 0]),
  (Song11_array[279] = [68.8, 1, 0.05]),
  (Song11_array[280] = [68.8, 3, 0]),
  (Song11_array[281] = [68.8, 5, 0.05]),
  (Song11_array[282] = [69.3, 1, 0]),
  (Song11_array[283] = [69.3, 3, 0.05]),
  (Song11_array[284] = [69.3, 5, 0.05]),
  (Song11_array[285] = [69.9, 1, 0.05]),
  (Song11_array[286] = [69.9, 3, 0]),
  (Song11_array[287] = [69.9, 5, 0.05]),
  (Song11_array[288] = [70.75, 5, 0]),
  (Song11_array[289] = [70.85, 5, 0]),
  (Song11_array[290] = [70.950005, 5, 0]),
  (Song11_array[291] = [71.05, 5, 0]),
  (Song11_array[292] = [71.35, 3, 0]),
  (Song11_array[293] = [71.55, 1, 0]),
  (Song11_array[294] = [71.75, 3, 0]),
  (Song11_array[295] = [72.05, 1, 0]),
  (Song11_array[296] = [72.35, 3, 0]),
  (Song11_array[297] = [72.75, 1, 0]),
  (Song11_array[298] = [73.05, 3, 0]),
  (Song11_array[299] = [73.55, 1, 0]),
  (Song11_array[300] = [73.85, 3, 0]),
  (Song11_array[301] = [74.450005, 1, 0]),
  (Song11_array[302] = [74.700005, 3, 0]),
  (Song11_array[303] = [75.35, 1, 0]),
  (Song11_array[304] = [75.6, 3, 0]),
  (Song11_array[305] = [76.1, 1, 0]),
  (Song11_array[306] = [76.35, 5, 0]),
  (Song11_array[307] = [76.950005, 1, 0]),
  (Song11_array[308] = [77.200005, 5, 0]),
  (Song11_array[309] = [77.75, 1, 0]),
  (Song11_array[310] = [78, 5, 0]),
  (Song11_array[311] = [78.65, 1, 0]),
  (Song11_array[312] = [78.9, 5, 0]),
  (Song11_array[313] = [79.5, 2, 0]),
  (Song11_array[314] = [79.75, 4, 0]),
  (Song11_array[315] = [80.3, 5, 0]),
  (Song11_array[316] = [80.4, 1, 0]),
  (Song11_array[317] = [80.6, 5, 0]),
  (Song11_array[318] = [80.8, 1, 0]),
  (Song11_array[319] = [81.15, 5, 0]),
  (Song11_array[320] = [81.4, 2, 0]),
  (Song11_array[321] = [81.700005, 5, 0]),
  (Song11_array[322] = [82, 1, 0]),
  (Song11_array[323] = [82.25, 3, 0]),
  (Song11_array[324] = [82.450005, 5, 0]),
  (Song11_array[325] = [82.700005, 1, 0]),
  (Song11_array[326] = [83, 3, 0]),
  (Song11_array[327] = [83.200005, 1, 0]),
  (Song11_array[328] = [83.5, 3, 0]),
  (Song11_array[329] = [83.950005, 1, 0]),
  (Song11_array[330] = [84.05, 1, 0]),
  (Song11_array[331] = [84.15, 1, 0]),
  (Song11_array[332] = [84.35, 5, 0]),
  (Song11_array[333] = [84.65, 2, 0]),
  (Song11_array[334] = [85.05, 5, 0]),
  (Song11_array[335] = [85.200005, 3, 0]),
  (Song11_array[336] = [85.4, 5, 0]),
  (Song11_array[337] = [85.65, 3, 0]),
  (Song11_array[338] = [85.9, 5, 0]),
  (Song11_array[339] = [86.3, 2, 0]),
  (Song11_array[340] = [86.85, 5, 0]),
  (Song11_array[341] = [87, 2, 0]),
  (Song11_array[342] = [87.25, 5, 0]),
  (Song11_array[343] = [87.55, 5, 0]),
  (Song11_array[344] = [87.75, 2, 0]),
  (Song11_array[345] = [87.950005, 5, 0]),
  (Song11_array[346] = [88.25, 5, 0]),
  (Song11_array[347] = [88.4, 2, 0]),
  (Song11_array[348] = [88.65, 5, 0]),
  (Song11_array[349] = [89.05, 3, 0]),
  (Song11_array[350] = [89.25, 1, 0]),
  (Song11_array[351] = [89.450005, 2, 0]),
  (Song11_array[352] = [89.8, 3, 0]),
  (Song11_array[353] = [90, 1, 0]),
  (Song11_array[354] = [90.200005, 2, 0]),
  (Song11_array[355] = [90.5, 3, 0]),
  (Song11_array[356] = [90.700005, 1, 0]),
  (Song11_array[357] = [90.9, 2, 0]),
  (Song11_array[358] = [91.200005, 5, 0]),
  (Song11_array[359] = [91.4, 2, 0]),
  (Song11_array[360] = [91.6, 5, 0]),
  (Song11_array[361] = [91.8, 3, 0]),
  (Song11_array[362] = [92, 1, 0]),
  (Song11_array[363] = [92.200005, 3, 0]),
  (Song11_array[364] = [92.5, 3, 0]),
  (Song11_array[365] = [92.700005, 1, 0]),
  (Song11_array[366] = [92.9, 3, 0]),
  (Song11_array[367] = [93.200005, 5, 0]),
  (Song11_array[368] = [93.450005, 1, 0]),
  (Song11_array[369] = [93.75, 5, 0]),
  (Song11_array[370] = [94.3, 3, 0]),
  (Song11_array[371] = [94.85, 5, 0]),
  (Song11_array[372] = [95.05, 3, 0]),
  (Song11_array[373] = [95.25, 5, 0]),
  (Song11_array[374] = [95.65, 1, 0]),
  (Song11_array[375] = [95.85, 3, 0]),
  (Song11_array[376] = [96.05, 1, 0]),
  (Song11_array[377] = [96.450005, 5, 0]),
  (Song11_array[378] = [96.65, 1, 0]),
  (Song11_array[379] = [96.85, 2, 0]),
  (Song11_array[380] = [97.15, 5, 0]),
  (Song11_array[381] = [97.35, 1, 0]),
  (Song11_array[382] = [97.55, 2, 0]),
  (Song11_array[383] = [97.950005, 4, 0]),
  (Song11_array[384] = [98.05, 4, 0]),
  (Song11_array[385] = [98.15, 4, 0]),
  (Song11_array[386] = [98.25, 4, 0]),
  (Song11_array[387] = [98.35, 4, 0]),
  (Song11_array[388] = [98.450005, 4, 0]),
  (Song11_array[389] = [98.55, 4, 0]),
  (Song11_array[390] = [98.65, 4, 0]),
  (Song11_array[391] = [98.75, 4, 0]),
  (Song11_array[392] = [98.85, 4, 0]),
  (Song11_array[393] = [98.950005, 4, 0]),
  (Song11_array[394] = [99.05, 4, 0]),
  (Song11_array[395] = [99.15, 4, 0]),
  (Song11_array[396] = [99.25, 4, 0]),
  (Song11_array[397] = [99.6, 1, 0]),
  (Song11_array[398] = [99.9, 3, 0.05]),
  (Song11_array[399] = [99.9, 5, 0]),
  (Song11_array[400] = [100.15, 5, 0]),
  (Song11_array[401] = [100.25, 5, 0]),
  (Song11_array[402] = [100.35, 5, 0]),
  (Song11_array[403] = [100.450005, 2, 0]),
  (Song11_array[404] = [100.55, 2, 0]),
  (Song11_array[405] = [100.65, 2, 0]),
  (Song11_array[406] = [100.75, 2, 0]),
  (Song11_array[407] = [100.85, 2, 0]),
  (Song11_array[408] = [100.950005, 2, 0]),
  (Song11_array[409] = [101.05, 2, 0]),
  (Song11_array[410] = [101.15, 2, 0]),
  (Song11_array[411] = [101.25, 2, 0]),
  (Song11_array[412] = [101.35, 2, 0]),
  (Song11_array[413] = [101.450005, 2, 0]),
  (Song11_array[414] = [101.55, 2, 0]),
  (Song11_array[415] = [101.65, 2, 0]),
  (Song11_array[416] = [101.75, 2, 0]),
  (Song11_array[417] = [101.85, 2, 0]),
  (Song11_array[418] = [101.950005, 2, 0]),
  (Song11_array[419] = [102.05, 2, 0]),
  (Song11_array[420] = [102.15, 2, 0]),
  (Song11_array[421] = [102.25, 2, 0]),
  (Song11_array[422] = [102.450005, 2, 0.05]),
  (Song11_array[423] = [102.450005, 4, 0]),
  (Song11_array[424] = [102.6, 1, 0]),
  (Song11_array[425] = [102.700005, 1, 0]),
  (Song11_array[426] = [102.8, 1, 0]),
  (Song11_array[427] = [102.9, 1, 0]),
  (Song11_array[428] = [103, 1, 0]),
  (Song11_array[429] = [103.1, 1, 0]),
  (Song11_array[430] = [103.200005, 1, 0]),
  (Song11_array[431] = [103.3, 1, 0]),
  (Song11_array[432] = [103.4, 1, 0]),
  (Song11_array[433] = [103.5, 1, 0]),
  (Song11_array[434] = [103.6, 1, 0]),
  (Song11_array[435] = [103.700005, 1, 0]),
  (Song11_array[436] = [103.8, 1, 0]),
  (Song11_array[437] = [103.9, 1, 0]),
  (Song11_array[438] = [104, 1, 0]),
  (Song11_array[439] = [104.1, 1, 0]),
  (Song11_array[440] = [104.4, 3, 0.05]),
  (Song11_array[441] = [104.4, 5, 0]),
  (Song11_array[442] = [104.65, 1, 0]),
  (Song11_array[443] = [104.75, 1, 0]),
  (Song11_array[444] = [104.85, 1, 0]),
  (Song11_array[445] = [104.950005, 4, 0]),
  (Song11_array[446] = [105.05, 4, 0]),
  (Song11_array[447] = [105.15, 4, 0]),
  (Song11_array[448] = [105.25, 4, 0]),
  (Song11_array[449] = [105.35, 4, 0]),
  (Song11_array[450] = [105.450005, 4, 0]),
  (Song11_array[451] = [105.55, 4, 0]),
  (Song11_array[452] = [105.65, 4, 0]),
  (Song11_array[453] = [105.75, 4, 0]),
  (Song11_array[454] = [105.85, 4, 0]),
  (Song11_array[455] = [105.950005, 4, 0]),
  (Song11_array[456] = [106.05, 4, 0]),
  (Song11_array[457] = [106.15, 4, 0]),
  (Song11_array[458] = [106.25, 4, 0]),
  (Song11_array[459] = [106.35, 4, 0]);
var Song12_array = [];
(Song12_array[0] = [0.4375, 3, 0]),
  (Song12_array[1] = [0.5625, 2, 0]),
  (Song12_array[2] = [0.6875, 5, 0]),
  (Song12_array[3] = [0.8125, 3, 0]),
  (Song12_array[4] = [0.9375, 4, 0]),
  (Song12_array[5] = [1.0625, 3, 0]),
  (Song12_array[6] = [1.1875, 1, 0]),
  (Song12_array[7] = [1.3125, 3, 0]),
  (Song12_array[8] = [1.4375, 2, 0]),
  (Song12_array[9] = [1.5625, 3, 0]),
  (Song12_array[10] = [1.6875, 5, 0]),
  (Song12_array[11] = [1.8125, 3, 0]),
  (Song12_array[12] = [2, 1, 0]),
  (Song12_array[13] = [2, 3, 0.0625]),
  (Song12_array[14] = [2.3125, 3, 0]),
  (Song12_array[15] = [2.4375, 2, 0]),
  (Song12_array[16] = [2.5625, 5, 0]),
  (Song12_array[17] = [2.6875, 3, 0]),
  (Song12_array[18] = [2.8125, 4, 0]),
  (Song12_array[19] = [2.9375, 3, 0]),
  (Song12_array[20] = [3.0625, 1, 0]),
  (Song12_array[21] = [3.1875, 3, 0]),
  (Song12_array[22] = [3.3125, 2, 0]),
  (Song12_array[23] = [3.4375, 3, 0]),
  (Song12_array[24] = [3.5625, 5, 0]),
  (Song12_array[25] = [3.6875, 3, 0]),
  (Song12_array[26] = [3.875, 1, 0]),
  (Song12_array[27] = [3.9375, 1, 0]),
  (Song12_array[28] = [4, 1, 0]),
  (Song12_array[29] = [4.125, 3, 0]),
  (Song12_array[30] = [4.25, 3, 0]),
  (Song12_array[31] = [4.375, 5, 0]),
  (Song12_array[32] = [4.5, 3, 0]),
  (Song12_array[33] = [4.625, 2, 0]),
  (Song12_array[34] = [4.75, 3, 0]),
  (Song12_array[35] = [4.875, 1, 0]),
  (Song12_array[36] = [5, 3, 0]),
  (Song12_array[37] = [5.125, 2, 0]),
  (Song12_array[38] = [5.25, 3, 0]),
  (Song12_array[39] = [5.375, 5, 0]),
  (Song12_array[40] = [5.5, 3, 0]),
  (Song12_array[41] = [5.6875, 1, 0]),
  (Song12_array[42] = [5.6875, 3, 0.0625]),
  (Song12_array[43] = [5.9375, 3, 0]),
  (Song12_array[44] = [6.0625, 3, 0]),
  (Song12_array[45] = [6.1875, 5, 0]),
  (Song12_array[46] = [6.3125, 3, 0]),
  (Song12_array[47] = [6.4375, 2, 0]),
  (Song12_array[48] = [6.5625, 3, 0]),
  (Song12_array[49] = [6.6875, 1, 0]),
  (Song12_array[50] = [6.8125, 3, 0]),
  (Song12_array[51] = [6.9375, 2, 0]),
  (Song12_array[52] = [7.0625, 3, 0]),
  (Song12_array[53] = [7.1875, 5, 0]),
  (Song12_array[54] = [7.3125, 3, 0]),
  (Song12_array[55] = [7.4375, 1, 0]),
  (Song12_array[56] = [7.5, 1, 0]),
  (Song12_array[57] = [7.5625, 1, 0]),
  (Song12_array[58] = [7.625, 1, 0]),
  (Song12_array[59] = [7.6875, 1, 0]),
  (Song12_array[60] = [7.8125, 3, 0]),
  (Song12_array[61] = [7.9375, 3, 0]),
  (Song12_array[62] = [8.0625, 5, 0]),
  (Song12_array[63] = [8.1875, 3, 0]),
  (Song12_array[64] = [8.3125, 2, 0]),
  (Song12_array[65] = [8.4375, 3, 0]),
  (Song12_array[66] = [8.5625, 1, 0]),
  (Song12_array[67] = [8.6875, 3, 0]),
  (Song12_array[68] = [8.8125, 2, 0]),
  (Song12_array[69] = [8.9375, 3, 0]),
  (Song12_array[70] = [9.0625, 5, 0]),
  (Song12_array[71] = [9.1875, 3, 0]),
  (Song12_array[72] = [9.375, 1, 0]),
  (Song12_array[73] = [9.375, 3, 0.0625]),
  (Song12_array[74] = [9.5625, 3, 0]),
  (Song12_array[75] = [9.6875, 3, 0]),
  (Song12_array[76] = [9.8125, 5, 0]),
  (Song12_array[77] = [9.9375, 3, 0]),
  (Song12_array[78] = [10.0625, 2, 0]),
  (Song12_array[79] = [10.1875, 3, 0]),
  (Song12_array[80] = [10.3125, 1, 0]),
  (Song12_array[81] = [10.4375, 3, 0]),
  (Song12_array[82] = [10.5625, 2, 0]),
  (Song12_array[83] = [10.6875, 3, 0]),
  (Song12_array[84] = [10.8125, 5, 0]),
  (Song12_array[85] = [10.9375, 3, 0]),
  (Song12_array[86] = [11.125, 1, 0]),
  (Song12_array[87] = [11.1875, 1, 0]),
  (Song12_array[88] = [11.25, 1, 0]),
  (Song12_array[89] = [11.3125, 1, 0]),
  (Song12_array[90] = [11.375, 1, 0]),
  (Song12_array[91] = [11.5, 5, 0]),
  (Song12_array[92] = [11.625, 3, 0]),
  (Song12_array[93] = [11.75, 2, 0]),
  (Song12_array[94] = [11.875, 3, 0]),
  (Song12_array[95] = [12, 1, 0]),
  (Song12_array[96] = [12.125, 3, 0]),
  (Song12_array[97] = [12.25, 2, 0]),
  (Song12_array[98] = [12.375, 3, 0]),
  (Song12_array[99] = [12.5, 5, 0]),
  (Song12_array[100] = [12.625, 3, 0]),
  (Song12_array[101] = [12.8125, 1, 0]),
  (Song12_array[102] = [12.8125, 3, 0.0625]),
  (Song12_array[103] = [13, 3, 0]),
  (Song12_array[104] = [13.125, 3, 0]),
  (Song12_array[105] = [13.25, 5, 0]),
  (Song12_array[106] = [13.375, 3, 0]),
  (Song12_array[107] = [13.5, 2, 0]),
  (Song12_array[108] = [13.625, 3, 0]),
  (Song12_array[109] = [13.75, 1, 0]),
  (Song12_array[110] = [13.875, 3, 0]),
  (Song12_array[111] = [14, 2, 0]),
  (Song12_array[112] = [14.125, 3, 0]),
  (Song12_array[113] = [14.25, 5, 0]),
  (Song12_array[114] = [14.375, 3, 0]),
  (Song12_array[115] = [14.5, 2, 0]),
  (Song12_array[116] = [14.5625, 2, 0]),
  (Song12_array[117] = [14.625, 2, 0]),
  (Song12_array[118] = [14.6875, 2, 0]),
  (Song12_array[119] = [14.75, 2, 0]),
  (Song12_array[120] = [14.9375, 5, 0]),
  (Song12_array[121] = [15.0625, 3, 0]),
  (Song12_array[122] = [15.1875, 2, 0]),
  (Song12_array[123] = [15.3125, 3, 0]),
  (Song12_array[124] = [15.4375, 1, 0]),
  (Song12_array[125] = [15.5625, 3, 0]),
  (Song12_array[126] = [15.6875, 2, 0]),
  (Song12_array[127] = [15.8125, 3, 0]),
  (Song12_array[128] = [15.9375, 5, 0]),
  (Song12_array[129] = [16.0625, 3, 0]),
  (Song12_array[130] = [16.25, 1, 0]),
  (Song12_array[131] = [16.25, 3, 0.0625]),
  (Song12_array[132] = [16.4375, 3, 0]),
  (Song12_array[133] = [16.5625, 3, 0]),
  (Song12_array[134] = [16.6875, 5, 0]),
  (Song12_array[135] = [16.8125, 3, 0]),
  (Song12_array[136] = [16.9375, 2, 0]),
  (Song12_array[137] = [17.0625, 3, 0]),
  (Song12_array[138] = [17.1875, 1, 0]),
  (Song12_array[139] = [17.3125, 3, 0]),
  (Song12_array[140] = [17.4375, 2, 0]),
  (Song12_array[141] = [17.5625, 3, 0]),
  (Song12_array[142] = [17.6875, 5, 0]),
  (Song12_array[143] = [17.8125, 3, 0]),
  (Song12_array[144] = [18, 3, 0]),
  (Song12_array[145] = [18.1875, 1, 0]),
  (Song12_array[146] = [18.25, 1, 0]),
  (Song12_array[147] = [18.3125, 1, 0]),
  (Song12_array[148] = [18.375, 1, 0]),
  (Song12_array[149] = [18.4375, 1, 0]),
  (Song12_array[150] = [18.625, 5, 0]),
  (Song12_array[151] = [18.75, 3, 0]),
  (Song12_array[152] = [18.875, 2, 0]),
  (Song12_array[153] = [19, 3, 0]),
  (Song12_array[154] = [19.125, 1, 0]),
  (Song12_array[155] = [19.25, 3, 0]),
  (Song12_array[156] = [19.375, 2, 0]),
  (Song12_array[157] = [19.5, 3, 0]),
  (Song12_array[158] = [19.625, 5, 0]),
  (Song12_array[159] = [19.75, 3, 0]),
  (Song12_array[160] = [19.9375, 1, 0]),
  (Song12_array[161] = [19.9375, 3, 0.0625]),
  (Song12_array[162] = [20.1875, 3, 0]),
  (Song12_array[163] = [20.3125, 3, 0]),
  (Song12_array[164] = [20.4375, 5, 0]),
  (Song12_array[165] = [20.5625, 3, 0]),
  (Song12_array[166] = [20.6875, 2, 0]),
  (Song12_array[167] = [20.8125, 3, 0]),
  (Song12_array[168] = [20.9375, 1, 0]),
  (Song12_array[169] = [21.0625, 3, 0]),
  (Song12_array[170] = [21.1875, 2, 0]),
  (Song12_array[171] = [21.3125, 3, 0]),
  (Song12_array[172] = [21.4375, 5, 0]),
  (Song12_array[173] = [21.5625, 3, 0]),
  (Song12_array[174] = [21.6875, 3, 0]),
  (Song12_array[175] = [21.8125, 1, 0]),
  (Song12_array[176] = [21.875, 1, 0]),
  (Song12_array[177] = [21.9375, 1, 0]),
  (Song12_array[178] = [22, 1, 0]),
  (Song12_array[179] = [22.25, 1, 0]),
  (Song12_array[180] = [22.375, 5, 0]),
  (Song12_array[181] = [22.5625, 1, 0]),
  (Song12_array[182] = [22.6875, 4, 0]),
  (Song12_array[183] = [22.875, 1, 0]),
  (Song12_array[184] = [23, 3, 0]),
  (Song12_array[185] = [23.1875, 1, 0]),
  (Song12_array[186] = [23.3125, 2, 0]),
  (Song12_array[187] = [23.625, 5, 0]),
  (Song12_array[188] = [24.0625, 1, 0]),
  (Song12_array[189] = [24.1875, 5, 0]),
  (Song12_array[190] = [24.375, 1, 0]),
  (Song12_array[191] = [24.5, 4, 0]),
  (Song12_array[192] = [24.6875, 1, 0]),
  (Song12_array[193] = [24.8125, 3, 0]),
  (Song12_array[194] = [25, 1, 0]),
  (Song12_array[195] = [25.125, 2, 0]),
  (Song12_array[196] = [25.4375, 5, 0]),
  (Song12_array[197] = [25.875, 1, 0]),
  (Song12_array[198] = [26, 5, 0]),
  (Song12_array[199] = [26.1875, 1, 0]),
  (Song12_array[200] = [26.3125, 4, 0]),
  (Song12_array[201] = [26.5, 1, 0]),
  (Song12_array[202] = [26.625, 3, 0]),
  (Song12_array[203] = [26.8125, 1, 0]),
  (Song12_array[204] = [26.9375, 2, 0]),
  (Song12_array[205] = [27.25, 1, 0]),
  (Song12_array[206] = [27.6875, 1, 0]),
  (Song12_array[207] = [27.8125, 5, 0]),
  (Song12_array[208] = [28, 1, 0]),
  (Song12_array[209] = [28.125, 4, 0]),
  (Song12_array[210] = [28.3125, 1, 0]),
  (Song12_array[211] = [28.4375, 3, 0]),
  (Song12_array[212] = [28.625, 1, 0]),
  (Song12_array[213] = [28.75, 2, 0]),
  (Song12_array[214] = [29.0625, 5, 0]),
  (Song12_array[215] = [29.4375, 1, 0]),
  (Song12_array[216] = [29.5625, 5, 0]),
  (Song12_array[217] = [29.75, 1, 0]),
  (Song12_array[218] = [29.875, 4, 0]),
  (Song12_array[219] = [30.0625, 1, 0]),
  (Song12_array[220] = [30.1875, 3, 0]),
  (Song12_array[221] = [30.375, 1, 0]),
  (Song12_array[222] = [30.5, 2, 0]),
  (Song12_array[223] = [30.8125, 5, 0]),
  (Song12_array[224] = [31.25, 1, 0]),
  (Song12_array[225] = [31.375, 5, 0]),
  (Song12_array[226] = [31.5625, 1, 0]),
  (Song12_array[227] = [31.6875, 4, 0]),
  (Song12_array[228] = [31.875, 1, 0]),
  (Song12_array[229] = [32, 3, 0]),
  (Song12_array[230] = [32.1875, 1, 0]),
  (Song12_array[231] = [32.3125, 2, 0]),
  (Song12_array[232] = [32.625, 5, 0]),
  (Song12_array[233] = [33.0625, 1, 0]),
  (Song12_array[234] = [33.1875, 5, 0]),
  (Song12_array[235] = [33.375, 1, 0]),
  (Song12_array[236] = [33.5, 4, 0]),
  (Song12_array[237] = [33.6875, 1, 0]),
  (Song12_array[238] = [33.8125, 3, 0]),
  (Song12_array[239] = [34, 1, 0]),
  (Song12_array[240] = [34.125, 2, 0]),
  (Song12_array[241] = [34.4375, 5, 0]),
  (Song12_array[242] = [34.875, 1, 0]),
  (Song12_array[243] = [35, 5, 0]),
  (Song12_array[244] = [35.1875, 1, 0]),
  (Song12_array[245] = [35.3125, 4, 0]),
  (Song12_array[246] = [35.5, 1, 0]),
  (Song12_array[247] = [35.625, 3, 0]),
  (Song12_array[248] = [35.8125, 1, 0]),
  (Song12_array[249] = [35.9375, 2, 0]),
  (Song12_array[250] = [36.25, 5, 0]),
  (Song12_array[251] = [36.6875, 1, 0]),
  (Song12_array[252] = [36.8125, 5, 0]),
  (Song12_array[253] = [37, 1, 0]),
  (Song12_array[254] = [37.125, 4, 0]),
  (Song12_array[255] = [37.3125, 1, 0]),
  (Song12_array[256] = [37.4375, 3, 0]),
  (Song12_array[257] = [37.625, 1, 0]),
  (Song12_array[258] = [37.75, 2, 0]),
  (Song12_array[259] = [38.0625, 5, 0]),
  (Song12_array[260] = [38.5, 1, 0]),
  (Song12_array[261] = [38.625, 5, 0]),
  (Song12_array[262] = [38.8125, 1, 0]),
  (Song12_array[263] = [38.9375, 4, 0]),
  (Song12_array[264] = [39.125, 1, 0]),
  (Song12_array[265] = [39.25, 3, 0]),
  (Song12_array[266] = [39.4375, 1, 0]),
  (Song12_array[267] = [39.5625, 2, 0]),
  (Song12_array[268] = [39.875, 5, 0]),
  (Song12_array[269] = [40.25, 3, 0]),
  (Song12_array[270] = [40.25, 5, 0.0625]),
  (Song12_array[271] = [40.6875, 1, 0]),
  (Song12_array[272] = [40.6875, 3, 0.0625]),
  (Song12_array[273] = [41.1875, 3, 0.0625]),
  (Song12_array[274] = [41.1875, 5, 0]),
  (Song12_array[275] = [41.625, 1, 0]),
  (Song12_array[276] = [41.625, 3, 0.0625]),
  (Song12_array[277] = [42.0625, 1, 0.0625]),
  (Song12_array[278] = [42.0625, 3, 0.0625]),
  (Song12_array[279] = [42.0625, 5, 0]),
  (Song12_array[280] = [42.5, 1, 0]),
  (Song12_array[281] = [42.5, 3, 0.0625]),
  (Song12_array[282] = [43, 3, 0.0625]),
  (Song12_array[283] = [43, 5, 0]),
  (Song12_array[284] = [43.4375, 1, 0]),
  (Song12_array[285] = [43.875, 1, 0.0625]),
  (Song12_array[286] = [43.875, 3, 0.0625]),
  (Song12_array[287] = [43.875, 5, 0]),
  (Song12_array[288] = [44.375, 2, 0]),
  (Song12_array[289] = [44.375, 4, 0.0625]),
  (Song12_array[290] = [44.8125, 3, 0.0625]),
  (Song12_array[291] = [44.8125, 5, 0]),
  (Song12_array[292] = [45.3125, 3, 0]),
  (Song12_array[293] = [45.6875, 1, 0]),
  (Song12_array[294] = [46.25, 3, 0.0625]),
  (Song12_array[295] = [46.25, 5, 0]),
  (Song12_array[296] = [46.75, 1, 0]),
  (Song12_array[297] = [46.75, 3, 0.0625]),
  (Song12_array[298] = [46.75, 5, 0.0625]),
  (Song12_array[299] = [47.1875, 1, 0.0625]),
  (Song12_array[300] = [47.1875, 3, 0]),
  (Song12_array[301] = [47.625, 5, 0]),
  (Song12_array[302] = [48.0625, 3, 0]),
  (Song12_array[303] = [48.0625, 5, 0.0625]),
  (Song12_array[304] = [48.4375, 1, 0]),
  (Song12_array[305] = [48.8125, 3, 0.0625]),
  (Song12_array[306] = [48.8125, 5, 0]),
  (Song12_array[307] = [49.3125, 1, 0.0625]),
  (Song12_array[308] = [49.3125, 3, 0]),
  (Song12_array[309] = [49.8125, 5, 0]),
  (Song12_array[310] = [51, 5, 0]),
  (Song12_array[311] = [51.125, 3, 0]),
  (Song12_array[312] = [51.25, 2, 0]),
  (Song12_array[313] = [51.375, 3, 0]),
  (Song12_array[314] = [51.5, 1, 0]),
  (Song12_array[315] = [51.625, 3, 0]),
  (Song12_array[316] = [51.75, 2, 0]),
  (Song12_array[317] = [51.875, 3, 0]),
  (Song12_array[318] = [52, 5, 0]),
  (Song12_array[319] = [52.125, 3, 0]),
  (Song12_array[320] = [52.3125, 1, 0]),
  (Song12_array[321] = [52.3125, 3, 0.0625]),
  (Song12_array[322] = [52.5, 3, 0]),
  (Song12_array[323] = [52.625, 3, 0]),
  (Song12_array[324] = [52.75, 5, 0]),
  (Song12_array[325] = [52.875, 3, 0]),
  (Song12_array[326] = [53, 2, 0]),
  (Song12_array[327] = [53.125, 3, 0]),
  (Song12_array[328] = [53.25, 1, 0]),
  (Song12_array[329] = [53.375, 3, 0]),
  (Song12_array[330] = [53.5, 2, 0]),
  (Song12_array[331] = [53.625, 3, 0]),
  (Song12_array[332] = [53.75, 5, 0]),
  (Song12_array[333] = [53.875, 3, 0]),
  (Song12_array[334] = [54.0625, 3, 0]),
  (Song12_array[335] = [54.25, 1, 0]),
  (Song12_array[336] = [54.3125, 1, 0]),
  (Song12_array[337] = [54.375, 1, 0]),
  (Song12_array[338] = [54.4375, 1, 0]),
  (Song12_array[339] = [54.5, 1, 0]),
  (Song12_array[340] = [54.6875, 5, 0]),
  (Song12_array[341] = [54.8125, 3, 0]),
  (Song12_array[342] = [54.9375, 2, 0]),
  (Song12_array[343] = [55.0625, 3, 0]),
  (Song12_array[344] = [55.1875, 1, 0]),
  (Song12_array[345] = [55.3125, 3, 0]),
  (Song12_array[346] = [55.4375, 2, 0]),
  (Song12_array[347] = [55.5625, 3, 0]),
  (Song12_array[348] = [55.6875, 5, 0]),
  (Song12_array[349] = [55.8125, 3, 0]),
  (Song12_array[350] = [56, 1, 0]),
  (Song12_array[351] = [56, 3, 0.0625]),
  (Song12_array[352] = [56.25, 3, 0]),
  (Song12_array[353] = [56.375, 3, 0]),
  (Song12_array[354] = [56.5, 5, 0]),
  (Song12_array[355] = [56.625, 3, 0]),
  (Song12_array[356] = [56.75, 2, 0]),
  (Song12_array[357] = [56.875, 3, 0]),
  (Song12_array[358] = [57, 1, 0]),
  (Song12_array[359] = [57.125, 3, 0]),
  (Song12_array[360] = [57.25, 2, 0]),
  (Song12_array[361] = [57.375, 3, 0]),
  (Song12_array[362] = [57.5, 5, 0]),
  (Song12_array[363] = [57.625, 3, 0]),
  (Song12_array[364] = [57.75, 3, 0]),
  (Song12_array[365] = [57.875, 1, 0]),
  (Song12_array[366] = [57.9375, 1, 0]),
  (Song12_array[367] = [58, 1, 0]),
  (Song12_array[368] = [58.0625, 1, 0]),
  (Song12_array[369] = [58.25, 5, 0]),
  (Song12_array[370] = [58.375, 3, 0]),
  (Song12_array[371] = [58.5, 2, 0]),
  (Song12_array[372] = [58.625, 3, 0]),
  (Song12_array[373] = [58.75, 1, 0]),
  (Song12_array[374] = [58.875, 3, 0]),
  (Song12_array[375] = [59, 2, 0]),
  (Song12_array[376] = [59.125, 3, 0]),
  (Song12_array[377] = [59.25, 5, 0]),
  (Song12_array[378] = [59.375, 3, 0]),
  (Song12_array[379] = [59.5625, 1, 0]),
  (Song12_array[380] = [59.5625, 3, 0.0625]),
  (Song12_array[381] = [59.75, 3, 0]),
  (Song12_array[382] = [59.875, 3, 0]),
  (Song12_array[383] = [60, 5, 0]),
  (Song12_array[384] = [60.125, 3, 0]),
  (Song12_array[385] = [60.25, 2, 0]),
  (Song12_array[386] = [60.375, 3, 0]),
  (Song12_array[387] = [60.5, 1, 0]),
  (Song12_array[388] = [60.625, 3, 0]),
  (Song12_array[389] = [60.75, 2, 0]),
  (Song12_array[390] = [60.875, 3, 0]),
  (Song12_array[391] = [61, 5, 0]),
  (Song12_array[392] = [61.125, 3, 0]),
  (Song12_array[393] = [61.3125, 3, 0]),
  (Song12_array[394] = [61.5, 1, 0]),
  (Song12_array[395] = [61.5625, 1, 0]),
  (Song12_array[396] = [61.625, 1, 0]),
  (Song12_array[397] = [61.6875, 1, 0]),
  (Song12_array[398] = [61.75, 1, 0]),
  (Song12_array[399] = [61.9375, 5, 0]),
  (Song12_array[400] = [62.0625, 3, 0]),
  (Song12_array[401] = [62.1875, 2, 0]),
  (Song12_array[402] = [62.3125, 3, 0]),
  (Song12_array[403] = [62.4375, 1, 0]),
  (Song12_array[404] = [62.5625, 3, 0]),
  (Song12_array[405] = [62.6875, 2, 0]),
  (Song12_array[406] = [62.8125, 3, 0]),
  (Song12_array[407] = [62.9375, 5, 0]),
  (Song12_array[408] = [63.0625, 3, 0]),
  (Song12_array[409] = [63.25, 1, 0]),
  (Song12_array[410] = [63.25, 3, 0.0625]),
  (Song12_array[411] = [63.5, 3, 0]),
  (Song12_array[412] = [63.625, 3, 0]),
  (Song12_array[413] = [63.75, 5, 0]),
  (Song12_array[414] = [63.875, 3, 0]),
  (Song12_array[415] = [64, 2, 0]),
  (Song12_array[416] = [64.125, 3, 0]),
  (Song12_array[417] = [64.25, 1, 0]),
  (Song12_array[418] = [64.375, 3, 0]),
  (Song12_array[419] = [64.5, 2, 0]),
  (Song12_array[420] = [64.625, 3, 0]),
  (Song12_array[421] = [64.75, 5, 0]),
  (Song12_array[422] = [64.875, 3, 0]),
  (Song12_array[423] = [65, 3, 0]),
  (Song12_array[424] = [65.125, 1, 0]),
  (Song12_array[425] = [65.1875, 1, 0]),
  (Song12_array[426] = [65.25, 1, 0]),
  (Song12_array[427] = [65.3125, 1, 0]),
  (Song12_array[428] = [65.6875, 5, 0]),
  (Song12_array[429] = [65.8125, 2, 0]),
  (Song12_array[430] = [65.9375, 4, 0]),
  (Song12_array[431] = [66.0625, 1, 0]),
  (Song12_array[432] = [66.5625, 1, 0]),
  (Song12_array[433] = [66.6875, 3, 0]),
  (Song12_array[434] = [66.8125, 5, 0]),
  (Song12_array[435] = [66.9375, 3, 0]),
  (Song12_array[436] = [67.125, 5, 0]),
  (Song12_array[437] = [67.5625, 5, 0]),
  (Song12_array[438] = [67.6875, 2, 0]),
  (Song12_array[439] = [67.8125, 4, 0]),
  (Song12_array[440] = [67.9375, 1, 0]),
  (Song12_array[441] = [68.375, 1, 0]),
  (Song12_array[442] = [68.5, 3, 0]),
  (Song12_array[443] = [68.625, 5, 0]),
  (Song12_array[444] = [68.75, 3, 0]),
  (Song12_array[445] = [68.9375, 5, 0]),
  (Song12_array[446] = [70.1875, 3, 0]),
  (Song12_array[447] = [70.3125, 5, 0]),
  (Song12_array[448] = [70.4375, 3, 0]),
  (Song12_array[449] = [70.75, 4, 0]),
  (Song12_array[450] = [70.9375, 4, 0]),
  (Song12_array[451] = [71.125, 1, 0]),
  (Song12_array[452] = [71.3125, 4, 0]),
  (Song12_array[453] = [72.0625, 4, 0]),
  (Song12_array[454] = [72.1875, 5, 0]),
  (Song12_array[455] = [72.3125, 3, 0]),
  (Song12_array[456] = [72.4375, 4, 0]),
  (Song12_array[457] = [72.5625, 3, 0]),
  (Song12_array[458] = [72.875, 5, 0]),
  (Song12_array[459] = [73, 2, 0]),
  (Song12_array[460] = [73.125, 4, 0]),
  (Song12_array[461] = [73.25, 1, 0]),
  (Song12_array[462] = [73.75, 1, 0]),
  (Song12_array[463] = [73.875, 3, 0]),
  (Song12_array[464] = [74, 5, 0]),
  (Song12_array[465] = [74.125, 3, 0]),
  (Song12_array[466] = [74.3125, 5, 0]),
  (Song12_array[467] = [74.75, 5, 0]),
  (Song12_array[468] = [74.875, 2, 0]),
  (Song12_array[469] = [75, 4, 0]),
  (Song12_array[470] = [75.125, 1, 0]),
  (Song12_array[471] = [75.5625, 1, 0]),
  (Song12_array[472] = [75.6875, 3, 0]),
  (Song12_array[473] = [75.8125, 5, 0]),
  (Song12_array[474] = [75.9375, 3, 0]),
  (Song12_array[475] = [76.125, 5, 0]),
  (Song12_array[476] = [77.375, 3, 0]),
  (Song12_array[477] = [77.5, 5, 0]),
  (Song12_array[478] = [77.625, 3, 0]),
  (Song12_array[479] = [77.9375, 4, 0]),
  (Song12_array[480] = [78.125, 4, 0]),
  (Song12_array[481] = [78.3125, 1, 0]),
  (Song12_array[482] = [78.5, 4, 0]),
  (Song12_array[483] = [79.25, 4, 0]),
  (Song12_array[484] = [79.375, 5, 0]),
  (Song12_array[485] = [79.5, 3, 0]),
  (Song12_array[486] = [79.625, 4, 0]),
  (Song12_array[487] = [79.75, 1, 0]),
  (Song12_array[488] = [80, 4, 0]),
  (Song12_array[489] = [80.125, 3, 0]),
  (Song12_array[490] = [80.25, 2, 0]),
  (Song12_array[491] = [80.375, 3, 0]),
  (Song12_array[492] = [80.5, 1, 0]),
  (Song12_array[493] = [80.625, 3, 0]),
  (Song12_array[494] = [80.75, 2, 0]),
  (Song12_array[495] = [80.875, 3, 0]),
  (Song12_array[496] = [81, 5, 0]),
  (Song12_array[497] = [81.125, 3, 0]),
  (Song12_array[498] = [81.3125, 1, 0]),
  (Song12_array[499] = [81.3125, 3, 0.0625]),
  (Song12_array[500] = [81.5, 3, 0]),
  (Song12_array[501] = [81.625, 3, 0]),
  (Song12_array[502] = [81.75, 5, 0]),
  (Song12_array[503] = [81.875, 3, 0]),
  (Song12_array[504] = [82, 2, 0]),
  (Song12_array[505] = [82.125, 3, 0]),
  (Song12_array[506] = [82.25, 1, 0]),
  (Song12_array[507] = [82.375, 3, 0]),
  (Song12_array[508] = [82.5, 2, 0]),
  (Song12_array[509] = [82.625, 3, 0]),
  (Song12_array[510] = [82.75, 5, 0]),
  (Song12_array[511] = [82.875, 3, 0]),
  (Song12_array[512] = [83.0625, 3, 0]),
  (Song12_array[513] = [83.25, 1, 0]),
  (Song12_array[514] = [83.3125, 1, 0]),
  (Song12_array[515] = [83.375, 1, 0]),
  (Song12_array[516] = [83.4375, 1, 0]),
  (Song12_array[517] = [83.5, 1, 0]),
  (Song12_array[518] = [83.6875, 5, 0]),
  (Song12_array[519] = [83.8125, 3, 0]),
  (Song12_array[520] = [83.9375, 2, 0]),
  (Song12_array[521] = [84.0625, 3, 0]),
  (Song12_array[522] = [84.1875, 1, 0]),
  (Song12_array[523] = [84.3125, 3, 0]),
  (Song12_array[524] = [84.4375, 2, 0]),
  (Song12_array[525] = [84.5625, 3, 0]),
  (Song12_array[526] = [84.6875, 5, 0]),
  (Song12_array[527] = [84.8125, 3, 0]),
  (Song12_array[528] = [85, 1, 0]),
  (Song12_array[529] = [85, 3, 0.0625]),
  (Song12_array[530] = [85.25, 3, 0]),
  (Song12_array[531] = [85.375, 3, 0]),
  (Song12_array[532] = [85.5, 5, 0]),
  (Song12_array[533] = [85.625, 3, 0]),
  (Song12_array[534] = [85.75, 2, 0]),
  (Song12_array[535] = [85.875, 3, 0]),
  (Song12_array[536] = [86, 1, 0]),
  (Song12_array[537] = [86.125, 3, 0]),
  (Song12_array[538] = [86.25, 2, 0]),
  (Song12_array[539] = [86.375, 3, 0]),
  (Song12_array[540] = [86.5, 5, 0]),
  (Song12_array[541] = [86.625, 3, 0]),
  (Song12_array[542] = [86.75, 3, 0]),
  (Song12_array[543] = [86.875, 1, 0]),
  (Song12_array[544] = [86.9375, 1, 0]),
  (Song12_array[545] = [87, 1, 0]),
  (Song12_array[546] = [87.0625, 1, 0]),
  (Song12_array[547] = [87.25, 5, 0]),
  (Song12_array[548] = [87.375, 3, 0]),
  (Song12_array[549] = [87.5, 2, 0]),
  (Song12_array[550] = [87.625, 3, 0]),
  (Song12_array[551] = [87.75, 1, 0]),
  (Song12_array[552] = [87.875, 3, 0]),
  (Song12_array[553] = [88, 2, 0]),
  (Song12_array[554] = [88.125, 3, 0]),
  (Song12_array[555] = [88.25, 5, 0]),
  (Song12_array[556] = [88.375, 3, 0]),
  (Song12_array[557] = [88.5625, 1, 0]),
  (Song12_array[558] = [88.5625, 3, 0.0625]),
  (Song12_array[559] = [88.75, 3, 0]),
  (Song12_array[560] = [88.875, 3, 0]),
  (Song12_array[561] = [89, 5, 0]),
  (Song12_array[562] = [89.125, 3, 0]),
  (Song12_array[563] = [89.25, 2, 0]),
  (Song12_array[564] = [89.375, 3, 0]),
  (Song12_array[565] = [89.5, 1, 0]),
  (Song12_array[566] = [89.625, 3, 0]),
  (Song12_array[567] = [89.75, 2, 0]),
  (Song12_array[568] = [89.875, 3, 0]),
  (Song12_array[569] = [90, 5, 0]),
  (Song12_array[570] = [90.125, 3, 0]),
  (Song12_array[571] = [90.3125, 3, 0]),
  (Song12_array[572] = [90.5, 1, 0]),
  (Song12_array[573] = [90.5625, 1, 0]),
  (Song12_array[574] = [90.625, 1, 0]),
  (Song12_array[575] = [90.6875, 1, 0]),
  (Song12_array[576] = [90.75, 1, 0]),
  (Song12_array[577] = [90.9375, 5, 0]),
  (Song12_array[578] = [91.0625, 3, 0]),
  (Song12_array[579] = [91.1875, 2, 0]),
  (Song12_array[580] = [91.3125, 3, 0]),
  (Song12_array[581] = [91.4375, 1, 0]),
  (Song12_array[582] = [91.5625, 3, 0]),
  (Song12_array[583] = [91.6875, 2, 0]),
  (Song12_array[584] = [91.8125, 3, 0]),
  (Song12_array[585] = [91.9375, 5, 0]),
  (Song12_array[586] = [92.0625, 3, 0]),
  (Song12_array[587] = [92.25, 1, 0]),
  (Song12_array[588] = [92.25, 3, 0.0625]),
  (Song12_array[589] = [92.5, 3, 0]),
  (Song12_array[590] = [92.625, 3, 0]),
  (Song12_array[591] = [92.75, 5, 0]),
  (Song12_array[592] = [92.875, 3, 0]),
  (Song12_array[593] = [93, 2, 0]),
  (Song12_array[594] = [93.125, 3, 0]),
  (Song12_array[595] = [93.25, 1, 0]),
  (Song12_array[596] = [93.375, 3, 0]),
  (Song12_array[597] = [93.5, 2, 0]),
  (Song12_array[598] = [93.625, 3, 0]),
  (Song12_array[599] = [93.75, 5, 0]),
  (Song12_array[600] = [93.875, 3, 0]),
  (Song12_array[601] = [94, 3, 0]),
  (Song12_array[602] = [94.125, 1, 0]),
  (Song12_array[603] = [94.1875, 1, 0]),
  (Song12_array[604] = [94.25, 1, 0]),
  (Song12_array[605] = [94.3125, 1, 0]),
  (Song12_array[606] = [94.5625, 1, 0]),
  (Song12_array[607] = [94.6875, 5, 0]),
  (Song12_array[608] = [94.875, 1, 0]),
  (Song12_array[609] = [95, 4, 0]),
  (Song12_array[610] = [95.1875, 1, 0]),
  (Song12_array[611] = [95.3125, 3, 0]),
  (Song12_array[612] = [95.5, 1, 0]),
  (Song12_array[613] = [95.625, 2, 0]),
  (Song12_array[614] = [95.9375, 5, 0]),
  (Song12_array[615] = [96.3125, 1, 0]),
  (Song12_array[616] = [96.4375, 5, 0]),
  (Song12_array[617] = [96.625, 1, 0]),
  (Song12_array[618] = [96.75, 4, 0]),
  (Song12_array[619] = [96.9375, 1, 0]),
  (Song12_array[620] = [97.0625, 3, 0]),
  (Song12_array[621] = [97.25, 1, 0]),
  (Song12_array[622] = [97.375, 2, 0]),
  (Song12_array[623] = [97.6875, 5, 0]),
  (Song12_array[624] = [98.125, 1, 0]),
  (Song12_array[625] = [98.25, 5, 0]),
  (Song12_array[626] = [98.4375, 1, 0]),
  (Song12_array[627] = [98.5625, 4, 0]),
  (Song12_array[628] = [98.75, 1, 0]),
  (Song12_array[629] = [98.875, 3, 0]),
  (Song12_array[630] = [99.0625, 1, 0]),
  (Song12_array[631] = [99.1875, 2, 0]),
  (Song12_array[632] = [99.5, 5, 0]),
  (Song12_array[633] = [99.875, 1, 0]),
  (Song12_array[634] = [100, 5, 0]),
  (Song12_array[635] = [100.1875, 1, 0]),
  (Song12_array[636] = [100.3125, 4, 0]),
  (Song12_array[637] = [100.5, 1, 0]),
  (Song12_array[638] = [100.625, 3, 0]),
  (Song12_array[639] = [100.8125, 1, 0]),
  (Song12_array[640] = [100.9375, 2, 0]),
  (Song12_array[641] = [101.25, 5, 0]),
  (Song12_array[642] = [101.75, 1, 0]),
  (Song12_array[643] = [101.875, 5, 0]),
  (Song12_array[644] = [102.0625, 1, 0]),
  (Song12_array[645] = [102.1875, 4, 0]),
  (Song12_array[646] = [102.375, 1, 0]),
  (Song12_array[647] = [102.5, 3, 0]),
  (Song12_array[648] = [102.6875, 1, 0]),
  (Song12_array[649] = [102.8125, 2, 0]),
  (Song12_array[650] = [103.125, 5, 0]),
  (Song12_array[651] = [103.5, 1, 0]),
  (Song12_array[652] = [103.625, 5, 0]),
  (Song12_array[653] = [103.8125, 1, 0]),
  (Song12_array[654] = [103.9375, 4, 0]),
  (Song12_array[655] = [104.125, 1, 0]),
  (Song12_array[656] = [104.25, 3, 0]),
  (Song12_array[657] = [104.4375, 1, 0]),
  (Song12_array[658] = [104.5625, 2, 0]),
  (Song12_array[659] = [104.875, 5, 0]),
  (Song12_array[660] = [105.3125, 1, 0]),
  (Song12_array[661] = [105.4375, 5, 0]),
  (Song12_array[662] = [105.625, 1, 0]),
  (Song12_array[663] = [105.75, 4, 0]),
  (Song12_array[664] = [105.9375, 1, 0]),
  (Song12_array[665] = [106.0625, 3, 0]),
  (Song12_array[666] = [106.25, 1, 0]),
  (Song12_array[667] = [106.375, 2, 0]),
  (Song12_array[668] = [106.6875, 5, 0]),
  (Song12_array[669] = [107.0625, 1, 0]),
  (Song12_array[670] = [107.1875, 5, 0]),
  (Song12_array[671] = [107.375, 1, 0]),
  (Song12_array[672] = [107.5, 4, 0]),
  (Song12_array[673] = [107.6875, 1, 0]),
  (Song12_array[674] = [107.8125, 3, 0]),
  (Song12_array[675] = [108, 1, 0]),
  (Song12_array[676] = [108.125, 2, 0]),
  (Song12_array[677] = [108.4375, 5, 0]),
  (Song12_array[678] = [108.9375, 1, 0.0625]),
  (Song12_array[679] = [108.9375, 3, 0]),
  (Song12_array[680] = [109.375, 3, 0.0625]),
  (Song12_array[681] = [109.375, 5, 0]),
  (Song12_array[682] = [109.875, 1, 0.0625]),
  (Song12_array[683] = [109.875, 3, 0]),
  (Song12_array[684] = [110.3125, 1, 0]),
  (Song12_array[685] = [110.3125, 3, 0.0625]),
  (Song12_array[686] = [110.75, 1, 0.0625]),
  (Song12_array[687] = [110.75, 3, 0.0625]),
  (Song12_array[688] = [110.75, 5, 0]),
  (Song12_array[689] = [111.1875, 1, 0]),
  (Song12_array[690] = [111.1875, 3, 0.0625]),
  (Song12_array[691] = [111.6875, 3, 0.0625]),
  (Song12_array[692] = [111.6875, 5, 0]),
  (Song12_array[693] = [112.125, 1, 0]),
  (Song12_array[694] = [112.5625, 1, 0.0625]),
  (Song12_array[695] = [112.5625, 3, 0.0625]),
  (Song12_array[696] = [112.5625, 5, 0]),
  (Song12_array[697] = [113.0625, 1, 0]),
  (Song12_array[698] = [113.0625, 3, 0.0625]),
  (Song12_array[699] = [113.5, 3, 0.0625]),
  (Song12_array[700] = [113.5, 5, 0]),
  (Song12_array[701] = [113.9375, 1, 0]),
  (Song12_array[702] = [114.375, 5, 0]),
  (Song12_array[703] = [114.8125, 1, 0]),
  (Song12_array[704] = [114.8125, 3, 0.0625]),
  (Song12_array[705] = [115.3125, 1, 0.0625]),
  (Song12_array[706] = [115.3125, 3, 0.0625]),
  (Song12_array[707] = [115.3125, 5, 0]),
  (Song12_array[708] = [115.75, 1, 0]),
  (Song12_array[709] = [115.75, 3, 0.0625]),
  (Song12_array[710] = [116.1875, 5, 0]),
  (Song12_array[711] = [116.625, 1, 0.0625]),
  (Song12_array[712] = [116.625, 3, 0]),
  (Song12_array[713] = [117.0625, 1, 0]),
  (Song12_array[714] = [117.5, 3, 0.0625]),
  (Song12_array[715] = [117.5, 5, 0]),
  (Song12_array[716] = [118, 1, 0]),
  (Song12_array[717] = [118, 3, 0.0625]),
  (Song12_array[718] = [118, 5, 0.0625]),
  (Song12_array[719] = [118.4375, 3, 0.0625]),
  (Song12_array[720] = [118.4375, 5, 0]),
  (Song12_array[721] = [118.875, 1, 0]),
  (Song12_array[722] = [118.875, 3, 0.0625]),
  (Song12_array[723] = [119.375, 3, 0.0625]),
  (Song12_array[724] = [119.375, 5, 0]),
  (Song12_array[725] = [119.8125, 1, 0]),
  (Song12_array[726] = [119.8125, 3, 0.0625]),
  (Song12_array[727] = [120.25, 1, 0.0625]),
  (Song12_array[728] = [120.25, 3, 0]),
  (Song12_array[729] = [120.25, 5, 0.0625]),
  (Song12_array[730] = [120.6875, 1, 0]),
  (Song12_array[731] = [120.6875, 3, 0.0625]),
  (Song12_array[732] = [121.1875, 3, 0.0625]),
  (Song12_array[733] = [121.1875, 5, 0]),
  (Song12_array[734] = [121.625, 1, 0]),
  (Song12_array[735] = [122.0625, 1, 0.0625]),
  (Song12_array[736] = [122.0625, 3, 0.0625]),
  (Song12_array[737] = [122.0625, 5, 0]),
  (Song12_array[738] = [122.5625, 1, 0]),
  (Song12_array[739] = [122.5625, 3, 0.0625]),
  (Song12_array[740] = [122.875, 5, 0]),
  (Song12_array[741] = [122.9375, 5, 0]),
  (Song12_array[742] = [123, 5, 0]),
  (Song12_array[743] = [123.0625, 5, 0]),
  (Song12_array[744] = [123.125, 5, 0]),
  (Song12_array[745] = [123.25, 2, 0]),
  (Song12_array[746] = [123.375, 4, 0]),
  (Song12_array[747] = [123.5, 2, 0]),
  (Song12_array[748] = [123.75, 5, 0]),
  (Song12_array[749] = [123.8125, 5, 0]),
  (Song12_array[750] = [123.875, 5, 0]),
  (Song12_array[751] = [123.9375, 5, 0]),
  (Song12_array[752] = [124, 5, 0]),
  (Song12_array[753] = [124.0625, 5, 0]),
  (Song12_array[754] = [124.125, 5, 0]),
  (Song12_array[755] = [124.1875, 5, 0]),
  (Song12_array[756] = [124.25, 5, 0]),
  (Song12_array[757] = [124.3125, 5, 0]),
  (Song12_array[758] = [124.375, 5, 0]),
  (Song12_array[759] = [124.4375, 5, 0]),
  (Song12_array[760] = [124.5, 5, 0]),
  (Song12_array[761] = [124.5625, 5, 0]),
  (Song12_array[762] = [124.625, 5, 0]),
  (Song12_array[763] = [124.6875, 5, 0]),
  (Song12_array[764] = [124.75, 5, 0]),
  (Song12_array[765] = [124.8125, 5, 0]),
  (Song12_array[766] = [124.875, 5, 0]),
  (Song12_array[767] = [124.9375, 5, 0]);
var MuevePasto = pc.createScript("muevePasto");
MuevePasto.attributes.add("speed", { type: "number" }),
  MuevePasto.attributes.add("inicio", { type: "number" }),
  MuevePasto.attributes.add("limite", { type: "number" }),
  (MuevePasto.prototype.initialize = function () {}),
  (MuevePasto.prototype.update = function (t) {
    if (!gameOver && !pause) {
      var e = this.entity.getLocalPosition();
      this.entity.setLocalPosition(
        e.x,
        e.y,
        e.z - t * (this.speed + extraSpeedSongsPastos[currentCancion])
      ),
        (e = this.entity.getLocalPosition()).z < this.limite &&
          this.entity.setLocalPosition(e.x, e.y, this.inicio);
    }
  });
var AnimaUvsPlus = pc.createScript("animaUvsPlus");
AnimaUvsPlus.attributes.add("material", {
  type: "asset",
  assetType: "material",
  array: !1,
}),
  AnimaUvsPlus.attributes.add("speed", {
    type: "number",
    default: 0.01,
    title: "speed",
  }),
  AnimaUvsPlus.attributes.add("eje", {
    type: "number",
    default: 0,
    title: "ejeX_o_Y",
  }),
  AnimaUvsPlus.attributes.add("loop", {
    type: "number",
    default: 1,
    title: "LOOP",
  }),
  AnimaUvsPlus.attributes.add("desde", {
    type: "number",
    default: 0,
    title: "desde",
  }),
  AnimaUvsPlus.attributes.add("hasta", {
    type: "number",
    default: 1,
    title: "hasta",
  }),
  AnimaUvsPlus.attributes.add("tipoMaterial", {
    type: "string",
    array: !0,
    title: "opacityMapOffset",
  }),
  (AnimaUvsPlus.prototype.initialize = function () {
    this.materialCargado = this.material.resource;
  }),
  (AnimaUvsPlus.prototype.resetMaterial = function (t) {
    (this.materialCargado[this.tipoMaterial] = new pc.Vec2(0, 0)),
      this.materialCargado.update(),
      (this.entity.enabled = !0),
      (this.eje = t);
  }),
  (AnimaUvsPlus.prototype.update = function (t) {
    if (!pause)
      for (var a = 0; a < this.tipoMaterial.length; a++) {
        var e;
        switch (this.tipoMaterial[a]) {
          case "opacityMapOffset":
            e = this.materialCargado.opacityMapOffset;
            break;
          case "diffuseMapOffset":
            e = this.materialCargado.diffuseMapOffset;
            break;
          case "emissiveMapOffset":
            e = this.materialCargado.emissiveMapOffset;
        }
        if (0 == this.eje)
          (i = e.y - t * this.speed) < 0 &&
            (0 == this.loop ? ((i = 0), (this.eje = -99)) : (i = 1)),
            (this.materialCargado[this.tipoMaterial[a]] = new pc.Vec2(0, i)),
            this.materialCargado.update();
        else if (1 == this.eje) {
          var i;
          (i = e.x + t * this.speed) > this.hasta &&
            (0 == this.loop
              ? ((i = this.hasta),
                (this.eje = -99),
                setTimeout(this.apagaObjeto.bind(this), 20))
              : (i = this.desde)),
            (this.materialCargado[this.tipoMaterial[a]] = new pc.Vec2(i, 0)),
            this.materialCargado.update();
        }
      }
  }),
  (AnimaUvsPlus.prototype.apagaObjeto = function () {
    this.entity.enabled = !1;
  });
var ScoreNumerosManager = pc.createScript("scoreNumerosManager");
ScoreNumerosManager.attributes.add("slot", { type: "entity", array: !0 }),
  (ScoreNumerosManager.prototype.initialize = function () {
    (this.indexSlot = 0),
      (this.speed = 7),
      (this.desde = 0.8),
      (this.hasta = 1);
  }),
  (ScoreNumerosManager.prototype.poneNumero = function (e, t, s, i) {
    null != t && (this.desde = t),
      null != s && (this.hasta = s),
      null != i && (this.speed = i),
      (this.slot[this.indexSlot].enabled = !0),
      this.slot[this.indexSlot].script.scoreNumerosControl.poneNumero(
        e,
        this.desde,
        this.hasta,
        this.speed
      ),
      (this.indexSlot = this.indexSlot + 1),
      this.indexSlot == this.slot.length && (this.indexSlot = 0);
  });
var ScoreNumeros = pc.createScript("scoreNumeros");
ScoreNumeros.attributes.add("material", {
  type: "asset",
  assetType: "material",
  array: !0,
}),
  (ScoreNumeros.prototype.initialize = function () {
    (this.iniciaAlfa = !1),
      (this.desde = 0),
      (this.hasta = 0),
      (this.currentNum = ""),
      (this.indexMaterial = 0),
      (this.speed = 8),
      (this.entity.enabled = !1),
      (this.modo = "poneYsaca"),
      (this.hilo = null),
      (this.tiempoVisible = 0.25),
      (this.materiales = []);
    for (var t = 0; t < this.material.length; t++)
      this.materiales[t] = this.material[t].resource.clone();
    (this.entity.enabled = !1),
      (this.posIni = this.entity.getLocalPosition().clone()),
      (this.tween = null);
  }),
  (ScoreNumeros.prototype.setNumero = function (t) {
    var e = this.getIndex(t);
    this.indexMaterial = e;
    for (
      var i = this.materiales[e], s = this.entity.model.meshInstances, a = 0;
      a < s.length;
      ++a
    ) {
      var r = s[a];
      (r.material = i), (r.material.opacity = this.desde), r.material.update();
    }
  }),
  (ScoreNumeros.prototype.poneNumero = function (t, e, i, s, a) {
    if (
      (clearInterval(this.hilo),
      (this.desde = e),
      (this.hasta = i),
      (this.speed = s),
      (this.currentNum = t),
      this.setNumero(t),
      (this.iniciaAlfa = !0),
      null != this.tween && this.tween.stop(),
      !a || null == a)
    ) {
      this.entity.setLocalPosition(this.posIni);
      var r = this.entity.getLocalPosition();
      (this.tween = this.entity
        .tween(this.entity.getLocalPosition())
        .to(new pc.Vec3(r.x, r.y, r.z - 3), 0.25, pc.Linear)),
        this.tween.start();
    }
  }),
  (ScoreNumeros.prototype.getIndex = function (t) {
    switch (t) {
      case "0":
        return 0;
      case "1":
        return 1;
      case "2":
        return 2;
      case "3":
        return 3;
      case "4":
        return 4;
      case "5":
        return 5;
      case "6":
        return 6;
      case "7":
        return 7;
      case "8":
        return 8;
      case "9":
        return 9;
      case "+":
        return 10;
      case "/":
        return 11;
    }
  }),
  (ScoreNumeros.prototype.update = function (t) {
    if (this.iniciaAlfa) {
      for (
        var e, i = this.entity.model.meshInstances, s = 0;
        s < i.length;
        ++s
      ) {
        var a = i[s];
        (e = a.material.opacity),
          this.desde < this.hasta
            ? (e += this.speed * t) > 1 && ((e = 1), (this.iniciaAlfa = !1))
            : (e -= this.speed * t) < 0 && ((e = 0), (this.iniciaAlfa = !1)),
          (a.material.opacity = e),
          a.material.update();
      }
      this.iniciaAlfa ||
        ("poneYsaca" == this.modo &&
          (1 == e
            ? (clearInterval(this.hilo),
              (this.hilo = setInterval(
                this.poneNumero.bind(this, this.currentNum, 1, 0, 3, !0),
                1e3 * this.tiempoVisible
              )))
            : (this.entity.enabled = !1)));
    }
  });
var ScoreNumerosControl = pc.createScript("scoreNumerosControl");
(ScoreNumerosControl.prototype.initialize = function () {}),
  (ScoreNumerosControl.prototype.update = function (e) {}),
  (ScoreNumerosControl.prototype.poneNumero = function (e, o, t, r) {
    null != o && (this.desde = o),
      null != t && (this.hasta = t),
      null != r && (this.speed = r);
    for (var n = 0; n < this.entity.children[n].length; n++)
      this.entity.children[n].enabled = !1;
    for (n = 0; n < e.length; n++)
      (this.entity.children[n].enabled = !0),
        this.entity.children[n].script.scoreNumeros.poneNumero(e[n], o, t, r);
  });
var Colisiones = pc.createScript("colisiones");
Colisiones.attributes.add("mcPisoHit", { type: "entity" }),
  Colisiones.attributes.add("tipo", { type: "string", default: "" }),
  (Colisiones.prototype.initialize = function () {
    (espera = 0),
      (this.espera = !1),
      (this.posMuerte = null),
      (this.bola = null),
      (this.coliderUsado = !1),
      (this.tiempoUsado = 0);
  }),
  (Colisiones.prototype.onTriggerEnter = function (a) {
    if (
      !gameOver &&
      !pause &&
      _coreSystem.start &&
      _coreSystem.startMusic &&
      !_coreSystem.finCancion &&
      !enMenu
    )
      switch (this.tipo) {
        case "normal":
          if (this.coliderUsado) return;
          var t = a.getPosition(),
            e = this.entity.parent,
            o = e.script.nota.tipoNota,
            i = e.getPosition();
          if (
            t.x >= i.x - anchoPlataforma &&
            t.x <= i.x + anchoPlataforma &&
            t.z <= i.z + largoPlataforma &&
            t.z >= i.z - largoPlataforma
          ) {
            espera = -1;
            var s = o;
            (this.mcPisoHit.enabled = !1),
              1 == s && _rebote.matarBola(!0),
              t.x >= i.x - anchoPlataforma / toleranciaPerfect &&
              t.x <= i.x + anchoPlataforma / toleranciaPerfect &&
              t.z <= i.z + largoPlataforma &&
              t.z >= i.z - largoPlataforma
                ? e.script.nota.mataNota("perfect")
                : t.x >= i.x - anchoPlataforma / toleranciaGema &&
                  t.x <= i.x + anchoPlataforma / toleranciaGema &&
                  t.z <= i.z + largoPlataforma &&
                  t.z >= i.z - largoPlataforma
                ? e.script.nota.mataNota("gema")
                : e.script.nota.mataNota("hit");
          }
          break;
        case "piso":
          (this.mcPisoHit.enabled = !1),
            (this.espera = !0),
            (this.bola = a),
            (espera = 0);
          break;
        case "marca":
          t = a.getPosition().clone();
          (t = new pc.Vec3(t.x, t.y - 0.6, t.z)),
            (this.mcPisoHit.enabled = !0),
            this.mcPisoHit.setPosition(t);
      }
  }),
  (Colisiones.prototype.update = function (a) {
    if (!pause) {
      if (
        (this.coliderUsado &&
          ((this.tiempoUsado = this.tiempoUsado + a),
          this.tiempoUsado >= 2 &&
            ((this.tiempoUsado = 0), (this.coliderUsado = !1))),
        gameOver)
      )
        return (this.espera = !1), void (espera = 0);
      this.espera &&
        (-1 == espera && ((this.espera = !1), (espera = 0)),
        (espera += a),
        espera >= 0.13 &&
          ((this.espera = !1),
          (espera = 0),
          _coreSystem.finCancion || _rebote.matarBola(!0)));
    }
  });
var Text = pc.createScript("text");
Text.attributes.add("text", { type: "string", default: "Hello World" }),
  (Text.prototype.initialize = function () {
    (this.canvas = document.createElement("canvas")),
      (this.canvas.height = 128),
      (this.canvas.width = 512),
      (this.context = this.canvas.getContext("2d")),
      (this.texture = new pc.Texture(this.app.graphicsDevice, {
        format: pc.PIXELFORMAT_R8_G8_B8,
        autoMipmap: !0,
      })),
      this.texture.setSource(this.canvas),
      (this.texture.minFilter = pc.FILTER_LINEAR_MIPMAP_LINEAR),
      (this.texture.magFilter = pc.FILTER_LINEAR),
      (this.texture.addressU = pc.ADDRESS_CLAMP_TO_EDGE),
      (this.texture.addressV = pc.ADDRESS_CLAMP_TO_EDGE),
      this.updateText();
    var t = this.entity.model.material;
    (t.emissiveMap = this.texture),
      (t.opacityMap = this.texture),
      (t.blendType = pc.BLEND_NORMAL),
      t.update(),
      this.on("attr", function (t, e, i) {
        this.updateText();
      });
  }),
  (Text.prototype.updateText = function () {
    var t = this.context,
      e = t.canvas.width,
      i = t.canvas.height;
    (t.fillStyle = "black"),
      t.fillRect(0, 0, e, i),
      (t.fillStyle = "white"),
      (t.font = "bold 70px Verdana"),
      (t.textAlign = "center"),
      (t.textBaseline = "middle"),
      t.fillText(this.text, e / 2, i / 2),
      this.texture.upload();
  });
var Billboard = pc.createScript("billboard");
(Billboard.prototype.initialize = function () {
  this.camera = this.app.root.findByName("Camera");
}),
  (Billboard.prototype.update = function (t) {
    this.entity.setRotation(this.camera.getRotation()),
      this.entity.rotateLocal(90, 0, 0);
  });
var AnimaAlfa3d = pc.createScript("animaAlfa3d");
AnimaAlfa3d.attributes.add("material", {
  type: "asset",
  assetType: "material",
  array: !1,
}),
  AnimaAlfa3d.attributes.add("speed", {
    type: "number",
    default: 0.01,
    title: "speed",
  }),
  AnimaAlfa3d.attributes.add("desde", {
    type: "number",
    default: 0,
    title: "desde",
  }),
  AnimaAlfa3d.attributes.add("hasta", {
    type: "number",
    default: 1,
    title: "hasta",
  }),
  AnimaAlfa3d.attributes.add("delay", {
    type: "number",
    default: 0,
    title: "delay",
  }),
  AnimaAlfa3d.attributes.add("loop", {
    type: "number",
    default: 1,
    title: "LOOP",
  }),
  AnimaAlfa3d.attributes.add("apagaAlTerminar", {
    type: "number",
    default: 1,
    title: "apagaAlTerminar",
  }),
  AnimaAlfa3d.attributes.add("tipoMaterial", {
    type: "string",
    default: "opacity",
    title: "opacity",
  }),
  AnimaAlfa3d.attributes.add("finAnim", {
    type: "number",
    default: 1,
    title: "finAnim",
  }),
  (AnimaAlfa3d.prototype.initialize = function () {
    (this.sentido = 0),
      (this.contadorDelay = 0),
      (this.materialCargado = this.material.resource),
      this.desde < this.hasta ? (this.sentido = 1) : (this.sentido = -1),
      this.resetMaterial();
  }),
  (AnimaAlfa3d.prototype.empiezaAnim = function (t, a, i, e) {
    (this.entity.enabled = !0),
      (this.desde = t),
      (this.hasta = a),
      null != i && (this.delay = i),
      null != e && (this.speed = e),
      this.desde < this.hasta ? (this.sentido = 1) : (this.sentido = -1),
      (this.contadorDelay = 0),
      this.resetMaterial(),
      (this.finAnim = 0);
  }),
  (AnimaAlfa3d.prototype.resetMaterial = function (t) {
    (this.materialCargado[this.tipoMaterial] = this.desde),
      this.materialCargado.update();
  }),
  (AnimaAlfa3d.prototype.update = function (t) {
    if (1 != this.finAnim)
      if (this.contadorDelay < this.delay)
        this.contadorDelay = this.contadorDelay + t;
      else {
        var a,
          i = this.materialCargado.opacity,
          e = !1;
        (a = -1 == this.sentido ? i - t * this.speed : i + t * this.speed) <= 0
          ? ((e = !0), (a = 0))
          : a >= 1 && ((e = !0), (a = 1)),
          (this.materialCargado[this.tipoMaterial] = a),
          this.materialCargado.update(),
          e && 1 == this.loop && this.empiezaAnim(this.desde, this.hasta);
      }
  }),
  (AnimaAlfa3d.prototype.apagaObjeto = function () {
    1 == this.finAnim && (this.entity.enabled = !1);
  }),
  (AnimaAlfa3d.prototype.terminaAnim = function () {
    this.finAnim = 1;
  });
var AlphaConVelocidad = pc.createScript("alphaConVelocidad");
AlphaConVelocidad.attributes.add("tiempoEspera", {
  type: "number",
  default: 0,
  title: "tiempoEspera",
}),
  AlphaConVelocidad.attributes.add("duracionIn", {
    type: "number",
    default: 0,
    title: "duracionIn",
  }),
  AlphaConVelocidad.attributes.add("duracionOut", {
    type: "number",
    default: 0,
    title: "duracionOut",
  }),
  AlphaConVelocidad.attributes.add("hijos", { type: "entity", array: !0 }),
  (AlphaConVelocidad.prototype.initialize = function () {}),
  (AlphaConVelocidad.prototype.update = function (t) {}),
  (AlphaConVelocidad.prototype.fadeIn = function (t) {
    for (var e = { x: 0 }, i = 0; i < this.hijos.length; i++)
      null != this.hijos[i].element
        ? (this.hijos[i].element.opacity = 0)
        : ((this.hijos[i].model.material.opacity = 0),
          this.hijos[i].model.material.update());
    null != this.entity.element
      ? (this.entity.element.opacity = 0)
      : ((this.entity.model.material.opacity = 0),
        this.entity.model.material.update()),
      (this.hiloDisco = this.app
        .tween(e)
        .to({ x: 1 }, this.duracionIn, pc.SineOut)
        .onComplete(() => {
          null != t && t();
        })
        .onUpdate(() => {
          null != this.entity.element
            ? (this.entity.element.opacity = e.x)
            : ((this.entity.model.material.opacity = e.x),
              this.entity.model.material.update());
          for (var t = 0; t < this.hijos.length; t++)
            null != this.hijos[t].element
              ? (this.hijos[t].element.opacity = e.x)
              : ((this.hijos[t].model.material.opacity = e.x),
                this.hijos[t].model.material.update());
        })
        .delay(this.tiempoEspera)
        .start());
  }),
  (AlphaConVelocidad.prototype.fadeOut = function (t) {
    for (var e = { x: 1 }, i = 0; i < this.hijos.length; i++)
      null != this.hijos[i].element
        ? (this.hijos[i].element.opacity = 1)
        : ((this.hijos[i].model.material.opacity = 1),
          this.hijos[i].model.material.update());
    null != this.entity.element
      ? (this.entity.element.opacity = 1)
      : ((this.entity.model.material.opacity = 1),
        this.entity.model.material.update()),
      (this.hiloDisco = this.app
        .tween(e)
        .to({ x: 0 }, this.duracionIn, pc.SineOut)
        .onComplete(() => {
          null != t && t();
        })
        .onUpdate(() => {
          null != this.entity.element
            ? (this.entity.element.opacity = e.x)
            : ((this.entity.model.material.opacity = e.x),
              this.entity.model.material.update());
          for (var t = 0; t < this.hijos.length; t++)
            null != this.hijos[t].element
              ? (this.hijos[t].element.opacity = e.x)
              : ((this.hijos[t].model.material.opacity = e.x),
                this.hijos[t].model.material.update());
        })
        .start());
  });
var ReproduceAnimSprite = pc.createScript("reproduceAnimSprite");
ReproduceAnimSprite.attributes.add("frames", {
  type: "number",
  title: "frames",
}),
  ReproduceAnimSprite.attributes.add("spriteNumber", {
    type: "number",
    title: "spriteNumber",
  }),
  ReproduceAnimSprite.attributes.add("loop", {
    type: "boolean",
    title: "loop",
  }),
  ReproduceAnimSprite.attributes.add("desde", {
    type: "number",
    title: "desde",
  }),
  ReproduceAnimSprite.attributes.add("hasta", {
    type: "number",
    title: "hasta",
  }),
  ReproduceAnimSprite.attributes.add("autoStart", {
    type: "boolean",
    title: "autoStart",
  }),
  ReproduceAnimSprite.attributes.add("hideOnFinish", {
    type: "boolean",
    title: "hideOnFinish",
  }),
  (ReproduceAnimSprite.prototype.initialize = function () {
    (this.index = this.desde), (this.cont = 0), (this.callBack = null);
  }),
  (ReproduceAnimSprite.prototype.Play = function (t, e, i) {
    (this.cont = 0),
      (this.desde = e),
      null == e && (this.desde = 0),
      (this.hasta = i),
      null == i && (this.hasta = this.spriteNumber),
      (this.index = this.desde),
      (this.callBack = t),
      (this.autoStart = !0);
  }),
  (ReproduceAnimSprite.prototype.Stop = function () {
    this.autoStart = !1;
  }),
  (ReproduceAnimSprite.prototype.update = function (t) {
    if (this.autoStart) {
      var e = t,
        i = 1 / e;
      this.cont = this.cont + e;
      var r = i / this.frames;
      (r /= i),
        this.cont >= r &&
          ((this.cont = 0),
          (this.entity.element.spriteFrame = this.index),
          (this.index = this.index + 1),
          this.index == this.hasta &&
            (this.loop
              ? (this.index = 0)
              : ((this.autoStart = !1),
                null != this.callBack && this.callBack(),
                this.hideOnFinish && (this.entity.enabled = !1))));
    }
  });
var CheckRotate = pc.createScript("checkRotate");
CheckRotate.prototype.initialize = function () {
  isMobile.any() &&
    ((this.orientation = ""),
    setInterval(() => {
      "portrait" != this.orientation &&
      window.matchMedia("(orientation: portrait)").matches
        ? ((this.entity.element.enabled = !1),
          (this.entity.element.useInput = !1),
          (this.entity.children[0].enabled = !1),
          (this.orientation = "portrait"),
          MetodoUnpause())
        : "landscape" != this.orientation &&
          window.matchMedia("(orientation: landscape)").matches &&
          ((this.orientation = "landscape"),
          console.log("El dispositivo está en modo landscape."),
          (this.entity.element.enabled = !0),
          (this.entity.element.useInput = !0),
          (this.entity.children[0].enabled = !0),
          MetodoPause());
    }, 100));
};
