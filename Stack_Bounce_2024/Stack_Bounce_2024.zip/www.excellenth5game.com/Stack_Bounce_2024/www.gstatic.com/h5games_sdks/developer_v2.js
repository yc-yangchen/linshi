(function () {
  "use strict";
  var q;
  function aa(a) {
    var b = 0;
    return function () {
      return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
    };
  }
  var r =
    typeof Object.defineProperties == "function"
      ? Object.defineProperty
      : function (a, b, c) {
          if (a == Array.prototype || a == Object.prototype) return a;
          a[b] = c.value;
          return a;
        };
  function ba(a) {
    a = [
      "object" == typeof globalThis && globalThis,
      a,
      "object" == typeof window && window,
      "object" == typeof self && self,
      "object" == typeof global && global,
    ];
    for (var b = 0; b < a.length; ++b) {
      var c = a[b];
      if (c && c.Math == Math) return c;
    }
    throw Error("Cannot find global object");
  }
  var t = ba(this);
  function u(a, b) {
    if (b)
      a: {
        var c = t;
        a = a.split(".");
        for (var d = 0; d < a.length - 1; d++) {
          var h = a[d];
          if (!(h in c)) break a;
          c = c[h];
        }
        a = a[a.length - 1];
        d = c[a];
        b = b(d);
        b != d &&
          b != null &&
          r(c, a, { configurable: !0, writable: !0, value: b });
      }
  }
  u("Symbol", function (a) {
    function b(l) {
      if (this instanceof b) throw new TypeError("Symbol is not a constructor");
      return new c(d + (l || "") + "_" + h++, l);
    }
    function c(l, e) {
      this.g = l;
      r(this, "description", { configurable: !0, writable: !0, value: e });
    }
    if (a) return a;
    c.prototype.toString = function () {
      return this.g;
    };
    var d = "jscomp_symbol_" + ((Math.random() * 1e9) >>> 0) + "_",
      h = 0;
    return b;
  });
  u("Symbol.iterator", function (a) {
    if (a) return a;
    a = Symbol("Symbol.iterator");
    for (
      var b =
          "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(
            " "
          ),
        c = 0;
      c < b.length;
      c++
    ) {
      var d = t[b[c]];
      typeof d === "function" &&
        typeof d.prototype[a] != "function" &&
        r(d.prototype, a, {
          configurable: !0,
          writable: !0,
          value: function () {
            return ca(aa(this));
          },
        });
    }
    return a;
  });
  function ca(a) {
    a = { next: a };
    a[Symbol.iterator] = function () {
      return this;
    };
    return a;
  }
  function v(a) {
    var b =
      typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
    if (b) return b.call(a);
    if (typeof a.length == "number") return { next: aa(a) };
    throw Error(String(a) + " is not an iterable or ArrayLike");
  }
  function da(a) {
    if (!(a instanceof Array)) {
      a = v(a);
      for (var b, c = []; !(b = a.next()).done; ) c.push(b.value);
      a = c;
    }
    return a;
  }
  var ea =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            function b() {}
            b.prototype = a;
            return new b();
          },
    fa;
  if (typeof Object.setPrototypeOf == "function") fa = Object.setPrototypeOf;
  else {
    var ha;
    a: {
      var ia = { a: !0 },
        ja = {};
      try {
        ja.__proto__ = ia;
        ha = ja.a;
        break a;
      } catch (a) {}
      ha = !1;
    }
    fa = ha
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var ka = fa;
  function w(a, b) {
    a.prototype = ea(b.prototype);
    a.prototype.constructor = a;
    if (ka) ka(a, b);
    else
      for (var c in b)
        if (c != "prototype")
          if (Object.defineProperties) {
            var d = Object.getOwnPropertyDescriptor(b, c);
            d && Object.defineProperty(a, c, d);
          } else a[c] = b[c];
    a.qa = b.prototype;
  }
  function la() {
    this.i = !1;
    this.g = null;
    this.A = void 0;
    this.j = 1;
    this.u = 0;
    this.h = null;
  }
  function ma(a) {
    if (a.i) throw new TypeError("Generator is already running");
    a.i = !0;
  }
  la.prototype.m = function (a) {
    this.A = a;
  };
  function na(a, b) {
    a.h = { X: b, ga: !0 };
    a.j = a.u;
  }
  la.prototype.return = function (a) {
    this.h = { return: a };
    this.j = this.u;
  };
  function oa(a) {
    this.g = new la();
    this.h = a;
  }
  function pa(a, b) {
    ma(a.g);
    var c = a.g.g;
    if (c)
      return qa(
        a,
        "return" in c
          ? c["return"]
          : function (d) {
              return { value: d, done: !0 };
            },
        b,
        a.g.return
      );
    a.g.return(b);
    return y(a);
  }
  function qa(a, b, c, d) {
    try {
      var h = b.call(a.g.g, c);
      if (!(h instanceof Object))
        throw new TypeError("Iterator result " + h + " is not an object");
      if (!h.done) return (a.g.i = !1), h;
      var l = h.value;
    } catch (e) {
      return (a.g.g = null), na(a.g, e), y(a);
    }
    a.g.g = null;
    d.call(a.g, l);
    return y(a);
  }
  function y(a) {
    for (; a.g.j; )
      try {
        var b = a.h(a.g);
        if (b) return (a.g.i = !1), { value: b.value, done: !1 };
      } catch (c) {
        (a.g.A = void 0), na(a.g, c);
      }
    a.g.i = !1;
    if (a.g.h) {
      b = a.g.h;
      a.g.h = null;
      if (b.ga) throw b.X;
      return { value: b.return, done: !0 };
    }
    return { value: void 0, done: !0 };
  }
  function ra(a) {
    this.next = function (b) {
      ma(a.g);
      a.g.g ? (b = qa(a, a.g.g.next, b, a.g.m)) : (a.g.m(b), (b = y(a)));
      return b;
    };
    this.throw = function (b) {
      ma(a.g);
      a.g.g ? (b = qa(a, a.g.g["throw"], b, a.g.m)) : (na(a.g, b), (b = y(a)));
      return b;
    };
    this.return = function (b) {
      return pa(a, b);
    };
    this[Symbol.iterator] = function () {
      return this;
    };
  }
  function sa(a) {
    function b(d) {
      return a.next(d);
    }
    function c(d) {
      return a.throw(d);
    }
    return new Promise(function (d, h) {
      function l(e) {
        e.done ? d(e.value) : Promise.resolve(e.value).then(b, c).then(l, h);
      }
      l(a.next());
    });
  }
  function ta() {
    for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
      b[c - a] = arguments[c];
    return b;
  }
  u("Promise", function (a) {
    function b(e) {
      this.h = 0;
      this.i = void 0;
      this.g = [];
      this.A = !1;
      var f = this.j();
      try {
        e(f.resolve, f.reject);
      } catch (g) {
        f.reject(g);
      }
    }
    function c() {
      this.g = null;
    }
    function d(e) {
      return e instanceof b
        ? e
        : new b(function (f) {
            f(e);
          });
    }
    if (a) return a;
    c.prototype.h = function (e) {
      if (this.g == null) {
        this.g = [];
        var f = this;
        this.i(function () {
          f.m();
        });
      }
      this.g.push(e);
    };
    var h = t.setTimeout;
    c.prototype.i = function (e) {
      h(e, 0);
    };
    c.prototype.m = function () {
      for (; this.g && this.g.length; ) {
        var e = this.g;
        this.g = [];
        for (var f = 0; f < e.length; ++f) {
          var g = e[f];
          e[f] = null;
          try {
            g();
          } catch (k) {
            this.j(k);
          }
        }
      }
      this.g = null;
    };
    c.prototype.j = function (e) {
      this.i(function () {
        throw e;
      });
    };
    b.prototype.j = function () {
      function e(k) {
        return function (m) {
          g || ((g = !0), k.call(f, m));
        };
      }
      var f = this,
        g = !1;
      return { resolve: e(this.T), reject: e(this.m) };
    };
    b.prototype.T = function (e) {
      if (e === this)
        this.m(new TypeError("A Promise cannot resolve to itself"));
      else if (e instanceof b) this.V(e);
      else {
        a: switch (typeof e) {
          case "object":
            var f = e != null;
            break a;
          case "function":
            f = !0;
            break a;
          default:
            f = !1;
        }
        f ? this.S(e) : this.u(e);
      }
    };
    b.prototype.S = function (e) {
      var f = void 0;
      try {
        f = e.then;
      } catch (g) {
        this.m(g);
        return;
      }
      typeof f == "function" ? this.W(f, e) : this.u(e);
    };
    b.prototype.m = function (e) {
      this.N(2, e);
    };
    b.prototype.u = function (e) {
      this.N(1, e);
    };
    b.prototype.N = function (e, f) {
      if (this.h != 0)
        throw Error(
          "Cannot settle(" +
            e +
            ", " +
            f +
            "): Promise already settled in state" +
            this.h
        );
      this.h = e;
      this.i = f;
      this.h === 2 && this.U();
      this.oa();
    };
    b.prototype.U = function () {
      var e = this;
      h(function () {
        if (e.pa()) {
          var f = t.console;
          typeof f !== "undefined" && f.error(e.i);
        }
      }, 1);
    };
    b.prototype.pa = function () {
      if (this.A) return !1;
      var e = t.CustomEvent,
        f = t.Event,
        g = t.dispatchEvent;
      if (typeof g === "undefined") return !0;
      typeof e === "function"
        ? (e = new e("unhandledrejection", { cancelable: !0 }))
        : typeof f === "function"
        ? (e = new f("unhandledrejection", { cancelable: !0 }))
        : ((e = t.document.createEvent("CustomEvent")),
          e.initCustomEvent("unhandledrejection", !1, !0, e));
      e.promise = this;
      e.reason = this.i;
      return g(e);
    };
    b.prototype.oa = function () {
      if (this.g != null) {
        for (var e = 0; e < this.g.length; ++e) l.h(this.g[e]);
        this.g = null;
      }
    };
    var l = new c();
    b.prototype.V = function (e) {
      var f = this.j();
      e.B(f.resolve, f.reject);
    };
    b.prototype.W = function (e, f) {
      var g = this.j();
      try {
        e.call(f, g.resolve, g.reject);
      } catch (k) {
        g.reject(k);
      }
    };
    b.prototype.then = function (e, f) {
      function g(p, x) {
        return typeof p == "function"
          ? function (K) {
              try {
                k(p(K));
              } catch (F) {
                m(F);
              }
            }
          : x;
      }
      var k,
        m,
        n = new b(function (p, x) {
          k = p;
          m = x;
        });
      this.B(g(e, k), g(f, m));
      return n;
    };
    b.prototype.catch = function (e) {
      return this.then(void 0, e);
    };
    b.prototype.B = function (e, f) {
      function g() {
        switch (k.h) {
          case 1:
            e(k.i);
            break;
          case 2:
            f(k.i);
            break;
          default:
            throw Error("Unexpected state: " + k.h);
        }
      }
      var k = this;
      this.g == null ? l.h(g) : this.g.push(g);
      this.A = !0;
    };
    b.resolve = d;
    b.reject = function (e) {
      return new b(function (f, g) {
        g(e);
      });
    };
    b.race = function (e) {
      return new b(function (f, g) {
        for (var k = v(e), m = k.next(); !m.done; m = k.next())
          d(m.value).B(f, g);
      });
    };
    b.all = function (e) {
      var f = v(e),
        g = f.next();
      return g.done
        ? d([])
        : new b(function (k, m) {
            function n(K) {
              return function (F) {
                p[K] = F;
                x--;
                x == 0 && k(p);
              };
            }
            var p = [],
              x = 0;
            do
              p.push(void 0),
                x++,
                d(g.value).B(n(p.length - 1), m),
                (g = f.next());
            while (!g.done);
          });
    };
    return b;
  });
  function z(a, b) {
    return Object.prototype.hasOwnProperty.call(a, b);
  }
  u("Symbol.dispose", function (a) {
    return a ? a : Symbol("Symbol.dispose");
  });
  u("WeakMap", function (a) {
    function b(g) {
      this.g = (f += Math.random() + 1).toString();
      if (g) {
        g = v(g);
        for (var k; !(k = g.next()).done; ) (k = k.value), this.set(k[0], k[1]);
      }
    }
    function c() {}
    function d(g) {
      var k = typeof g;
      return (k === "object" && g !== null) || k === "function";
    }
    function h(g) {
      if (!z(g, e)) {
        var k = new c();
        r(g, e, { value: k });
      }
    }
    function l(g) {
      var k = Object[g];
      k &&
        (Object[g] = function (m) {
          if (m instanceof c) return m;
          Object.isExtensible(m) && h(m);
          return k(m);
        });
    }
    if (
      (function () {
        if (!a || !Object.seal) return !1;
        try {
          var g = Object.seal({}),
            k = Object.seal({}),
            m = new a([
              [g, 2],
              [k, 3],
            ]);
          if (m.get(g) != 2 || m.get(k) != 3) return !1;
          m.delete(g);
          m.set(k, 4);
          return !m.has(g) && m.get(k) == 4;
        } catch (n) {
          return !1;
        }
      })()
    )
      return a;
    var e = "$jscomp_hidden_" + Math.random();
    l("freeze");
    l("preventExtensions");
    l("seal");
    var f = 0;
    b.prototype.set = function (g, k) {
      if (!d(g)) throw Error("Invalid WeakMap key");
      h(g);
      if (!z(g, e)) throw Error("WeakMap key fail: " + g);
      g[e][this.g] = k;
      return this;
    };
    b.prototype.get = function (g) {
      return d(g) && z(g, e) ? g[e][this.g] : void 0;
    };
    b.prototype.has = function (g) {
      return d(g) && z(g, e) && z(g[e], this.g);
    };
    b.prototype.delete = function (g) {
      return d(g) && z(g, e) && z(g[e], this.g) ? delete g[e][this.g] : !1;
    };
    return b;
  });
  u("Map", function (a) {
    function b() {
      var f = {};
      return (f.s = f.next = f.head = f);
    }
    function c(f, g) {
      var k = f[1];
      return ca(function () {
        if (k) {
          for (; k.head != f[1]; ) k = k.s;
          for (; k.next != k.head; )
            return (k = k.next), { done: !1, value: g(k) };
          k = null;
        }
        return { done: !0, value: void 0 };
      });
    }
    function d(f, g) {
      var k = g && typeof g;
      k == "object" || k == "function"
        ? l.has(g)
          ? (k = l.get(g))
          : ((k = "" + ++e), l.set(g, k))
        : (k = "p_" + g);
      var m = f[0][k];
      if (m && z(f[0], k))
        for (f = 0; f < m.length; f++) {
          var n = m[f];
          if ((g !== g && n.key !== n.key) || g === n.key)
            return { id: k, list: m, index: f, o: n };
        }
      return { id: k, list: m, index: -1, o: void 0 };
    }
    function h(f) {
      this[0] = {};
      this[1] = b();
      this.size = 0;
      if (f) {
        f = v(f);
        for (var g; !(g = f.next()).done; ) (g = g.value), this.set(g[0], g[1]);
      }
    }
    if (
      (function () {
        if (
          !a ||
          typeof a != "function" ||
          !a.prototype.entries ||
          typeof Object.seal != "function"
        )
          return !1;
        try {
          var f = Object.seal({ x: 4 }),
            g = new a(v([[f, "s"]]));
          if (
            g.get(f) != "s" ||
            g.size != 1 ||
            g.get({ x: 4 }) ||
            g.set({ x: 4 }, "t") != g ||
            g.size != 2
          )
            return !1;
          var k = g.entries(),
            m = k.next();
          if (m.done || m.value[0] != f || m.value[1] != "s") return !1;
          m = k.next();
          return m.done ||
            m.value[0].x != 4 ||
            m.value[1] != "t" ||
            !k.next().done
            ? !1
            : !0;
        } catch (n) {
          return !1;
        }
      })()
    )
      return a;
    var l = new WeakMap();
    h.prototype.set = function (f, g) {
      f = f === 0 ? 0 : f;
      var k = d(this, f);
      k.list || (k.list = this[0][k.id] = []);
      k.o
        ? (k.o.value = g)
        : ((k.o = {
            next: this[1],
            s: this[1].s,
            head: this[1],
            key: f,
            value: g,
          }),
          k.list.push(k.o),
          (this[1].s.next = k.o),
          (this[1].s = k.o),
          this.size++);
      return this;
    };
    h.prototype.delete = function (f) {
      f = d(this, f);
      return f.o && f.list
        ? (f.list.splice(f.index, 1),
          f.list.length || delete this[0][f.id],
          (f.o.s.next = f.o.next),
          (f.o.next.s = f.o.s),
          (f.o.head = null),
          this.size--,
          !0)
        : !1;
    };
    h.prototype.clear = function () {
      this[0] = {};
      this[1] = this[1].s = b();
      this.size = 0;
    };
    h.prototype.has = function (f) {
      return !!d(this, f).o;
    };
    h.prototype.get = function (f) {
      return (f = d(this, f).o) && f.value;
    };
    h.prototype.entries = function () {
      return c(this, function (f) {
        return [f.key, f.value];
      });
    };
    h.prototype.keys = function () {
      return c(this, function (f) {
        return f.key;
      });
    };
    h.prototype.values = function () {
      return c(this, function (f) {
        return f.value;
      });
    };
    h.prototype.forEach = function (f, g) {
      for (var k = this.entries(), m; !(m = k.next()).done; )
        (m = m.value), f.call(g, m[1], m[0], this);
    };
    h.prototype[Symbol.iterator] = h.prototype.entries;
    var e = 0;
    return h;
  });
  u("Number.isFinite", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b !== "number"
            ? !1
            : !isNaN(b) && b !== Infinity && b !== -Infinity;
        };
  });
  u("Object.values", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) z(b, d) && c.push(b[d]);
          return c;
        };
  });
  u("Object.is", function (a) {
    return a
      ? a
      : function (b, c) {
          return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c;
        };
  });
  u("Array.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = this;
          d instanceof String && (d = String(d));
          var h = d.length;
          c = c || 0;
          for (c < 0 && (c = Math.max(c + h, 0)); c < h; c++) {
            var l = d[c];
            if (l === b || Object.is(l, b)) return !0;
          }
          return !1;
        };
  });
  u("String.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          if (this == null)
            throw new TypeError(
              "The 'this' value for String.prototype.includes must not be null or undefined"
            );
          if (b instanceof RegExp)
            throw new TypeError(
              "First argument to String.prototype.includes must not be a regular expression"
            );
          return this.indexOf(b, c || 0) !== -1;
        };
  });
  function ua(a, b) {
    a instanceof String && (a += "");
    var c = 0,
      d = !1,
      h = {
        next: function () {
          if (!d && c < a.length) {
            var l = c++;
            return { value: b(l, a[l]), done: !1 };
          }
          d = !0;
          return { done: !0, value: void 0 };
        },
      };
    h[Symbol.iterator] = function () {
      return h;
    };
    return h;
  }
  u("Array.prototype.keys", function (a) {
    return a
      ? a
      : function () {
          return ua(this, function (b) {
            return b;
          });
        };
  });
  u("Array.prototype.values", function (a) {
    return a
      ? a
      : function () {
          return ua(this, function (b, c) {
            return c;
          });
        };
  });
  u("Array.from", function (a) {
    return a
      ? a
      : function (b, c, d) {
          c =
            c != null
              ? c
              : function (f) {
                  return f;
                };
          var h = [],
            l =
              typeof Symbol != "undefined" &&
              Symbol.iterator &&
              b[Symbol.iterator];
          if (typeof l == "function") {
            b = l.call(b);
            for (var e = 0; !(l = b.next()).done; )
              h.push(c.call(d, l.value, e++));
          } else
            for (l = b.length, e = 0; e < l; e++) h.push(c.call(d, b[e], e));
          return h;
        };
  });
  u("Set", function (a) {
    function b(c) {
      this.g = new Map();
      if (c) {
        c = v(c);
        for (var d; !(d = c.next()).done; ) this.add(d.value);
      }
      this.size = this.g.size;
    }
    if (
      (function () {
        if (
          !a ||
          typeof a != "function" ||
          !a.prototype.entries ||
          typeof Object.seal != "function"
        )
          return !1;
        try {
          var c = Object.seal({ x: 4 }),
            d = new a(v([c]));
          if (
            !d.has(c) ||
            d.size != 1 ||
            d.add(c) != d ||
            d.size != 1 ||
            d.add({ x: 4 }) != d ||
            d.size != 2
          )
            return !1;
          var h = d.entries(),
            l = h.next();
          if (l.done || l.value[0] != c || l.value[1] != c) return !1;
          l = h.next();
          return l.done ||
            l.value[0] == c ||
            l.value[0].x != 4 ||
            l.value[1] != l.value[0]
            ? !1
            : h.next().done;
        } catch (e) {
          return !1;
        }
      })()
    )
      return a;
    b.prototype.add = function (c) {
      c = c === 0 ? 0 : c;
      this.g.set(c, c);
      this.size = this.g.size;
      return this;
    };
    b.prototype.delete = function (c) {
      c = this.g.delete(c);
      this.size = this.g.size;
      return c;
    };
    b.prototype.clear = function () {
      this.g.clear();
      this.size = 0;
    };
    b.prototype.has = function (c) {
      return this.g.has(c);
    };
    b.prototype.entries = function () {
      return this.g.entries();
    };
    b.prototype.values = function () {
      return this.g.values();
    };
    b.prototype.keys = b.prototype.values;
    b.prototype[Symbol.iterator] = b.prototype.values;
    b.prototype.forEach = function (c, d) {
      var h = this;
      this.g.forEach(function (l) {
        return c.call(d, l, l, h);
      });
    };
    return b;
  }); /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var A = this || self;
  function va(a, b) {
    a: {
      var c = ["CLOSURE_FLAGS"];
      for (var d = A, h = 0; h < c.length; h++)
        if (((d = d[c[h]]), d == null)) {
          c = null;
          break a;
        }
      c = d;
    }
    a = c && c[a];
    return a != null ? a : b;
  }
  function wa(a, b) {
    var c = Array.prototype.slice.call(arguments, 1);
    return function () {
      var d = c.slice();
      d.push.apply(d, arguments);
      return a.apply(this, d);
    };
  }
  function xa(a) {
    A.setTimeout(function () {
      throw a;
    }, 0);
  }
  var ya = va(610401301, !1),
    za = va(188588736, !0);
  var B,
    Aa = A.navigator;
  B = Aa ? Aa.userAgentData || null : null;
  function Ba(a) {
    return ya
      ? B
        ? B.brands.some(function (b) {
            return (b = b.brand) && b.indexOf(a) != -1;
          })
        : !1
      : !1;
  }
  function C(a) {
    var b;
    a: {
      if ((b = A.navigator)) if ((b = b.userAgent)) break a;
      b = "";
    }
    return b.indexOf(a) != -1;
  }
  function D() {
    return ya ? !!B && B.brands.length > 0 : !1;
  }
  function Ca() {
    return D()
      ? Ba("Chromium")
      : ((C("Chrome") || C("CriOS")) && !(D() ? 0 : C("Edge"))) || C("Silk");
  }
  var Da = D() ? !1 : C("Trident") || C("MSIE");
  !C("Android") || Ca();
  Ca();
  C("Safari") &&
    (Ca() ||
      (D() ? 0 : C("Coast")) ||
      (D() ? 0 : C("Opera")) ||
      (D() ? 0 : C("Edge")) ||
      (D() ? Ba("Microsoft Edge") : C("Edg/")) ||
      (D() && Ba("Opera")));
  var Ea = {},
    E = null;
  var Fa = typeof Uint8Array !== "undefined",
    Ga = !Da && typeof btoa === "function";
  var G = typeof Symbol === "function" && typeof Symbol() === "symbol";
  function Ha(a) {
    return typeof Symbol === "function" && typeof Symbol() === "symbol"
      ? Symbol()
      : a;
  }
  var Ia = Ha(),
    H = Ha("1oa");
  var I = G
      ? function (a) {
          return a[Ia] | 0;
        }
      : function (a) {
          return a.g | 0;
        },
    J = G
      ? function (a) {
          return a[Ia];
        }
      : function (a) {
          return a.g;
        },
    L = G
      ? function (a, b) {
          a[Ia] = b;
        }
      : function (a, b) {
          a.g !== void 0
            ? (a.g = b)
            : Object.defineProperties(a, {
                g: { value: b, configurable: !0, writable: !0, enumerable: !1 },
              });
        };
  var Ja = {},
    Ka = {};
  function La(a) {
    return !(!a || typeof a !== "object" || a.g !== Ka);
  }
  function Ma(a) {
    return (
      a !== null &&
      typeof a === "object" &&
      !Array.isArray(a) &&
      a.constructor === Object
    );
  }
  function M(a, b, c) {
    if (!Array.isArray(a) || a.length) return !1;
    var d = I(a);
    if (d & 1) return !0;
    if (!(b && (Array.isArray(b) ? b.includes(c) : b.has(c)))) return !1;
    L(a, d | 1);
    return !0;
  }
  function Na(a) {
    if (a & 2) throw Error();
  }
  Object.freeze({});
  var Oa = Object.freeze({});
  var Pa;
  function N(a, b, c) {
    a == null && (a = Pa);
    Pa = void 0;
    if (a == null) {
      var d = 96;
      c ? ((a = [c]), (d |= 512)) : (a = []);
      b && (d = (d & -16760833) | ((b & 1023) << 14));
    } else {
      if (!Array.isArray(a)) throw Error("narr");
      d = I(a);
      if (d & 2048) throw Error("farr");
      if (d & 64) return a;
      d |= 64;
      if (c && ((d |= 512), c !== a[0])) throw Error("mid");
      a: {
        c = a;
        var h = c.length;
        if (h) {
          var l = h - 1;
          if (Ma(c[l])) {
            d |= 256;
            b = l - (+!!(d & 512) - 1);
            if (b >= 1024) throw Error("pvtlmt");
            d = (d & -16760833) | ((b & 1023) << 14);
            break a;
          }
        }
        if (b) {
          b = Math.max(b, h - (+!!(d & 512) - 1));
          if (b > 1024) throw Error("spvt");
          d = (d & -16760833) | ((b & 1023) << 14);
        }
      }
    }
    L(a, d);
    return a;
  }
  function Qa(a) {
    switch (typeof a) {
      case "number":
        return isFinite(a) ? a : String(a);
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (a)
          if (Array.isArray(a)) {
            if (M(a, void 0, 0)) return;
          } else if (Fa && a != null && a instanceof Uint8Array) {
            if (Ga) {
              for (var b = "", c = 0, d = a.length - 10240; c < d; )
                b += String.fromCharCode.apply(
                  null,
                  a.subarray(c, (c += 10240))
                );
              b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
              a = btoa(b);
            } else {
              b === void 0 && (b = 0);
              if (!E) {
                E = {};
                c =
                  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
                    ""
                  );
                d = ["+/=", "+/", "-_=", "-_.", "-_"];
                for (var h = 0; h < 5; h++) {
                  var l = c.concat(d[h].split(""));
                  Ea[h] = l;
                  for (var e = 0; e < l.length; e++) {
                    var f = l[e];
                    E[f] === void 0 && (E[f] = e);
                  }
                }
              }
              b = Ea[b];
              c = Array(Math.floor(a.length / 3));
              d = b[64] || "";
              for (h = l = 0; l < a.length - 2; l += 3) {
                var g = a[l],
                  k = a[l + 1];
                f = a[l + 2];
                e = b[g >> 2];
                g = b[((g & 3) << 4) | (k >> 4)];
                k = b[((k & 15) << 2) | (f >> 6)];
                f = b[f & 63];
                c[h++] = e + g + k + f;
              }
              e = 0;
              f = d;
              switch (a.length - l) {
                case 2:
                  (e = a[l + 1]), (f = b[(e & 15) << 2] || d);
                case 1:
                  (a = a[l]),
                    (c[h] = b[a >> 2] + b[((a & 3) << 4) | (e >> 4)] + f + d);
              }
              a = c.join("");
            }
            return a;
          }
    }
    return a;
  }
  function Ra(a, b, c, d, h) {
    if (a != null) {
      if (Array.isArray(a))
        a = M(a, void 0, 0)
          ? void 0
          : h && I(a) & 2
          ? a
          : Sa(a, b, c, d !== void 0, h);
      else if (Ma(a)) {
        var l = {},
          e;
        for (e in a) l[e] = Ra(a[e], b, c, d, h);
        a = l;
      } else a = b(a, d);
      return a;
    }
  }
  function Sa(a, b, c, d, h) {
    var l = d || c ? I(a) : 0;
    d = d ? !!(l & 32) : void 0;
    a = Array.prototype.slice.call(a);
    for (var e = 0; e < a.length; e++) a[e] = Ra(a[e], b, c, d, h);
    c && c(l, a);
    return a;
  }
  function Ta(a) {
    return a.M === Ja
      ? a.toJSON()
      : Fa && a != null && a instanceof Uint8Array
      ? new Uint8Array(a)
      : a;
  }
  function Ua(a) {
    return a.M === Ja ? a.toJSON() : Qa(a);
  }
  function O(a, b, c, d) {
    var h = (b >> 14) & 1023 || 536870912;
    if (c >= h) {
      var l = b;
      if (b & 256) var e = a[a.length - 1];
      else {
        if (d == null) return l;
        e = a[h + (+!!(b & 512) - 1)] = {};
        l |= 256;
      }
      e[c] = d;
      c < h && (a[c + (+!!(b & 512) - 1)] = void 0);
      l !== b && L(a, l);
      return l;
    }
    a[c + (+!!(b & 512) - 1)] = d;
    b & 256 && ((a = a[a.length - 1]), c in a && delete a[c]);
    return b;
  }
  function Va(a, b) {
    a = a.l;
    return Wa(Xa(a), a, J(a), b);
  }
  function Xa(a) {
    if (G) {
      var b;
      return (b = a[H]) != null ? b : (a[H] = new Map());
    }
    if (H in a) return a[H];
    b = new Map();
    Object.defineProperty(a, H, { value: b });
    return b;
  }
  function Wa(a, b, c, d) {
    var h = a.get(d);
    if (h != null) return h;
    for (var l = (h = 0); l < d.length; l++) {
      var e = d[l];
      var f = b;
      var g = c;
      if (e === -1) f = null;
      else {
        var k = (g >> 14) & 1023 || 536870912;
        e >= k
          ? (f = g & 256 ? f[f.length - 1][e] : void 0)
          : ((g = e + (+!!(g & 512) - 1)),
            (f = g < 0 || g >= f.length || g >= k ? void 0 : f[g]));
      }
      f != null && (h !== 0 && (c = O(b, c, h)), (h = e));
    }
    a.set(d, h);
    return h;
  }
  function P(a, b, c) {
    var d = Ya;
    c == null && (c = void 0);
    a: {
      var h = a.l,
        l = J(h);
      Na(l);
      if (c == null) {
        var e = Xa(h);
        if (Wa(e, h, l, d) === b) e.set(d, 0);
        else break a;
      } else {
        e = Xa(h);
        var f = Wa(e, h, l, d);
        f !== b && (f && (l = O(h, l, f)), e.set(d, b));
      }
      O(h, l, b, c);
    }
    return a;
  }
  function Za(a, b) {
    a = 2 & b ? a | 2 : a & -3;
    return (a | 32) & -2049;
  }
  function $a(a, b) {
    32 & b || (a &= -33);
    return a;
  }
  function ab(a, b, c) {
    if (c != null && typeof c !== "string") throw Error();
    var d = a.l,
      h = J(d);
    Na(h);
    O(d, h, b, c);
    return a;
  }
  var Q, bb;
  function R(a, b, c) {
    this.l = N(a, b, c);
  }
  R.prototype.toJSON = function () {
    return cb(this);
  };
  R.prototype.M = Ja;
  R.prototype.toString = function () {
    try {
      return (Q = !0), cb(this).toString();
    } finally {
      Q = !1;
    }
  };
  function cb(a) {
    var b = Q
      ? a.l
      : bb
      ? Sa(a.l, Ta, void 0, void 0, !1)
      : Sa(a.l, Ua, void 0, void 0, !1);
    var c = !Q;
    var d = za ? void 0 : a.constructor.ma;
    var h = J(c ? a.l : b);
    if ((a = b.length)) {
      var l = b[a - 1],
        e = Ma(l);
      e ? a-- : (l = void 0);
      h = +!!(h & 512) - 1;
      var f = b;
      if (e) {
        b: {
          var g = l;
          var k = {};
          e = !1;
          if (g)
            for (var m in g)
              if (isNaN(+m)) k[m] = g[m];
              else {
                var n = g[m];
                Array.isArray(n) &&
                  (M(n, d, +m) || (La(n) && n.size === 0)) &&
                  (n = null);
                n == null && (e = !0);
                n != null && (k[m] = n);
              }
          if (e) {
            for (var p in k) break b;
            k = null;
          } else k = g;
        }
        g = k == null ? l != null : k !== l;
      }
      for (var x; a > 0; a--) {
        p = a - 1;
        m = f[p];
        p -= h;
        if (!(m == null || M(m, d, p) || (La(m) && m.size === 0))) break;
        x = !0;
      }
      if (f !== b || g || x) {
        if (!c) f = Array.prototype.slice.call(f, 0, a);
        else if (x || g || k) f.length = a;
        k && f.push(k);
      }
      b = f;
    }
    return b;
  }
  function db(a) {
    this.l = N(a);
  }
  w(db, R);
  function eb(a) {
    this.l = N(a);
  }
  w(eb, R);
  function fb(a) {
    this.l = N(a);
  }
  w(fb, R);
  function gb(a) {
    this.l = N(a);
  }
  w(gb, R);
  function hb(a) {
    this.l = N(a);
  }
  w(hb, R);
  function ib(a) {
    this.l = N(a);
  }
  w(ib, R);
  function jb(a) {
    this.l = N(a);
  }
  w(jb, R);
  function kb(a) {
    this.l = N(a);
  }
  w(kb, R);
  function lb(a) {
    this.l = N(a);
  }
  w(lb, R);
  lb.ma = [1];
  function S(a) {
    this.l = N(a);
  }
  w(S, R);
  S.prototype.D = function () {
    return Va(this, Ya);
  };
  var Ya = [1, 2, 3, 4, 5, 6, 7, 8, 9];
  function mb(a) {
    this.l = N(a);
  }
  w(mb, R);
  mb.prototype.D = function () {
    return Va(this, nb);
  };
  var nb = [2, 3, 4, 5, 6, 7];
  function ob(a) {
    a.indexOf("#") === 0 && (a = a.substring(1));
    return new URLSearchParams(a);
  }
  var pb = { G: !1, F: !1, requestNonPersonalizedAds: !1, K: !1, L: !1 },
    qb = { R: !1 };
  function rb(a) {
    return a ? "on" : "off";
  }
  var sb = ["preroll", "start", "pause", "next", "browse"];
  function tb(a, b, c, d) {
    var h = this;
    this.postMessageHandler = a;
    this.monetizationScriptAttributes = b;
    this.O = c;
    this.P = !1;
    this.I = function (l) {
      (h.monetizationScriptAttributes.G || h.monetizationScriptAttributes.F) &&
        window.adsbygoogle.push({ sound: rb(l.isAudioEnabled) });
    };
    this.postMessageHandler.v("SET_AUDIO", this.I);
    (a = ub.fa()) &&
      setTimeout(function () {
        return void vb(h);
      }, Math.max(0, a - Date.now()));
    this.postMessageHandler.v("SPLASH_TIMEOUT", function () {
      h.P = !0;
    });
    window.adsbygoogle = window.adsbygoogle || [];
    b.requestNonPersonalizedAds &&
      (window.adsbygoogle.requestNonPersonalizedAds = 1);
    if (b.G || b.F)
      (b = {
        preloadAdBreaks: "on",
        sound: rb(d.audio.isEnabled()),
        onReady: function () {
          window.adsbygoogle.push({ preloadAdBreaks: "on" });
        },
      }),
        window.adsbygoogle.push(b);
  }
  function vb(a) {
    a.P ||
      a.break({
        type: "preroll",
        beforeAd: function () {
          a.O(!0);
          setTimeout(function () {
            a.postMessageHandler.send({ messageType: "PREROLL_READY" });
          }, 33);
        },
        adBreakDone: function () {
          a.O(!1);
          a.postMessageHandler.send({ messageType: "PREROLL_DONE" });
        },
      });
  }
  tb.prototype.break = function (a) {
    this.postMessageHandler.send({ messageType: "AD_BREAK" });
    this.monetizationScriptAttributes.G &&
      a.type === "reward" &&
      window.adsbygoogle.push(a);
    this.monetizationScriptAttributes.F &&
      sb.includes(a.type) &&
      window.adsbygoogle.push(a);
  };
  var ub = {
    fa: function (a) {
      a = ob(a || window.location.hash);
      if (!a) return 0;
      a = (a = a.get("preStart")) ? Number(a) : 0;
      return isNaN(a) ? 0 : a;
    },
  };
  function wb() {}
  function T(a) {
    var b = this;
    this.postMessageHandler = a;
    this.g = !xb.Y();
    this.m = [];
    this.h = !1;
    this.i = !0;
    this.u = this.g;
    this.I = function (c) {
      b.g = c.isAudioEnabled;
      yb(b);
    };
    this.postMessageHandler.v("SET_AUDIO", this.I);
  }
  T.prototype.j = function (a) {
    this.h !== a && ((this.h = a), yb(this));
  };
  function yb(a) {
    var b = a.g && !a.h && a.i;
    if (b !== a.u) {
      for (var c = v(a.m), d = c.next(); !d.done; d = c.next())
        (d = d.value), d(b);
      a.u = b;
    }
  }
  T.prototype.isEnabled = function () {
    this.postMessageHandler.send({ messageType: "AUDIO_IS_ENABLED" });
    return this.g && !this.h && this.i;
  };
  T.prototype.subscribe = function (a) {
    typeof a === "function" &&
      (this.postMessageHandler.send({ messageType: "AUDIO_SUBSCRIBE" }),
      this.m.push(a));
  };
  var xb = {
    Y: function (a) {
      return ob(a || window.location.hash).get("audioMuted") === "true";
    },
  };
  function U(a) {
    a = Error.call(this, a);
    this.message = a.message;
    "stack" in a && (this.stack = a.stack);
  }
  w(U, Error);
  function zb(a, b) {
    this.data = a;
    this.channel = b;
  }
  function Ab(a) {
    this.g = a;
  }
  Ab.prototype.send = function (a, b, c) {
    c = c === void 0 ? [] : c;
    b = Bb(b);
    this.g.postMessage(a, [b.port2].concat(c));
  };
  function Cb(a, b) {
    Db(a, b);
    return new Ab(a);
  }
  function Bb(a) {
    var b = new MessageChannel();
    Db(b.port1, a);
    return b;
  }
  function Db(a, b) {
    b &&
      (a.onmessage = function (c) {
        var d = c.data;
        c = Cb(c.ports[0]);
        b(new zb(d, c));
      });
  }
  function V(a) {
    try {
      a();
    } catch (b) {
      xa(b);
    }
  }
  function Eb(a) {
    var b = this;
    var c = a.da;
    var d = a.la === void 0 ? function () {} : a.la;
    var h = a.ia === void 0 ? function () {} : a.ia;
    a = a.ha === void 0 ? function () {} : a.ha;
    this.g = new Map();
    this.h = c;
    this.m = d;
    this.j = h;
    this.i = a;
    this.onMessage = function (l) {
      return Fb(b, l);
    };
  }
  Eb.prototype.register = function (a, b) {
    this.g.set(a, b);
    return this;
  };
  function Fb(a, b) {
    var c = a.h(b.data),
      d = a.g.get(c);
    d
      ? (V(function () {
          return a.j(b, c);
        }),
        V(function () {
          return d(b);
        }),
        V(function () {
          return a.i(b, c);
        }))
      : V(function () {
          return a.m(b, c);
        });
  }
  function Gb(a) {
    this.g = a;
  }
  Gb.prototype.send = function (a, b, c) {
    var d = this.g,
      h = d.send;
    try {
      bb = !0;
      var l = cb(a);
    } finally {
      bb = !1;
    }
    h.call(d, l, b, c);
  };
  function Hb(a, b) {
    return function (c) {
      var d = new a(c.data);
      return b(new zb(d, c.channel));
    };
  }
  function Ib(a) {
    return function (b) {
      return a(new zb(b.data, new Gb(b.channel)));
    };
  }
  function Jb(a, b, c, d) {
    this.j = a;
    this.i = b;
    this.J = c;
    this.H = d;
    this.g = !1;
    this.h = new Set();
  }
  function Kb(a) {
    var b = new Eb({ da: a.D }),
      c = {
        destination: window.parent,
        origin: a.origin,
        C: a.C,
        onMessage: Ib(Hb(a.J, b.onMessage)),
      };
    var d = c.destination;
    var h = c.origin;
    var l = c.na === void 0 ? void 0 : c.na;
    var e = c.C === void 0 ? "ZNWN1d" : c.C;
    c = c.onMessage === void 0 ? void 0 : c.onMessage;
    if (h === "*") throw Error("Sending to wildcard origin not allowed.");
    var f = Bb(c),
      g = {};
    l = l ? ((g.n = e), (g.t = l), g) : e;
    d.postMessage(l, h, [f.port2]);
    d = Cb(f.port1, c);
    return new Jb(b, new Gb(d), a.J, a.H);
  }
  Jb.prototype.send = function (a) {
    if (!this.g)
      throw new U("Attempted to send a message before initialisation.");
    this.i.send(a);
  };
  Jb.prototype.init = function () {
    var a = this;
    return sa(
      new ra(
        new oa(function (b) {
          if (a.g)
            throw new U(
              "Attempted to initialise twice. The SDK can only be initialised once."
            );
          if (a.H !== void 0) {
            var c = a.i,
              d = c.send,
              h = a.H,
              l = new lb();
            var e = [].concat(da(a.h)),
              f = l.l,
              g = J(f);
            Na(g);
            if (e == null) O(f, g, 1);
            else {
              var k = I(e),
                m = k,
                n = !!(2 & k) || Object.isFrozen(e),
                p;
              if ((p = !n)) p = void 0 === Oa || !1;
              if (!(4 & k))
                for (
                  k = 21,
                    n &&
                      ((e = Array.prototype.slice.call(e)),
                      (m = 0),
                      (k = Za(k, g)),
                      (k = $a(k, g))),
                    n = 0;
                  n < e.length;
                  n++
                ) {
                  var x = e,
                    K = n,
                    F = e[n];
                  if (!Number.isFinite(F))
                    throw (
                      ((c = b = Error("enum")),
                      c.__closure__error__context__984382 ||
                        (c.__closure__error__context__984382 = {}),
                      (c.__closure__error__context__984382.severity =
                        "warning"),
                      b)
                    );
                  x[K] = F | 0;
                }
              p &&
                ((e = Array.prototype.slice.call(e)),
                (m = 0),
                (k = Za(k, g)),
                (k = $a(k, g)));
              k !== m && L(e, k);
              O(f, g, 1, e);
            }
            d.call(c, h.call(a, l));
          }
          a.g = !0;
          b.j = 0;
        })
      )
    );
  };
  function Lb(a, b) {
    if (a.g)
      throw new U(
        "Attempted to use a new API after initialisation. All APIs must be set up before initialising the SDK."
      );
    a.h.add(b);
    return a.j;
  }
  function Mb(a) {
    return Kb({
      origin: a,
      C: "gamesnacks-developer",
      J: mb,
      D: function (b) {
        return b.D();
      },
    });
  }
  function Nb(a, b, c, d, h) {
    this.postMessageHandler = a;
    this.channel = b === void 0 ? null : b;
    this.monetizationScriptAttributes = c;
    this.g = d;
    this.ad = h;
    this.h = [];
    this.i = [];
    this.channel !== null &&
      Lb(this.channel, 2)
        .register(6, this.ja.bind(this))
        .register(7, this.ka.bind(this));
  }
  q = Nb.prototype;
  q.firstFrameReady = function () {
    var a;
    if ((a = this.channel) != null) {
      var b = a.send;
      var c = new S();
      var d = new db();
      c = P(c, 5, d);
      b.call(a, c);
    }
  };
  q.ready = function () {
    this.postMessageHandler.send({
      messageType: "GAME_READY",
      timestamp: Date.now(),
    });
  };
  q.onPause = function (a) {
    this.h.push(a);
    if ((a = this.channel) != null) {
      var b = a.send;
      var c = new S();
      var d = new eb();
      c = P(c, 8, d);
      b.call(a, c);
    }
  };
  q.onResume = function (a) {
    this.i.push(a);
    if ((a = this.channel) != null) {
      var b = a.send;
      var c = new S();
      var d = new gb();
      c = P(c, 9, d);
      b.call(a, c);
    }
  };
  q.gameOver = function () {
    this.postMessageHandler.send({ messageType: "GAME_OVER" });
    this.monetizationScriptAttributes.K && Ob(this, "gameOver");
  };
  q.levelComplete = function (a) {
    typeof a === "number" &&
      (this.postMessageHandler.send({
        messageType: "LEVEL_COMPLETE",
        level: a,
      }),
      this.monetizationScriptAttributes.L && Ob(this, "levelComplete"));
  };
  q.ja = function (a) {
    for (var b = v(this.h), c = b.next(); !c.done; c = b.next())
      (c = c.value), c();
    b = new S();
    c = new fb();
    b = P(b, 6, c);
    a.channel.send(b, void 0, void 0);
  };
  q.ka = function (a) {
    for (var b = v(this.i), c = b.next(); !c.done; c = b.next())
      (c = c.value), c();
    b = new S();
    c = new hb();
    b = P(b, 7, c);
    a.channel.send(b, void 0, void 0);
  };
  function Ob(a, b) {
    a.ad.break({
      type: "next",
      name: b,
      beforeAd: function () {
        return void a.g.j(!0);
      },
      afterAd: function () {
        return void a.g.j(!1);
      },
    });
  }
  function Pb(a) {
    a && typeof a.dispose == "function" && a.dispose();
  }
  function W() {
    this.h = this.h;
    this.g = this.g;
  }
  W.prototype.h = !1;
  W.prototype.dispose = function () {
    if (!this.h && ((this.h = !0), this.g))
      for (; this.g.length; ) this.g.shift()();
  };
  W.prototype[Symbol.dispose] = function () {
    this.dispose();
  };
  function X(a, b) {
    a.h ? b() : (a.g || (a.g = []), a.g.push(b));
  }
  function Qb(a) {
    W.call(this);
    var b = this;
    this.audio = a;
    this.i = function () {
      var c = b.audio,
        d = !document.hidden;
      c.i !== d && ((c.i = d), yb(c));
    };
    X(this, function () {
      document.removeEventListener("visibilitychange", b.i, !1);
    });
    document.addEventListener("visibilitychange", this.i, !1);
  }
  w(Qb, W);
  function Rb(a) {
    this.postMessageHandler = a;
  }
  Rb.prototype.update = function (a) {
    typeof a === "number" &&
      this.postMessageHandler.send({ messageType: "SCORE", score: a });
  };
  function Sb(a) {
    return a[A.Symbol.iterator]();
  }
  function Tb(a, b) {
    this.g = Sb(a);
    this.h = b;
  }
  Tb.prototype[Symbol.iterator] = function () {
    return this;
  };
  Tb.prototype.next = function () {
    var a = this.g.next();
    return {
      value: a.done ? void 0 : this.h.call(void 0, a.value),
      done: a.done,
    };
  };
  function Ub(a, b) {
    return new Tb(a, b);
  }
  function Vb(a) {
    this.h = a;
    this.g = 0;
  }
  Vb.prototype[Symbol.iterator] = function () {
    return this;
  };
  Vb.prototype.next = function () {
    for (; this.g < this.h.length; ) {
      var a = this.h[this.g].next();
      if (!a.done) return a;
      this.g++;
    }
    return { done: !0 };
  };
  function Wb() {
    return new Vb(ta.apply(0, arguments).map(Sb));
  } /*

 SPDX-License-Identifier: Apache-2.0
*/
  function Y(a) {
    this.g = a;
  }
  Y.prototype.toString = function () {
    return this.g;
  };
  var Xb = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  function Yb(a, b) {
    if (b instanceof Y)
      if (b instanceof Y) b = b.g;
      else throw Error("");
    else b = Xb.test(b) ? b : void 0;
    b !== void 0 && (a.href = b);
  }
  function Zb() {
    var a = document;
    var b = "A";
    a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
    return a.createElement(b);
  }
  var $b = A.URL,
    ac;
  try {
    new $b("http://example.com"), (ac = !0);
  } catch (a) {
    ac = !1;
  }
  var bc = ac;
  function Z(a) {
    this.g = new Map();
    a.indexOf("?") == 0 && (a = a.substring(1));
    a = v(a.split("&"));
    for (var b = a.next(); !b.done; b = a.next()) {
      var c = b.value;
      b = c;
      var d = "";
      c = c.split("=");
      c.length > 1 &&
        ((b = decodeURIComponent(c[0].replace("+", " "))),
        (d = decodeURIComponent(c[1].replace("+", " "))));
      c = this.g.get(b);
      c == null && ((c = []), this.g.set(b, c));
      c.push(d);
    }
  }
  Z.prototype.get = function (a) {
    return (a = this.g.get(a)) && a.length ? a[0] : null;
  };
  Z.prototype.getAll = function (a) {
    return [].concat(da(this.g.get(a) || []));
  };
  Z.prototype.has = function (a) {
    return this.g.has(a);
  };
  Z.prototype[Symbol.iterator] = function () {
    return Wb.apply(
      null,
      da(
        Ub(this.g, function (a) {
          var b = a[0];
          return Ub(a[1], function (c) {
            return [b, c];
          });
        })
      )
    );
  };
  Z.prototype.toString = function () {
    return cc(this);
  };
  function cc(a) {
    function b(c) {
      return encodeURIComponent(c).replace(/[!()~']|(%20)/g, function (d) {
        return {
          "!": "%21",
          "(": "%28",
          ")": "%29",
          "%20": "+",
          "'": "%27",
          "~": "%7E",
        }[d];
      });
    }
    return Array.from(a, function (c) {
      return b(c[0]) + "=" + b(c[1]);
    }).join("&");
  }
  function dc(a) {
    var b = Zb();
    try {
      Yb(b, new Y(a));
      var c = b.protocol;
    } catch (h) {
      throw Error(a + " is not a valid URL.");
    }
    if (c === "" || c === ":" || c[c.length - 1] != ":")
      throw Error(a + " is not a valid URL.");
    if (!ec.has(c)) throw Error(a + " is not a valid URL.");
    if (!b.hostname) throw Error(a + " is not a valid URL.");
    var d = b.href;
    a = {
      href: d,
      protocol: b.protocol,
      username: "",
      password: "",
      hostname: b.hostname,
      pathname: "/" + b.pathname,
      search: b.search,
      hash: b.hash,
      toString: function () {
        return d;
      },
    };
    ec.get(b.protocol) === b.port
      ? ((a.host = a.hostname),
        (a.port = ""),
        (a.origin = a.protocol + "//" + a.hostname))
      : ((a.host = b.host),
        (a.port = b.port),
        (a.origin = a.protocol + "//" + a.hostname + ":" + a.port));
    return a;
  }
  var ec = new Map([
    ["http:", "80"],
    ["https:", "443"],
    ["ws:", "80"],
    ["wss:", "443"],
    ["ftp:", "21"],
  ]);
  var fc = { google_ama_config: !0 };
  function gc(a) {
    this.channel = a === void 0 ? null : a;
    this.g = {};
    if ((a = hc.ca() || hc.ba()))
      try {
        var b = JSON.parse(atob(decodeURIComponent(a)));
        if (typeof b !== "object")
          throw Error("malformed gameData param: " + a);
        this.g = b;
      } catch (c) {
        console.error("Error parsing gameData param: " + JSON.stringify(c));
      }
  }
  q = gc.prototype;
  q.clear = function () {
    var a = new S();
    var b = new ib();
    a = P(a, 4, b);
    var c;
    (c = this.channel) == null || c.send(a);
    this.g = {};
  };
  q.getItem = function (a) {
    var b;
    return (b = this.g[a]) != null ? b : null;
  };
  q.setItem = function (a, b) {
    ["boolean", "number"].includes(typeof b) && (b = b.toString());
    if (!fc[a]) {
      var c = new S();
      var d = new kb();
      d = ab(d, 1, a);
      d = ab(d, 2, b);
      c = P(c, 1, d);
      var h;
      (h = this.channel) == null || h.send(c);
      this.g[a] = b;
    }
  };
  q.removeItem = function (a) {
    var b = new S();
    var c = new jb();
    c = ab(c, 1, a);
    b = P(b, 3, c);
    var d;
    (d = this.channel) == null || d.send(b);
    delete this.g[a];
  };
  q.key = function (a) {
    var b = Object.keys(this.g);
    return a >= b.length ? null : b[a];
  };
  q.hasOwnProperty = function (a) {
    return this.g.hasOwnProperty(a);
  };
  t.Object.defineProperties(gc.prototype, {
    length: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        var a;
        return (a = Object.keys(this.g).length) != null ? a : 0;
      },
    },
  });
  var hc = {
    ba: function () {
      var a = window.location.href;
      if (bc) {
        try {
          var b = new $b(a);
        } catch (d) {
          throw Error(a + " is not a valid URL.");
        }
        var c = ec.get(b.protocol);
        if (!c) throw Error(a + " is not a valid URL.");
        if (!b.hostname) throw Error(a + " is not a valid URL.");
        b.origin == "null" &&
          ((a = {
            href: b.href,
            protocol: b.protocol,
            username: "",
            password: "",
            host: b.host,
            port: b.port,
            hostname: b.hostname,
            pathname: b.pathname,
            search: b.search,
            hash: b.hash,
          }),
          (a.origin =
            c === b.port
              ? b.protocol + "//" + b.hostname
              : b.protocol + "//" + b.hostname + ":" + b.port),
          (b = a));
      } else b = dc(a);
      return (bc && b.searchParams ? b.searchParams : new Z(b.search)).get(
        "gameData"
      );
    },
    ca: function (a) {
      a = a || window.location.hash;
      return ob(a).get("gameData");
    },
  };
  function ic(a, b, c, d, h) {
    b = b === void 0 ? null : b;
    c = c === void 0 ? pb : c;
    d = d === void 0 ? qb : d;
    W.call(this);
    this.postMessageHandler = a;
    this.channel = b;
    this.monetizationScriptAttributes = c;
    this.experimentFlags = d;
    this.i = h;
    this.audio = new T(this.postMessageHandler);
    this.ad = new tb(
      this.postMessageHandler,
      this.monetizationScriptAttributes,
      this.audio.j.bind(this.audio),
      this
    );
    this.game = new Nb(
      this.postMessageHandler,
      this.channel,
      this.monetizationScriptAttributes,
      this.audio,
      this.ad
    );
    this.score = new Rb(this.postMessageHandler);
    this.storage = new gc(this.channel);
    this.postMessageHandler.send({ messageType: "LOADED" });
    a.v("SET_LOG_LEVEL", wb);
    this.j = new Qb(this.audio);
    X(this, wa(Pb, this.j));
    X(this, wa(Pb, a));
    this.i && X(this, wa(Pb, this.i));
    b && (Lb(b, 4), b.init());
  }
  w(ic, W);
  function jc() {
    W.apply(this, arguments);
    this.targetOrigin = "";
  }
  w(jc, W);
  jc.prototype.v = function () {};
  jc.prototype.send = function () {};
  function kc(a) {
    W.call(this);
    var b = this;
    this.targetOrigin = a;
    this.i = new Map();
    if (a === "*")
      throw Error(
        "targetOrigin of '*' is insecure. Use the origin of the parent frame."
      );
    X(this, function () {
      b.i.clear();
    });
    window.addEventListener("message", function (c) {
      var d = c.data;
      if (
        c.origin === b.targetOrigin &&
        typeof (d == null ? void 0 : d.messageType) === "string" &&
        ((c = d.messageType),
        typeof d !== "object" || d === null ? 0 : d.messageType === c) &&
        (c = b.i.get(c))
      ) {
        c = v(c);
        for (var h = c.next(); !h.done; h = c.next()) (h = h.value), h(d);
      }
    });
  }
  w(kc, W);
  kc.prototype.v = function (a, b) {
    if (!this.h) {
      var c = this.i.get(a);
      c || ((c = new Set()), this.i.set(a, c));
      c.add(b);
    }
  };
  kc.prototype.send = function (a) {
    window.parent.postMessage(a, this.targetOrigin);
  };
  function lc(a, b) {
    W.call(this);
    var c = this;
    this.postMessageHandler = a;
    this.window = b;
    this.i = this.userActivityLoggingIntervalMs = 0;
    this.m = function (d) {
      d = d.userActivityLoggingIntervalMs;
      d <= 0 ||
        ((c.userActivityLoggingIntervalMs = d),
        c.window.addEventListener("pointerdown", c.j, !0));
    };
    this.j = function (d) {
      !d.isTrusted ||
        Date.now() - c.i < c.userActivityLoggingIntervalMs ||
        ((c.i = Date.now()),
        c.postMessageHandler.send({ messageType: "USER_ACTIVITY" }));
    };
    a.v("SET_USER_ACTIVITY_METRICS_INTERVAL", this.m);
  }
  w(lc, W);
  lc.prototype.dispose = function () {
    W.prototype.dispose.call(this);
    this.window.removeEventListener("pointerdown", this.j, !0);
  };
  var mc = {
    Z: function () {
      var a;
      return (
        ((a = document.currentScript) == null
          ? void 0
          : a.getAttribute("data-target-origin")) || void 0
      );
    },
    ea: function (a) {
      return document.currentScript
        ? {
            G: document.currentScript.hasAttribute("data-rewarded-monetizable"),
            F: document.currentScript.hasAttribute(
              "data-interstitial-monetizable"
            ),
            requestNonPersonalizedAds: document.currentScript.hasAttribute(
              "data-request-non-personalized-ads"
            ),
            K:
              a &&
              document.currentScript.hasAttribute("data-game-over-monetizable"),
            L:
              a &&
              document.currentScript.hasAttribute(
                "data-level-complete-monetizable"
              ),
          }
        : pb;
    },
    aa: function () {
      return document.currentScript
        ? {
            R: document.currentScript.hasAttribute(
              "data-user-activity-metrics"
            ),
          }
        : qb;
    },
  };
  function nc() {
    try {
      document.body &&
        document.body.style &&
        ((document.body.style.userSelect = "none"),
        (document.body.style.webkitUserSelect = "none"));
    } catch (a) {
      console.warn(a);
    }
  }
  (function (a) {
    a = a === void 0 ? !0 : a;
    var b = mc.Z(),
      c = null;
    if (b === null || b === void 0) {
      console.warn(
        "Couldn't find targetOrigin for postMessages. Cross-frame messaging is deactivated."
      );
      var d = new jc();
    } else (d = new kc(b)), (c = Mb(b));
    b = mc.aa();
    a = new ic(d, c, mc.ea(a), b, b.R ? new lc(d, window) : void 0);
    window.GameSnacks = a;
    Object.defineProperty(window, "localStorage", {
      get: function () {
        throw Error(
          "window.localStorage not available, please use the GameSnacks.storage API."
        );
      },
    });
    window.addEventListener("load", function () {
      nc();
    });
    nc();
    return a;
  })();
}).call(this);
/*h5games_sdks_20240722-21_RC00*/
