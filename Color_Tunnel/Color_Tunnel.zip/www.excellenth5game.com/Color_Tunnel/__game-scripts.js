var _0x26c5 = [
  "KEY_D",
  "rightPressed",
  "onKeyUp",
  "KEY_LEFT",
  "buttons",
  "touches",
  "playerMovement",
  "pathRoot",
  "Path\x20Root",
  "CURVE_ENUM",
  "CURVE_CARDINAL",
  "rotationCurveType",
  "upCurveType",
  "Duration\x20Secs",
  "pathLength",
  "debugPositions",
  "debugColors",
  "createPath",
  "attr:pathRoot",
  "lookAt",
  "flyingThrough",
  "pathSlider",
  "totalLength",
  "previousLength",
  "setPosition",
  "showDebugLines",
  "createDebugPath",
  "drawLineArrays",
  "getPoint",
  "normalize",
  "mulScalar",
  "Curve",
  "positionCurveType",
  "curves",
  "CurveSet",
  "getPosition",
  "render",
  "forward",
  "acos",
  "dot",
  "setObstacle",
  "CURVE_LINEAR",
  "CURVE_SMOOTHSTEP",
  "CURVE_SPLINE",
  "path",
  "others",
  "distance",
  "hitboxScripts",
  "obstacleHitbox",
  "No\x20hitbox\x20scripts\x20found",
  "othersRotationSpeed",
  "PlayerHurtbox:checkCollision",
  "checkCollision",
  "rotationEntity",
  "random",
  "rotateLocal",
  "dodged",
  "center",
  "obstacle_dodged",
  "lengthSq",
  "obstacle",
  "pathEntity",
  "tunnelMeshEntity",
  "radiusBetweenNodes",
  "rotationBetweenNodes",
  "tunnelMeshGenerator",
  "obstaclePositions",
  "nodes",
  "nodeParent",
  "obstacles",
  "obstacleParents",
  "LevelManager:setLevel",
  "randomizePath",
  "setObstacles",
  "generateMesh",
  "math",
  "updatePath",
  "chunkLevel",
  "amountOfObstacles",
  "getRandomObstacle",
  "rotationMultiplier",
  "sort",
  "getValidObstaclePosition",
  "MINIMAL_T_FIRST_LEVEL",
  "MINIMAL_T",
  "MAXIMAL_T",
  "abs",
  "MINIMAL_DISTANCE_T",
  "meshData",
  "material",
  "obstacleY",
  "obstacleZ",
  "RENDERSTYLE_POINTS",
  "RENDERSTYLE_WIREFRAME",
  "obstacleX",
  "renderStyle",
  "mesh",
  "Mesh",
  "StandardMaterial",
  "diffuse",
  "GraphNode",
  "addChild",
  "createMesh",
  "createRender",
  "positions",
  "uvs",
  "indices",
  "updateMesh",
  "setPositions",
  "setUvs",
  "setIndices",
  "calculateNormals",
  "obstacleMeshGenerator",
  "circleDivision",
  "lengthDivision",
  "RENDERSTYLE_SOLID",
  "attr:circleDivision",
  "attr:lengthDivision",
  "isClosed",
  "tunnelPoints",
  "attr:uvXDivision",
  "attr:uvYDivision",
  "updateUV",
  "MeshInstance",
  "reset",
  "getAllTunnelPoints",
  "setTexture",
  "uvYDivision",
  "uvXDivision",
  "fixSharedNormals",
  "createTexture",
  "diffuseMap",
  "halfExtents",
  "debugEntity",
  "getWorldTransform",
  "setRenderVisibility",
  "aabb",
  "worldTransform",
  "intersectsRay",
  "POINT",
  "previousPosition",
  "collision",
  "intersectsBoundingSphere",
  "postupdate",
  "postUpdate",
  "deltaPosition",
  "ray",
  "Ray",
  "BoundingSphere",
  "setRadius",
  "attr:radius",
  "VEC_3",
  "invincible",
  "grantInvincibility",
  "playerHurtbox",
  "index",
  "textureAmount",
  "floor",
  "randomIndex",
  "destroyTexture",
  "Texture",
  "createBlocksTexture",
  "createStripesTexture",
  "createCheckerBoardTexture",
  "No\x20texture",
  "PIXELFORMAT_R8_G8_B8",
  "lock",
  "getColor",
  "unlock",
  "FILTER_LINEAR",
  "colors",
  "FILTER_NEAREST",
  "textureGenerator",
  "circleMesh",
  "circleLength",
  "circleInnerRadius",
  "circleOuterRadius",
  "setNormals",
  "circleObstacle",
  "scoreTextEntity",
  "highscoreGroup",
  "scoreText",
  "highscoreTextEntity",
  "adButtonEntity",
  "restartButtonEntity",
  "adButtonEntityAnim",
  "restarted",
  "continueClicked",
  "applyHighscore",
  "levelFail",
  "animationSequence",
  "BackOut",
  "getPromise",
  "previousHighscore",
  "toFixed",
  "ONE",
  "highscore",
  "SCORE",
  "score",
  "canContinue",
  "SineInOut",
  "tween2",
  "chain",
  "KEY_R",
  "onRestart",
  "restart",
  "onContinue",
  "cant\x20continue",
  "onRewardedAd",
  "rewardGranted",
  "continue",
  "Input\x20Screen",
  "resultScreen",
  "materialAsset",
  "createDiagonalLinesTexture",
  "opacityMap",
  "tmpVec2",
  "diffuseMapOffset",
  "opacityMapOffset",
  "endOfLevel",
  "chunkInfo",
  "weights",
  "getChunkInfo",
  "info",
  "Amount\x20of\x20obstacles\x20is\x20not\x20the\x20same\x20as\x20weights",
  "totalWeight",
  "getTotalWeight",
  "UPDATE_SCORE_THRESHOLD",
  "getRoundedScore",
  "updateLiveScore",
  "ScoreManager:updateScore",
  "round",
  "scoreManager",
  "shakeInterval",
  "Camera\x20Shake\x20Interval",
  "maxShakeDistance",
  "Duration",
  "POSITIVE_INFINITY",
  "onStartShake",
  "timeSinceLastShake",
  "clamp",
  "startPosition",
  "cameraShake",
  "increaseLevel",
  "incrementStat",
  "level_completed",
  "LevelManager:increaseText",
  "resetLevel",
  "LevelManager:resetLevel",
  "levelManager",
  "updateScore",
  "scoreTracker",
  "levelRange",
  "obstacleMaterial",
  "level1Colors",
  "obstacleColor",
  "backgroundColor",
  "ambientOcclusionColor",
  "level3Colors",
  "levelRangeIndex",
  "getLevelRangeIndex",
  "color",
  "tunnelAO",
  "resetIndex",
  "getRandomIndex",
  "level2Colors",
  "level\x20range\x20index",
  "getIndex",
  "updateUI",
  "levelTracker",
  "onPlayClick",
  "Main\x20Menu",
  "onMouseDown",
  "wasPressed",
  "rotate",
  "rollingCube",
  "OPACITY",
  "DURATION",
  "statistics",
  "incrementStatistic",
  "setStatistic",
  "trackStats",
  "statisticsManager",
  "showButtons",
  "loop",
  "skip_tutorial",
  "entityDisabled",
  "hideScreen",
  "inputScreen",
  "famobiApi",
  "extend",
  "prototype",
  "famobi",
  "localStorage",
  "sessionStorage",
  "gameReady",
  "warn",
  "getBrandingButtonImage",
  "showInterstitialAd",
  "showAd",
  "hasRewardedAd",
  "rewardedAd",
  "bind",
  "famobi_onResumeRequested",
  "getCurrentLanguage",
  "setItem",
  "getItem",
  "clear",
  "hasFeature",
  "onRequest",
  "getFeatureProperties",
  "getVolume",
  "playerReady",
  "push",
  "famobi_analytics",
  "trackEvent",
  "EVENT_LEVELSUCCESS",
  "EVENT_TOTALSCORE",
  "EVENT_LEVELFAIL",
  "level_",
  "dead",
  "EVENT_LEVELRESTART",
  "EVENT_LEVELSTART",
  "all",
  "EVENT_CUSTOM",
  "LEVELEND",
  "GetMoreGamesButtonImage\x20is\x20deprecated,\x20use\x20getBrandingButtonImage\x20instead",
  "openBrandingLink",
  "submitHighscore\x20is\x20deprecated,\x20use\x20window.famobi_analytics.trackEvent\x20instead",
  "levelUp\x20is\x20deprecated,\x20use\x20window.famobi_analytics.trackEvent\x20instead",
  "gameOver\x20is\x20deprecated,\x20use\x20window.famobi_analytics.trackEvent\x20instead",
  "createScript",
  "fakeFamobiApi",
  "BOILERPLATE_FAMOBI",
  "attributes",
  "add",
  "templateName",
  "Template\x20Name",
  "Has\x20Rewarded\x20Ad",
  "You\x20can\x20change\x20this\x20value\x20for\x20testing\x20purposes.\x20This\x20will\x20not\x20affect\x20the\x20real\x20famobi\x20API",
  "Interstitial\x20Duration",
  "number",
  "Rewarded\x20Ad\x20Duration",
  "Event\x20tracking\x20duration",
  "trackingLog",
  "debug",
  "feature_auto_quality",
  "feature_copyright",
  "feature_credits",
  "feature_external_achievements",
  "feature_external_pause",
  "feature_external_start",
  "feature_forced_mode",
  "feature_leaderboard",
  "feature_multiplayer",
  "feature_skip_title",
  "feature_skip_tutorial",
  "feature_properties_forced_mode",
  "asset",
  "json",
  "volume",
  "attr:hasRewardedAd",
  "famobi_hasRewardedAd",
  "attr:interstitialDuration",
  "famobi_interstitialDuration",
  "attr:rewardedDuration",
  "famobi_rewardedDuration",
  "attr:debug",
  "interstitialDuration",
  "rewardedDuration",
  "famobi_eventDuration",
  "eventDuration",
  "famobi_debug",
  "famobi_script",
  "famobi_gameID",
  "log",
  "Game\x20is\x20Ready",
  "feature_",
  "feature_properties_",
  "resource",
  "Application",
  "getApplication",
  "assets",
  "find",
  "getFileUrl",
  "replace",
  "/api/",
  "Player\x20Ready",
  "https://html5games.com/",
  "showAd\x20is\x20deprecated",
  "\x20seconds",
  "famobi_onPauseRequested",
  "[Show\x20Rewarded\x20Ad]\x20Waiting\x20for\x20",
  "function",
  "need\x20a\x20smart\x20solution\x20for\x20this.",
  "enableAudio",
  "disableMusic",
  "enableMusic",
  "changeVolume",
  "pauseGameplay",
  "restartGame",
  "Event\x20[",
  "]\x20is\x20not\x20recognized",
  "location",
  "href",
  "searchParams",
  "get",
  "language",
  "userLanguage",
  "removeItem",
  "innerWidth",
  "innerHeight",
  "landscape",
  "portrait",
  "addEventListener",
  "resize",
  "EVENT_VOLUMECHANGE",
  "EVENT_PAUSE",
  "EVENT_RESUME",
  "_validateParameters",
  "eventName",
  "done",
  "Track\x20stats",
  "string",
  "length",
  "match",
  "trackStats():\x20key\x20\x27",
  "\x27\x20contains\x20not\x20only\x20lowercase\x20letters,\x20numbers\x20and\x20underscore\x20([a-z_0-9]),\x20maximum\x20length:\x2042\x20characters",
  "trackStats():\x20invalid\x20params\x20",
  "stringify",
  "levelName",
  "Object\x20with\x20the\x20key\x20levelName\x20has\x20a\x20wrong\x20value",
  "reason",
  "Object\x20with\x20the\x20key\x20reason\x20has\x20a\x20wrong\x20value.\x20It\x20should\x20be\x20either\x20\x22timeout\x22\x20|\x20\x22dead\x22\x20|\x20\x22wrong_answer\x22\x20|\x20\x22draw\x22",
  "EVENT_LEVELSCORE",
  "levelScore",
  "sfxVolume",
  "Object\x20has\x20no\x20bgmVolume\x20and\x20sfxVolume\x20value",
  "keys",
  "Object\x20should\x20have\x20atleast\x20one\x20key\x20value\x20pair",
  "liveScore",
  "Object\x20with\x20the\x20key\x20liveScore\x20has\x20a\x20wrong\x20value",
  "Event\x20name",
  "is\x20not\x20recognized!",
  "famobi_tracking",
  "event/level/start",
  "event/level/update",
  "event/ad",
  "boolean",
  "object",
  "Track\x20Event",
  "EVENTS",
  "with\x20data",
  "tracking\x20event\x20cancelled\x20-\x20wrong/missing\x20parameters",
  "data",
  "EVENT_PARAMS",
  "tracking\x20event\x20cancelled\x20-\x20wrong\x20key\x20or\x20type",
  "event",
  "tracking",
  "processQueue",
  "tracking\x20event",
  "queue",
  "currentPromise",
  "then",
  "sendRequest",
  "ScriptType",
  "addAttributes",
  "bgmSettingKey",
  "This\x20key\x20must\x20be\x20the\x20same\x20as\x20in\x20the\x20default_save_data.json",
  "sfxSettingKey",
  "Leave\x20this\x20empty\x20if\x20there\x20is\x20only\x20one\x20setting\x20for\x20all\x20sounds",
  "bgmSoundEntity",
  "sfxSoundEntity",
  "entity",
  "muteIfPaused",
  "bgmVolume",
  "_bgmVolume",
  "_sfxVolume",
  "setSFXVolume",
  "_userBGMVolume",
  "userBGMVolume",
  "calculateBGMVolume",
  "_userSFXVolume",
  "userSFXVolume",
  "calculateSFXVolume",
  "externalMasterVolume",
  "_externalMasterVolume",
  "_externalBGMVolume",
  "externalBGMVolume",
  "_externalSFXVolume",
  "initialize",
  "instance",
  "bgmSoundComponent",
  "sound",
  "bgmSlots",
  "sfxSoundComponent",
  "setOriginalSlotVolume",
  "ready",
  "suspended",
  "externalMute",
  "external_mute",
  "enabled",
  "Sound\x20Entity\x20should\x20be\x20disabled\x20if\x20you\x20want\x20to\x20lazy\x20load\x20it!",
  "app",
  "Audio:sfx",
  "_playSFX",
  "Audio:bgm",
  "_playBGM",
  "isSuspended",
  "InputManager:input",
  "onResumeContext",
  "postInitialize",
  "onPauseManagerValueChanged",
  "disableAudio",
  "externalSFXVolume",
  "hasSFXSetting",
  "Slot\x20with\x20the\x20name\x20",
  "\x20was\x20not\x20found!",
  "stopAllBGM",
  "playSFX",
  "hasSlot",
  "sfxSlots",
  "play",
  "stop",
  "stopBGM",
  "stopAllSFX",
  "stopSFX",
  "fadeOut",
  "call",
  "overlap",
  "tween",
  "Linear",
  "complete",
  "fadeIn",
  "Slot\x20has\x20overlap\x20turned\x20on,\x20so\x20fadeIn\x20won\x27t\x20work.",
  "_originalVolume",
  "unmute",
  "mute",
  "systems",
  "updateSoundComponentVolume",
  "slots",
  "instances",
  "SoundSlot",
  "context",
  "_soundManager",
  "off",
  "_onResumeContext",
  "This\x20is\x20deprecated,\x20use\x20AudioManager.instance.playBGM\x20instead.",
  "playBGM",
  "This\x20is\x20deprecated,\x20use\x20AudioManager.instance.playSFX\x20instead.",
  "setBGMSetting",
  "setBGMSetting\x20is\x20deprecated.\x20Use\x20bgmVolume\x20=\x20value\x20instead",
  "setSFXSetting",
  "audioManager",
  "gameManager",
  "radius",
  "cameraEntity",
  "maxContinuesInARow",
  "canCreateInstance",
  "fire",
  "radiusSq",
  "tryToFocus",
  "goToNextLevel",
  "focus",
  "forcedMode",
  "showUI",
  "setForcedModeProperties",
  "start",
  "getStateValue",
  "level",
  "external_start",
  "pause",
  "startGame",
  "GameManager:ready",
  "LevelManager:levelLoaded",
  "setLevel",
  "intro",
  "createNewPath",
  "roundedScore",
  "fail",
  "started",
  "camera:shake",
  "GameManager:collision",
  "UIManager:hideUI",
  "Game\x20Screen",
  "levelEnd",
  "Result\x20Screen",
  "GameManager:restart",
  "continues",
  "LevelManager:increaseLevel",
  "CAMERA_COLOR",
  "copy",
  "getBackgroundColor",
  "camera",
  "clearColor",
  "resetTime",
  "levelStart",
  "Flash",
  "hideUI",
  "Color",
  "tweenAlpha",
  "initFrom",
  "From",
  "playStyle",
  "duration",
  "curve",
  "Animation\x20Curve",
  "ignoreTimeScale",
  "startDelay",
  "Start\x20Delay",
  "Show\x20Debug",
  "Start\x20on\x20Enable",
  "startOnInitialize",
  "Start\x20on\x20Initialize",
  "_currentOpacity",
  "_time",
  "_oldTime",
  "_from",
  "_to",
  "initTo",
  "_elements",
  "_getAllElementComponents",
  "state",
  "startOnEnable",
  "isActive",
  "updateTime",
  "value",
  "setAllElementOpacity",
  "name",
  "element",
  "opacity",
  "forEach",
  "mask",
  "ELEMENTTYPE_TEXT",
  "shadowOffset",
  "equals",
  "Vec2",
  "ZERO",
  "set",
  "shadowColor",
  "COLOR",
  "outlineThickness",
  "COLOR_1",
  "outlineColor",
  "tweenPosition",
  "vec3",
  "Ignore\x20Time\x20Scale",
  "clone",
  "_initPosition",
  "getLocalPosition",
  "_newPosition",
  "Vec3",
  "startTween",
  "startAtEnable",
  "sub",
  "scale",
  "sub2",
  "setLocalPosition",
  "tweenRotation",
  "startOnInit",
  "speed",
  "attr:initFrom",
  "attr:initTo",
  "stopTween",
  "_initRotation",
  "getLocalEulerAngles",
  "_newRotation",
  "setLocalEulerAngles",
  "tweenScale",
  "Play\x20Style",
  "_active",
  "_temp",
  "_newScale",
  "_initScale",
  "getLocalScale",
  "_updateTime",
  "mul",
  "setLocalScale",
  "finish",
  "vibrationManager",
  "vibrate",
  "webkitVibrate",
  "mozVibrate",
  "_defaultVibration",
  "_vibration",
  "_vibrate",
  "Vibration\x20not\x20supported",
  "_save",
  "save",
  "_isSupported",
  "platform",
  "lazyLoader",
  "getHandler",
  "texture",
  "Asset\x20is\x20undefined",
  "LevelLoader:levelsLoaded",
  "load",
  "error",
  "onLoaded",
  "Asset",
  "loadingOverlay",
  "_stackScreen",
  "_stackOverlay",
  "_stackPopup",
  "_uiTypes",
  "Screen",
  "Popup",
  "_uis",
  "_removeLoadingOverlay",
  "UIManager:showUI",
  "_showUI",
  "UIManager:hideAll",
  "_hideAll",
  "children",
  "script",
  "has",
  "uiEntity",
  "Entity",
  "Type\x20is\x20not\x20recognize",
  "Name\x20is\x20invalid",
  "This\x20ui\x20name\x20is\x20already\x20occupied.",
  "destroy",
  "getScreen",
  "No\x20ui\x20is\x20found\x20with\x20the\x20name",
  "isBusy",
  "UI\x20is\x20already\x20enabled",
  "onOpen",
  "_showUIFinish",
  "_addToStack",
  "type",
  "UIManager:opened",
  "onOpenFinish",
  "_hideUI",
  "_removeFromStack",
  "onClose",
  "onCloseFinish",
  "_getStack",
  "indexOf",
  "Entity\x20is\x20already\x20in\x20the\x20stack,\x20pushed\x20to\x20the\x20top",
  "splice",
  "Entity\x20doesn\x27t\x20exist\x20in\x20the\x20stack",
  "_stack",
  "screen",
  "referenceResolution",
  "SceneTransition",
  "LoadingScreen",
  "getTopStack",
  "scriptName",
  "showOnStartUp",
  "ignoreHideAll",
  "addUIEntity",
  "doesn\x27t\x20have\x20a\x20group\x20element,\x20please\x20add\x20it!",
  "dynamicScreen",
  "init",
  "getPrototypeOf",
  "constructor",
  "onUIEntityClose",
  "_isBusy",
  "closed",
  "onUIEntityCloseFinish",
  "onUIEntityOpen",
  "templateAsset",
  "template",
  "Template",
  "initialLength",
  "growCount",
  "Disable\x20In\x20Pool",
  "If\x20the\x20object\x20is\x20in\x20the\x20pool,\x20it\x20is\x20disabled.",
  "parentlessInPool",
  "Parentless\x20In\x20Pool",
  "parentEntity",
  "Parent",
  "The\x20parent\x20which\x20the\x20object\x20is\x20added\x20to.\x20Default\x20is\x20the\x20objectPool",
  "_pool",
  "_nextFreeSlot",
  "parent",
  "entityReference",
  "Entity\x20and\x20template\x20found,\x20using\x20entity",
  "_data",
  "entities",
  "No\x20object\x20found",
  "_grow",
  "instantiate",
  "disableInPool",
  "objectPool",
  "use",
  "recycle",
  "Already\x20in\x20the\x20object\x20pool",
  "reparent",
  "registerScript",
  "openUIEntity",
  "Open\x20UI\x20Entities",
  "closeItself",
  "Close\x20current\x20UI\x20Entity",
  "closeUIEntity",
  "args",
  "_waitForEvent",
  "_createInputEvent",
  "_setCloseItself",
  "_elementInput",
  "elementInput",
  "Add\x20the\x20script\x20elementInput\x20to\x20this\x20entity:",
  "CLICK",
  "_onClick",
  "_getUIEntity",
  "Wait\x20for\x20promise\x20to\x20resolve",
  "_openEntities",
  "has\x20in\x20invalid\x20parameter\x20in\x20the\x20array\x20openUIEntity\x20with\x20index",
  "has\x20in\x20invalid\x20parameter\x20in\x20the\x20array\x20closeUIEntity\x20with\x20index",
  "_hideUIFinish",
  "_app",
  "_tweens",
  "_add",
  "concat",
  "attach",
  "time",
  "stopped",
  "pending",
  "target",
  "_currentDelay",
  "timeScale",
  "_reverse",
  "_yoyo",
  "_count",
  "_repeatDelay",
  "_slerp",
  "_fromQuat",
  "Quat",
  "_toQuat",
  "_quat",
  "easing",
  "EASE_LINEAR",
  "_sv",
  "_ev",
  "_properties",
  "delay",
  "repeat",
  "yoyo",
  "playing",
  "setFromEulerAngles",
  "_delay",
  "_numRepeats",
  "_chained",
  "slerp",
  "_dirtifyLocal",
  "setLocalRotation",
  "_repeat",
  "once",
  "cos",
  "sin",
  "pow",
  "sqrt",
  "asin",
  "_tweenManager",
  "TweenManager",
  "update",
  "Tween",
  "dynamicElement",
  "freeze",
  "TOPLEFT",
  "TOPLEFT_ANCHOR",
  "TOP",
  "TOP_ANCHOR",
  "LEFT",
  "LEFT_ANCHOR",
  "CENTER",
  "CENTER_ANCHOR",
  "RIGHT_ANCHOR",
  "BOTTOMLEFT",
  "BOTTOM",
  "BOTTOM_ANCHOR",
  "BOTTOMRIGHT",
  "BOTTOMRIGHT_ANCHOR",
  "------------------------------------------------------",
  "desktopLandscapePreset",
  "Preset",
  "NONE",
  "desktopLandscapeAnchor",
  "Anchor",
  "desktopLandscapePivot",
  "Pivot",
  "desktopLandscapePosition",
  "Position",
  "desktopLandscapeRotation",
  "Rotation",
  "desktopLandscapeScale",
  "Scale",
  "desktopPortraitPreset",
  "desktopPortraitAnchor",
  "vec4",
  "desktopPortraitPivot",
  "vec2",
  "desktopPortraitRotation",
  "desktopPortraitScale",
  "Mobile\x20Landscape",
  "mobileLandscapePreset",
  "mobileLandscapeAnchor",
  "mobileLandscapePivot",
  "mobileLandscapeRotation",
  "mobileLandscapeScale",
  "Mobile\x20Portrait",
  "mobilePortraitPreset",
  "mobilePortraitAnchor",
  "mobilePortraitPivot",
  "mobilePortraitPosition",
  "mobilePortraitRotation",
  "mobilePortraitScale",
  "updatePosition",
  "Update\x20Position",
  "updateScale",
  "Update\x20Scale",
  "_orientation",
  "_device",
  "attr",
  "onAttributeChange",
  "_onResize",
  "getOrientation",
  "ViewportManager:onResize",
  "getDevice",
  "_setCurrentProperties",
  "DESKTOP",
  "_applyOrientationTransform",
  "desktopPortraitPosition",
  "Orientation",
  "LANDSCAPE",
  "Device",
  "Something\x20went\x20wrong",
  "test",
  "anchor",
  "pivot",
  "mobileLandscapePosition",
  "notificationBadge",
  "TEMPLATE_ID",
  "This\x20is\x20an\x20unique\x20id,\x20which\x20is\x20used\x20to\x20get\x20the\x20correct\x20notification\x20badge.",
  "textEntity",
  "If\x20true,\x20this\x20notification\x20badge\x20will\x20be\x20disabled\x20automatically\x20when\x20clicked\x20on\x20the\x20button.\x20It\x20can\x20also\x20be\x20disabled\x20with\x20the\x20function\x20\x22disable\x22",
  "buttonEntity",
  "_setDisableEvent",
  "setState",
  "disableOnClick",
  "switchUibutton",
  "click",
  "disable",
  "No\x20properties\x20are\x20found\x20with\x20the\x20id",
  "text",
  "null",
  "doesn\x27t\x20have\x20the\x20script",
  "NotificationBadgeManager:set",
  "setBadgeProperties",
  "_notificationBadges",
  "_badgeStates",
  "DISABLED",
  "That\x20entity\x20could\x20be\x20disabled\x20from\x20the\x20beginning",
  "pauseScreen",
  "resume",
  "viewportManager",
  "Delay",
  "Time\x20till\x20the\x20dimension\x20of\x20the\x20viewport\x20is\x20recalculated.",
  "delayIOS",
  "Delay\x20IOS",
  "calculateDPR",
  "setOnOrientationChange",
  "onOrientationChange",
  "_timeout",
  "ViewportManager:preResize",
  "getHeight",
  "resizeCanvas",
  "mobile",
  "MOBILE",
  "max",
  "min",
  "devicePixelRatio",
  "graphicsDevice",
  "_dpr",
  "desktop",
  "Vec4",
  "ORIENTATION_VERTICAL",
  "ORIENTATION_HORIZONTAL",
  "desktopClamp",
  "mobileClamp",
  "mobileClampWidth",
  "getReferenceResolution",
  "width",
  "height",
  "desktopClampWidth",
  "onChange",
  "inputManager",
  "disableContextMenu",
  "Disable\x20the\x20context\x20menu\x20usually\x20activated\x20with\x20right-click.",
  "Disable\x20Context\x20Menu",
  "Prevent\x20Default",
  "disablePreventDefaultForKeyboardCodes",
  "F12",
  "_supportTouch",
  "touch",
  "_supportMouse",
  "_hasFocus",
  "_onFocus",
  "blur",
  "_onBlur",
  "mouse",
  "EVENT_MOUSEDOWN",
  "_onInput",
  "EVENT_MOUSEUP",
  "EVENT_MOUSEWHEEL",
  "keyboard",
  "_onKeyInput",
  "EVENT_KEYUP",
  "EVENT_TOUCHCANCEL",
  "EVENT_TOUCHEND",
  "EVENT_TOUCHMOVE",
  "EVENT_TOUCHSTART",
  "doPreventDefault",
  "keyboardPreventDefault",
  "code",
  "Event\x20is\x20undefined",
  "Input\x20Down\x20Event",
  "Send\x20a\x20input\x20down\x20event",
  "inputUpEvent",
  "Input\x20Up\x20Event",
  "inputClickEvent",
  "Input\x20Click\x20Event",
  "inputMoveEvent",
  "Input\x20Move\x20Event",
  "Send\x20a\x20input\x20move\x20event",
  "buttonClick",
  "_touch",
  "getSupportTouch",
  "_mouse",
  "getSupportMouse",
  "_button",
  "button",
  "_enter",
  "_createButtonEvents",
  "_events",
  "inputEvent",
  "enable",
  "_element",
  "This\x20entity\x20with\x20the\x20name",
  "has\x20no\x20element\x20component!",
  "useInput",
  "_onTouchStart",
  "_onTouchMove",
  "touchleave",
  "_onTouchLeave",
  "_onMouseMove",
  "mouseleave",
  "mouseenter",
  "_sendDownEvent",
  "onButtonInputChange",
  "_inputDown",
  "getButtonActive",
  "_sendUpEvent",
  "_onTouchEnd",
  "_sendClickEvent",
  "_sendMoveEvent",
  "MOVE",
  "inputDownEvent",
  "addEvent",
  "DOWN",
  "clickSFX",
  "active",
  "wrapper",
  "api",
  "defaultApi",
  "_script",
  "setOnPauseRequested",
  "setOnResumeRequested",
  "setLocalStorageItem",
  "parse",
  "getLocalStorageItem",
  "clearLocalStorage",
  "localStorageHasKey",
  "setSessionStorageItem",
  "getSessionStorageItem",
  "removeSessionStorageItem",
  "clearSessionStorage",
  "levelSuccess",
  "1.3.2",
  "background:\x20#000;\x20color:\x20#FFF;",
  "singleton",
  "A\x20singleton\x20instance\x20is\x20already\x20made\x20of",
  "__name",
  "storageManager",
  "_basicInfo",
  "defaultSaveData",
  "_storages",
  "LOCALSTORAGE",
  "SESSIONSTORAGE",
  "_localStorage",
  "_sessionStorage",
  "loadSaveData",
  "toUpperCase",
  ",\x20which\x20is\x20incorrect.",
  "_writeToStorage",
  "_getStorage",
  "removeLocalStorageItem",
  "Storage\x20is\x20not\x20recognized.",
  "Key\x20is\x20",
  "Storage\x20",
  "\x20not\x20found",
  "isArray",
  "brandingButton",
  "famobi_branding_button",
  "hasBrandingButton",
  "lazyLoad",
  "onLoadedAsset",
  "mouseup",
  "touchend",
  "timer",
  "secsLeft",
  "callback",
  "scope",
  "findScripts",
  "QUAT_2",
  "QUAT_1",
  "trackingManager",
  "settings",
  "_resetData",
  "_settings",
  "gameTitle",
  "preferredUid",
  "versionNumber",
  "trackAds",
  "_currentData",
  "_getCurrentData",
  "LEVEL_END",
  "setData",
  "LEVEL_START",
  "_levelUpdate",
  "DEFAULT_DATA",
  "Inventory:",
  "isAffordable",
  "inventory",
  "copyright",
  "buttonComponentHelper",
  "defaultTint",
  "rgb",
  "hoverTint",
  "pressedTint",
  "inactiveTint",
  "fadeDuration",
  "_createButtonComponent",
  "_setButtonValues",
  "addComponent",
  "imageEntity",
  "defaultLanguage",
  "hasLanguagePack",
  "[I18n]\x20Default\x20language\x20has\x20no\x20default\x20language\x20pack",
  "setLanguage",
  "currentLanguage",
  "i18n",
  "I18n:language",
  "_availableLangs",
  "getText",
  "format",
  "EventHandler",
  "_callbackActive",
  "_callbacks",
  "slice",
  "messageButton",
  "functionName",
  "pauseWhenOutOfFocus",
  "gameTimeScale",
  "_gameTimeScale",
  "_setTimeScale",
  "focusTimeScale",
  "_focusTimeScale",
  "adTimeScale",
  "_adTimeScale",
  "externalPause",
  "STATES",
  "onPauseRequest",
  "resumeGameplay",
  "onResumeRequest",
  "onfocus",
  "onblur",
  "onBlur",
  "onAdPauseRequested",
  "onAdResumeRequested",
  "I\x27m\x20focussed\x20now",
  "I\x27m\x20blurred\x20now",
  "PAUSED",
  "PauseManager:valueChanged",
  "_pause",
  "_resume",
  "PauseManager:paused",
  "PauseManager:resumed",
  "setTimeScale",
  "pauseManager",
  "paused",
  "forcedModeProperties",
  "forced_mode",
  "hide_ui",
  "override",
  "_keepDisabled",
  "includes",
  "getOverrideValue",
  "rotationSpeed",
  "offset",
  "angle",
  "leftButtonEntity",
  "rightButtonEntity",
  "getWidth",
  "onResize",
  "onTouchLeft",
  "onInputUp",
  "leftButton",
  "rightButton",
  "onTouchRight",
  "EVENT_MOUSEMOVE",
  "onInputMove",
  "EVENT_KEYDOWN",
  "onKeyDown",
  "windowWidth",
  "key",
  "KEY_A",
  "leftPressed",
  "KEY_RIGHT",
];
(function (_0x548e90, _0x520267) {
  var _0xa390f0 = function (_0x30ee7d) {
    while (--_0x30ee7d) {
      _0x548e90["push"](_0x548e90["shift"]());
    }
  };
  _0xa390f0(++_0x520267);
})(_0x26c5, 0x121);
var _0x40b4 = function (_0x46c304, _0x35c031) {
  _0x46c304 = _0x46c304 - 0x0;
  var _0x2368f9 = _0x26c5[_0x46c304];
  return _0x2368f9;
};
var FamobiApi = pc["createScript"](_0x40b4("0x0"));
pc[_0x40b4("0x1")](FamobiApi[_0x40b4("0x2")], {
  initialize: function () {
    window[_0x40b4("0x3")] = window["famobi"] || {};
    window[_0x40b4("0x3")][_0x40b4("0x4")] =
      window[_0x40b4("0x3")][_0x40b4("0x4")] || window[_0x40b4("0x4")];
    window[_0x40b4("0x3")][_0x40b4("0x5")] =
      window[_0x40b4("0x3")][_0x40b4("0x5")] || window[_0x40b4("0x5")];
  },
  gameReady: function () {
    try {
      window[_0x40b4("0x3")][_0x40b4("0x6")]();
    } catch (_0x59e467) {
      console[_0x40b4("0x7")](_0x59e467);
    }
  },
  getBrandingButtonImage: function () {
    return window[_0x40b4("0x3")][_0x40b4("0x8")]();
  },
  moreGamesLink: function () {
    window[_0x40b4("0x3")]["moreGamesLink"]();
  },
  showInterstitialAd: function () {
    return window[_0x40b4("0x3")][_0x40b4("0x9")]();
  },
  showAd: function () {
    try {
      return window["famobi"][_0x40b4("0xa")]();
    } catch (_0x56b290) {}
  },
  hasRewardedAd: function () {
    return window[_0x40b4("0x3")][_0x40b4("0xb")]();
  },
  rewardedAd: function (_0x5a65c2, _0x4a7494) {
    window["famobi"][_0x40b4("0xc")](_0x5a65c2[_0x40b4("0xd")](_0x4a7494));
  },
  setOnPauseRequested: function (_0xfa592e, _0x1e5345) {
    window["famobi_onPauseRequested"] = _0xfa592e[_0x40b4("0xd")](
      _0x1e5345 || this
    );
  },
  setOnResumeRequested: function (_0x4b5c22, _0x32626d) {
    window[_0x40b4("0xe")] = _0x4b5c22["bind"](_0x32626d || this);
  },
  get: function (_0x3f0c15) {
    return window[_0x40b4("0x3")]["__"](_0x3f0c15) || _0x3f0c15;
  },
  getCurrentLanguage: function () {
    return window[_0x40b4("0x3")][_0x40b4("0xf")]();
  },
  setLocalStorageItem: function (_0x3ba448, _0x5987e4) {
    window[_0x40b4("0x3")][_0x40b4("0x4")]["setItem"](_0x3ba448, _0x5987e4);
  },
  getLocalStorageItem: function (_0x4a9879) {
    return window["famobi"]["localStorage"]["getItem"](_0x4a9879);
  },
  removeLocalStorageItem: function (_0x11657b) {
    window[_0x40b4("0x3")][_0x40b4("0x4")]["removeItem"](_0x11657b);
  },
  clearLocalStorage: function () {
    window[_0x40b4("0x3")]["localStorage"]["clear"]();
  },
  setSessionStorageItem: function (_0x327155, _0x46f3fa) {
    window[_0x40b4("0x3")]["sessionStorage"][_0x40b4("0x10")](
      _0x327155,
      _0x46f3fa
    );
  },
  getSessionStorageItem: function (_0x4086cd) {
    window["famobi"][_0x40b4("0x5")][_0x40b4("0x11")](_0x4086cd);
  },
  removeSessionStorageItem: function (_0x2a1a7e) {
    window[_0x40b4("0x3")][_0x40b4("0x5")]["removeItem"](_0x2a1a7e);
  },
  clearSessionStorage: function () {
    window[_0x40b4("0x3")]["sessionStorage"][_0x40b4("0x12")]();
  },
  getOrientation: function () {
    return window[_0x40b4("0x3")]["getOrientation"]();
  },
  setOnOrientationChange: function (_0x194fb0, _0x5077f3) {
    window["famobi"]["onOrientationChange"](
      _0x194fb0[_0x40b4("0xd")](_0x5077f3)
    );
  },
  hasFeature: function (_0x2baee7) {
    return window["famobi"][_0x40b4("0x13")](_0x2baee7);
  },
  onRequest: function (_0x49e844, _0x5de6d7) {
    window[_0x40b4("0x3")][_0x40b4("0x14")](_0x49e844, _0x5de6d7);
  },
  getFeatureProperties: function (_0x2f399b) {
    return window[_0x40b4("0x3")][_0x40b4("0x15")](_0x2f399b);
  },
  getVolume: function () {
    return window[_0x40b4("0x3")][_0x40b4("0x16")]();
  },
  playerReady: function () {
    window["famobi"][_0x40b4("0x17")]();
  },
  levelSuccess: function (_0x221b54, _0x1cf309) {
    const _0x711793 = [];
    _0x711793[_0x40b4("0x18")](
      window[_0x40b4("0x19")][_0x40b4("0x1a")](_0x40b4("0x1b"), {
        levelName: "level_" + _0x221b54,
      })
    );
    _0x711793[_0x40b4("0x18")](
      window[_0x40b4("0x19")][_0x40b4("0x1a")](_0x40b4("0x1c"), {
        totalScore: _0x1cf309,
      })
    );
    _0x711793[_0x40b4("0x18")](this["showInterstitialAd"]());
    return Promise["all"](_0x711793);
  },
  levelFail: function (_0x138bc0, _0x4b966e) {
    const _0x5247fd = [];
    _0x5247fd[_0x40b4("0x18")](
      window[_0x40b4("0x19")][_0x40b4("0x1a")](_0x40b4("0x1d"), {
        levelName: _0x40b4("0x1e") + _0x138bc0,
        reason: _0x40b4("0x1f"),
      })
    );
    _0x5247fd[_0x40b4("0x18")](
      window[_0x40b4("0x19")][_0x40b4("0x1a")]("EVENT_TOTALSCORE", {
        totalScore: _0x4b966e,
      })
    );
    _0x5247fd[_0x40b4("0x18")](this[_0x40b4("0x9")]());
    return Promise["all"](_0x5247fd);
  },
  levelStart(_0x2b0360 = 0x1, _0x1f03f7 = ![]) {
    const _0x36874d = [];
    _0x36874d["push"](
      window[_0x40b4("0x19")][_0x40b4("0x1a")](
        _0x1f03f7 ? _0x40b4("0x20") : _0x40b4("0x21"),
        { levelName: "level_" + _0x2b0360 }
      )
    );
    return Promise[_0x40b4("0x22")](_0x36874d);
  },
  levelEnd(_0x385687, _0x513981) {
    return window[_0x40b4("0x19")][_0x40b4("0x1a")](_0x40b4("0x23"), {
      eventName: _0x40b4("0x24"),
      result: _0x385687,
      score: _0x513981,
    });
  },
});
pc[_0x40b4("0x1")](FamobiApi["prototype"], {
  getMoreGamesButtonImage: function () {
    console["warn"](_0x40b4("0x25"));
    this["getBrandingButtonImage"]();
  },
  moreGamesLink: function () {
    console[_0x40b4("0x7")](
      "moreGamesLink\x20is\x20deprecated,\x20use\x20openBrandingLink\x20instead"
    );
    this[_0x40b4("0x26")]();
  },
  submitHighscore: function () {
    console[_0x40b4("0x7")](_0x40b4("0x27"));
  },
  levelUp: function () {
    console[_0x40b4("0x7")](_0x40b4("0x28"));
  },
  gameOver: function () {
    console[_0x40b4("0x7")](_0x40b4("0x29"));
  },
});
var FakeFamobiApi = pc[_0x40b4("0x2a")](_0x40b4("0x2b"));
var templateName = _0x40b4("0x2c");
FakeFamobiApi[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x2f"), {
  type: "string",
  default: templateName,
  title: _0x40b4("0x30"),
  description:
    "This\x20value\x20is\x20used\x20for\x20saving\x20in\x20the\x20localStorage.\x20Make\x20sure\x20to\x20make\x20it\x20unique,\x20so\x20it\x20doesn\x27t\x20override\x20any\x20other\x20storages.",
});
FakeFamobiApi[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0xb"), {
  type: "boolean",
  default: ![],
  title: _0x40b4("0x31"),
  description: _0x40b4("0x32"),
});
FakeFamobiApi[_0x40b4("0x2d")][_0x40b4("0x2e")]("interstitialDuration", {
  type: "number",
  default: 0xbb8,
  title: _0x40b4("0x33"),
});
FakeFamobiApi[_0x40b4("0x2d")]["add"]("rewardedDuration", {
  type: _0x40b4("0x34"),
  default: 0xbb8,
  title: _0x40b4("0x35"),
});
FakeFamobiApi["attributes"][_0x40b4("0x2e")]("eventDuration", {
  type: _0x40b4("0x34"),
  default: 0x32,
  title: _0x40b4("0x36"),
});
FakeFamobiApi["attributes"]["add"](_0x40b4("0x37"), { type: "boolean" });
FakeFamobiApi[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x38"), {
  type: "boolean",
  default: ![],
});
FakeFamobiApi[_0x40b4("0x2d")]["add"]("feature_highscores", {
  type: _0x40b4("0x34"),
  default: 0x1,
});
FakeFamobiApi["attributes"][_0x40b4("0x2e")]("feature_rewarded", {
  type: _0x40b4("0x34"),
  default: 0x1,
});
FakeFamobiApi[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x39"), {
  type: _0x40b4("0x34"),
  default: 0x1,
});
FakeFamobiApi[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x3a"), {
  type: _0x40b4("0x34"),
  default: 0x1,
});
FakeFamobiApi["attributes"][_0x40b4("0x2e")](_0x40b4("0x3b"), {
  type: "number",
  default: 0x1,
});
FakeFamobiApi[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x3c"), {
  type: "number",
  default: 0x1,
});
FakeFamobiApi[_0x40b4("0x2d")][_0x40b4("0x2e")](
  "feature_external_leaderboard",
  { type: _0x40b4("0x34"), default: 0x1 }
);
FakeFamobiApi[_0x40b4("0x2d")]["add"]("feature_external_mute", {
  type: "number",
  default: 0x1,
});
FakeFamobiApi[_0x40b4("0x2d")]["add"](_0x40b4("0x3d"), {
  type: _0x40b4("0x34"),
  default: 0x1,
});
FakeFamobiApi[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x3e"), {
  type: _0x40b4("0x34"),
  default: 0x1,
});
FakeFamobiApi[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x3f"), {
  type: _0x40b4("0x34"),
  default: 0x1,
});
FakeFamobiApi[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x40"), {
  type: "number",
  default: 0x1,
});
FakeFamobiApi[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x41"), {
  type: _0x40b4("0x34"),
  default: 0x1,
});
FakeFamobiApi["attributes"][_0x40b4("0x2e")]("feature_multiplayer_local", {
  type: "number",
  default: 0x1,
});
FakeFamobiApi["attributes"]["add"](_0x40b4("0x42"), {
  type: "number",
  default: 0x1,
});
FakeFamobiApi[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x43"), {
  type: "number",
  default: 0x1,
});
FakeFamobiApi[_0x40b4("0x2d")][_0x40b4("0x2e")]("feature_version", {
  type: "number",
  default: 0x1,
});
FakeFamobiApi[_0x40b4("0x2d")]["add"](_0x40b4("0x44"), {
  type: _0x40b4("0x45"),
  assetType: _0x40b4("0x46"),
});
FakeFamobiApi[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x47"), {
  type: _0x40b4("0x34"),
  min: 0x0,
  max: 0x1,
  default: 0.5,
});
pc[_0x40b4("0x1")](FakeFamobiApi[_0x40b4("0x2")], {
  initialize: function () {
    this["on"](_0x40b4("0x48"), function (_0x24ecb1) {
      window[_0x40b4("0x49")] = _0x24ecb1;
    });
    this["on"](_0x40b4("0x4a"), function (_0x3574d4) {
      window[_0x40b4("0x4b")] = _0x3574d4;
    });
    this["on"](_0x40b4("0x4c"), function (_0x512e65) {
      window[_0x40b4("0x4d")] = _0x512e65;
    });
    this["on"](_0x40b4("0x4e"), function (_0x49eab1) {
      window["famobi_debug"] = _0x49eab1;
    });
    if (!window[_0x40b4("0x3")]) {
      window["famobi_interstitialDuration"] = this[_0x40b4("0x4f")];
      window[_0x40b4("0x49")] = this["hasRewardedAd"];
      window["famobi_rewardedDuration"] = this[_0x40b4("0x50")];
      window["famobi_gameID"] = this[_0x40b4("0x2f")];
      window[_0x40b4("0x51")] = this[_0x40b4("0x52")];
      window[_0x40b4("0x53")] = this[_0x40b4("0x38")];
      window[_0x40b4("0x54")] = this;
      if (window[_0x40b4("0x55")] === templateName) {
        console["warn"](
          "Set\x20a\x20different\x20Famobi\x20Game\x20ID\x20in\x20FakeFamobiAPI"
        );
      }
      window[_0x40b4("0x3")] = {
        gameReady: function () {
          window[_0x40b4("0x3")][_0x40b4("0x56")](_0x40b4("0x57"));
        },
        hasFeature: function (_0x2c7020) {
          return !!window[_0x40b4("0x54")][_0x40b4("0x58") + _0x2c7020];
        },
        getFeatureProperties: function (_0x492cf7) {
          return (
            window[_0x40b4("0x54")][_0x40b4("0x59") + _0x492cf7][
              _0x40b4("0x5a")
            ] || {}
          );
        },
        getVolume: function () {
          return window["famobi_script"][_0x40b4("0x47")];
        },
        getBrandingButtonImage: function () {
          var _0x54bd83 = pc[_0x40b4("0x5b")]
            [_0x40b4("0x5c")]()
            [_0x40b4("0x5d")][_0x40b4("0x5e")](
              "placeholder_famobi_branding_button.png"
            )
            [_0x40b4("0x5f")]();
          var _0x1e6de3 = _0x54bd83[_0x40b4("0x60")](_0x40b4("0x61"), "");
          return _0x1e6de3;
        },
        playerReady: function () {
          window[_0x40b4("0x3")][_0x40b4("0x56")](_0x40b4("0x62"));
        },
        openBrandingLink: function () {
          window["open"](_0x40b4("0x63"));
        },
        showAd: function () {
          console[_0x40b4("0x7")](_0x40b4("0x64"));
          return this[_0x40b4("0x9")]();
        },
        showInterstitialAd: function () {
          window[_0x40b4("0x3")][_0x40b4("0x56")](
            "[Show\x20Interstitital\x20Ad]\x20Waiting\x20for\x20" +
              window[_0x40b4("0x4b")] / 0x3e8 +
              _0x40b4("0x65")
          );
          if (typeof window[_0x40b4("0x66")] === "function") {
            window[_0x40b4("0x66")]();
          }
          return new Promise(function (_0x3c78b7, _0x183b3c) {
            setTimeout(function () {
              if (typeof window["famobi_onResumeRequested"] === "function") {
                window[_0x40b4("0xe")]();
              }
              _0x3c78b7();
            }, window[_0x40b4("0x4b")]);
          });
        },
        hasRewardedAd: function () {
          return window["famobi_hasRewardedAd"];
        },
        rewardedAd: function (_0x4cf792) {
          window[_0x40b4("0x3")]["log"](
            _0x40b4("0x67") +
              window["famobi_rewardedDuration"] / 0x3e8 +
              "\x20seconds"
          );
          if (typeof window[_0x40b4("0x66")] === _0x40b4("0x68")) {
            window["famobi_onPauseRequested"]();
          }
          window[_0x40b4("0x49")] = ![];
          setTimeout(function () {
            window[_0x40b4("0x49")] = !![];
          }, 0x0);
          setTimeout(function () {
            if (typeof window["famobi_onPauseRequested"] === "function") {
              window[_0x40b4("0xe")]();
            }
            _0x4cf792({ rewardGranted: !![] });
          }, window[_0x40b4("0x4d")]);
        },
        __: function (_0x867da0) {
          window[_0x40b4("0x3")]["log"](_0x40b4("0x69"));
          return _0x867da0;
        },
        onRequest: function (_0x2b4255, _0x1af800) {
          switch (_0x2b4255) {
            case "startGame":
              new Promise((_0x30ea7a) => {
                setTimeout(_0x1af800, 0x1);
              });
            case "disableAudio":
            case _0x40b4("0x6a"):
            case _0x40b4("0x6b"):
            case _0x40b4("0x6c"):
            case _0x40b4("0x6d"):
            case _0x40b4("0x6e"):
            case "resumeGameplay":
            case _0x40b4("0x6f"):
              window["famobi_script"]["app"]["on"](
                "Famobi:" + _0x2b4255,
                _0x1af800
              );
              break;
            default:
              console["warn"](_0x40b4("0x70") + _0x2b4255 + _0x40b4("0x71"));
              window[_0x40b4("0x54")]["app"]["on"](
                "Famobi:" + _0x2b4255,
                _0x1af800
              );
              break;
          }
        },
        getCurrentLanguage: function () {
          let _0x139229;
          try {
            _0x139229 = new URL(window[_0x40b4("0x72")][_0x40b4("0x73")])[
              _0x40b4("0x74")
            ][_0x40b4("0x75")]("locale");
          } catch (_0x3474b7) {
            console["error"](_0x3474b7);
          }
          return (
            _0x139229 ||
            (navigator[_0x40b4("0x76")] || navigator[_0x40b4("0x77")])[
              "substr"
            ](0x0, 0x2)
          );
        },
        localStorage: {
          setItem: function (_0x32b4de, _0x345104) {
            window[_0x40b4("0x4")][_0x40b4("0x10")](
              window[_0x40b4("0x55")] + ":" + _0x32b4de,
              _0x345104
            );
          },
          getItem: function (_0x215634) {
            return window[_0x40b4("0x4")][_0x40b4("0x11")](
              window["famobi_gameID"] + ":" + _0x215634
            );
          },
          removeItem: function (_0x2dcc3b) {
            window[_0x40b4("0x4")][_0x40b4("0x78")](_0x2dcc3b);
          },
          clear: function () {
            for (var _0x26e7fc in window[_0x40b4("0x4")]) {
              if (_0x26e7fc["startsWith"](window[_0x40b4("0x55")] + ":")) {
                window[_0x40b4("0x4")][_0x40b4("0x78")](_0x26e7fc);
              }
            }
          },
        },
        getOrientation: function () {
          var _0x144aaa = window[_0x40b4("0x79")];
          var _0x168329 = window[_0x40b4("0x7a")];
          if (_0x144aaa > _0x168329) return _0x40b4("0x7b");
          if (_0x144aaa < _0x168329) return _0x40b4("0x7c");
          return "";
        },
        onOrientationChange: function (_0x44cb90) {
          window[_0x40b4("0x7d")](_0x40b4("0x7e"), _0x44cb90);
        },
      };
    }
    if (!window[_0x40b4("0x19")]) {
      window[_0x40b4("0x19")] = {
        EVENT_LEVELSUCCESS: _0x40b4("0x1b"),
        EVENT_LEVELFAIL: "EVENT_LEVELFAIL",
        EVENT_LEVELSTART: _0x40b4("0x21"),
        EVENT_LEVELRESTART: _0x40b4("0x20"),
        EVENT_TOTALSCORE: _0x40b4("0x1c"),
        EVENT_LEVELSCORE: "EVENT_LEVELSCORE",
        EVENT_VOLUMECHANGE: _0x40b4("0x7f"),
        EVENT_PAUSE: _0x40b4("0x80"),
        EVENT_RESUME: _0x40b4("0x81"),
        EVENT_CUSTOM: _0x40b4("0x23"),
        EVENT_LIVESCORE: "EVENT_LIVESCORE",
        trackEvent: function (_0x3ac402, _0x522ccf) {
          this[_0x40b4("0x82")](_0x3ac402, _0x522ccf);
          return new Promise(function (_0x487e21, _0x43f649) {
            setTimeout(function () {
              if (
                _0x3ac402 === window["famobi_analytics"][_0x40b4("0x23")] &&
                _0x522ccf[_0x40b4("0x83")] === _0x40b4("0x24") &&
                window["famobi"]["hasFeature"]("forced_mode")
              ) {
                _0x43f649(_0x40b4("0x84"));
              } else {
                _0x487e21();
              }
            }, window[_0x40b4("0x51")]);
          });
        },
        trackStats: function (_0xe3c0a7, _0x117510) {
          if (window["famobi_debug"]) {
            console[_0x40b4("0x7")](_0x40b4("0x85"), _0xe3c0a7, _0x117510);
          }
          return new Promise(function (_0x390bc0, _0xd5b23f) {
            var _0x308c9a = {};
            var _0xb9f589 = {};
            if (typeof _0xe3c0a7 === _0x40b4("0x86")) {
              _0xb9f589[_0xe3c0a7] = _0x117510;
            }
            var _0x39939a = function () {
              for (var _0x4618a0 in _0xb9f589) {
                var _0xc69a68 =
                  typeof _0xe3c0a7 === _0x40b4("0x86") &&
                  _0xe3c0a7[_0x40b4("0x87")] &&
                  _0xe3c0a7["length"] <= 0x2a &&
                  _0xe3c0a7[_0x40b4("0x88")](/^[a-z\_0-9]+$/);
                if (!_0xc69a68) {
                  console["warn"](
                    _0x40b4("0x89") + _0xe3c0a7 + _0x40b4("0x8a")
                  );
                  return ![];
                }
              }
              return !![];
            };
            var _0x281e5f = _0x39939a();
            if (!_0x281e5f) {
              _0xd5b23f(
                _0x40b4("0x8b") + JSON[_0x40b4("0x8c")](_0xe3c0a7, _0x117510)
              );
              return ![];
            }
            _0x390bc0(_0x308c9a);
          });
        },
        _validateParameters: function (_0xa9c853, _0x12025a) {
          switch (_0xa9c853) {
            case this[_0x40b4("0x1b")]: {
              if (
                !_0x12025a ||
                typeof _0x12025a[_0x40b4("0x8d")] !== _0x40b4("0x86")
              ) {
                window[_0x40b4("0x3")][_0x40b4("0x56")](
                  _0x40b4("0x8e"),
                  _0x12025a
                );
              }
              break;
            }
            case this[_0x40b4("0x1d")]: {
              if (
                !_0x12025a ||
                typeof _0x12025a[_0x40b4("0x8d")] !== "string"
              ) {
                window["famobi"]["log"](
                  "Object\x20with\x20the\x20key\x20levelName\x20has\x20a\x20wrong\x20value",
                  _0x12025a
                );
              }
              if (
                !_0x12025a ||
                typeof _0x12025a[_0x40b4("0x8f")] !== _0x40b4("0x86")
              ) {
                window["famobi"][_0x40b4("0x56")](_0x40b4("0x90"), _0x12025a);
              }
              break;
            }
            case this[_0x40b4("0x21")]: {
              if (
                !_0x12025a ||
                typeof _0x12025a[_0x40b4("0x8d")] !== _0x40b4("0x86")
              ) {
                window[_0x40b4("0x3")][_0x40b4("0x56")](
                  _0x40b4("0x8e"),
                  _0x12025a
                );
              }
              break;
            }
            case this[_0x40b4("0x20")]: {
              if (
                !_0x12025a ||
                typeof _0x12025a[_0x40b4("0x8d")] !== _0x40b4("0x86")
              ) {
                window["famobi"][_0x40b4("0x56")](_0x40b4("0x8e"), _0x12025a);
              }
              break;
            }
            case this[_0x40b4("0x1c")]: {
              if (
                !_0x12025a ||
                typeof _0x12025a["totalScore"] !== _0x40b4("0x34")
              ) {
                window[_0x40b4("0x3")][_0x40b4("0x56")](
                  "Object\x20with\x20the\x20key\x20totalScore\x20has\x20a\x20wrong\x20value",
                  _0x12025a
                );
              }
              break;
            }
            case this[_0x40b4("0x91")]: {
              if (!_0x12025a || typeof _0x12025a["levelName"] !== "string") {
                window[_0x40b4("0x3")][_0x40b4("0x56")](
                  _0x40b4("0x8e"),
                  _0x12025a
                );
              }
              if (
                !_0x12025a ||
                typeof _0x12025a[_0x40b4("0x92")] !== _0x40b4("0x34")
              ) {
                window[_0x40b4("0x3")]["log"](
                  "Object\x20with\x20the\x20key\x20levelScore\x20has\x20a\x20wrong\x20value",
                  _0x12025a
                );
              }
              break;
            }
            case this[_0x40b4("0x7f")]: {
              if (
                !_0x12025a ||
                (typeof _0x12025a["bgmVolume"] !== _0x40b4("0x34") &&
                  typeof _0x12025a[_0x40b4("0x93")] !== _0x40b4("0x34"))
              ) {
                window[_0x40b4("0x3")]["log"](_0x40b4("0x94"), _0x12025a);
              }
              break;
            }
            case this["EVENT_PAUSE"]: {
              break;
            }
            case this["EVENT_RESUME"]: {
              break;
            }
            case this[_0x40b4("0x23")]: {
              if (Object[_0x40b4("0x95")](_0x12025a)["length"] === 0x0) {
                window[_0x40b4("0x3")][_0x40b4("0x56")](
                  _0x40b4("0x96"),
                  _0x12025a
                );
              }
              break;
            }
            case this["EVENT_LIVESCORE"]: {
              if (
                !_0x12025a ||
                typeof _0x12025a[_0x40b4("0x97")] !== "number"
              ) {
                window[_0x40b4("0x3")][_0x40b4("0x56")](
                  _0x40b4("0x98"),
                  _0x12025a
                );
              }
              break;
            }
            default: {
              console["warn"](_0x40b4("0x99"), _0xa9c853, _0x40b4("0x9a"));
              break;
            }
          }
        },
      };
    }
    if (!window[_0x40b4("0x9b")]) {
      window["famobi_tracking"] = {
        trackingLog: this[_0x40b4("0x37")],
        tracking: { queue: [], currentPromise: Promise["resolve"]() },
        EVENTS: {
          LEVEL_START: _0x40b4("0x9c"),
          LEVEL_END: "event/level/end",
          LEVEL_UPDATE: _0x40b4("0x9d"),
          AD: _0x40b4("0x9e"),
        },
        EVENT_PARAMS: {
          level: _0x40b4("0x34"),
          score: _0x40b4("0x34"),
          stars: "number",
          movesAvailable: _0x40b4("0x34"),
          movesLeft: _0x40b4("0x34"),
          success: _0x40b4("0x9f"),
          revives: _0x40b4("0x34"),
          powerups: _0x40b4("0xa0"),
          jumpStarters: "object",
          data: "object",
        },
        init: function (_0x569550, _0x4ab01f, _0xd6c211, _0xa8809a, _0x216402) {
          window["famobi"][_0x40b4("0x56")](
            _0x569550,
            _0x4ab01f,
            _0xd6c211,
            _0xa8809a,
            _0x216402
          );
        },
        trackEvent: function (_0x18f833, _0x565fbe) {
          if (window[_0x40b4("0x53")]) {
            console[_0x40b4("0x7")](_0x40b4("0xa1"), _0x18f833, _0x565fbe);
          }
          if (_0x18f833 in this[_0x40b4("0xa2")]) {
            _0x18f833 = this["EVENTS"][_0x18f833];
          }
          if (this["trackingLog"]) {
            window[_0x40b4("0x3")][_0x40b4("0x56")](
              "queuing\x20event",
              _0x18f833,
              _0x40b4("0xa3"),
              _0x565fbe
            );
          }
          if (
            typeof _0x18f833 !== _0x40b4("0x86") ||
            typeof _0x565fbe !== "object" ||
            _0x565fbe === null
          ) {
            window[_0x40b4("0x3")][_0x40b4("0x56")](
              _0x40b4("0xa4"),
              "event",
              _0x18f833,
              _0x40b4("0xa5"),
              _0x565fbe
            );
            return;
          }
          var _0x59b4a5 = Object[_0x40b4("0x95")](_0x565fbe);
          for (
            var _0x5e2946 = 0x0;
            _0x5e2946 < _0x59b4a5[_0x40b4("0x87")];
            _0x5e2946++
          ) {
            var _0x3c620e = _0x59b4a5[_0x5e2946];
            if (
              !(_0x3c620e in this["EVENT_PARAMS"]) ||
              typeof _0x565fbe[_0x3c620e] !== this[_0x40b4("0xa6")][_0x3c620e]
            ) {
              window["famobi"][_0x40b4("0x56")](
                _0x40b4("0xa7"),
                _0x40b4("0xa8"),
                _0x18f833,
                _0x40b4("0xa5"),
                _0x565fbe,
                "key",
                _0x3c620e
              );
            }
          }
          this[_0x40b4("0xa9")]["queue"]["push"]({
            event: _0x18f833,
            data: _0x565fbe,
          });
          this[_0x40b4("0xaa")]();
        },
        sendRequest: function (_0x46bdb1, _0x352238) {
          if (this[_0x40b4("0x37")]) {
            window[_0x40b4("0x3")]["log"](
              _0x40b4("0xab"),
              _0x46bdb1,
              _0x40b4("0xa3"),
              _0x352238
            );
          }
          return new Promise(function (_0x241e1d, _0x11b68b) {
            setTimeout(_0x241e1d, 0x3e8);
          });
        },
        processQueue: function () {
          this["tracking"][_0x40b4("0xac")]["forEach"](
            function (_0x12891d) {
              this[_0x40b4("0xa9")][_0x40b4("0xad")] = this[_0x40b4("0xa9")][
                _0x40b4("0xad")
              ][_0x40b4("0xae")](
                function () {
                  return this[_0x40b4("0xaf")](
                    _0x12891d[_0x40b4("0xa8")],
                    _0x12891d[_0x40b4("0xa5")]
                  );
                }["bind"](this),
                function () {
                  return this[_0x40b4("0xaf")](
                    _0x12891d[_0x40b4("0xa8")],
                    _0x12891d["data"]
                  );
                }[_0x40b4("0xd")](this)
              );
            }[_0x40b4("0xd")](this)
          );
          this[_0x40b4("0xa9")]["queue"]["length"] = 0x0;
        },
      };
    }
  },
});
class AudioManager extends pc[_0x40b4("0xb0")] {
  static [_0x40b4("0xb1")]() {
    this["attributes"]["add"](_0x40b4("0xb2"), {
      type: _0x40b4("0x86"),
      default: "music",
      description: _0x40b4("0xb3"),
    });
    this[_0x40b4("0x2d")]["add"](_0x40b4("0xb4"), {
      type: _0x40b4("0x86"),
      default: "",
      description: _0x40b4("0xb5"),
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0xb6"), { type: "entity" });
    this["attributes"]["add"](_0x40b4("0xb7"), { type: _0x40b4("0xb8") });
    this["attributes"][_0x40b4("0x2e")](_0x40b4("0xb9"), {
      type: _0x40b4("0x9f"),
    });
  }
  get [_0x40b4("0xba")]() {
    return this[_0x40b4("0xbb")];
  }
  set ["bgmVolume"](_0x3e7750) {
    this["_bgmVolume"] = _0x3e7750;
    this["setBGMVolume"]();
  }
  get ["sfxVolume"]() {
    return this[_0x40b4("0xbc")];
  }
  set ["sfxVolume"](_0xe5fbf8) {
    this[_0x40b4("0xbc")] = _0xe5fbf8;
    this[_0x40b4("0xbd")]();
  }
  get ["userBGMVolume"]() {
    return this[_0x40b4("0xbe")];
  }
  set [_0x40b4("0xbf")](_0x35bf37) {
    this[_0x40b4("0xbe")] = _0x35bf37;
    this[_0x40b4("0xc0")]();
  }
  get ["userSFXVolume"]() {
    return this[_0x40b4("0xc1")];
  }
  set [_0x40b4("0xc2")](_0x519f0a) {
    this[_0x40b4("0xc1")] = _0x519f0a;
    this[_0x40b4("0xc3")]();
  }
  get [_0x40b4("0xc4")]() {
    return this[_0x40b4("0xc5")];
  }
  set [_0x40b4("0xc4")](_0x186aad) {
    this["_externalMasterVolume"] = _0x186aad;
    this[_0x40b4("0xc0")]();
    this[_0x40b4("0xc3")]();
  }
  get ["externalBGMVolume"]() {
    return this[_0x40b4("0xc6")];
  }
  set [_0x40b4("0xc7")](_0x52a1b5) {
    this[_0x40b4("0xc6")] = _0x52a1b5;
    this["calculateBGMVolume"]();
  }
  get ["externalSFXVolume"]() {
    return this["_externalSFXVolume"];
  }
  set ["externalSFXVolume"](_0x1946c6) {
    this[_0x40b4("0xc8")] = _0x1946c6;
    this[_0x40b4("0xc3")]();
  }
  [_0x40b4("0xc9")]() {
    AudioManager[_0x40b4("0xca")] = this;
    this[_0x40b4("0xcb")] = this[_0x40b4("0xb6")][_0x40b4("0xcc")];
    this["sfxSoundComponent"] = this[_0x40b4("0xb7")][_0x40b4("0xcc")];
    this[_0x40b4("0xcd")] = this[_0x40b4("0xcb")]["slots"];
    this["sfxSlots"] = this[_0x40b4("0xce")]["slots"];
    this["setOriginalSlotVolume"](this[_0x40b4("0xcd")]);
    this[_0x40b4("0xcf")](this["sfxSlots"]);
    this[_0x40b4("0xd0")] = ![];
    this[_0x40b4("0xd1")] = ![];
    this[_0x40b4("0xd2")] = Wrapper["instance"][_0x40b4("0x13")](
      _0x40b4("0xd3")
    );
    this["hasSFXSetting"] = !!this[_0x40b4("0xb4")];
    this[_0x40b4("0xbb")] = 0x1;
    this[_0x40b4("0xbc")] = 0x1;
    this[_0x40b4("0xbe")] = 0x1;
    this[_0x40b4("0xc1")] = 0x1;
    this[_0x40b4("0xc5")] = 0x1;
    this["_externalBGMVolume"] = 0x1;
    this[_0x40b4("0xc8")] = 0x1;
    if (this["bgmSoundEntity"][_0x40b4("0xd4")]) {
      console[_0x40b4("0x7")](_0x40b4("0xd5"));
    }
    if (this[_0x40b4("0xb7")]["enabled"]) {
      console[_0x40b4("0x7")](_0x40b4("0xd5"));
    }
    this[_0x40b4("0xd6")]["on"](_0x40b4("0xd7"), this[_0x40b4("0xd8")], this);
    this[_0x40b4("0xd6")]["on"](_0x40b4("0xd9"), this[_0x40b4("0xda")], this);
    if (this[_0x40b4("0xdb")]()) {
      this[_0x40b4("0xd6")]["on"](_0x40b4("0xdc"), this[_0x40b4("0xdd")], this);
      this["suspended"] = !![];
    }
  }
  [_0x40b4("0xde")]() {
    this[_0x40b4("0xd6")]["on"](
      "PauseManager:valueChanged",
      this[_0x40b4("0xdf")],
      this
    );
    if (this[_0x40b4("0xd2")]) {
      Wrapper[_0x40b4("0xca")][_0x40b4("0x14")](
        _0x40b4("0x6a"),
        () => (this["externalSFXVolume"] = 0x1)
      );
      Wrapper[_0x40b4("0xca")][_0x40b4("0x14")](
        _0x40b4("0xe0"),
        () => (this[_0x40b4("0xe1")] = 0x0)
      );
      Wrapper[_0x40b4("0xca")][_0x40b4("0x14")](
        _0x40b4("0x6c"),
        () => (this["externalBGMVolume"] = 0x1)
      );
      Wrapper["instance"][_0x40b4("0x14")](
        "disableMusic",
        () => (this[_0x40b4("0xc7")] = 0x0)
      );
    }
    Wrapper["instance"][_0x40b4("0x14")](
      _0x40b4("0x6d"),
      (_0x134c1a) => (this[_0x40b4("0xc4")] = _0x134c1a)
    );
    this["externalMasterVolume"] = Wrapper[_0x40b4("0xca")][_0x40b4("0x16")]();
    this[_0x40b4("0xbf")] = this["externalMute"]
      ? 0x1
      : StorageManager["instance"][_0x40b4("0x75")](this[_0x40b4("0xb2")]);
    this[_0x40b4("0xc2")] =
      this[_0x40b4("0xd2")] || !this[_0x40b4("0xe2")]
        ? 0x1
        : StorageManager[_0x40b4("0xca")][_0x40b4("0x75")](
            this[_0x40b4("0xb4")]
          );
  }
  ["onReady"]() {
    this[_0x40b4("0xd0")] = !![];
    this["sfxSoundEntity"][_0x40b4("0xd4")] = !![];
    this[_0x40b4("0xb6")]["enabled"] = !![];
    return this;
  }
  ["playBGM"](_0x229280, _0x41d2da = !![]) {
    if (!this["hasSlot"](this[_0x40b4("0xcd")], _0x229280)) {
      console[_0x40b4("0x7")](_0x40b4("0xe3") + _0x229280 + _0x40b4("0xe4"));
      return null;
    }
    if (!this["ready"]) {
      return null;
    }
    if (_0x41d2da) {
      this[_0x40b4("0xe5")]();
    }
    const _0x490947 = this["bgmSoundComponent"]["play"](_0x229280);
    return _0x490947;
  }
  [_0x40b4("0xe6")](_0x5a975d) {
    if (!this[_0x40b4("0xe7")](this[_0x40b4("0xe8")], _0x5a975d)) {
      console[_0x40b4("0x7")](_0x40b4("0xe3") + _0x5a975d + _0x40b4("0xe4"));
      return null;
    }
    if (!this[_0x40b4("0xd0")]) {
      return null;
    }
    const _0x6cd737 = this[_0x40b4("0xce")][_0x40b4("0xe9")](_0x5a975d);
    return _0x6cd737;
  }
  [_0x40b4("0xe5")]() {
    this[_0x40b4("0xcb")][_0x40b4("0xea")]();
  }
  [_0x40b4("0xeb")](_0x1bfa3b) {
    this[_0x40b4("0xcb")]["stop"](_0x1bfa3b);
  }
  [_0x40b4("0xec")]() {
    this[_0x40b4("0xce")][_0x40b4("0xea")]();
  }
  [_0x40b4("0xed")](_0x515580) {
    this[_0x40b4("0xce")]["stop"](_0x515580);
  }
  [_0x40b4("0xee")](
    _0x513543,
    _0x28c125 = 0x1,
    _0x468b96 = null,
    _0x3b894d = null
  ) {
    if (!this["hasSlot"](this[_0x40b4("0xcd")], _0x513543)) {
      console[_0x40b4("0x7")](
        _0x40b4("0xe3") + _0x513543 + "\x20was\x20not\x20found!"
      );
      if (typeof _0x468b96 === "function") {
        _0x468b96[_0x40b4("0xef")](_0x3b894d);
      }
      return;
    }
    const _0x1a5e07 = this[_0x40b4("0xcd")][_0x513543];
    if (_0x1a5e07[_0x40b4("0xf0")]) {
      console[_0x40b4("0x7")](
        "Slot\x20has\x20overlap\x20turned\x20on,\x20so\x20fadeOut\x20won\x27t\x20work."
      );
      if (typeof _0x468b96 === _0x40b4("0x68")) {
        _0x468b96["call"](_0x3b894d);
      }
      return;
    }
    const _0xbcd492 = this[_0x40b4("0xb8")]
      [_0x40b4("0xf1")](_0x1a5e07)
      ["to"]({ volume: 0x0 }, _0x28c125, pc[_0x40b4("0xf2")])
      ["start"]();
    if (typeof _0x468b96 === "function") {
      _0xbcd492["on"](_0x40b4("0xf3"), _0x468b96, _0x3b894d);
    }
    return _0xbcd492;
  }
  [_0x40b4("0xf4")](
    _0x291383,
    _0x4339d4 = 0x1,
    _0x259088 = null,
    _0x36a44c = null
  ) {
    if (!this[_0x40b4("0xe7")](this[_0x40b4("0xcd")], _0x291383)) {
      console[_0x40b4("0x7")](
        "Slot\x20with\x20the\x20name\x20" +
          _0x291383 +
          "\x20was\x20not\x20found!"
      );
      if (typeof _0x259088 === _0x40b4("0x68")) {
        _0x259088["call"](_0x36a44c);
      }
      return;
    }
    const _0x1fbf2f = this[_0x40b4("0xcd")][_0x291383];
    if (_0x1fbf2f[_0x40b4("0xf0")]) {
      console["warn"](_0x40b4("0xf5"));
      if (typeof _0x259088 === _0x40b4("0x68")) {
        _0x259088["call"](_0x36a44c);
      }
      return;
    }
    const _0xcb6714 = this["entity"]
      [_0x40b4("0xf1")](_0x1fbf2f)
      ["to"](
        { volume: _0x1fbf2f[_0x40b4("0xf6")] },
        _0x4339d4,
        pc[_0x40b4("0xf2")]
      )
      ["start"]();
    if (typeof _0x259088 === "function") {
      _0xcb6714["on"]("complete", _0x259088, _0x36a44c);
    }
    return _0xcb6714;
  }
  ["onPauseManagerValueChanged"](_0x5075a6, _0x1ba5b6, _0x4f1315, _0x1f26e9) {
    if (_0x5075a6 > 0x0) {
      this[_0x40b4("0xf7")]();
      return;
    }
    if (
      !this["muteIfPaused"] &&
      _0x1ba5b6 === 0x0 &&
      _0x4f1315 === 0x1 &&
      _0x1f26e9 === 0x1
    ) {
      this["unmute"]();
      return;
    }
    this["mute"]();
  }
  [_0x40b4("0xf8")]() {
    this["app"]["systems"]["sound"][_0x40b4("0x47")] = 0x0;
  }
  [_0x40b4("0xf7")]() {
    this[_0x40b4("0xd6")][_0x40b4("0xf9")]["sound"][_0x40b4("0x47")] = 0x1;
  }
  ["calculateBGMVolume"]() {
    this[_0x40b4("0xba")] =
      this["userBGMVolume"] * this[_0x40b4("0xc4")] * this[_0x40b4("0xc7")];
  }
  [_0x40b4("0xc3")]() {
    if (!this["hasSFXSetting"]) {
      return;
    }
    this[_0x40b4("0x93")] =
      this[_0x40b4("0xc2")] * this[_0x40b4("0xc4")] * this[_0x40b4("0xe1")];
  }
  ["setBGMVolume"]() {
    this[_0x40b4("0xcb")][_0x40b4("0x47")] = this[_0x40b4("0xba")];
    this[_0x40b4("0xfa")](this[_0x40b4("0xcb")]);
    if (!this[_0x40b4("0xe2")]) {
      this["sfxSoundComponent"][_0x40b4("0x47")] = this[_0x40b4("0xba")];
      this[_0x40b4("0xfa")](this[_0x40b4("0xce")]);
    }
  }
  [_0x40b4("0xbd")]() {
    if (!this[_0x40b4("0xe2")]) {
      return;
    }
    this[_0x40b4("0xce")][_0x40b4("0x47")] = this[_0x40b4("0x93")];
    this[_0x40b4("0xfa")](this[_0x40b4("0xce")]);
  }
  [_0x40b4("0xfa")](_0x40dab1) {
    for (const _0x106b70 in _0x40dab1[_0x40b4("0xfb")]) {
      const _0x3b4b08 = _0x40dab1[_0x40b4("0xfb")][_0x106b70];
      if (_0x3b4b08["overlap"]) {
        for (
          let _0xe0376c = 0x0;
          _0xe0376c < _0x3b4b08["instances"]["length"];
          _0xe0376c++
        ) {
          const _0x1542b9 = _0x3b4b08[_0x40b4("0xfc")][_0xe0376c];
          _0x1542b9[_0x40b4("0x47")] =
            _0x3b4b08["volume"] * _0x40dab1[_0x40b4("0x47")];
        }
      }
    }
  }
  [_0x40b4("0xe7")](_0x101459, _0x3e8fce) {
    return _0x101459[_0x3e8fce] instanceof pc[_0x40b4("0xfd")];
  }
  [_0x40b4("0xdb")]() {
    return (
      this[_0x40b4("0xd6")][_0x40b4("0xfe")][_0x40b4("0xff")][
        _0x40b4("0xfe")
      ] &&
      this[_0x40b4("0xd6")][_0x40b4("0xfe")][_0x40b4("0xff")]["context"][
        "state"
      ] === _0x40b4("0xd1")
    );
  }
  ["setOriginalSlotVolume"](_0x249339) {
    for (const _0x36227f in _0x249339) {
      const _0x1f776e = _0x249339[_0x36227f];
      _0x1f776e[_0x40b4("0xf6")] = _0x1f776e[_0x40b4("0x47")];
    }
  }
  [_0x40b4("0xdd")]() {
    this["app"][_0x40b4("0xfe")][_0x40b4("0xff")][_0x40b4("0xfe")]["resume"]();
    setTimeout(() => {
      if (!this[_0x40b4("0xdb")]()) {
        this[_0x40b4("0xd6")][_0x40b4("0x100")](
          _0x40b4("0xdc"),
          this[_0x40b4("0x101")],
          this
        );
        this[_0x40b4("0xd1")] = ![];
      }
    }, 0x64);
  }
  [_0x40b4("0xda")]() {
    console[_0x40b4("0x7")](_0x40b4("0x102"));
    this[_0x40b4("0x103")](...arguments);
  }
  [_0x40b4("0xd8")]() {
    console[_0x40b4("0x7")](_0x40b4("0x104"));
    this[_0x40b4("0xe6")](...arguments);
  }
  [_0x40b4("0x105")](_0x3f7fdc) {
    console[_0x40b4("0x7")](_0x40b4("0x106"));
    this[_0x40b4("0xba")] = _0x3f7fdc;
  }
  [_0x40b4("0x107")](_0x1e3867) {
    console[_0x40b4("0x7")](
      "setSFXSetting\x20is\x20deprecated.\x20Use\x20sfxVolume\x20=\x20value\x20instead"
    );
    this[_0x40b4("0x93")] = _0x1e3867;
  }
}
pc["registerScript"](AudioManager, _0x40b4("0x108"));
AudioManager[_0x40b4("0xb1")]();
var GameManager = pc[_0x40b4("0x2a")](_0x40b4("0x109"));
GameManager[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x10a"), {
  type: _0x40b4("0x34"),
  default: 0x1,
});
GameManager["attributes"][_0x40b4("0x2e")](_0x40b4("0x38"), {
  type: _0x40b4("0x9f"),
  default: ![],
});
GameManager["attributes"][_0x40b4("0x2e")](_0x40b4("0x10b"), {
  type: _0x40b4("0xb8"),
});
GameManager[_0x40b4("0x2d")]["add"](_0x40b4("0x10c"), {
  type: _0x40b4("0x34"),
  default: 0x1,
});
pc[_0x40b4("0x1")](GameManager[_0x40b4("0x2")], {
  initialize: function () {
    if (Singleton["instance"][_0x40b4("0x10d")](this)) {
      GameManager["instance"] = this;
    }
    this["on"]("attr:debug", () => {
      this[_0x40b4("0xd6")][_0x40b4("0x10e")](
        _0x40b4("0x38"),
        this[_0x40b4("0x38")]
      );
    });
    this["continues"] = 0x0;
    this[_0x40b4("0x10f")] = this[_0x40b4("0x10a")] * this[_0x40b4("0x10a")];
    Wrapper[_0x40b4("0xca")][_0x40b4("0x14")](
      _0x40b4("0x6f"),
      this["restart"][_0x40b4("0xd")](this)
    );
    this[_0x40b4("0x110")]();
  },
  postInitialize: function () {
    Path[_0x40b4("0xca")]["on"](_0x40b4("0xf3"), this[_0x40b4("0x111")], this);
    this["checkReady"]();
  },
  tryToFocus() {
    setTimeout(function () {
      window[_0x40b4("0x112")]();
    });
  },
  checkReady() {
    if (ForcedModeManager["instance"][_0x40b4("0x113")]) {
      UIManager["instance"][_0x40b4("0x114")]("Game\x20Screen");
      ForcedModeManager["instance"][_0x40b4("0x115")]();
      this[_0x40b4("0x116")](
        ForcedModeManager["instance"][_0x40b4("0x117")](_0x40b4("0x118"))
      );
    } else {
      this["showIntro"]();
    }
    if (Wrapper[_0x40b4("0xca")][_0x40b4("0x13")](_0x40b4("0x119"))) {
      PauseManager["instance"][_0x40b4("0x11a")]();
      Wrapper[_0x40b4("0xca")][_0x40b4("0x14")](_0x40b4("0x11b"), () => {
        PauseManager[_0x40b4("0xca")]["resume"]();
      });
      Wrapper["instance"][_0x40b4("0x6")]();
    }
    this["app"][_0x40b4("0x10e")](_0x40b4("0x11c"));
    this["app"]["fire"](_0x40b4("0x11d"));
    this["tryToFocus"]();
  },
  showIntro() {
    Colors[_0x40b4("0xca")][_0x40b4("0x11e")](0x1);
    this[_0x40b4("0x11f")] = !![];
    PathGenerator[_0x40b4("0xca")][_0x40b4("0x120")]();
    UIManager[_0x40b4("0xca")][_0x40b4("0x114")]("Main\x20Menu");
  },
  collision: function () {
    ScoreManager[_0x40b4("0xca")]["updateLiveScore"]();
    let _0x1c570c = ScoreManager[_0x40b4("0xca")][_0x40b4("0x121")];
    const _0xf29390 = _0x40b4("0x122");
    this[_0x40b4("0x123")] = ![];
    this[_0x40b4("0xd6")][_0x40b4("0x10e")](_0x40b4("0x124"));
    this[_0x40b4("0xd6")][_0x40b4("0x10e")](_0x40b4("0x125"));
    this["app"][_0x40b4("0x10e")](_0x40b4("0x126"), _0x40b4("0x127"));
    Wrapper["instance"]
      [_0x40b4("0x128")](_0xf29390, _0x1c570c)
      [_0x40b4("0xae")](() => {
        UIManager[_0x40b4("0xca")][_0x40b4("0x114")](_0x40b4("0x129"));
      });
  },
  restart: function () {
    ScoreManager[_0x40b4("0xca")]["reset"]();
    this[_0x40b4("0xd6")][_0x40b4("0x10e")](_0x40b4("0x12a"));
    this[_0x40b4("0x12b")] = 0x0;
    const _0x30dcbf = ForcedModeManager[_0x40b4("0xca")][_0x40b4("0x113")]
      ? ForcedModeManager[_0x40b4("0xca")][_0x40b4("0x117")](_0x40b4("0x118"))
      : 0x1;
    this["startGamePlay"](_0x30dcbf, !![]);
  },
  goToNextLevel: function () {
    if (!this["intro"]) {
      this[_0x40b4("0xd6")][_0x40b4("0x10e")](_0x40b4("0x12c"));
    }
    Colors["instance"][_0x40b4("0x11e")](LevelManager["instance"]["level"]);
    GameManager[_0x40b4("0x12d")][_0x40b4("0x12e")](
      Colors[_0x40b4("0xca")][_0x40b4("0x12f")]()
    );
    this["cameraEntity"][_0x40b4("0x130")][_0x40b4("0x131")] =
      GameManager["CAMERA_COLOR"];
    PathGenerator["instance"]["createNewPath"]();
  },
  start: function (_0x28a52a = 0x1, _0x2d4bc2 = !![]) {
    this[_0x40b4("0x11f")] = ![];
    this[_0x40b4("0x123")] = !![];
    ScoreManager[_0x40b4("0xca")]["reset"]();
    Wrapper["instance"][_0x40b4("0x17")]();
    if (_0x2d4bc2) {
      LevelManager[_0x40b4("0xca")][_0x40b4("0x11e")](_0x28a52a);
    }
    Colors[_0x40b4("0xca")]["setLevel"](
      LevelManager[_0x40b4("0xca")][_0x40b4("0x118")],
      _0x2d4bc2
    );
    GameManager[_0x40b4("0x12d")][_0x40b4("0x12e")](
      Colors["instance"]["getBackgroundColor"]()
    );
    this["cameraEntity"][_0x40b4("0x130")][_0x40b4("0x131")] =
      GameManager[_0x40b4("0x12d")];
    Path[_0x40b4("0xca")][_0x40b4("0x132")]();
    this[_0x40b4("0x12b")] = 0x0;
    PathGenerator[_0x40b4("0xca")][_0x40b4("0x120")](!![], _0x2d4bc2);
    Path[_0x40b4("0xca")]["resetTime"]();
  },
  continue() {
    Wrapper[_0x40b4("0xca")][_0x40b4("0x133")](0x1)["then"](() => {
      UIManager[_0x40b4("0xca")][_0x40b4("0x114")](_0x40b4("0x127"));
      UIManager[_0x40b4("0xca")]["hideUI"](_0x40b4("0x129"));
      this[_0x40b4("0x12b")]++;
      PlayerHurtbox[_0x40b4("0xca")]["grantInvincibility"](0x2);
      this["started"] = !![];
    });
  },
  canContinue: function () {
    return this[_0x40b4("0x12b")] < this["maxContinuesInARow"];
  },
  async startGamePlay(_0x4d47e8 = 0x1, _0x4fffaf = ![]) {
    await UIManager[_0x40b4("0xca")][_0x40b4("0x114")](_0x40b4("0x134"));
    UIManager[_0x40b4("0xca")][_0x40b4("0x135")]("Main\x20Menu");
    await Wrapper["instance"][_0x40b4("0x133")](_0x4d47e8, _0x4fffaf);
    GameManager[_0x40b4("0xca")][_0x40b4("0x116")](_0x4d47e8);
    UIManager[_0x40b4("0xca")]["hideUI"]("Flash");
    UIManager[_0x40b4("0xca")]["showUI"](_0x40b4("0x127"));
  },
});
GameManager["CAMERA_COLOR"] = new pc[_0x40b4("0x136")]();
var TweenAlpha = pc["createScript"](_0x40b4("0x137"));
TweenAlpha[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x138"), {
  type: _0x40b4("0x34"),
  default: 0x1,
  title: _0x40b4("0x139"),
});
TweenAlpha[_0x40b4("0x2d")][_0x40b4("0x2e")]("initTo", {
  type: _0x40b4("0x34"),
  default: 0x0,
  title: "To",
});
TweenAlpha[_0x40b4("0x2d")]["add"](_0x40b4("0x13a"), {
  type: _0x40b4("0x34"),
  enum: [{ Once: 0x0 }, { Loop: 0x1 }, { PingPong: 0x2 }],
  title: "Play\x20Style",
});
TweenAlpha["attributes"][_0x40b4("0x2e")]("duration", {
  type: _0x40b4("0x34"),
  default: 0x1,
  title: _0x40b4("0x13b"),
});
TweenAlpha[_0x40b4("0x2d")]["add"](_0x40b4("0x13c"), {
  type: _0x40b4("0x13c"),
  title: _0x40b4("0x13d"),
});
TweenAlpha[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x13e"), {
  type: _0x40b4("0x9f"),
  default: !![],
  title: "Ignore\x20Time\x20Scale",
});
TweenAlpha[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x13f"), {
  type: _0x40b4("0x34"),
  default: 0x0,
  title: _0x40b4("0x140"),
});
TweenAlpha[_0x40b4("0x2d")][_0x40b4("0x2e")]("debug", {
  type: "boolean",
  default: ![],
  title: _0x40b4("0x141"),
});
TweenAlpha[_0x40b4("0x2d")][_0x40b4("0x2e")]("startOnEnable", {
  type: "boolean",
  default: !![],
  title: _0x40b4("0x142"),
});
TweenAlpha[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x143"), {
  type: _0x40b4("0x9f"),
  default: !![],
  title: _0x40b4("0x144"),
});
pc[_0x40b4("0x1")](TweenAlpha["prototype"], {
  initialize: function () {
    this[_0x40b4("0x145")] = 0x1;
    this[_0x40b4("0x146")] = this[_0x40b4("0x143")]
      ? 0x0
      : this["duration"] + this[_0x40b4("0x13f")];
    this[_0x40b4("0x147")] = this[_0x40b4("0xd6")][_0x40b4("0x146")] || 0x0;
    this[_0x40b4("0x148")] = this[_0x40b4("0x138")];
    this[_0x40b4("0x149")] = this[_0x40b4("0x14a")];
    this[_0x40b4("0x14b")] = this[_0x40b4("0x14b")] || [];
  },
  postInitialize: function () {
    this[_0x40b4("0x14c")](this[_0x40b4("0xb8")]);
    if (this[_0x40b4("0x143")]) {
      this["startTween"]();
    }
    this["on"](_0x40b4("0x14d"), function (_0x56f3d5) {
      if (_0x56f3d5 && this[_0x40b4("0x14e")]) {
        this["startTween"]();
      }
    });
  },
  update: function (_0x1c5cf0) {
    if (this[_0x40b4("0x14f")]()) {
      this[_0x40b4("0x150")](_0x1c5cf0);
      if (this["_time"] > this[_0x40b4("0x13f")]) {
        var _0x4aba8c =
          this[_0x40b4("0x148")] -
          this[_0x40b4("0x13c")][_0x40b4("0x151")](
            (this[_0x40b4("0x146")] - this["startDelay"]) /
              this[_0x40b4("0x13b")]
          ) *
            (this["_from"] - this["_to"]);
        this[_0x40b4("0x145")] = _0x4aba8c;
        this[_0x40b4("0x152")](_0x4aba8c);
        if (this[_0x40b4("0x38")]) {
          window[_0x40b4("0x3")][_0x40b4("0x56")](
            this[_0x40b4("0xb8")][_0x40b4("0x153")],
            this[_0x40b4("0x146")],
            _0x4aba8c
          );
        }
      }
      this[_0x40b4("0x147")] = this["app"]["_time"];
    }
    if (
      this[_0x40b4("0x146")] >=
      this[_0x40b4("0x13b")] + this[_0x40b4("0x13f")]
    ) {
      switch (this[_0x40b4("0x13a")]) {
        case 0x0:
          this[_0x40b4("0x10e")]("finish");
          break;
        case 0x1:
          this[_0x40b4("0x146")] = 0x0;
          break;
        case 0x2:
          this[_0x40b4("0x146")] = 0x0;
          var _0x16bcec = this["_from"];
          this["_from"] = this[_0x40b4("0x149")];
          this[_0x40b4("0x149")] = _0x16bcec;
          break;
      }
    }
  },
  updateTime: function (_0x4957be) {
    this[_0x40b4("0x146")] += this[_0x40b4("0x13e")]
      ? (this[_0x40b4("0xd6")]["_time"] - this[_0x40b4("0x147")]) / 0x3e8
      : _0x4957be;
  },
  _getAllElementComponents: function (_0x1bbf98) {
    var _0x28193a = _0x1bbf98[_0x40b4("0x154")];
    if (
      _0x28193a !== undefined &&
      _0x28193a[_0x40b4("0x155")] !== null &&
      _0x28193a["opacity"] !== undefined
    ) {
      this[_0x40b4("0x14b")][_0x40b4("0x18")](_0x1bbf98[_0x40b4("0x154")]);
    }
    var _0x9b617b = this;
    _0x1bbf98["children"]["forEach"](function (_0x425daf) {
      _0x9b617b["_getAllElementComponents"](_0x425daf);
    });
  },
  startTween: function (
    _0x200742 = this[_0x40b4("0x138")],
    _0xe66584 = this[_0x40b4("0x14a")]
  ) {
    this[_0x40b4("0x138")] = _0x200742;
    this[_0x40b4("0x14a")] = _0xe66584;
    this["_time"] = 0x0;
    this[_0x40b4("0x148")] = this[_0x40b4("0x138")];
    this[_0x40b4("0x149")] = this["initTo"];
    this["setAllElementOpacity"](this[_0x40b4("0x148")]);
    this["_oldTime"] = this[_0x40b4("0xd6")][_0x40b4("0x146")];
    return this;
  },
  setAllElementOpacity: function (_0x3641f8) {
    if (!this[_0x40b4("0x14b")]) {
      this[_0x40b4("0x14b")] = [];
      this["_getAllElementComponents"](this["entity"]);
    }
    this[_0x40b4("0x14b")][_0x40b4("0x156")](function (_0x4022f7) {
      if (!_0x4022f7[_0x40b4("0x157")]) {
        _0x4022f7[_0x40b4("0x155")] = _0x3641f8;
      }
      if (_0x4022f7["type"] === pc[_0x40b4("0x158")]) {
        if (
          !_0x4022f7[_0x40b4("0x159")][_0x40b4("0x15a")](
            pc[_0x40b4("0x15b")][_0x40b4("0x15c")]
          )
        ) {
          TweenAlpha["COLOR"][_0x40b4("0x15d")](
            _0x4022f7[_0x40b4("0x15e")]["r"],
            _0x4022f7[_0x40b4("0x15e")]["g"],
            _0x4022f7[_0x40b4("0x15e")]["b"],
            _0x3641f8
          );
          _0x4022f7[_0x40b4("0x15e")] = TweenAlpha[_0x40b4("0x15f")];
        }
        if (_0x4022f7[_0x40b4("0x160")] > 0x0) {
          TweenAlpha[_0x40b4("0x161")][_0x40b4("0x15d")](
            _0x4022f7[_0x40b4("0x162")]["r"],
            _0x4022f7[_0x40b4("0x162")]["g"],
            _0x4022f7["outlineColor"]["b"],
            _0x3641f8
          );
          _0x4022f7[_0x40b4("0x162")] = TweenAlpha[_0x40b4("0x161")];
        }
      }
    });
  },
  getCurrentOpacity: function () {
    return this[_0x40b4("0x145")];
  },
  isActive: function () {
    return (
      this[_0x40b4("0x146")] >= 0x0 &&
      this["_time"] <= this["duration"] + this["startDelay"]
    );
  },
});
TweenAlpha[_0x40b4("0x15f")] = new pc["Color"]();
TweenAlpha[_0x40b4("0x161")] = new pc[_0x40b4("0x136")]();
var TweenPosition = pc["createScript"](_0x40b4("0x163"));
TweenPosition[_0x40b4("0x2d")][_0x40b4("0x2e")]("initFrom", {
  type: _0x40b4("0x164"),
  default: [0x0, 0x0, 0x0],
  title: "From",
});
TweenPosition[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x14a"), {
  type: _0x40b4("0x164"),
  default: [0x0, 0x0, 0x0],
  title: "To",
});
TweenPosition[_0x40b4("0x2d")][_0x40b4("0x2e")]("playStyle", {
  type: "number",
  enum: [{ Once: 0x0 }, { Loop: 0x1 }, { PingPong: 0x2 }],
  title: "Play\x20Style",
});
TweenPosition[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x13b"), {
  type: _0x40b4("0x34"),
  default: 0x1,
  title: _0x40b4("0x13b"),
});
TweenPosition[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x13c"), {
  type: _0x40b4("0x13c"),
  title: _0x40b4("0x13d"),
});
TweenPosition[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x13e"), {
  type: _0x40b4("0x9f"),
  default: !![],
  title: _0x40b4("0x165"),
});
TweenPosition[_0x40b4("0x2d")]["add"](_0x40b4("0x13f"), {
  type: _0x40b4("0x34"),
  default: 0x0,
  title: _0x40b4("0x140"),
});
TweenPosition[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x38"), {
  type: _0x40b4("0x9f"),
  default: ![],
  title: _0x40b4("0x141"),
});
TweenPosition["attributes"][_0x40b4("0x2e")]("startAtEnable", {
  type: _0x40b4("0x9f"),
  default: !![],
  title: _0x40b4("0x144"),
});
TweenPosition["attributes"][_0x40b4("0x2e")]("startOnEnable", {
  type: _0x40b4("0x9f"),
  default: !![],
  title: _0x40b4("0x142"),
});
pc[_0x40b4("0x1")](TweenPosition[_0x40b4("0x2")], {
  initialize: function () {
    this[_0x40b4("0x146")] = this["startAtEnable"]
      ? 0x0
      : this[_0x40b4("0x13b")] + this[_0x40b4("0x13f")] + 0x1;
    this[_0x40b4("0x147")] = this["app"]["_time"] || 0x0;
    this[_0x40b4("0x148")] = this[_0x40b4("0x138")][_0x40b4("0x166")]();
    this["_to"] = this[_0x40b4("0x14a")][_0x40b4("0x166")]();
    this[_0x40b4("0x167")] = this["entity"]
      [_0x40b4("0x168")]()
      [_0x40b4("0x166")]();
    this[_0x40b4("0x169")] = new pc[_0x40b4("0x16a")](0x0, 0x0, 0x0);
  },
  postInitialize: function () {
    this["on"](
      "state",
      function (_0x1a1be9) {
        if (_0x1a1be9 && this["startOnEnable"]) {
          this[_0x40b4("0x16b")]();
        }
      },
      this
    );
    if (this[_0x40b4("0x16c")]) {
      this[_0x40b4("0x16b")]();
    }
  },
  update: function (_0x32575c) {
    if (
      this["_time"] >= 0x0 &&
      this[_0x40b4("0x146")] <= this[_0x40b4("0x13b")] + this[_0x40b4("0x13f")]
    ) {
      this[_0x40b4("0x150")](_0x32575c);
      if (this[_0x40b4("0x146")] > this["startDelay"]) {
        this[_0x40b4("0x169")]
          [_0x40b4("0x15d")](
            this[_0x40b4("0x148")]["x"],
            this[_0x40b4("0x148")]["y"],
            this[_0x40b4("0x148")]["z"]
          )
          [_0x40b4("0x16d")](this["_to"])
          [_0x40b4("0x16e")](
            this[_0x40b4("0x13c")]["value"](
              (this["_time"] - this[_0x40b4("0x13f")]) / this[_0x40b4("0x13b")]
            )
          )
          [_0x40b4("0x16f")](this[_0x40b4("0x148")], this[_0x40b4("0x169")])
          [_0x40b4("0x2e")](this["_initPosition"]);
        this["entity"][_0x40b4("0x170")](this[_0x40b4("0x169")]);
      }
      this["_oldTime"] = this[_0x40b4("0xd6")][_0x40b4("0x146")];
    }
    if (
      this["_time"] >= this[_0x40b4("0x13b")] + this["startDelay"] ||
      this["_time"] <= 0x0
    ) {
      switch (this["playStyle"]) {
        case 0x0:
          break;
        case 0x1:
          this[_0x40b4("0x146")] = 0x0;
          break;
        case 0x2:
          this[_0x40b4("0x146")] = 0x0;
          var _0x2771da = this["_from"];
          this[_0x40b4("0x148")] = this["_to"];
          this[_0x40b4("0x149")] = _0x2771da;
          break;
      }
    }
  },
  updateTime: function (_0x5e72b8) {
    this[_0x40b4("0x146")] += this[_0x40b4("0x13e")]
      ? (this[_0x40b4("0xd6")][_0x40b4("0x146")] - this[_0x40b4("0x147")]) /
        0x3e8
      : _0x5e72b8;
  },
  moveTo: function (_0x29d42d, _0x363e78) {
    this[_0x40b4("0x146")] = 0x0;
    this[_0x40b4("0x148")]["set"](0x0, 0x0, 0x0);
    this[_0x40b4("0x149")][_0x40b4("0x15d")](0x0, 0x0, 0x0);
    this[_0x40b4("0x149")]["sub"](_0x29d42d);
    this[_0x40b4("0x167")][_0x40b4("0x15d")](
      _0x29d42d["x"],
      _0x29d42d["y"],
      _0x29d42d["z"]
    );
    this[_0x40b4("0x147")] = this[_0x40b4("0xd6")][_0x40b4("0x146")];
  },
  startTween: function () {
    try {
      this[_0x40b4("0x146")] = 0x0;
      this[_0x40b4("0x148")][_0x40b4("0x15d")](
        this[_0x40b4("0x138")]["x"],
        this[_0x40b4("0x138")]["y"],
        this["initFrom"]["z"]
      );
      this["_to"]["set"](
        this["initTo"]["x"],
        this[_0x40b4("0x14a")]["y"],
        this["initTo"]["z"]
      );
      this[_0x40b4("0xb8")][_0x40b4("0x170")](
        this["_from"]["x"] + this[_0x40b4("0x167")]["x"],
        this[_0x40b4("0x148")]["y"] + this[_0x40b4("0x167")]["y"],
        this[_0x40b4("0x148")]["z"] + this[_0x40b4("0x167")]["z"]
      );
      this[_0x40b4("0x147")] = this["app"][_0x40b4("0x146")];
    } catch (_0x259e37) {
      window["famobi"][_0x40b4("0x56")](_0x259e37);
      setTimeout(this["startTween"]);
    }
  },
});
var TweenRotation = pc[_0x40b4("0x2a")](_0x40b4("0x171"));
TweenRotation[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x138"), {
  type: _0x40b4("0x164"),
  default: [0x0, 0x0, 0x0],
  title: _0x40b4("0x139"),
});
TweenRotation["attributes"][_0x40b4("0x2e")](_0x40b4("0x14a"), {
  type: "vec3",
  default: [0x0, 0x0, 0x0],
  title: "To",
});
TweenRotation[_0x40b4("0x2d")][_0x40b4("0x2e")]("playStyle", {
  type: _0x40b4("0x34"),
  enum: [{ Once: 0x0 }, { Loop: 0x1 }, { PingPong: 0x2 }],
  title: "Play\x20Style",
});
TweenRotation[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x13b"), {
  type: _0x40b4("0x34"),
  default: 0x1,
  title: _0x40b4("0x13b"),
});
TweenRotation["attributes"]["add"](_0x40b4("0x13c"), {
  type: "curve",
  title: "Animation\x20Curve",
});
TweenRotation["attributes"][_0x40b4("0x2e")]("ignoreTimeScale", {
  type: _0x40b4("0x9f"),
  default: !![],
  title: _0x40b4("0x165"),
});
TweenRotation[_0x40b4("0x2d")]["add"]("startDelay", {
  type: _0x40b4("0x34"),
  default: 0x0,
  title: "Start\x20Delay",
});
TweenRotation["attributes"][_0x40b4("0x2e")]("debug", {
  type: "boolean",
  default: ![],
  title: _0x40b4("0x141"),
});
TweenRotation[_0x40b4("0x2d")]["add"](_0x40b4("0x14e"), {
  type: _0x40b4("0x9f"),
  default: !![],
  title: _0x40b4("0x142"),
});
TweenRotation[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x172"), {
  type: "boolean",
  default: !![],
  title: _0x40b4("0x144"),
});
TweenRotation[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x173"), {
  type: "number",
  default: 0x1,
  title: _0x40b4("0x173"),
});
pc[_0x40b4("0x1")](TweenRotation[_0x40b4("0x2")], {
  initialize: function () {
    this["pause"] = ![];
    this["on"](
      _0x40b4("0x174"),
      function () {
        this["stopTween"]();
        this["startTween"]();
      },
      this
    );
    this["on"](
      _0x40b4("0x175"),
      function () {
        this[_0x40b4("0x176")]();
        this["startTween"]();
      },
      this
    );
    this["_time"] = this["startOnInit"]
      ? 0x0
      : this[_0x40b4("0x13b")] + this[_0x40b4("0x13f")] + 0x1;
    this["_oldTime"] = this[_0x40b4("0xd6")]["_time"] || 0x0;
    this[_0x40b4("0x148")] = this[_0x40b4("0x138")]["clone"]();
    this[_0x40b4("0x149")] = this[_0x40b4("0x14a")]["clone"]();
  },
  postInitialize: function () {
    this[_0x40b4("0x177")] = this[_0x40b4("0xb8")][_0x40b4("0x178")]();
    this[_0x40b4("0x179")] = new pc[_0x40b4("0x16a")](0x0, 0x0, 0x0);
    this["on"](_0x40b4("0x14d"), function (_0x338bf9) {
      if (_0x338bf9 && this[_0x40b4("0x14e")]) {
        this[_0x40b4("0x16b")]();
      }
    });
    if (this[_0x40b4("0x172")]) {
      this["startTween"]();
    }
  },
  update: function (_0x72dec0) {
    if (
      this[_0x40b4("0x146")] >= 0x0 &&
      this[_0x40b4("0x146")] <= this[_0x40b4("0x13b")] + this[_0x40b4("0x13f")]
    ) {
      this["_updateTime"](_0x72dec0);
      if (this[_0x40b4("0x146")] > this[_0x40b4("0x13f")]) {
        this["_newRotation"]
          [_0x40b4("0x15d")](
            this[_0x40b4("0x148")]["x"],
            this[_0x40b4("0x148")]["y"],
            this[_0x40b4("0x148")]["z"]
          )
          [_0x40b4("0x16d")](this["_to"])
          [_0x40b4("0x16e")](
            this["curve"]["value"](
              (this[_0x40b4("0x146")] - this["startDelay"]) /
                this[_0x40b4("0x13b")]
            )
          )
          [_0x40b4("0x16f")](this["_from"], this[_0x40b4("0x179")])
          ["add"](this[_0x40b4("0x177")]);
        this[_0x40b4("0xb8")][_0x40b4("0x17a")](
          this[_0x40b4("0x179")]["x"],
          this[_0x40b4("0x179")]["y"],
          this[_0x40b4("0x179")]["z"]
        );
      }
      this["_oldTime"] = this[_0x40b4("0xd6")][_0x40b4("0x146")];
    }
    if (
      this[_0x40b4("0x146")] >=
        this[_0x40b4("0x13b")] + this[_0x40b4("0x13f")] ||
      this[_0x40b4("0x146")] <= 0x0
    ) {
      switch (this[_0x40b4("0x13a")]) {
        case 0x0:
          break;
        case 0x1:
          this[_0x40b4("0x146")] = 0x0;
          break;
        case 0x2:
          this[_0x40b4("0x146")] = 0x0;
          var _0xfaebce = this[_0x40b4("0x148")];
          this[_0x40b4("0x148")] = this[_0x40b4("0x149")];
          this[_0x40b4("0x149")] = _0xfaebce;
          break;
      }
    }
  },
  _updateTime: function (_0x2106d9) {
    this[_0x40b4("0x146")] += this[_0x40b4("0x13e")]
      ? (this["app"]["_time"] - this[_0x40b4("0x147")]) / 0x3e8
      : _0x2106d9 * this[_0x40b4("0x173")];
  },
  setInitRotation: function (_0x2e9044, _0x787982, _0x3482e4) {
    this[_0x40b4("0xb8")][_0x40b4("0x17a")](_0x2e9044, _0x787982, _0x3482e4);
    this[_0x40b4("0x177")]["set"](
      this[_0x40b4("0xb8")]["getLocalEulerAngles"]()["x"],
      this[_0x40b4("0xb8")][_0x40b4("0x178")]()["y"],
      this[_0x40b4("0xb8")][_0x40b4("0x178")]()["z"]
    );
  },
  startTween: function () {
    this[_0x40b4("0x146")] = 0x0;
    this["_from"][_0x40b4("0x15d")](
      this[_0x40b4("0x138")]["x"],
      this[_0x40b4("0x138")]["y"],
      this[_0x40b4("0x138")]["z"]
    );
    this[_0x40b4("0x149")][_0x40b4("0x15d")](
      this[_0x40b4("0x14a")]["x"],
      this[_0x40b4("0x14a")]["y"],
      this[_0x40b4("0x14a")]["z"]
    );
    this[_0x40b4("0xb8")]["setLocalEulerAngles"](
      this[_0x40b4("0x148")]["x"],
      this[_0x40b4("0x148")]["y"],
      this["_from"]["z"]
    );
    this[_0x40b4("0x147")] = this[_0x40b4("0xd6")][_0x40b4("0x146")];
  },
  stopTween: function () {
    this["entity"]["setLocalEulerAngles"](
      this[_0x40b4("0x138")]["x"],
      this[_0x40b4("0x138")]["y"],
      this["initFrom"]["z"]
    );
    this[_0x40b4("0x146")] =
      this[_0x40b4("0x13b")] + this[_0x40b4("0x13f")] + 0x1;
  },
});
var TweenScale = pc[_0x40b4("0x2a")](_0x40b4("0x17b"));
TweenScale[_0x40b4("0x2d")]["add"](_0x40b4("0x138"), {
  type: "vec3",
  default: [0x0, 0x0, 0x0],
  title: _0x40b4("0x139"),
});
TweenScale[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x14a"), {
  type: _0x40b4("0x164"),
  default: [0x0, 0x0, 0x0],
  title: "To",
});
TweenScale[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x13a"), {
  type: "number",
  enum: [{ Once: 0x0 }, { Loop: 0x1 }, { PingPong: 0x2 }],
  title: _0x40b4("0x17c"),
});
TweenScale["attributes"][_0x40b4("0x2e")](_0x40b4("0x13b"), {
  type: _0x40b4("0x34"),
  default: 0x1,
  title: _0x40b4("0x13b"),
});
TweenScale[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x13c"), {
  type: "curve",
  title: _0x40b4("0x13d"),
});
TweenScale[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x13e"), {
  type: _0x40b4("0x9f"),
  default: !![],
  title: _0x40b4("0x165"),
});
TweenScale[_0x40b4("0x2d")]["add"](_0x40b4("0x13f"), {
  type: _0x40b4("0x34"),
  default: 0x0,
  title: _0x40b4("0x140"),
});
TweenScale[_0x40b4("0x2d")]["add"]("debug", {
  type: _0x40b4("0x9f"),
  default: ![],
  title: _0x40b4("0x141"),
});
TweenScale[_0x40b4("0x2d")]["add"](_0x40b4("0x14e"), {
  type: _0x40b4("0x9f"),
  default: !![],
  title: "Start\x20on\x20Enable",
});
TweenScale["attributes"][_0x40b4("0x2e")](_0x40b4("0x172"), {
  type: _0x40b4("0x9f"),
  default: !![],
  title: "Start\x20on\x20Initialize",
});
pc["extend"](TweenScale[_0x40b4("0x2")], {
  initialize: function () {
    this[_0x40b4("0x146")] = this[_0x40b4("0x16c")]
      ? 0x0
      : this[_0x40b4("0x13b")] + this[_0x40b4("0x13f")] + 0x1;
    this[_0x40b4("0x147")] = this[_0x40b4("0xd6")]["_time"] || 0x0;
    this[_0x40b4("0x17d")] = ![];
    this["_from"] = this[_0x40b4("0x138")];
    this["_to"] = this[_0x40b4("0x14a")];
    this[_0x40b4("0x17e")] = new pc[_0x40b4("0x16a")](0x0, 0x0, 0x0);
    this[_0x40b4("0x17f")] = new pc[_0x40b4("0x16a")](0x0, 0x0, 0x0);
    this[_0x40b4("0x180")] = this[_0x40b4("0xb8")]
      [_0x40b4("0x181")]()
      [_0x40b4("0x166")]();
  },
  postInitialize: function () {
    this[_0x40b4("0x180")] = this["entity"]
      [_0x40b4("0x181")]()
      [_0x40b4("0x166")]();
    this["on"](_0x40b4("0x14d"), function (_0x300ccb) {
      if (this[_0x40b4("0x38")]) {
        window[_0x40b4("0x3")][_0x40b4("0x56")](
          this[_0x40b4("0xb8")][_0x40b4("0x153")],
          _0x300ccb,
          this["startOnEnable"]
        );
      }
      if (_0x300ccb && this[_0x40b4("0x14e")]) {
        this["startTween"]();
      }
    });
    if (this[_0x40b4("0x172")]) {
      this["startTween"]();
    }
  },
  update: function (_0x37b860) {
    if (!this["_active"]) {
      return;
    }
    if (
      this["_time"] >= 0x0 &&
      this[_0x40b4("0x146")] <= this["duration"] + this["startDelay"]
    ) {
      this[_0x40b4("0x182")](_0x37b860);
      if (this[_0x40b4("0x146")] > this[_0x40b4("0x13f")]) {
        this["_newScale"]
          [_0x40b4("0x15d")](
            this["_from"]["x"],
            this[_0x40b4("0x148")]["y"],
            this["_from"]["z"]
          )
          [_0x40b4("0x16d")](this[_0x40b4("0x149")])
          ["scale"](
            this[_0x40b4("0x13c")][_0x40b4("0x151")](
              (this["_time"] - this[_0x40b4("0x13f")]) / this[_0x40b4("0x13b")]
            )
          )
          ["sub2"](this["_from"], this[_0x40b4("0x17f")])
          [_0x40b4("0x183")](this[_0x40b4("0x180")]);
        this[_0x40b4("0xb8")][_0x40b4("0x184")](
          this["_newScale"]["x"],
          this[_0x40b4("0x17f")]["y"],
          this[_0x40b4("0x17f")]["z"]
        );
      }
      this[_0x40b4("0x147")] = this[_0x40b4("0xd6")][_0x40b4("0x146")];
    }
    if (
      this[_0x40b4("0x146")] >=
        this[_0x40b4("0x13b")] + this[_0x40b4("0x13f")] ||
      this["_time"] <= 0x0
    ) {
      switch (this["playStyle"]) {
        case 0x0:
          this[_0x40b4("0x10e")](_0x40b4("0x185"));
          break;
        case 0x1:
          this["_time"] = 0x0;
          break;
        case 0x2:
          this[_0x40b4("0x146")] = 0x0;
          this["_temp"][_0x40b4("0x15d")](
            this["_from"]["x"],
            this[_0x40b4("0x148")]["y"],
            this["_from"]["z"]
          );
          this["_from"][_0x40b4("0x15d")](
            this[_0x40b4("0x149")]["x"],
            this[_0x40b4("0x149")]["y"],
            this["_to"]["z"]
          );
          this[_0x40b4("0x149")][_0x40b4("0x15d")](
            this[_0x40b4("0x17e")]["x"],
            this[_0x40b4("0x17e")]["y"],
            this[_0x40b4("0x17e")]["z"]
          );
          break;
      }
    }
  },
  _updateTime: function (_0x1ce2ab) {
    this[_0x40b4("0x146")] += this["ignoreTimeScale"]
      ? (this[_0x40b4("0xd6")]["_time"] - this[_0x40b4("0x147")]) / 0x3e8
      : _0x1ce2ab;
  },
  startTween: function () {
    if (!this["_from"]) return;
    this[_0x40b4("0x17d")] = !![];
    this[_0x40b4("0x146")] = 0x0;
    this[_0x40b4("0x148")]["set"](
      this[_0x40b4("0x138")]["x"],
      this[_0x40b4("0x138")]["y"],
      this[_0x40b4("0x138")]["z"]
    );
    this["_to"][_0x40b4("0x15d")](
      this[_0x40b4("0x14a")]["x"],
      this[_0x40b4("0x14a")]["y"],
      this[_0x40b4("0x14a")]["z"]
    );
    this["entity"]["setLocalScale"](
      this[_0x40b4("0x148")]["x"] * this[_0x40b4("0x180")]["x"],
      this["_from"]["y"] * this[_0x40b4("0x180")]["y"],
      this["_from"]["z"] * this[_0x40b4("0x180")]["z"]
    );
    this[_0x40b4("0x147")] = this[_0x40b4("0xd6")][_0x40b4("0x146")];
  },
  stopTween: function () {
    this[_0x40b4("0x17d")] = ![];
  },
  reset: function () {
    this[_0x40b4("0xb8")]["setLocalScale"](this[_0x40b4("0x138")]);
  },
  isTweening: function () {
    return (
      this[_0x40b4("0x146")] >= 0x0 &&
      this[_0x40b4("0x146")] < this["duration"] + this[_0x40b4("0x13f")]
    );
  },
});
var VibrationManager = pc[_0x40b4("0x2a")](_0x40b4("0x186"));
pc[_0x40b4("0x1")](VibrationManager[_0x40b4("0x2")], {
  initialize: function () {
    if (Singleton[_0x40b4("0xca")][_0x40b4("0x10d")](this)) {
      VibrationManager["instance"] = this;
    }
    navigator[_0x40b4("0x187")] =
      navigator["vibrate"] ||
      navigator[_0x40b4("0x188")] ||
      navigator[_0x40b4("0x189")] ||
      navigator["msVibrate"];
    this["_isSupported"] = !!navigator["vibrate"];
    this[_0x40b4("0x18a")] = [0x64, 0xa, 0x64];
  },
  postInitialize: function () {
    this[_0x40b4("0x18b")] = StorageManager[_0x40b4("0xca")]["get"]("vibrate");
    if (!navigator[_0x40b4("0x187")]) {
      this[_0x40b4("0xd4")] = ![];
      return;
    }
    this[_0x40b4("0xd6")]["on"](_0x40b4("0x187"), this[_0x40b4("0x18c")], this);
  },
  _vibrate: function (_0x4ea127) {
    if (!navigator[_0x40b4("0x187")]) {
      console[_0x40b4("0x7")](_0x40b4("0x18d"));
    }
    if (!this[_0x40b4("0x18b")]) {
      return;
    }
    navigator[_0x40b4("0x187")](_0x4ea127 || this[_0x40b4("0x18a")]);
  },
  _save: function () {
    StorageManager[_0x40b4("0xca")][_0x40b4("0x15d")](
      _0x40b4("0x187"),
      this["_vibration"]
    );
  },
  get: function () {
    return this[_0x40b4("0x18b")];
  },
  set: function (_0x3f5710) {
    this[_0x40b4("0x18b")] = _0x3f5710;
    this[_0x40b4("0x18e")]();
  },
  toggle: function () {
    this[_0x40b4("0x18b")] = !this["_vibration"];
    this[_0x40b4("0x18f")]();
    return this[_0x40b4("0x18b")];
  },
  isVibrationSupported: function () {
    return this[_0x40b4("0x190")] && pc[_0x40b4("0x191")]["mobile"];
  },
});
var LazyLoader = pc[_0x40b4("0x2a")](_0x40b4("0x192"));
pc["extend"](LazyLoader[_0x40b4("0x2")], {
  initialize: function () {
    if (Singleton[_0x40b4("0xca")][_0x40b4("0x10d")](this)) {
      LazyLoader[_0x40b4("0xca")] = this;
    }
    var _0x2c128e = this[_0x40b4("0xd6")]["loader"][_0x40b4("0x193")](
      _0x40b4("0x194")
    );
    _0x2c128e["crossOrigin"] = "anonymous";
  },
  lazyLoad: function (_0x4ee09e, _0x34b5ed, _0x2ddfdd, _0x4a6cb5) {
    if (!_0x4ee09e) {
      if (!_0x4a6cb5) {
        console[_0x40b4("0x7")](_0x40b4("0x195"), _0x34b5ed, _0x2ddfdd);
      } else {
        this["app"][_0x40b4("0x10e")](_0x40b4("0x196"));
      }
      return;
    }
    if (_0x4ee09e[_0x40b4("0x5a")]) {
      if (_0x34b5ed) {
        _0x34b5ed[_0x40b4("0xef")](_0x2ddfdd, _0x4ee09e);
      }
    } else {
      var _0x177835 = this;
      _0x4ee09e["once"](_0x40b4("0x197"), function () {
        if (_0x34b5ed) {
          _0x34b5ed["call"](_0x2ddfdd, _0x4ee09e);
        }
      });
      this[_0x40b4("0xd6")]["assets"][_0x40b4("0x197")](_0x4ee09e);
    }
  },
  lazyLoadParallel: function (_0x20a276, _0x57aa33, _0x4dcdbf) {
    var _0x4c271d = _0x20a276[_0x40b4("0x87")];
    var _0x64f5ed = 0x0;
    var _0x38e1ed = this;
    var _0x5d9701 = function (_0x3fb778) {
      _0x3fb778[_0x40b4("0x100")](_0x40b4("0x198"), _0x55c9fd);
      _0x64f5ed++;
      _0x38e1ed[_0x40b4("0x10e")](_0x40b4("0x199"), _0x64f5ed, _0x4c271d);
      if (_0x4c271d === _0x64f5ed) {
        if (typeof _0x57aa33 === _0x40b4("0x68")) {
          _0x57aa33["call"](_0x4dcdbf);
        }
      }
    };
    var _0x38e1ed = this;
    var _0x55c9fd = function (_0xf29b7d, _0x2a23ae) {
      window[_0x40b4("0x3")]["log"](_0xf29b7d);
      _0x5d9701(_0x2a23ae);
    };
    for (
      var _0x22a3ed = 0x0;
      _0x22a3ed < _0x20a276[_0x40b4("0x87")];
      _0x22a3ed++
    ) {
      var _0x34e99d = _0x20a276[_0x22a3ed];
      if (!(_0x34e99d instanceof pc[_0x40b4("0x19a")])) {
        _0x4c271d--;
        continue;
      }
      _0x34e99d["ready"](_0x5d9701);
      _0x34e99d["on"]("error", _0x55c9fd);
      this[_0x40b4("0xd6")][_0x40b4("0x5d")][_0x40b4("0x197")](_0x34e99d);
    }
  },
  lazyLoadSeries: function (_0x4266ab, _0x59828d, _0x3d67f2) {
    var _0xc1fbd = -0x1;
    var _0x1b8fe1 = this;
    var _0x477b0a = function () {
      _0xc1fbd++;
      var _0x22cb9b = _0x4266ab[_0xc1fbd];
      if (!(_0x22cb9b instanceof pc[_0x40b4("0x19a")])) {
        if (_0x59828d) {
          _0x59828d[_0x40b4("0xef")](_0x3d67f2);
        }
      } else {
        _0x1b8fe1[_0x40b4("0xd6")]["assets"][_0x40b4("0x197")](_0x22cb9b);
        _0x22cb9b["ready"](_0x477b0a);
      }
    };
    _0x477b0a();
  },
});
var UIManager = pc[_0x40b4("0x2a")]("uiManager");
UIManager[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x19b"), {
  type: _0x40b4("0xb8"),
});
pc[_0x40b4("0x1")](UIManager[_0x40b4("0x2")], {
  initialize: function () {
    if (Singleton[_0x40b4("0xca")][_0x40b4("0x10d")](this)) {
      UIManager[_0x40b4("0xca")] = this;
    }
    this[_0x40b4("0x19c")] = [];
    this[_0x40b4("0x19d")] = [];
    this[_0x40b4("0x19e")] = [];
    this[_0x40b4("0x19f")] = [_0x40b4("0x1a0"), "Overlay", _0x40b4("0x1a1")];
    this[_0x40b4("0x1a2")] = {};
    this[_0x40b4("0xd6")]["on"](_0x40b4("0x11c"), this[_0x40b4("0x1a3")], this);
    this["app"]["on"](_0x40b4("0x1a4"), this[_0x40b4("0x1a5")], this);
    this[_0x40b4("0xd6")]["on"](_0x40b4("0x126"), this["_hideUI"], this);
    this[_0x40b4("0xd6")]["on"](_0x40b4("0x1a6"), this[_0x40b4("0x1a7")], this);
    this["initChildrens"]();
  },
  postInitialize: function () {},
  initChildrens: function () {
    for (
      var _0x5c08f9 = 0x0;
      _0x5c08f9 < this[_0x40b4("0xb8")][_0x40b4("0x1a8")][_0x40b4("0x87")];
      _0x5c08f9 += 0x1
    ) {
      var _0x55a8fc = this["entity"][_0x40b4("0x1a8")][_0x5c08f9];
      if (
        _0x55a8fc instanceof pc["Entity"] &&
        _0x55a8fc[_0x40b4("0x1a9")] &&
        _0x55a8fc[_0x40b4("0x1a9")][_0x40b4("0x1aa")](_0x40b4("0x1ab"))
      ) {
        _0x55a8fc["script"][_0x40b4("0x1ab")]["init"]();
      }
    }
  },
  enableChildrens: function () {
    for (
      var _0x25be58 = 0x0;
      _0x25be58 < this["entity"][_0x40b4("0x1a8")][_0x40b4("0x87")];
      _0x25be58 += 0x1
    ) {
      var _0x39414 = this[_0x40b4("0xb8")][_0x40b4("0x1a8")][_0x25be58];
      if (_0x39414 instanceof pc[_0x40b4("0x1ac")]) {
        if (!_0x39414[_0x40b4("0x1a9")]["uiEntity"]) {
        } else if (!_0x39414[_0x40b4("0xd4")]) {
          _0x39414[_0x40b4("0xd4")] = !![];
        }
      }
    }
  },
  getScreen: function (_0x34827f) {
    return this[_0x40b4("0x1a2")][_0x34827f][_0x40b4("0xb8")];
  },
  addUIEntity: function (_0x46eac6, _0x5da6f1, _0x169ba2, _0x21f582) {
    var _0x1beea4 = this[_0x40b4("0x19f")]["indexOf"](_0x5da6f1);
    if (_0x1beea4 === -0x1) {
      console[_0x40b4("0x7")](_0x40b4("0x1ad"), _0x5da6f1);
      return;
    }
    if (typeof _0x46eac6 !== _0x40b4("0x86") || !_0x46eac6) {
      console[_0x40b4("0x7")](_0x40b4("0x1ae"), _0x46eac6);
    }
    if (this[_0x40b4("0x1a2")][_0x46eac6]) {
      console["warn"](_0x40b4("0x1af"), _0x46eac6);
      return;
    }
    this[_0x40b4("0x1a2")][_0x46eac6] = { entity: _0x169ba2, type: _0x5da6f1 };
    if (_0x21f582) {
      this["_showUI"](_0x46eac6, null, !![]);
    } else {
      _0x169ba2[_0x40b4("0xd4")] = ![];
    }
  },
  _removeLoadingOverlay: function () {
    if (this[_0x40b4("0x19b")] instanceof pc[_0x40b4("0x1ac")]) {
      delete this["_uis"][
        this[_0x40b4("0x19b")]["script"]["uiEntity"][_0x40b4("0x153")]
      ];
      this[_0x40b4("0x19b")][_0x40b4("0x1b0")]();
    }
  },
  showUI: function (_0x47c1aa, _0x5aad9c) {
    return this["_showUI"](_0x47c1aa, _0x5aad9c);
  },
  _showUI: function (_0x2c152b, _0x268042, _0x110692) {
    var _0x542be5 = this[_0x40b4("0x1b1")](_0x2c152b);
    if (!_0x542be5) {
      console["warn"](_0x40b4("0x1b2"), _0x2c152b);
      return;
    }
    if (
      _0x542be5[_0x40b4("0xd4")] ||
      (_0x542be5["script"]["uiEntity"][_0x40b4("0x1b3")]() && !_0x110692)
    ) {
      console["warn"](_0x40b4("0x1b4"), _0x2c152b);
      return;
    }
    var _0x2e3105 =
      _0x542be5[_0x40b4("0x1a9")]["uiEntity"][_0x40b4("0x1b5")](_0x268042);
    if (!_0x110692) {
      if (_0x2e3105 instanceof Promise) {
        _0x2e3105["then"](
          function () {
            this[_0x40b4("0x1b6")](_0x2c152b, _0x268042);
          }[_0x40b4("0xd")](this)
        );
      } else {
        this[_0x40b4("0x1b6")](_0x2c152b, _0x268042);
      }
    }
    this[_0x40b4("0x1b7")](
      _0x542be5,
      _0x542be5[_0x40b4("0x1a9")][_0x40b4("0x1ab")][_0x40b4("0x1b8")],
      _0x110692
    );
    this[_0x40b4("0xd6")]["fire"](_0x40b4("0x1b9"), _0x2c152b);
    return _0x2e3105;
  },
  _showUIFinish: function (_0x445365, _0x59b7d6) {
    var _0x351176 = this[_0x40b4("0x1b1")](_0x445365);
    if (!_0x351176) {
      console[_0x40b4("0x7")](_0x40b4("0x1b2"), _0x445365);
      return;
    }
    if (!_0x351176["script"]) return;
    _0x351176[_0x40b4("0x1a9")][_0x40b4("0x1ab")][_0x40b4("0x1ba")](_0x59b7d6);
  },
  hideUI: function (_0xce4792, _0x4dc9a) {
    return this[_0x40b4("0x1bb")](_0xce4792, _0x4dc9a);
  },
  _hideUI: function (_0x3d8714, _0x5cf08c, _0x3879dd) {
    var _0x2c241f = this[_0x40b4("0x1b1")](_0x3d8714);
    if (!_0x2c241f) {
      console[_0x40b4("0x7")](_0x40b4("0x1b2"), _0x3d8714);
      return;
    }
    if (
      !_0x2c241f[_0x40b4("0xd4")] ||
      (_0x2c241f[_0x40b4("0x1a9")][_0x40b4("0x1ab")][_0x40b4("0x1b3")]() &&
        !_0x3879dd)
    ) {
      return;
    }
    if (!_0x2c241f[_0x40b4("0x1a9")]) return;
    this[_0x40b4("0x1bc")](
      _0x2c241f,
      _0x2c241f["script"]["uiEntity"]["type"],
      _0x3879dd
    );
    if (_0x3879dd) {
      _0x2c241f[_0x40b4("0x1a9")][_0x40b4("0xb8")][_0x40b4("0xd4")] = ![];
    } else {
      var _0x5a172d =
        _0x2c241f["script"][_0x40b4("0x1ab")][_0x40b4("0x1bd")](_0x5cf08c);
      if (_0x5a172d instanceof Promise) {
        _0x5a172d[_0x40b4("0xae")](
          function () {
            this["_hideUIFinish"](_0x3d8714, _0x5cf08c);
          }[_0x40b4("0xd")](this)
        );
        return _0x5a172d;
      } else {
        this["_hideUIFinish"](_0x3d8714, _0x5cf08c);
      }
    }
  },
  _hideUIFinish: function (_0x186382, _0x417cf8) {
    var _0x19d642 = this[_0x40b4("0x1b1")](_0x186382);
    if (!_0x19d642) {
      console[_0x40b4("0x7")](_0x40b4("0x1b2"), _0x186382);
      return;
    }
    if (!_0x19d642[_0x40b4("0x1a9")]) return;
    _0x19d642[_0x40b4("0x1a9")][_0x40b4("0x1ab")][_0x40b4("0x1be")](_0x417cf8);
  },
  _addToStack: function (_0xd5bd58, _0x5097cb, _0x51d725) {
    var _0x56ae6a = this[_0x40b4("0x1bf")](_0x5097cb);
    var _0x257159 = _0x56ae6a[_0x40b4("0x1c0")](_0xd5bd58);
    if (_0x257159 !== -0x1) {
      window[_0x40b4("0x3")][_0x40b4("0x56")](_0x40b4("0x1c1"), _0xd5bd58);
      _0x56ae6a[_0x40b4("0x1c2")](_0x257159, 0x1);
    }
    _0x56ae6a["push"](_0xd5bd58);
  },
  _removeFromStack: function (_0x11081a, _0x146629, _0x33d8a4) {
    if (_0x33d8a4) {
      return;
    }
    var _0x1b2c19 = this[_0x40b4("0x1bf")](_0x146629);
    var _0x50d6ea = _0x1b2c19[_0x40b4("0x1c0")](_0x11081a);
    if (_0x50d6ea === -0x1) {
      console[_0x40b4("0x7")](_0x40b4("0x1c3"), _0x1b2c19, _0x11081a);
      return;
    }
    _0x1b2c19[_0x40b4("0x1c2")](_0x50d6ea, 0x1);
  },
  _getStack: function (_0x2f9807) {
    return this[_0x40b4("0x1c4") + _0x2f9807];
  },
  getTopStack: function (_0x47a423) {
    var _0xb30d61 = this[_0x40b4("0x1c4") + _0x47a423][_0x40b4("0x87")];
    return this[_0x40b4("0x1c4") + _0x47a423][_0xb30d61 - 0x1];
  },
  getReferenceResolution: function () {
    return this["entity"][_0x40b4("0x1c5")][_0x40b4("0x1c6")];
  },
  getScale: function () {
    return this[_0x40b4("0xb8")]["screen"]["scale"];
  },
  _hideAll: function (_0x25f037) {
    var _0x5cd708 = [_0x40b4("0x1c7"), _0x40b4("0x1c8")];
    for (
      var _0x7cb4d3 = 0x0;
      _0x7cb4d3 < arguments[_0x40b4("0x87")];
      _0x7cb4d3++
    ) {
      if (arguments[_0x7cb4d3]) {
        _0x5cd708[_0x7cb4d3] = arguments[_0x7cb4d3];
      }
    }
    var _0xc83af6 = Object[_0x40b4("0x95")](this[_0x40b4("0x1a2")]);
    for (
      var _0x42a165 = 0x0;
      _0x42a165 < _0xc83af6[_0x40b4("0x87")];
      _0x42a165 += 0x1
    ) {
      var _0x31924a = ![];
      for (
        var _0xd3ff0b = 0x0;
        _0xd3ff0b < _0x5cd708[_0x40b4("0x87")];
        _0xd3ff0b++
      ) {
        if (_0x5cd708[_0xd3ff0b] === _0xc83af6[_0x42a165]) {
          _0x31924a = !![];
        }
      }
      if (!_0x31924a) {
        this[_0x40b4("0x1bb")](_0xc83af6[_0x42a165], _0x25f037);
      }
    }
  },
  isTopOfStack: function (_0x4a0db2, _0x42e9ac) {
    var _0x3a4c03 = this[_0x40b4("0x1c9")](_0x4a0db2);
    if (_0x3a4c03 === undefined) return ![];
    return _0x3a4c03[_0x40b4("0x153")] === _0x42e9ac;
  },
  isOpen: function (_0x10e33e) {
    var _0x4ad9d8 = this[_0x40b4("0x1a2")][_0x10e33e];
    if (!_0x4ad9d8) {
      console[_0x40b4("0x7")](
        "No\x20UI\x20found\x20with\x20the\x20name",
        _0x10e33e
      );
      return;
    }
    return _0x4ad9d8[_0x40b4("0xb8")][_0x40b4("0xd4")];
  },
});
var UIEntity = pc[_0x40b4("0x2a")]("uiEntity");
UIEntity[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x153"), {
  type: _0x40b4("0x86"),
  default: "",
});
UIEntity[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x1b8"), {
  type: "string",
  enum: [
    { Screen: _0x40b4("0x1a0") },
    { Overlay: "Overlay" },
    { Popup: _0x40b4("0x1a1") },
  ],
});
UIEntity[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x1ca"), {
  type: _0x40b4("0x86"),
  default: "",
});
UIEntity[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x1cb"), {
  type: "boolean",
  default: ![],
});
UIEntity["attributes"]["add"](_0x40b4("0x1cc"), {
  type: _0x40b4("0x9f"),
  default: ![],
});
pc["extend"](UIEntity["prototype"], {
  init: function () {
    UIManager[_0x40b4("0xca")][_0x40b4("0x1cd")](
      this[_0x40b4("0x153")],
      this[_0x40b4("0x1b8")],
      this["entity"],
      this["showOnStartUp"]
    );
    this["_isBusy"] = ![];
    if (!this[_0x40b4("0xb8")][_0x40b4("0x154")]) {
      console[_0x40b4("0x7")](
        this["entity"][_0x40b4("0x153")],
        _0x40b4("0x1ce")
      );
    }
    if (
      !this[_0x40b4("0xb8")]["script"] &&
      !this[_0x40b4("0xb8")][_0x40b4("0x1a9")][_0x40b4("0x1cf")]
    ) {
      console[_0x40b4("0x7")](
        this["entity"]["name"],
        "doesn\x27t\x20have\x20a\x20dynamicScreen\x20script,\x20please\x20add\x20it!"
      );
    }
    if (
      this[_0x40b4("0xb8")][_0x40b4("0x1a9")] &&
      this[_0x40b4("0xb8")][_0x40b4("0x1a9")]["has"](this[_0x40b4("0x1ca")]) &&
      typeof this[_0x40b4("0xb8")][_0x40b4("0x1a9")][this[_0x40b4("0x1ca")]][
        _0x40b4("0x1d0")
      ] === "function"
    ) {
      this[_0x40b4("0xb8")][_0x40b4("0x1a9")][this[_0x40b4("0x1ca")]][
        _0x40b4("0x1d0")
      ]();
    }
  },
  onClose: function (_0xf9f5fd) {
    if (this["entity"][_0x40b4("0x1a9")]) {
      if (
        !(
          this["entity"][_0x40b4("0x1a9")][this[_0x40b4("0x1ca")]] instanceof
          Object[_0x40b4("0x1d1")](pc[_0x40b4("0x1a9")])[_0x40b4("0x1d2")]
        )
      ) {
      }
    }
    var _0x38b498 = [];
    if (
      this["entity"][_0x40b4("0x1a9")] &&
      this["entity"]["script"][this[_0x40b4("0x1ca")]] &&
      typeof this["entity"]["script"][this[_0x40b4("0x1ca")]][
        _0x40b4("0x1d3")
      ] === _0x40b4("0x68")
    ) {
      var _0x4b5d5e =
        this["entity"][_0x40b4("0x1a9")][this[_0x40b4("0x1ca")]][
          _0x40b4("0x1d3")
        ](_0xf9f5fd);
      if (_0x4b5d5e instanceof Promise) {
        _0x38b498["push"](_0x4b5d5e);
      }
    }
    if (_0x38b498[_0x40b4("0x87")] > 0x0) {
      this["_isBusy"] = !![];
      var _0x1bd459 = Promise[_0x40b4("0x22")](_0x38b498);
      _0x1bd459[_0x40b4("0xae")](() => {
        this[_0x40b4("0xb8")]["enabled"] = ![];
        this[_0x40b4("0x1d4")] = ![];
      });
      return _0x1bd459;
    } else {
      this[_0x40b4("0xb8")][_0x40b4("0xd4")] = ![];
    }
  },
  onCloseFinish: function (_0x36f6bb) {
    this[_0x40b4("0xb8")][_0x40b4("0xd4")] = ![];
    if (!this[_0x40b4("0x1ca")]) {
      this[_0x40b4("0x10e")](_0x40b4("0x1d5"));
      return ![];
    }
    if (
      !(
        this[_0x40b4("0xb8")]["script"][this["scriptName"]] instanceof
        Object[_0x40b4("0x1d1")](pc["script"])[_0x40b4("0x1d2")]
      )
    ) {
      console[_0x40b4("0x7")](
        this[_0x40b4("0x1ca")],
        "is\x20not\x20a\x20valid\x20script."
      );
      this[_0x40b4("0xb8")][_0x40b4("0xd4")] = ![];
      this["fire"]("closed");
      return ![];
    }
    if (
      typeof this[_0x40b4("0xb8")][_0x40b4("0x1a9")][this["scriptName"]][
        _0x40b4("0x1d6")
      ] !== _0x40b4("0x68")
    ) {
      this["entity"][_0x40b4("0xd4")] = ![];
      this[_0x40b4("0x10e")](_0x40b4("0x1d5"));
      return ![];
    }
    var _0xd44d1f =
      this[_0x40b4("0xb8")][_0x40b4("0x1a9")][this[_0x40b4("0x1ca")]][
        "onUIEntityCloseFinish"
      ](_0x36f6bb);
    return _0xd44d1f;
  },
  onOpen: function (_0x46dba7) {
    this[_0x40b4("0xb8")][_0x40b4("0xd4")] = !![];
    if (this[_0x40b4("0xb8")][_0x40b4("0x1a9")]) {
      if (
        !(
          this["entity"]["script"][this[_0x40b4("0x1ca")]] instanceof
          Object[_0x40b4("0x1d1")](pc[_0x40b4("0x1a9")])[_0x40b4("0x1d2")]
        )
      ) {
      }
    }
    var _0x1e35a9 = [];
    if (
      this[_0x40b4("0xb8")][_0x40b4("0x1a9")] &&
      this[_0x40b4("0xb8")]["script"][this[_0x40b4("0x1ca")]] &&
      typeof this[_0x40b4("0xb8")][_0x40b4("0x1a9")][this[_0x40b4("0x1ca")]][
        _0x40b4("0x1d7")
      ] === _0x40b4("0x68")
    ) {
      var _0x39bd67 =
        this[_0x40b4("0xb8")][_0x40b4("0x1a9")][this["scriptName"]][
          _0x40b4("0x1d7")
        ](_0x46dba7);
      if (_0x39bd67 instanceof Promise) {
        _0x1e35a9[_0x40b4("0x18")](_0x39bd67);
      }
    }
    if (_0x1e35a9[_0x40b4("0x87")] > 0x0) {
      this[_0x40b4("0x1d4")] = !![];
      var _0xf2a1f6 = Promise[_0x40b4("0x22")](_0x1e35a9);
      _0xf2a1f6[_0x40b4("0xae")](() => {
        this["_isBusy"] = ![];
      });
      return _0xf2a1f6;
    }
  },
  onOpenFinish: function (_0x181b62) {
    this[_0x40b4("0xb8")][_0x40b4("0xd4")] = !![];
    if (!this[_0x40b4("0x1ca")]) {
      return ![];
    }
    if (
      !(
        this[_0x40b4("0xb8")][_0x40b4("0x1a9")][this["scriptName"]] instanceof
        Object[_0x40b4("0x1d1")](pc[_0x40b4("0x1a9")])[_0x40b4("0x1d2")]
      )
    ) {
      console[_0x40b4("0x7")](
        this["scriptName"],
        "is\x20not\x20a\x20valid\x20script."
      );
      this["entity"][_0x40b4("0xd4")] = !![];
      return ![];
    }
    if (
      typeof this[_0x40b4("0xb8")][_0x40b4("0x1a9")][this[_0x40b4("0x1ca")]][
        "onUIEntityOpenFinish"
      ] !== _0x40b4("0x68")
    ) {
      this["entity"][_0x40b4("0xd4")] = !![];
      return ![];
    }
    var _0x5b133e =
      this[_0x40b4("0xb8")][_0x40b4("0x1a9")][this[_0x40b4("0x1ca")]][
        "onUIEntityOpenFinish"
      ](_0x181b62);
    return _0x5b133e;
  },
  isBusy: function () {
    return this[_0x40b4("0x1d4")];
  },
});
class ObjectPool extends pc[_0x40b4("0xb0")] {
  static [_0x40b4("0xb1")]() {
    this[_0x40b4("0x2d")][_0x40b4("0x2e")]("entityReference", {
      type: _0x40b4("0xb8"),
      title: _0x40b4("0x1ac"),
    });
    this[_0x40b4("0x2d")]["add"](_0x40b4("0x1d8"), {
      type: _0x40b4("0x45"),
      assetType: _0x40b4("0x1d9"),
      title: _0x40b4("0x1da"),
    });
    this["attributes"]["add"](_0x40b4("0x1db"), {
      type: _0x40b4("0x34"),
      default: 0x0,
    });
    this[_0x40b4("0x2d")]["add"](_0x40b4("0x1dc"), {
      type: _0x40b4("0x34"),
      default: 0x1,
    });
    this["attributes"][_0x40b4("0x2e")]("disableInPool", {
      type: _0x40b4("0x9f"),
      default: !![],
      title: _0x40b4("0x1dd"),
      description: _0x40b4("0x1de"),
    });
    this["attributes"][_0x40b4("0x2e")](_0x40b4("0x1df"), {
      type: _0x40b4("0x9f"),
      default: !![],
      title: _0x40b4("0x1e0"),
      description:
        "If\x20the\x20object\x20is\x20in\x20the\x20pool,\x20it\x20has\x20no\x20parent",
    });
    this[_0x40b4("0x2d")]["add"](_0x40b4("0x1e1"), {
      type: _0x40b4("0xb8"),
      title: _0x40b4("0x1e2"),
      description: _0x40b4("0x1e3"),
    });
  }
  [_0x40b4("0xc9")]() {
    this[_0x40b4("0x1e4")] = [];
    this[_0x40b4("0x1e5")] = null;
    this["isTemplate"] = ![];
    this[_0x40b4("0x153")] = "";
    this[_0x40b4("0x1e6")] = this[_0x40b4("0x1e1")] || this["entity"];
    this["object"] = null;
    if (this[_0x40b4("0x1e7")] && this[_0x40b4("0x1d8")]) {
      console[_0x40b4("0x7")](_0x40b4("0x1e8"));
    }
    if (this["entityReference"]) {
      this[_0x40b4("0xa0")] = this["entityReference"];
      this[_0x40b4("0x153")] = this["entityReference"][_0x40b4("0x153")];
    } else if (this[_0x40b4("0x1d8")]) {
      this["isTemplate"] = !![];
      const _0x39f2f0 = Object[_0x40b4("0x95")](
        this[_0x40b4("0x1d8")][_0x40b4("0x5a")]["_data"]["entities"]
      );
      for (var _0x342323 = 0x0; _0x342323 < _0x39f2f0["length"]; _0x342323++) {
        const _0x1f5f9a = _0x39f2f0[_0x342323];
        const _0x5b52ef =
          this[_0x40b4("0x1d8")]["resource"][_0x40b4("0x1e9")][
            _0x40b4("0x1ea")
          ][_0x1f5f9a];
        if (!_0x5b52ef["parent"]) {
          this[_0x40b4("0xa0")] = _0x5b52ef;
          this[_0x40b4("0x153")] = _0x5b52ef[_0x40b4("0x153")];
          break;
        }
      }
    } else {
      console[_0x40b4("0x7")](_0x40b4("0x1eb"));
      return;
    }
    this[_0x40b4("0x1ec")](this["initialLength"]);
  }
  [_0x40b4("0x1ec")](_0x68cf77) {
    if (_0x68cf77 > 0x0 && this[_0x40b4("0x1e5")] === null) {
      this[_0x40b4("0x1e5")] = 0x0;
    }
    if (_0x68cf77 > 0x0) {
      var _0x1c0b25 = this[_0x40b4("0x1e4")][_0x40b4("0x87")];
      this[_0x40b4("0x1e4")]["length"] += Number(_0x68cf77);
      for (
        var _0x5a6775 = _0x1c0b25;
        _0x5a6775 < this[_0x40b4("0x1e4")][_0x40b4("0x87")];
        _0x5a6775 += 0x1
      ) {
        var _0x18a026 = this["isTemplate"]
          ? this[_0x40b4("0x1d8")][_0x40b4("0x5a")][_0x40b4("0x1ed")]()
          : this["entityReference"][_0x40b4("0x166")]();
        if (this[_0x40b4("0x1ee")]) {
          _0x18a026[_0x40b4("0xd4")] = ![];
        }
        if (this[_0x40b4("0x1df")]) {
          _0x18a026["reparent"](null);
        }
        _0x18a026[_0x40b4("0x1ef")] = this;
        this[_0x40b4("0x1e4")][_0x5a6775] = _0x18a026;
      }
    }
    return this["_pool"]["length"];
  }
  [_0x40b4("0x1f0")]() {
    if (
      this["_nextFreeSlot"] === null ||
      this[_0x40b4("0x1e5")] === this[_0x40b4("0x1e4")][_0x40b4("0x87")]
    ) {
      this[_0x40b4("0x1ec")](this["growCount"]);
    }
    var _0x180555 = this[_0x40b4("0x1e4")][this[_0x40b4("0x1e5")]];
    this[_0x40b4("0x1e4")][this[_0x40b4("0x1e5")]] = null;
    this["_nextFreeSlot"] += 0x1;
    return _0x180555;
  }
  [_0x40b4("0x1f1")](_0xcc8c75) {
    if (_0xcc8c75["name"] !== this[_0x40b4("0x153")]) {
      console[_0x40b4("0x7")](
        "This\x20object\x20should\x20not\x20be\x20in\x20this\x20pool",
        _0xcc8c75,
        this[_0x40b4("0xa0")]
      );
      return;
    }
    if (this[_0x40b4("0x1e4")][_0x40b4("0x1c0")](_0xcc8c75) !== -0x1) {
      window["famobi"]["log"](_0x40b4("0x1f2"), _0xcc8c75);
      return;
    }
    if (this[_0x40b4("0x1ee")]) {
      _0xcc8c75[_0x40b4("0xd4")] = ![];
    }
    if (this[_0x40b4("0x1df")]) {
      _0xcc8c75[_0x40b4("0x1f3")](null);
    }
    if (this[_0x40b4("0x1e5")] === null || this[_0x40b4("0x1e5")] === -0x1) {
      this[_0x40b4("0x1e4")][this[_0x40b4("0x1e4")][_0x40b4("0x87")]] =
        _0xcc8c75;
    } else {
      this[_0x40b4("0x1e4")][(this[_0x40b4("0x1e5")] -= 0x1)] = _0xcc8c75;
    }
  }
  ["size"]() {
    return this[_0x40b4("0x1e4")]["length"];
  }
}
pc[_0x40b4("0x1f4")](ObjectPool, "objectPool");
ObjectPool["addAttributes"]();
var SwitchUibutton = pc[_0x40b4("0x2a")]("switchUibutton");
SwitchUibutton[_0x40b4("0x2d")]["add"](_0x40b4("0x1f5"), {
  type: _0x40b4("0xb8"),
  array: !![],
  title: _0x40b4("0x1f6"),
});
SwitchUibutton[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x1f7"), {
  type: _0x40b4("0x9f"),
  default: ![],
  title: _0x40b4("0x1f8"),
});
SwitchUibutton[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x1f9"), {
  type: _0x40b4("0xb8"),
  array: !![],
  title: "Close\x20other\x20UI\x20Entities",
});
SwitchUibutton[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x1fa"), {
  type: _0x40b4("0x86"),
});
pc[_0x40b4("0x1")](SwitchUibutton[_0x40b4("0x2")], {
  initialize: function () {
    this["_elementInput"] = null;
    this[_0x40b4("0x1fb")] = ![];
    this[_0x40b4("0x1fc")]();
    this[_0x40b4("0x1fd")]();
  },
  _createInputEvent: function () {
    this[_0x40b4("0x1fe")] =
      this[_0x40b4("0xb8")][_0x40b4("0x1a9")][_0x40b4("0x1ff")];
    if (!this[_0x40b4("0x1fe")]) {
      this[_0x40b4("0x1fe")] = this[_0x40b4("0xb8")][_0x40b4("0x1a9")][
        "create"
      ](_0x40b4("0x1ff"));
      console[_0x40b4("0x7")](
        _0x40b4("0x200"),
        this["entity"][_0x40b4("0x153")]
      );
    }
    this[_0x40b4("0x1fe")]["on"](
      inputEvents[_0x40b4("0x201")],
      this[_0x40b4("0x202")],
      this
    );
  },
  _setCloseItself: function () {
    if (this["closeItself"]) {
      var _0x1171ba = this[_0x40b4("0x203")](this[_0x40b4("0xb8")], 0x4);
      if (_0x1171ba instanceof pc[_0x40b4("0x1ac")]) {
        this["closeUIEntity"][_0x40b4("0x18")](_0x1171ba);
      } else {
        console[_0x40b4("0x7")]("Couldn\x27t\x20find\x20a\x20UI\x20Entity");
      }
    }
  },
  _getUIEntity: function (_0x1ec023, _0x4af614) {
    if (_0x4af614 <= 0x0 && !(_0x1ec023 instanceof pc[_0x40b4("0x1ac")])) {
      return null;
    }
    if (
      _0x1ec023[_0x40b4("0x1a9")] &&
      _0x1ec023[_0x40b4("0x1a9")][_0x40b4("0x1ab")] instanceof
        Object["getPrototypeOf"](pc[_0x40b4("0x1a9")])[_0x40b4("0x1d2")]
    ) {
      return _0x1ec023;
    } else {
      return this[_0x40b4("0x203")](
        _0x1ec023[_0x40b4("0x1e6")],
        (_0x4af614 -= 0x1)
      );
    }
  },
  _onClick: function (_0x3d4134) {
    if (this[_0x40b4("0x1fb")]) {
      console[_0x40b4("0x7")](_0x40b4("0x204"));
      return;
    }
    if (this[_0x40b4("0x1b3")]()) {
      console["warn"]("Unable\x20to\x20switch\x20while\x20busy");
      return;
    }
    this[_0x40b4("0x1fb")] = !![];
    this[_0x40b4("0x10e")]("click");
    var _0x218a76 = this["_closeEntities"]();
    _0x218a76[_0x40b4("0xae")](() => {
      this[_0x40b4("0x205")]()[_0x40b4("0xae")](() => {
        this[_0x40b4("0x1fb")] = ![];
      });
    });
  },
  _openEntities: function () {
    var _0x1533fd = [];
    for (
      var _0x3820da = 0x0;
      _0x3820da < this["openUIEntity"]["length"];
      _0x3820da += 0x1
    ) {
      if (this[_0x40b4("0x1f5")][_0x3820da] instanceof pc[_0x40b4("0x1ac")]) {
        _0x1533fd[_0x40b4("0x18")](
          UIManager[_0x40b4("0xca")][_0x40b4("0x1a5")](
            this[_0x40b4("0x1f5")][_0x3820da][_0x40b4("0x1a9")]["uiEntity"][
              _0x40b4("0x153")
            ],
            this["args"]
          )
        );
      } else {
        console[_0x40b4("0x7")](
          this["entity"]["parent"][_0x40b4("0x153")],
          _0x40b4("0x206"),
          _0x3820da
        );
      }
    }
    return Promise["all"](_0x1533fd);
  },
  _onOpenEntities: function (_0x390e4a, _0xf3fcc4) {
    for (
      var _0xacc95b = 0x0;
      _0xacc95b < this[_0x40b4("0x1f5")][_0x40b4("0x87")];
      _0xacc95b += 0x1
    ) {
      if (this[_0x40b4("0x1f5")][_0xacc95b] instanceof pc[_0x40b4("0x1ac")]) {
        promises[_0x40b4("0x18")](
          UIManager[_0x40b4("0xca")]["_showUIFinish"](
            this["openUIEntity"][_0xacc95b][_0x40b4("0x1a9")][_0x40b4("0x1ab")][
              "name"
            ],
            this[_0x40b4("0x1fa")]
          )
        );
      } else {
        console[_0x40b4("0x7")](
          this[_0x40b4("0xb8")][_0x40b4("0x1e6")][_0x40b4("0x153")],
          _0x40b4("0x207"),
          _0xacc95b
        );
      }
    }
  },
  _closeEntities: function (_0x2cb8c3, _0x4e1dfd) {
    var _0x22c886 = [];
    for (
      var _0x443940 = 0x0;
      _0x443940 < this[_0x40b4("0x1f9")]["length"];
      _0x443940 += 0x1
    ) {
      if (this[_0x40b4("0x1f9")][_0x443940] instanceof pc[_0x40b4("0x1ac")]) {
        _0x22c886["push"](
          UIManager[_0x40b4("0xca")][_0x40b4("0x1bb")](
            this[_0x40b4("0x1f9")][_0x443940][_0x40b4("0x1a9")][
              _0x40b4("0x1ab")
            ][_0x40b4("0x153")],
            this[_0x40b4("0x1fa")]
          )
        );
      } else {
        console["warn"](
          this[_0x40b4("0xb8")]["parent"][_0x40b4("0x153")],
          _0x40b4("0x207"),
          _0x443940
        );
      }
    }
    return Promise["all"](_0x22c886);
  },
  _onClosedEntities: function (_0x3ea200, _0x861b5e) {
    var _0x17254a = [];
    for (
      var _0x246135 = 0x0;
      _0x246135 < this["closeUIEntity"][_0x40b4("0x87")];
      _0x246135 += 0x1
    ) {
      if (this["closeUIEntity"][_0x246135] instanceof pc["Entity"]) {
        _0x17254a[_0x40b4("0x18")](
          UIManager[_0x40b4("0xca")][_0x40b4("0x208")](
            this[_0x40b4("0x1f9")][_0x246135][_0x40b4("0x1a9")][
              _0x40b4("0x1ab")
            ]["name"],
            this[_0x40b4("0x1fa")]
          )
        );
      } else {
        console[_0x40b4("0x7")](
          this[_0x40b4("0xb8")][_0x40b4("0x1e6")][_0x40b4("0x153")],
          _0x40b4("0x207"),
          _0x246135
        );
      }
    }
    return Promise[_0x40b4("0x22")](_0x17254a);
  },
  isBusy: function () {
    for (
      var _0x44e266 = 0x0;
      _0x44e266 < this[_0x40b4("0x1f9")][_0x40b4("0x87")];
      _0x44e266 += 0x1
    ) {
      if (
        this[_0x40b4("0x1f9")][_0x44e266]["script"][_0x40b4("0x1ab")][
          _0x40b4("0x1b3")
        ]()
      ) {
        return !![];
      }
    }
    return ![];
  },
});
pc[_0x40b4("0x1")](
  pc,
  (function () {
    var _0x48d0e5 = function (_0x5d5f5b) {
      this[_0x40b4("0x209")] = _0x5d5f5b;
      this[_0x40b4("0x20a")] = [];
      this[_0x40b4("0x20b")] = [];
    };
    _0x48d0e5["prototype"] = {
      add: function (_0x27e069) {
        this[_0x40b4("0x20b")]["push"](_0x27e069);
        return _0x27e069;
      },
      update: function (_0x1b0b93) {
        var _0xf7a974 = 0x0;
        var _0x50986c = this[_0x40b4("0x20a")][_0x40b4("0x87")];
        while (_0xf7a974 < _0x50986c) {
          if (this[_0x40b4("0x20a")][_0xf7a974]["update"](_0x1b0b93)) {
            _0xf7a974++;
          } else {
            this["_tweens"][_0x40b4("0x1c2")](_0xf7a974, 0x1);
            _0x50986c--;
          }
        }
        if (this[_0x40b4("0x20b")][_0x40b4("0x87")]) {
          this[_0x40b4("0x20a")] = this[_0x40b4("0x20a")][_0x40b4("0x20c")](
            this[_0x40b4("0x20b")]
          );
          this[_0x40b4("0x20b")][_0x40b4("0x87")] = 0x0;
        }
      },
    };
    var _0x1d2c23 = function (_0xf3a41c, _0x2f2c77, _0x41b69f) {
      pc["events"][_0x40b4("0x20d")](this);
      this["manager"] = _0x2f2c77;
      if (_0x41b69f) {
        this[_0x40b4("0xb8")] = null;
      }
      this[_0x40b4("0x20e")] = 0x0;
      this[_0x40b4("0xf3")] = ![];
      this["playing"] = ![];
      this[_0x40b4("0x20f")] = !![];
      this[_0x40b4("0x210")] = ![];
      this[_0x40b4("0x211")] = _0xf3a41c;
      this[_0x40b4("0x13b")] = 0x0;
      this[_0x40b4("0x212")] = 0x0;
      this[_0x40b4("0x213")] = 0x1;
      this[_0x40b4("0x214")] = ![];
      this["_delay"] = 0x0;
      this[_0x40b4("0x215")] = ![];
      this[_0x40b4("0x216")] = 0x0;
      this["_numRepeats"] = 0x0;
      this[_0x40b4("0x217")] = 0x0;
      this["_from"] = ![];
      this[_0x40b4("0x218")] = ![];
      this[_0x40b4("0x219")] = new pc[_0x40b4("0x21a")]();
      this[_0x40b4("0x21b")] = new pc["Quat"]();
      this[_0x40b4("0x21c")] = new pc[_0x40b4("0x21a")]();
      this[_0x40b4("0x21d")] = pc[_0x40b4("0x21e")];
      this[_0x40b4("0x21f")] = {};
      this[_0x40b4("0x220")] = {};
    };
    _0x1d2c23[_0x40b4("0x2")] = {
      to: function (
        _0x1f79a3,
        _0x46bd6b,
        _0x3f43da,
        _0x295303,
        _0x4c5ac6,
        _0x4b1fbc
      ) {
        if (_0x1f79a3 instanceof pc[_0x40b4("0x16a")]) {
          this[_0x40b4("0x221")] = {
            x: _0x1f79a3["x"],
            y: _0x1f79a3["y"],
            z: _0x1f79a3["z"],
          };
        } else if (_0x1f79a3 instanceof pc["Color"]) {
          this[_0x40b4("0x221")] = {
            r: _0x1f79a3["r"],
            g: _0x1f79a3["g"],
            b: _0x1f79a3["b"],
          };
          if (_0x1f79a3["a"] !== undefined) {
            this[_0x40b4("0x221")]["a"] = _0x1f79a3["a"];
          }
        } else {
          this["_properties"] = _0x1f79a3;
        }
        this["duration"] = _0x46bd6b;
        if (_0x3f43da) this["easing"] = _0x3f43da;
        if (_0x295303) {
          this[_0x40b4("0x222")](_0x295303);
        }
        if (_0x4c5ac6) {
          this[_0x40b4("0x223")](_0x4c5ac6);
        }
        if (_0x4b1fbc) {
          this[_0x40b4("0x224")](_0x4b1fbc);
        }
        return this;
      },
      from: function (
        _0x46f9c8,
        _0x1e13a,
        _0x132296,
        _0x7b409b,
        _0x2852ce,
        _0x3cbe8a
      ) {
        if (_0x46f9c8 instanceof pc[_0x40b4("0x16a")]) {
          this[_0x40b4("0x221")] = {
            x: _0x46f9c8["x"],
            y: _0x46f9c8["y"],
            z: _0x46f9c8["z"],
          };
        } else if (_0x46f9c8 instanceof pc[_0x40b4("0x136")]) {
          this["_properties"] = {
            r: _0x46f9c8["r"],
            g: _0x46f9c8["g"],
            b: _0x46f9c8["b"],
          };
          if (_0x46f9c8["a"] !== undefined) {
            this[_0x40b4("0x221")]["a"] = _0x46f9c8["a"];
          }
        } else {
          this[_0x40b4("0x221")] = _0x46f9c8;
        }
        this[_0x40b4("0x13b")] = _0x1e13a;
        if (_0x132296) this[_0x40b4("0x21d")] = _0x132296;
        if (_0x7b409b) {
          this[_0x40b4("0x222")](_0x7b409b);
        }
        if (_0x2852ce) {
          this[_0x40b4("0x223")](_0x2852ce);
        }
        if (_0x3cbe8a) {
          this[_0x40b4("0x224")](_0x3cbe8a);
        }
        this[_0x40b4("0x148")] = !![];
        return this;
      },
      rotate: function (
        _0x45e19e,
        _0x1c3d4d,
        _0x33a53c,
        _0x29ed21,
        _0x53db25,
        _0x32148e
      ) {
        if (_0x45e19e instanceof pc[_0x40b4("0x21a")]) {
          this[_0x40b4("0x221")] = {
            x: _0x45e19e["x"],
            y: _0x45e19e["y"],
            z: _0x45e19e["z"],
            w: _0x45e19e["w"],
          };
        } else if (_0x45e19e instanceof pc[_0x40b4("0x16a")]) {
          this[_0x40b4("0x221")] = {
            x: _0x45e19e["x"],
            y: _0x45e19e["y"],
            z: _0x45e19e["z"],
          };
        } else if (_0x45e19e instanceof pc[_0x40b4("0x136")]) {
          this[_0x40b4("0x221")] = {
            r: _0x45e19e["r"],
            g: _0x45e19e["g"],
            b: _0x45e19e["b"],
          };
          if (_0x45e19e["a"] !== undefined) {
            this["_properties"]["a"] = _0x45e19e["a"];
          }
        } else {
          this[_0x40b4("0x221")] = _0x45e19e;
        }
        this[_0x40b4("0x13b")] = _0x1c3d4d;
        if (_0x33a53c) this["easing"] = _0x33a53c;
        if (_0x29ed21) {
          this["delay"](_0x29ed21);
        }
        if (_0x53db25) {
          this[_0x40b4("0x223")](_0x53db25);
        }
        if (_0x32148e) {
          this["yoyo"](_0x32148e);
        }
        this[_0x40b4("0x218")] = !![];
        return this;
      },
      start: function () {
        this[_0x40b4("0x225")] = !![];
        this[_0x40b4("0xf3")] = ![];
        this[_0x40b4("0x20f")] = ![];
        this["_count"] = 0x0;
        this[_0x40b4("0x210")] = this["_delay"] > 0x0;
        if (this[_0x40b4("0x214")] && !this["pending"]) {
          this[_0x40b4("0x20e")] = this[_0x40b4("0x13b")];
        } else {
          this[_0x40b4("0x20e")] = 0x0;
        }
        if (this[_0x40b4("0x148")]) {
          for (var _0x5b061e in this[_0x40b4("0x221")]) {
            this["_sv"][_0x5b061e] = this[_0x40b4("0x221")][_0x5b061e];
            this[_0x40b4("0x220")][_0x5b061e] =
              this[_0x40b4("0x211")][_0x5b061e];
          }
          if (this["_slerp"]) {
            this[_0x40b4("0x21b")][_0x40b4("0x226")](
              this["target"]["x"],
              this[_0x40b4("0x211")]["y"],
              this[_0x40b4("0x211")]["z"]
            );
            var _0x348501 =
              this[_0x40b4("0x221")]["x"] !== undefined
                ? this["_properties"]["x"]
                : this["target"]["x"];
            var _0xab4534 =
              this[_0x40b4("0x221")]["y"] !== undefined
                ? this["_properties"]["y"]
                : this[_0x40b4("0x211")]["y"];
            var _0x1cc96d =
              this[_0x40b4("0x221")]["z"] !== undefined
                ? this[_0x40b4("0x221")]["z"]
                : this[_0x40b4("0x211")]["z"];
            this[_0x40b4("0x219")]["setFromEulerAngles"](
              _0x348501,
              _0xab4534,
              _0x1cc96d
            );
          }
        } else {
          for (var _0x5b061e in this[_0x40b4("0x221")]) {
            this[_0x40b4("0x21f")][_0x5b061e] =
              this[_0x40b4("0x211")][_0x5b061e];
            this["_ev"][_0x5b061e] = this["_properties"][_0x5b061e];
          }
          if (this["_slerp"]) {
            this["_fromQuat"][_0x40b4("0x226")](
              this["target"]["x"],
              this[_0x40b4("0x211")]["y"],
              this[_0x40b4("0x211")]["z"]
            );
            var _0x348501 =
              this[_0x40b4("0x221")]["x"] !== undefined
                ? this[_0x40b4("0x221")]["x"]
                : this["target"]["x"];
            var _0xab4534 =
              this[_0x40b4("0x221")]["y"] !== undefined
                ? this[_0x40b4("0x221")]["y"]
                : this[_0x40b4("0x211")]["y"];
            var _0x1cc96d =
              this["_properties"]["z"] !== undefined
                ? this[_0x40b4("0x221")]["z"]
                : this[_0x40b4("0x211")]["z"];
            this["_toQuat"][_0x40b4("0x226")](_0x348501, _0xab4534, _0x1cc96d);
          }
        }
        this[_0x40b4("0x212")] = this[_0x40b4("0x227")];
        this["manager"][_0x40b4("0x2e")](this);
        return this;
      },
      pause: function () {
        this[_0x40b4("0x225")] = ![];
      },
      resume: function () {
        this[_0x40b4("0x225")] = !![];
      },
      stop: function () {
        this[_0x40b4("0x225")] = ![];
        this[_0x40b4("0x20f")] = !![];
      },
      delay: function (_0x593ac1) {
        this["_delay"] = _0x593ac1;
        this[_0x40b4("0x210")] = !![];
        return this;
      },
      repeat: function (_0x14f0aa, _0x296f00) {
        this[_0x40b4("0x216")] = 0x0;
        this[_0x40b4("0x228")] = _0x14f0aa;
        if (_0x296f00) {
          this["_repeatDelay"] = _0x296f00;
        } else {
          this[_0x40b4("0x217")] = 0x0;
        }
        return this;
      },
      loop: function (_0x5845b1) {
        if (_0x5845b1) {
          this[_0x40b4("0x216")] = 0x0;
          this["_numRepeats"] = Infinity;
        } else {
          this[_0x40b4("0x228")] = 0x0;
        }
        return this;
      },
      yoyo: function (_0x5d6511) {
        this["_yoyo"] = _0x5d6511;
        return this;
      },
      reverse: function () {
        this[_0x40b4("0x214")] = !this[_0x40b4("0x214")];
        return this;
      },
      chain: function () {
        var _0x336914 = arguments["length"];
        while (_0x336914--) {
          if (_0x336914 > 0x0) {
            arguments[_0x336914 - 0x1]["_chained"] = arguments[_0x336914];
          } else {
            this[_0x40b4("0x229")] = arguments[_0x336914];
          }
        }
        return this;
      },
      update: function (_0x564eee) {
        if (this[_0x40b4("0x20f")]) return ![];
        if (!this[_0x40b4("0x225")]) return !![];
        if (!this[_0x40b4("0x214")] || this[_0x40b4("0x210")]) {
          this[_0x40b4("0x20e")] += _0x564eee * this["timeScale"];
        } else {
          this[_0x40b4("0x20e")] -= _0x564eee * this["timeScale"];
        }
        if (this[_0x40b4("0x210")]) {
          if (this[_0x40b4("0x20e")] > this[_0x40b4("0x212")]) {
            if (this["_reverse"]) {
              this["time"] =
                this[_0x40b4("0x13b")] -
                (this[_0x40b4("0x20e")] - this["_currentDelay"]);
            } else {
              this[_0x40b4("0x20e")] =
                this[_0x40b4("0x20e")] - this["_currentDelay"];
            }
            this[_0x40b4("0x210")] = ![];
          } else {
            return !![];
          }
        }
        var _0x4c4860 = 0x0;
        if (
          (!this[_0x40b4("0x214")] && this["time"] > this[_0x40b4("0x13b")]) ||
          (this[_0x40b4("0x214")] && this[_0x40b4("0x20e")] < 0x0)
        ) {
          this["_count"]++;
          this["complete"] = !![];
          this[_0x40b4("0x225")] = ![];
          if (this["_reverse"]) {
            _0x4c4860 = this["duration"] - this[_0x40b4("0x20e")];
            this[_0x40b4("0x20e")] = 0x0;
          } else {
            _0x4c4860 = this["time"] - this[_0x40b4("0x13b")];
            this[_0x40b4("0x20e")] = this[_0x40b4("0x13b")];
          }
        }
        var _0x2e67ab = this[_0x40b4("0x20e")] / this[_0x40b4("0x13b")];
        var _0x3bf262 = this["easing"](_0x2e67ab);
        var _0xfb90dd, _0x30adda, _0x4d7308;
        for (var _0x351bbf in this[_0x40b4("0x221")]) {
          _0xfb90dd = this[_0x40b4("0x21f")][_0x351bbf];
          _0x30adda = this[_0x40b4("0x220")][_0x351bbf];
          this["target"][_0x351bbf] =
            _0xfb90dd + (_0x30adda - _0xfb90dd) * _0x3bf262;
        }
        if (this[_0x40b4("0x218")]) {
          this["_quat"][_0x40b4("0x22a")](
            this[_0x40b4("0x219")],
            this[_0x40b4("0x21b")],
            _0x3bf262
          );
        }
        if (this[_0x40b4("0xb8")]) {
          this["entity"][_0x40b4("0x22b")](!![]);
          if (this[_0x40b4("0x154")] && this[_0x40b4("0xb8")]["element"]) {
            this[_0x40b4("0xb8")]["element"][this[_0x40b4("0x154")]] =
              this[_0x40b4("0x211")];
          }
          if (this[_0x40b4("0x218")]) {
            this[_0x40b4("0xb8")][_0x40b4("0x22c")](this[_0x40b4("0x21c")]);
          }
        }
        this["fire"]("update", _0x564eee);
        if (this[_0x40b4("0xf3")]) {
          var _0xd7a3a7 = this[_0x40b4("0x22d")](_0x4c4860);
          if (!_0xd7a3a7) {
            this[_0x40b4("0x10e")](_0x40b4("0xf3"), _0x4c4860);
            if (this[_0x40b4("0x229")]) this[_0x40b4("0x229")]["start"]();
          } else {
            this[_0x40b4("0x10e")]("loop");
          }
          return _0xd7a3a7;
        }
        return !![];
      },
      getPromise: function () {
        return new Promise((_0x40d6ea) => {
          this[_0x40b4("0x22e")]("complete", _0x40d6ea);
        });
      },
      _repeat: function (_0x2d0e11) {
        if (this[_0x40b4("0x216")] < this[_0x40b4("0x228")]) {
          if (this[_0x40b4("0x214")]) {
            this[_0x40b4("0x20e")] = this[_0x40b4("0x13b")] - _0x2d0e11;
          } else {
            this[_0x40b4("0x20e")] = _0x2d0e11;
          }
          this[_0x40b4("0xf3")] = ![];
          this[_0x40b4("0x225")] = !![];
          this[_0x40b4("0x212")] = this[_0x40b4("0x217")];
          this[_0x40b4("0x210")] = !![];
          if (this[_0x40b4("0x215")]) {
            for (var _0x1321b2 in this[_0x40b4("0x221")]) {
              tmp = this[_0x40b4("0x21f")][_0x1321b2];
              this[_0x40b4("0x21f")][_0x1321b2] =
                this[_0x40b4("0x220")][_0x1321b2];
              this[_0x40b4("0x220")][_0x1321b2] = tmp;
            }
            if (this[_0x40b4("0x218")]) {
              this[_0x40b4("0x21c")]["copy"](this[_0x40b4("0x219")]);
              this[_0x40b4("0x219")][_0x40b4("0x12e")](this[_0x40b4("0x21b")]);
              this[_0x40b4("0x21b")]["copy"](this[_0x40b4("0x21c")]);
            }
          }
          return !![];
        }
        return ![];
      },
    };
    var _0x31172a = function (_0x3dd3fa) {
      return _0x3dd3fa;
    };
    var _0x1d8564 = function (_0x254f8a) {
      return _0x254f8a * _0x254f8a;
    };
    var _0x551049 = function (_0x58e75f) {
      return _0x58e75f * (0x2 - _0x58e75f);
    };
    var _0x491a91 = function (_0x34754f) {
      if ((_0x34754f *= 0x2) < 0x1) {
        return 0.5 * _0x34754f * _0x34754f;
      }
      return -0.5 * (--_0x34754f * (_0x34754f - 0x2) - 0x1);
    };
    var _0x5b7053 = function (_0x2bc9ae) {
      return _0x2bc9ae * _0x2bc9ae * _0x2bc9ae;
    };
    var _0x104c37 = function (_0x10e54e) {
      return --_0x10e54e * _0x10e54e * _0x10e54e + 0x1;
    };
    var _0xd9c6f6 = function (_0x6029fd) {
      if ((_0x6029fd *= 0x2) < 0x1)
        return 0.5 * _0x6029fd * _0x6029fd * _0x6029fd;
      return 0.5 * ((_0x6029fd -= 0x2) * _0x6029fd * _0x6029fd + 0x2);
    };
    var _0x1f0f75 = function (_0x155dc4) {
      return _0x155dc4 * _0x155dc4 * _0x155dc4 * _0x155dc4;
    };
    var _0x62bff = function (_0x931c82) {
      return 0x1 - --_0x931c82 * _0x931c82 * _0x931c82 * _0x931c82;
    };
    var _0x76aa32 = function (_0x4f9cf4) {
      if ((_0x4f9cf4 *= 0x2) < 0x1)
        return 0.5 * _0x4f9cf4 * _0x4f9cf4 * _0x4f9cf4 * _0x4f9cf4;
      return (
        -0.5 * ((_0x4f9cf4 -= 0x2) * _0x4f9cf4 * _0x4f9cf4 * _0x4f9cf4 - 0x2)
      );
    };
    var _0x18281d = function (_0x40fa78) {
      return _0x40fa78 * _0x40fa78 * _0x40fa78 * _0x40fa78 * _0x40fa78;
    };
    var _0x56944e = function (_0x1e8509) {
      return --_0x1e8509 * _0x1e8509 * _0x1e8509 * _0x1e8509 * _0x1e8509 + 0x1;
    };
    var _0x54fc60 = function (_0x46da87) {
      if ((_0x46da87 *= 0x2) < 0x1)
        return 0.5 * _0x46da87 * _0x46da87 * _0x46da87 * _0x46da87 * _0x46da87;
      return (
        0.5 *
        ((_0x46da87 -= 0x2) * _0x46da87 * _0x46da87 * _0x46da87 * _0x46da87 +
          0x2)
      );
    };
    var _0x4aac4c = function (_0x3a6175) {
      if (_0x3a6175 === 0x0) return 0x0;
      if (_0x3a6175 === 0x1) return 0x1;
      return 0x1 - Math[_0x40b4("0x22f")]((_0x3a6175 * Math["PI"]) / 0x2);
    };
    var _0x36adf7 = function (_0x517014) {
      if (_0x517014 === 0x0) return 0x0;
      if (_0x517014 === 0x1) return 0x1;
      return Math[_0x40b4("0x230")]((_0x517014 * Math["PI"]) / 0x2);
    };
    var _0x54ab08 = function (_0x5925f3) {
      if (_0x5925f3 === 0x0) return 0x0;
      if (_0x5925f3 === 0x1) return 0x1;
      return 0.5 * (0x1 - Math[_0x40b4("0x22f")](Math["PI"] * _0x5925f3));
    };
    var _0x467abe = function (_0x3e4ada) {
      return _0x3e4ada === 0x0 ? 0x0 : Math["pow"](0x400, _0x3e4ada - 0x1);
    };
    var _0x55c228 = function (_0x3030c7) {
      return _0x3030c7 === 0x1
        ? 0x1
        : 0x1 - Math[_0x40b4("0x231")](0x2, -0xa * _0x3030c7);
    };
    var _0x50db77 = function (_0x1854d9) {
      if (_0x1854d9 === 0x0) return 0x0;
      if (_0x1854d9 === 0x1) return 0x1;
      if ((_0x1854d9 *= 0x2) < 0x1)
        return 0.5 * Math[_0x40b4("0x231")](0x400, _0x1854d9 - 0x1);
      return (
        0.5 * (-Math[_0x40b4("0x231")](0x2, -0xa * (_0x1854d9 - 0x1)) + 0x2)
      );
    };
    var _0x355cfa = function (_0x1c0da6) {
      return 0x1 - Math[_0x40b4("0x232")](0x1 - _0x1c0da6 * _0x1c0da6);
    };
    var _0x4e1d91 = function (_0x3d5d1a) {
      return Math["sqrt"](0x1 - --_0x3d5d1a * _0x3d5d1a);
    };
    var _0x4c0c57 = function (_0x49dc60) {
      if ((_0x49dc60 *= 0x2) < 0x1)
        return -0.5 * (Math["sqrt"](0x1 - _0x49dc60 * _0x49dc60) - 0x1);
      return (
        0.5 *
        (Math[_0x40b4("0x232")](0x1 - (_0x49dc60 -= 0x2) * _0x49dc60) + 0x1)
      );
    };
    var _0x5bb436 = function (_0x2121f0) {
      var _0x4da269,
        _0x23f3a6 = 0.1,
        _0x3d3e16 = 0.4;
      if (_0x2121f0 === 0x0) return 0x0;
      if (_0x2121f0 === 0x1) return 0x1;
      if (!_0x23f3a6 || _0x23f3a6 < 0x1) {
        _0x23f3a6 = 0x1;
        _0x4da269 = _0x3d3e16 / 0x4;
      } else
        _0x4da269 =
          (_0x3d3e16 * Math[_0x40b4("0x233")](0x1 / _0x23f3a6)) /
          (0x2 * Math["PI"]);
      return -(
        _0x23f3a6 *
        Math[_0x40b4("0x231")](0x2, 0xa * (_0x2121f0 -= 0x1)) *
        Math[_0x40b4("0x230")](
          ((_0x2121f0 - _0x4da269) * (0x2 * Math["PI"])) / _0x3d3e16
        )
      );
    };
    var _0x20caed = function (_0x6f09cf) {
      var _0xf6f26,
        _0x200276 = 0.1,
        _0x2ddb31 = 0.4;
      if (_0x6f09cf === 0x0) return 0x0;
      if (_0x6f09cf === 0x1) return 0x1;
      if (!_0x200276 || _0x200276 < 0x1) {
        _0x200276 = 0x1;
        _0xf6f26 = _0x2ddb31 / 0x4;
      } else
        _0xf6f26 =
          (_0x2ddb31 * Math[_0x40b4("0x233")](0x1 / _0x200276)) /
          (0x2 * Math["PI"]);
      return (
        _0x200276 *
          Math[_0x40b4("0x231")](0x2, -0xa * _0x6f09cf) *
          Math["sin"](
            ((_0x6f09cf - _0xf6f26) * (0x2 * Math["PI"])) / _0x2ddb31
          ) +
        0x1
      );
    };
    var _0x3fbf3c = function (_0x498bad) {
      var _0x3583be,
        _0x1ab85a = 0.1,
        _0x28b16d = 0.4;
      if (_0x498bad === 0x0) return 0x0;
      if (_0x498bad === 0x1) return 0x1;
      if (!_0x1ab85a || _0x1ab85a < 0x1) {
        _0x1ab85a = 0x1;
        _0x3583be = _0x28b16d / 0x4;
      } else
        _0x3583be =
          (_0x28b16d * Math[_0x40b4("0x233")](0x1 / _0x1ab85a)) /
          (0x2 * Math["PI"]);
      if ((_0x498bad *= 0x2) < 0x1)
        return (
          -0.5 *
          (_0x1ab85a *
            Math[_0x40b4("0x231")](0x2, 0xa * (_0x498bad -= 0x1)) *
            Math[_0x40b4("0x230")](
              ((_0x498bad - _0x3583be) * (0x2 * Math["PI"])) / _0x28b16d
            ))
        );
      return (
        _0x1ab85a *
          Math[_0x40b4("0x231")](0x2, -0xa * (_0x498bad -= 0x1)) *
          Math[_0x40b4("0x230")](
            ((_0x498bad - _0x3583be) * (0x2 * Math["PI"])) / _0x28b16d
          ) *
          0.5 +
        0x1
      );
    };
    var _0x4e8006 = function (_0x43d541) {
      var _0x4b7fb0 = 1.70158;
      return (
        _0x43d541 * _0x43d541 * ((_0x4b7fb0 + 0x1) * _0x43d541 - _0x4b7fb0)
      );
    };
    var _0xffa8f3 = function (_0x15b503) {
      var _0x1c7cb2 = 1.70158;
      return (
        --_0x15b503 * _0x15b503 * ((_0x1c7cb2 + 0x1) * _0x15b503 + _0x1c7cb2) +
        0x1
      );
    };
    var _0x855b57 = function (_0x2b3574) {
      var _0x210412 = 1.70158 * 1.525;
      if ((_0x2b3574 *= 0x2) < 0x1)
        return (
          0.5 *
          (_0x2b3574 * _0x2b3574 * ((_0x210412 + 0x1) * _0x2b3574 - _0x210412))
        );
      return (
        0.5 *
        ((_0x2b3574 -= 0x2) *
          _0x2b3574 *
          ((_0x210412 + 0x1) * _0x2b3574 + _0x210412) +
          0x2)
      );
    };
    var _0x59f743 = function (_0x1bfc78) {
      return 0x1 - _0x9c6d29(0x1 - _0x1bfc78);
    };
    var _0x9c6d29 = function (_0x58ccdf) {
      if (_0x58ccdf < 0x1 / 2.75) {
        return 7.5625 * _0x58ccdf * _0x58ccdf;
      } else if (_0x58ccdf < 0x2 / 2.75) {
        return 7.5625 * (_0x58ccdf -= 1.5 / 2.75) * _0x58ccdf + 0.75;
      } else if (_0x58ccdf < 2.5 / 2.75) {
        return 7.5625 * (_0x58ccdf -= 2.25 / 2.75) * _0x58ccdf + 0.9375;
      } else {
        return 7.5625 * (_0x58ccdf -= 2.625 / 2.75) * _0x58ccdf + 0.984375;
      }
    };
    var _0x3d0c5f = function (_0x30b45a) {
      if (_0x30b45a < 0.5) return _0x59f743(_0x30b45a * 0x2) * 0.5;
      return _0x9c6d29(_0x30b45a * 0x2 - 0x1) * 0.5 + 0.5;
    };
    return {
      TweenManager: _0x48d0e5,
      Tween: _0x1d2c23,
      Linear: _0x31172a,
      QuadraticIn: _0x1d8564,
      QuadraticOut: _0x551049,
      QuadraticInOut: _0x491a91,
      CubicIn: _0x5b7053,
      CubicOut: _0x104c37,
      CubicInOut: _0xd9c6f6,
      QuarticIn: _0x1f0f75,
      QuarticOut: _0x62bff,
      QuarticInOut: _0x76aa32,
      QuinticIn: _0x18281d,
      QuinticOut: _0x56944e,
      QuinticInOut: _0x54fc60,
      SineIn: _0x4aac4c,
      SineOut: _0x36adf7,
      SineInOut: _0x54ab08,
      ExponentialIn: _0x467abe,
      ExponentialOut: _0x55c228,
      ExponentialInOut: _0x50db77,
      CircularIn: _0x355cfa,
      CircularOut: _0x4e1d91,
      CircularInOut: _0x4c0c57,
      BackIn: _0x4e8006,
      BackOut: _0xffa8f3,
      BackInOut: _0x855b57,
      BounceIn: _0x59f743,
      BounceOut: _0x9c6d29,
      BounceInOut: _0x3d0c5f,
      ElasticIn: _0x5bb436,
      ElasticOut: _0x20caed,
      ElasticInOut: _0x3fbf3c,
    };
  })()
);
(function () {
  var _0x45d104 = pc[_0x40b4("0x5b")]["getApplication"]();
  if (_0x45d104) {
    _0x45d104[_0x40b4("0x234")] = new pc[_0x40b4("0x235")](_0x45d104);
    _0x45d104["on"](_0x40b4("0x236"), function (_0x540e7a) {
      _0x45d104[_0x40b4("0x234")][_0x40b4("0x236")](_0x540e7a);
    });
    pc["Application"][_0x40b4("0x2")][_0x40b4("0xf1")] = function (_0x29a7e3) {
      return new pc[_0x40b4("0x237")](_0x29a7e3, this[_0x40b4("0x234")]);
    };
    pc[_0x40b4("0x1ac")]["prototype"]["tween"] = function (
      _0x44d2ab,
      _0x476fc2
    ) {
      var _0x35bb08 = this[_0x40b4("0x209")]["tween"](_0x44d2ab);
      _0x35bb08[_0x40b4("0xb8")] = this;
      this["on"](_0x40b4("0x1b0"), function () {
        _0x35bb08[_0x40b4("0xea")]();
      });
      if (_0x476fc2 && _0x476fc2[_0x40b4("0x154")]) {
        _0x35bb08[_0x40b4("0x154")] = element;
      }
      return _0x35bb08;
    };
  }
})();
var DynamicElement = pc[_0x40b4("0x2a")](_0x40b4("0x238"));
var ElementPreset = Object[_0x40b4("0x239")]([
  { NONE: "NONE" },
  { TOPLEFT: _0x40b4("0x23a") },
  { TOPLEFT_ANCHOR: _0x40b4("0x23b") },
  { TOP: _0x40b4("0x23c") },
  { TOP_ANCHOR: _0x40b4("0x23d") },
  { TOPRIGHT: "TOPRIGHT" },
  { TOPRIGHT_ANCHOR: "TOPRIGHT_ANCHOR" },
  { LEFT: _0x40b4("0x23e") },
  { LEFT_ANCHOR: _0x40b4("0x23f") },
  { CENTER: _0x40b4("0x240") },
  { CENTER_ANCHOR: _0x40b4("0x241") },
  { RIGHT: "RIGHT" },
  { RIGHT_ANCHOR: _0x40b4("0x242") },
  { BOTTOMLEFT: _0x40b4("0x243") },
  { BOTTOMLEFT_ANCHOR: "BOTTOMLEFT_ANCHOR" },
  { BOTTOM: _0x40b4("0x244") },
  { BOTTOM_ANCHOR: _0x40b4("0x245") },
  { BOTTOMRIGHT: _0x40b4("0x246") },
  { BOTTOMRIGHT_ANCHOR: _0x40b4("0x247") },
]);
var defaultString = _0x40b4("0x248");
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")]("a", {
  type: _0x40b4("0x86"),
  title: "Desktop\x20Landscape",
  default: defaultString,
});
DynamicElement["attributes"]["add"](_0x40b4("0x249"), {
  type: _0x40b4("0x86"),
  enum: ElementPreset,
  title: _0x40b4("0x24a"),
  default: _0x40b4("0x24b"),
});
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x24c"), {
  type: "vec4",
  title: _0x40b4("0x24d"),
});
DynamicElement["attributes"][_0x40b4("0x2e")](_0x40b4("0x24e"), {
  type: "vec2",
  title: _0x40b4("0x24f"),
});
DynamicElement["attributes"]["add"](_0x40b4("0x250"), {
  type: _0x40b4("0x164"),
  title: _0x40b4("0x251"),
});
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x252"), {
  type: _0x40b4("0x164"),
  title: _0x40b4("0x253"),
});
DynamicElement["attributes"][_0x40b4("0x2e")](_0x40b4("0x254"), {
  type: _0x40b4("0x164"),
  title: _0x40b4("0x255"),
  default: [0x1, 0x1, 0x1],
});
DynamicElement["attributes"]["add"]("b", {
  type: _0x40b4("0x86"),
  title: "Desktop\x20Portrait",
  default: defaultString,
});
DynamicElement["attributes"][_0x40b4("0x2e")](_0x40b4("0x256"), {
  type: "string",
  enum: ElementPreset,
  title: _0x40b4("0x24a"),
  default: _0x40b4("0x24b"),
});
DynamicElement[_0x40b4("0x2d")]["add"](_0x40b4("0x257"), {
  type: _0x40b4("0x258"),
  title: "Anchor",
});
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x259"), {
  type: _0x40b4("0x25a"),
  title: _0x40b4("0x24f"),
});
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")]("desktopPortraitPosition", {
  type: "vec3",
  title: "Position",
});
DynamicElement[_0x40b4("0x2d")]["add"](_0x40b4("0x25b"), {
  type: _0x40b4("0x164"),
  title: _0x40b4("0x253"),
});
DynamicElement["attributes"][_0x40b4("0x2e")](_0x40b4("0x25c"), {
  type: "vec3",
  title: _0x40b4("0x255"),
  default: [0x1, 0x1, 0x1],
});
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")]("c", {
  type: _0x40b4("0x86"),
  title: _0x40b4("0x25d"),
  default: defaultString,
});
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x25e"), {
  type: _0x40b4("0x86"),
  enum: ElementPreset,
  title: _0x40b4("0x24a"),
  default: _0x40b4("0x24b"),
});
DynamicElement["attributes"][_0x40b4("0x2e")](_0x40b4("0x25f"), {
  type: _0x40b4("0x258"),
  title: "Anchor",
});
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x260"), {
  type: "vec2",
  title: _0x40b4("0x24f"),
});
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")]("mobileLandscapePosition", {
  type: _0x40b4("0x164"),
  title: _0x40b4("0x251"),
});
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x261"), {
  type: _0x40b4("0x164"),
  title: _0x40b4("0x253"),
});
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x262"), {
  type: _0x40b4("0x164"),
  title: _0x40b4("0x255"),
  default: [1.5, 1.5, 1.5],
});
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")]("d", {
  type: _0x40b4("0x86"),
  title: _0x40b4("0x263"),
  default: defaultString,
});
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x264"), {
  type: _0x40b4("0x86"),
  enum: ElementPreset,
  title: _0x40b4("0x24a"),
  default: _0x40b4("0x24b"),
});
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x265"), {
  type: _0x40b4("0x258"),
  title: _0x40b4("0x24d"),
});
DynamicElement[_0x40b4("0x2d")]["add"](_0x40b4("0x266"), {
  type: "vec2",
  title: _0x40b4("0x24f"),
});
DynamicElement["attributes"][_0x40b4("0x2e")](_0x40b4("0x267"), {
  type: _0x40b4("0x164"),
  title: _0x40b4("0x251"),
});
DynamicElement[_0x40b4("0x2d")]["add"](_0x40b4("0x268"), {
  type: _0x40b4("0x164"),
  title: "Rotation",
});
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x269"), {
  type: _0x40b4("0x164"),
  title: _0x40b4("0x255"),
  default: [0x1, 0x1, 0x1],
});
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x26a"), {
  type: _0x40b4("0x9f"),
  default: !![],
  title: _0x40b4("0x26b"),
});
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")]("updateRotation", {
  type: _0x40b4("0x9f"),
  default: !![],
  title: "Update\x20Rotation",
});
DynamicElement[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x26c"), {
  type: _0x40b4("0x9f"),
  default: !![],
  title: _0x40b4("0x26d"),
});
DynamicElement["attributes"][_0x40b4("0x2e")](_0x40b4("0x38"), {
  type: _0x40b4("0x9f"),
  default: ![],
  title: "Debug",
});
pc[_0x40b4("0x1")](DynamicElement[_0x40b4("0x2")], {
  initialize: function () {
    this[_0x40b4("0x26e")] = "";
    this[_0x40b4("0x26f")] = "";
    this["on"](_0x40b4("0x270"), this[_0x40b4("0x271")], this);
    this[_0x40b4("0x272")](
      ViewportManager["instance"][_0x40b4("0x273")](),
      window[_0x40b4("0x79")],
      window[_0x40b4("0x7a")],
      ViewportManager[_0x40b4("0xca")]["getDevice"]()
    );
    this["app"]["on"](_0x40b4("0x274"), this[_0x40b4("0x272")], this);
    this["on"](_0x40b4("0x1b0"), this["onDestroy"], this);
  },
  onAttributeChange(_0x4957e5, _0x192d90) {
    window[_0x40b4("0x3")][_0x40b4("0x56")](_0x4957e5, _0x192d90);
    this["_onResize"](
      ViewportManager[_0x40b4("0xca")]["getOrientation"](),
      window[_0x40b4("0x79")],
      window[_0x40b4("0x7a")],
      ViewportManager[_0x40b4("0xca")][_0x40b4("0x275")]()
    );
  },
  onDestroy: function () {
    this[_0x40b4("0xd6")][_0x40b4("0x100")](
      _0x40b4("0x274"),
      this["_onResize"],
      this
    );
  },
  _setCurrentProperties: function (_0x139049, _0x3eae14) {
    this["_orientation"] = _0x139049;
    this[_0x40b4("0x26f")] = _0x3eae14;
  },
  _onResize: function (_0x4febe6, _0x1a7761, _0xac3ae3, _0x2ce964) {
    this["_setCorrectOrientation"](_0x4febe6 || _0x40b4("0x7b"), _0x2ce964);
  },
  _setCorrectOrientation: function (_0x40d0d2, _0x4e1787) {
    this[_0x40b4("0x276")](_0x40d0d2, _0x4e1787);
    if (_0x4e1787 === deviceEnum[_0x40b4("0x277")]) {
      if (this["_orientation"] === orientationEnum["LANDSCAPE"]) {
        this[_0x40b4("0x278")](
          this[_0x40b4("0x249")],
          this[_0x40b4("0x250")],
          this[_0x40b4("0x252")],
          this["desktopLandscapeScale"],
          this[_0x40b4("0x24c")],
          this[_0x40b4("0x24e")]
        );
        return;
      }
      if (this[_0x40b4("0x26e")] === orientationEnum["PORTRAIT"]) {
        this["_applyOrientationTransform"](
          this[_0x40b4("0x256")],
          this[_0x40b4("0x279")],
          this[_0x40b4("0x25b")],
          this[_0x40b4("0x25c")],
          this[_0x40b4("0x257")],
          this[_0x40b4("0x259")]
        );
        return;
      }
      console[_0x40b4("0x7")](
        _0x40b4("0x27a"),
        this[_0x40b4("0x26e")],
        _0x40b4("0x9a")
      );
      return;
    }
    if (_0x4e1787 === deviceEnum["MOBILE"]) {
      if (this[_0x40b4("0x26e")] === orientationEnum[_0x40b4("0x27b")]) {
        this["_applyOrientationTransform"](
          this[_0x40b4("0x25e")],
          this["mobileLandscapePosition"],
          this["mobileLandscapeRotation"],
          this[_0x40b4("0x262")],
          this[_0x40b4("0x25f")],
          this[_0x40b4("0x260")]
        );
        return;
      }
      if (this["_orientation"] === orientationEnum["PORTRAIT"]) {
        this[_0x40b4("0x278")](
          this[_0x40b4("0x264")],
          this[_0x40b4("0x267")],
          this[_0x40b4("0x268")],
          this[_0x40b4("0x269")],
          this[_0x40b4("0x265")],
          this[_0x40b4("0x266")]
        );
        return;
      }
      console[_0x40b4("0x7")](
        _0x40b4("0x27a"),
        this[_0x40b4("0x26e")],
        _0x40b4("0x9a")
      );
      return;
    }
    console["warn"](_0x40b4("0x27c"), _0x4e1787, _0x40b4("0x9a"));
  },
  _applyOrientationTransform: function (
    _0x4d6c4b,
    _0x324bb6,
    _0x4e6b81,
    _0x2d131c,
    _0x1d5742,
    _0x40eca7
  ) {
    if (this[_0x40b4("0x38")]) {
      window["famobi"][_0x40b4("0x56")](_0x40b4("0x278"));
    }
    if (typeof _0x4d6c4b !== _0x40b4("0x86")) {
      console[_0x40b4("0x198")](
        "Preset\x20should\x20be\x20a\x20string",
        _0x4d6c4b
      );
      return;
    }
    var _0x4909ef = ElementPresetEnum[_0x4d6c4b];
    if (!_0x4909ef) {
      console[_0x40b4("0x198")](_0x40b4("0x27d"), _0x4d6c4b, _0x4909ef);
      return;
    }
    if (this[_0x40b4("0xb8")]["element"] === undefined) {
      window[_0x40b4("0x3")][_0x40b4("0x56")](_0x40b4("0x27e"));
      return;
    }
    if (_0x4909ef[_0x40b4("0x27f")]) {
      this[_0x40b4("0xb8")]["element"]["anchor"][_0x40b4("0x15d")](
        _0x4909ef[_0x40b4("0x27f")]["x"],
        _0x4909ef["anchor"]["y"],
        _0x4909ef[_0x40b4("0x27f")]["z"],
        _0x4909ef["anchor"]["w"]
      );
    } else {
      this[_0x40b4("0xb8")][_0x40b4("0x154")][_0x40b4("0x27f")]["set"](
        _0x1d5742["x"],
        _0x1d5742["y"],
        _0x1d5742["z"],
        _0x1d5742["w"]
      );
    }
    if (_0x4909ef[_0x40b4("0x280")]) {
      this["entity"][_0x40b4("0x154")][_0x40b4("0x280")][_0x40b4("0x15d")](
        _0x4909ef["pivot"]["x"],
        _0x4909ef[_0x40b4("0x280")]["y"]
      );
    } else {
      this[_0x40b4("0xb8")]["element"][_0x40b4("0x280")][_0x40b4("0x15d")](
        _0x40eca7["x"],
        _0x40eca7["y"]
      );
    }
    if (this["debug"]) {
      window[_0x40b4("0x3")][_0x40b4("0x56")](
        this[_0x40b4("0xb8")][_0x40b4("0x154")][_0x40b4("0x27f")],
        this["entity"][_0x40b4("0x154")][_0x40b4("0x280")],
        _0x324bb6
      );
    }
    this[_0x40b4("0xb8")][_0x40b4("0x154")][_0x40b4("0x27f")] =
      this["entity"][_0x40b4("0x154")]["anchor"];
    this[_0x40b4("0xb8")]["element"][_0x40b4("0x280")] =
      this[_0x40b4("0xb8")][_0x40b4("0x154")]["pivot"];
    if (this[_0x40b4("0x26a")])
      this[_0x40b4("0xb8")]["setLocalPosition"](_0x324bb6);
    if (this["updateRotation"])
      this[_0x40b4("0xb8")][_0x40b4("0x17a")](_0x4e6b81);
    if (this[_0x40b4("0x26c")]) this["entity"][_0x40b4("0x184")](_0x2d131c);
  },
  getScale: function () {
    if (this["_device"] === deviceEnum["DESKTOP"]) {
      if (this[_0x40b4("0x26e")] === orientationEnum[_0x40b4("0x27b")]) {
        return this[_0x40b4("0x254")];
      }
      if (this[_0x40b4("0x26e")] === orientationEnum["PORTRAIT"]) {
        return this[_0x40b4("0x25c")];
      }
    }
    if (this[_0x40b4("0x26f")] === deviceEnum["MOBILE"]) {
      if (this["_orientation"] === orientationEnum[_0x40b4("0x27b")]) {
        return this[_0x40b4("0x262")];
      }
      if (this["_orientation"] === orientationEnum["PORTRAIT"]) {
        return this[_0x40b4("0x269")];
      }
    }
  },
  getPosition: function () {
    if (this["_device"] === deviceEnum["DESKTOP"]) {
      if (this[_0x40b4("0x26e")] === orientationEnum[_0x40b4("0x27b")]) {
        return this[_0x40b4("0x250")];
      }
      if (this["_orientation"] === orientationEnum["PORTRAIT"]) {
        return this[_0x40b4("0x279")];
      }
    }
    if (this[_0x40b4("0x26f")] === deviceEnum["MOBILE"]) {
      if (this[_0x40b4("0x26e")] === orientationEnum[_0x40b4("0x27b")]) {
        return this[_0x40b4("0x281")];
      }
      if (this[_0x40b4("0x26e")] === orientationEnum["PORTRAIT"]) {
        return this[_0x40b4("0x267")];
      }
    }
  },
});
var NotificationBadge = pc[_0x40b4("0x2a")](_0x40b4("0x282"));
NotificationBadge[_0x40b4("0x2d")][_0x40b4("0x2e")]("id", {
  type: "string",
  default: _0x40b4("0x283"),
  description: _0x40b4("0x284"),
});
NotificationBadge[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x285"), {
  type: _0x40b4("0xb8"),
  description:
    "Optional:\x20A\x20text\x20entity\x20in\x20the\x20notification\x20badge\x20that\x20needs\x20to\x20be\x20changed.",
});
NotificationBadge["attributes"]["add"]("tween", {
  type: _0x40b4("0x86"),
  enum: [
    { None: "null" },
    { "Tween Scale": _0x40b4("0x17b") },
    { "Tween Position": "tweenPosition" },
    { "Tween Rotation": "tweenRotation" },
    { "Tween Alpha": _0x40b4("0x137") },
  ],
});
NotificationBadge[_0x40b4("0x2d")]["add"]("disableOnClick", {
  type: _0x40b4("0x9f"),
  default: ![],
  description: _0x40b4("0x286"),
});
NotificationBadge[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x287"), {
  type: "entity",
});
pc[_0x40b4("0x1")](NotificationBadge[_0x40b4("0x2")], {
  initialize: function () {
    NotificationBadgeManager["instance"]["initializeBadge"](
      this[_0x40b4("0xb8")],
      this["id"]
    );
    this[_0x40b4("0x288")]();
  },
  postInitialize: function () {
    this[_0x40b4("0x289")]();
  },
  _setDisableEvent: function () {
    if (this[_0x40b4("0x28a")]) {
      if (this["buttonEntity"]) {
        if (
          this[_0x40b4("0x287")][_0x40b4("0x1a9")] &&
          this[_0x40b4("0x287")]["script"][_0x40b4("0x28b")]
        ) {
          this[_0x40b4("0x287")][_0x40b4("0x1a9")][_0x40b4("0x28b")]["on"](
            _0x40b4("0x28c"),
            this[_0x40b4("0x28d")],
            this
          );
        } else {
          this[_0x40b4("0x287")][_0x40b4("0x154")]["on"](
            _0x40b4("0x28c"),
            this["disable"],
            this
          );
        }
      } else {
        if (this["entity"][_0x40b4("0x1e6")][_0x40b4("0x154")]) {
          this[_0x40b4("0xb8")][_0x40b4("0x1e6")][_0x40b4("0x154")]["on"](
            _0x40b4("0x28c"),
            this[_0x40b4("0x28d")],
            this
          );
        } else {
          console[_0x40b4("0x7")](
            "No\x20viable\x20button\x20could\x20be\x20found."
          );
        }
      }
    }
  },
  setState: function (_0x2cb94c) {
    if (!_0x2cb94c) {
      _0x2cb94c = NotificationBadgeManager[_0x40b4("0xca")][
        "getBadgeProperties"
      ](this["id"]);
    }
    if (!_0x2cb94c) {
      console[_0x40b4("0x7")](_0x40b4("0x28e"), this["id"]);
      return;
    }
    this[_0x40b4("0xb8")][_0x40b4("0xd4")] = _0x2cb94c["enabled"];
    if (this["entity"][_0x40b4("0xd4")]) {
      this["_startTween"]();
    } else {
      this["_stopTween"]();
    }
    if (this[_0x40b4("0x285")] && this[_0x40b4("0x285")][_0x40b4("0x154")]) {
      this["textEntity"][_0x40b4("0x154")]["text"] =
        _0x2cb94c[_0x40b4("0x28f")];
    }
  },
  _startTween: function () {
    if (this[_0x40b4("0xf1")] && this[_0x40b4("0xf1")] !== _0x40b4("0x290")) {
      if (this[_0x40b4("0xb8")][_0x40b4("0x1a9")][this[_0x40b4("0xf1")]]) {
        this["entity"][_0x40b4("0x1a9")][this[_0x40b4("0xf1")]][
          _0x40b4("0x16b")
        ]();
      } else {
        console[_0x40b4("0x7")](
          this["entity"][_0x40b4("0x153")],
          _0x40b4("0x291"),
          this[_0x40b4("0xf1")]
        );
      }
    }
  },
  _stopTween: function () {},
  disable: function () {
    this[_0x40b4("0xb8")]["enabled"] = ![];
    NotificationBadgeManager[_0x40b4("0xca")]["setBadgeProperties"](
      this["id"],
      ![]
    );
  },
});
var NotificationBadgeManager = pc[_0x40b4("0x2a")]("notificationBadgeManager");
pc[_0x40b4("0x1")](NotificationBadgeManager[_0x40b4("0x2")], {
  initialize: function () {
    if (Singleton[_0x40b4("0xca")][_0x40b4("0x10d")](this)) {
      NotificationBadgeManager["instance"] = this;
    }
    this["_badgeStates"] = Object[_0x40b4("0x239")]({
      DISABLED: ![],
      ENABLED: !![],
    });
    this["_notificationBadges"] = {};
    this[_0x40b4("0xd6")]["on"](_0x40b4("0x292"), this[_0x40b4("0x293")], this);
  },
  initializeBadge: function (_0x16c756, _0xd930fd) {
    if (this[_0x40b4("0x294")][_0xd930fd] || _0xd930fd === _0x40b4("0x283")) {
      console[_0x40b4("0x7")](
        "Change\x20the\x20id\x20of\x20the\x20notification\x20badge\x20with\x20the\x20id",
        _0xd930fd
      );
      return;
    }
    this[_0x40b4("0x294")][_0xd930fd] = {
      enabled: this[_0x40b4("0x295")][_0x40b4("0x296")],
      text: null,
      entity: _0x16c756,
    };
  },
  setBadgeProperties: function (_0x3d344a, _0x160978, _0x55cc89) {
    var _0x4c666f = this[_0x40b4("0x294")][_0x3d344a];
    if (!_0x4c666f) {
      window[_0x40b4("0x3")][_0x40b4("0x56")](
        _0x40b4("0x28e"),
        _0x3d344a,
        _0x40b4("0x297")
      );
      return;
    }
    _0x4c666f["enabled"] = _0x160978;
    if (_0x55cc89) {
      _0x4c666f[_0x40b4("0x28f")] = _0x55cc89;
    }
    _0x4c666f[_0x40b4("0xb8")][_0x40b4("0x1a9")]["notificationBadge"][
      "setState"
    ](_0x4c666f);
  },
  getBadgeProperties: function (_0x429b40) {
    return this["_notificationBadges"][_0x429b40];
  },
});
var PauseScreen = pc[_0x40b4("0x2a")](_0x40b4("0x298"));
pc[_0x40b4("0x1")](PauseScreen[_0x40b4("0x2")], {
  onUIEntityOpen: function () {
    PauseManager[_0x40b4("0xca")][_0x40b4("0x11a")]();
  },
  onUIEntityClose: function () {
    PauseManager[_0x40b4("0xca")][_0x40b4("0x299")]();
  },
});
var ViewportManager = pc[_0x40b4("0x2a")](_0x40b4("0x29a"));
ViewportManager[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x222"), {
  type: "number",
  default: 0x1f4,
  title: _0x40b4("0x29b"),
  description: _0x40b4("0x29c"),
  placeholder: "ms",
});
ViewportManager[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x29d"), {
  type: _0x40b4("0x34"),
  default: 0x12c,
  title: _0x40b4("0x29e"),
  description:
    "Time\x20till\x20the\x20dimension\x20of\x20the\x20viewport\x20is\x20recalculated.",
  placeholder: "ms",
});
pc[_0x40b4("0x1")](ViewportManager[_0x40b4("0x2")], {
  initialize: function () {
    if (Singleton[_0x40b4("0xca")][_0x40b4("0x10d")](this)) {
      ViewportManager["instance"] = this;
    }
    this[_0x40b4("0x29f")]();
    Wrapper[_0x40b4("0xca")][_0x40b4("0x2a0")](this[_0x40b4("0x2a1")], this);
  },
  onOrientationChange: function () {
    clearTimeout(this[_0x40b4("0x2a2")]);
    this[_0x40b4("0xd6")][_0x40b4("0x10e")](_0x40b4("0x2a3"));
    this["_timeout"] = setTimeout(
      this[_0x40b4("0x272")][_0x40b4("0xd")](this),
      this[_0x40b4("0x222")]
    );
  },
  _onResize: function () {
    const _0x3f9886 = this["getWidth"]();
    const _0x5137a4 = this[_0x40b4("0x2a4")]();
    this[_0x40b4("0xd6")][_0x40b4("0x2a5")](_0x3f9886, _0x5137a4);
    this["app"][_0x40b4("0x10e")](
      _0x40b4("0x274"),
      this[_0x40b4("0x273")](),
      _0x3f9886,
      _0x5137a4,
      this[_0x40b4("0x275")]()
    );
  },
  getDevice: function () {
    if (pc[_0x40b4("0x191")]["desktop"]) {
      return deviceEnum[_0x40b4("0x277")];
    }
    if (pc[_0x40b4("0x191")][_0x40b4("0x2a6")]) {
      return deviceEnum[_0x40b4("0x2a7")];
    }
    return "";
  },
  getOrientation: function () {
    var _0x8f1fef = Wrapper[_0x40b4("0xca")][_0x40b4("0x273")]();
    return _0x8f1fef && _0x8f1fef !== "" ? _0x8f1fef : _0x40b4("0x7b");
  },
  calculateDPR: function () {
    this["_dpr"] = Math[_0x40b4("0x2a8")](
      Math[_0x40b4("0x2a9")](
        window[_0x40b4("0x2aa")],
        this[_0x40b4("0xd6")][_0x40b4("0x2ab")]["maxPixelRatio"]
      ),
      0x1
    );
  },
  getDPR: function () {
    return this[_0x40b4("0x2ac")];
  },
  getWidth: function () {
    return window[_0x40b4("0x79")];
  },
  getHeight: function () {
    return window[_0x40b4("0x7a")];
  },
});
var deviceEnum = Object[_0x40b4("0x239")]({
  DESKTOP: _0x40b4("0x2ad"),
  MOBILE: _0x40b4("0x2a6"),
});
var orientationEnum = Object[_0x40b4("0x239")]({
  LANDSCAPE: _0x40b4("0x7b"),
  PORTRAIT: _0x40b4("0x7c"),
});
var ElementPresetEnum = Object["freeze"]({
  TOPLEFT: {
    anchor: new pc[_0x40b4("0x2ae")](0x0, 0x1, 0x0, 0x1),
    pivot: new pc[_0x40b4("0x15b")](0x0, 0x1),
  },
  TOPLEFT_ANCHOR: { anchor: new pc["Vec4"](0x0, 0x1, 0x0, 0x1) },
  TOP: {
    anchor: new pc["Vec4"](0.5, 0x1, 0.5, 0x1),
    pivot: new pc["Vec2"](0.5, 0x1),
  },
  TOP_ANCHOR: { anchor: new pc["Vec4"](0.5, 0x1, 0.5, 0x1) },
  TOPRIGHT: {
    anchor: new pc[_0x40b4("0x2ae")](0x1, 0x1, 0x1, 0x1),
    pivot: new pc["Vec2"](0x1, 0x1),
  },
  TOPRIGHT_ANCHOR: { anchor: new pc[_0x40b4("0x2ae")](0x1, 0x1, 0x1, 0x1) },
  LEFT: {
    anchor: new pc[_0x40b4("0x2ae")](0x0, 0.5, 0x0, 0.5),
    pivot: new pc[_0x40b4("0x15b")](0x0, 0.5),
  },
  LEFT_ANCHOR: { anchor: new pc[_0x40b4("0x2ae")](0x0, 0.5, 0x0, 0.5) },
  CENTER: {
    anchor: new pc[_0x40b4("0x2ae")](0.5, 0.5, 0.5, 0.5),
    pivot: new pc[_0x40b4("0x15b")](0.5, 0.5),
  },
  CENTER_ANCHOR: { anchor: new pc["Vec4"](0.5, 0.5, 0.5, 0.5) },
  RIGHT: {
    anchor: new pc[_0x40b4("0x2ae")](0x1, 0.5, 0x1, 0.5),
    pivot: new pc[_0x40b4("0x15b")](0x1, 0.5),
  },
  RIGHT_ANCHOR: { anchor: new pc["Vec4"](0x1, 0.5, 0x1, 0.5) },
  BOTTOMLEFT: {
    anchor: new pc[_0x40b4("0x2ae")](0x0, 0x0, 0x0, 0x0),
    pivot: new pc[_0x40b4("0x15b")](0x0, 0x0),
  },
  BOTTOMLEFT_ANCHOR: { anchor: new pc[_0x40b4("0x2ae")](0x0, 0x0, 0x0, 0x0) },
  BOTTOM: {
    anchor: new pc[_0x40b4("0x2ae")](0.5, 0x0, 0.5, 0x0),
    pivot: new pc[_0x40b4("0x15b")](0.5, 0x0),
  },
  BOTTOM_ANCHOR: { anchor: new pc["Vec4"](0.5, 0x0, 0.5, 0x0) },
  BOTTOMRIGHT: {
    anchor: new pc[_0x40b4("0x2ae")](0x1, 0x0, 0x1, 0x0),
    pivot: new pc[_0x40b4("0x15b")](0x1, 0x0),
  },
  BOTTOMRIGHT_ANCHOR: { anchor: new pc[_0x40b4("0x2ae")](0x1, 0x0, 0x1, 0x0) },
  NONE: {},
});
var LayoutOrientationEnum = Object["freeze"]({
  VERTICAL: pc[_0x40b4("0x2af")],
  HORIZONTAL: pc[_0x40b4("0x2b0")],
});
var DynamicGroup = pc["createScript"]("dynamicGroup");
DynamicGroup["attributes"][_0x40b4("0x2e")](_0x40b4("0x2b1"), {
  type: "boolean",
  default: !![],
});
DynamicGroup[_0x40b4("0x2d")][_0x40b4("0x2e")]("desktopClampWidth", {
  type: _0x40b4("0x34"),
  default: 0x5dc,
});
DynamicGroup[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x2b2"), {
  type: "boolean",
  default: ![],
});
DynamicGroup["attributes"][_0x40b4("0x2e")](_0x40b4("0x2b3"), {
  type: _0x40b4("0x34"),
  default: 0x0,
});
pc[_0x40b4("0x1")](DynamicGroup[_0x40b4("0x2")], {
  initialize: function () {
    this[_0x40b4("0x272")](
      ViewportManager[_0x40b4("0xca")][_0x40b4("0x273")](),
      window[_0x40b4("0x79")],
      window[_0x40b4("0x7a")],
      ViewportManager["instance"][_0x40b4("0x275")]()
    );
    this[_0x40b4("0xd6")]["on"](_0x40b4("0x274"), this[_0x40b4("0x272")], this);
    this["on"](_0x40b4("0x1b0"), this["onDestroy"], this);
  },
  onDestroy: function () {
    this["app"]["off"](_0x40b4("0x274"), this[_0x40b4("0x272")], this);
  },
  _onResize: function (_0x281733, _0x1a7659, _0x421bb1, _0x28f0cb) {
    this["_calculateDimensions"](_0x1a7659, _0x421bb1);
    this["_setClamp"](_0x28f0cb);
  },
  _calculateDimensions: function (_0x2ca5bf, _0x2860fe) {
    var _0x38696d =
      UIManager[_0x40b4("0xca")][_0x40b4("0x2b4")]()["y"] / _0x2860fe;
    if (!this[_0x40b4("0xb8")][_0x40b4("0x154")]) return;
    this["entity"]["element"][_0x40b4("0x2b5")] = _0x2ca5bf * _0x38696d;
    this[_0x40b4("0xb8")][_0x40b4("0x154")][_0x40b4("0x2b6")] =
      _0x2860fe * _0x38696d;
  },
  _setClamp: function (_0x3fcb0a) {
    var _0x8d94b8 = ![];
    var _0x3accea = 0x0;
    if (_0x3fcb0a === deviceEnum[_0x40b4("0x277")]) {
      _0x8d94b8 = this[_0x40b4("0x2b1")];
      _0x3accea = this[_0x40b4("0x2b7")];
    }
    if (_0x3fcb0a === deviceEnum["MOBILE"]) {
      _0x8d94b8 = this[_0x40b4("0x2b2")];
      _0x3accea = this[_0x40b4("0x2b3")];
    }
    if (_0x8d94b8) {
      var _0x3480f9 = this[_0x40b4("0xb8")]["element"][_0x40b4("0x2b5")];
      if (_0x3480f9 > _0x3accea) {
        this[_0x40b4("0xb8")]["element"][_0x40b4("0x2b5")] = _0x3accea;
      }
    }
    this["fire"](_0x40b4("0x2b8"));
  },
});
var InputManager = pc[_0x40b4("0x2a")](_0x40b4("0x2b9"));
InputManager[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x2ba"), {
  type: _0x40b4("0x9f"),
  default: !![],
  description: _0x40b4("0x2bb"),
  title: _0x40b4("0x2bc"),
});
InputManager["attributes"][_0x40b4("0x2e")]("preventDefault", {
  type: _0x40b4("0x9f"),
  default: !![],
  title: _0x40b4("0x2bd"),
});
InputManager[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x2be"), {
  type: _0x40b4("0x86"),
  array: !![],
  default: [_0x40b4("0x2bf"), "F5"],
});
pc["extend"](InputManager[_0x40b4("0x2")], {
  initialize: function () {
    if (Singleton[_0x40b4("0xca")][_0x40b4("0x10d")](this)) {
      InputManager["instance"] = this;
    }
    this[_0x40b4("0x2c0")] = pc["platform"][_0x40b4("0x2c1")];
    this[_0x40b4("0x2c2")] = !![];
    this[_0x40b4("0x2c3")] = document["hasFocus"]();
    window[_0x40b4("0x7d")](
      _0x40b4("0x112"),
      this[_0x40b4("0x2c4")]["bind"](this)
    );
    window["addEventListener"](
      _0x40b4("0x2c5"),
      this[_0x40b4("0x2c6")][_0x40b4("0xd")](this)
    );
    if (this[_0x40b4("0xd6")][_0x40b4("0x2c7")]) {
      if (this[_0x40b4("0x2ba")]) {
        this[_0x40b4("0xd6")]["mouse"][_0x40b4("0x2ba")]();
      }
      this[_0x40b4("0xd6")][_0x40b4("0x2c7")]["on"](
        pc[_0x40b4("0x2c8")],
        this[_0x40b4("0x2c9")],
        this
      );
      this[_0x40b4("0xd6")]["mouse"]["on"](
        pc[_0x40b4("0x2ca")],
        this["_onInput"],
        this
      );
      this[_0x40b4("0xd6")][_0x40b4("0x2c7")]["on"](
        pc[_0x40b4("0x2cb")],
        this["_onInput"],
        this
      );
    }
    if (this[_0x40b4("0xd6")][_0x40b4("0x2cc")]) {
      this[_0x40b4("0xd6")]["keyboard"]["on"](
        pc["EVENT_KEYDOWN"],
        this[_0x40b4("0x2cd")],
        this
      );
      this["app"][_0x40b4("0x2cc")]["on"](
        pc[_0x40b4("0x2ce")],
        this[_0x40b4("0x2cd")],
        this
      );
    }
    if (this[_0x40b4("0xd6")]["touch"]) {
      this["app"]["touch"]["on"](
        pc[_0x40b4("0x2cf")],
        this[_0x40b4("0x2c9")],
        this
      );
      this[_0x40b4("0xd6")]["touch"]["on"](
        pc[_0x40b4("0x2d0")],
        this[_0x40b4("0x2c9")],
        this
      );
      this[_0x40b4("0xd6")][_0x40b4("0x2c1")]["on"](
        pc[_0x40b4("0x2d1")],
        this[_0x40b4("0x2c9")],
        this
      );
      this["app"]["touch"]["on"](
        pc[_0x40b4("0x2d2")],
        this[_0x40b4("0x2c9")],
        this
      );
    }
  },
  _onFocus: function () {
    this["_hasFocus"] = !![];
  },
  _onBlur: function () {
    this[_0x40b4("0x2c3")] = ![];
  },
  _sendInputEvent: function (_0x326a63) {
    this["app"][_0x40b4("0x10e")](_0x40b4("0xdc"), _0x326a63);
  },
  _onInput: function (_0x3f012a) {
    this[_0x40b4("0x2d3")](_0x3f012a);
    this["_sendInputEvent"](_0x3f012a);
  },
  _onKeyInput: function (_0x2ceea1) {
    this[_0x40b4("0x2d4")](_0x2ceea1);
    this["_sendInputEvent"](_0x2ceea1);
  },
  getSupportTouch: function () {
    return this["_supportTouch"];
  },
  getSupportMouse: function () {
    return this[_0x40b4("0x2c2")];
  },
  keyboardPreventDefault: function (_0x39d344) {
    var _0xe5cea7 = this[_0x40b4("0x2be")][_0x40b4("0x1c0")](
      _0x39d344[_0x40b4("0xa8")][_0x40b4("0x2d5")]
    );
    if (_0xe5cea7 !== -0x1) {
      this[_0x40b4("0x2d3")](_0x39d344);
    }
  },
  doPreventDefault: function (_0x249bb0) {
    if (!_0x249bb0) {
      console[_0x40b4("0x7")](_0x40b4("0x2d6"));
      return;
    }
    if (this["preventDefault"] && this[_0x40b4("0x2c3")]) {
      _0x249bb0[_0x40b4("0xa8")]["preventDefault"]();
    }
  },
});
var ElementInput = pc[_0x40b4("0x2a")](_0x40b4("0x1ff"));
ElementInput["attributes"][_0x40b4("0x2e")]("inputDownEvent", {
  type: "boolean",
  default: ![],
  title: _0x40b4("0x2d7"),
  description: _0x40b4("0x2d8"),
});
ElementInput[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x2d9"), {
  type: _0x40b4("0x9f"),
  default: ![],
  title: _0x40b4("0x2da"),
  description: "Send\x20a\x20input\x20up\x20event",
});
ElementInput[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x2db"), {
  type: _0x40b4("0x9f"),
  default: !![],
  title: _0x40b4("0x2dc"),
  description: "Send\x20a\x20input\x20click\x20event",
});
ElementInput["attributes"][_0x40b4("0x2e")](_0x40b4("0x2dd"), {
  type: _0x40b4("0x9f"),
  default: ![],
  title: _0x40b4("0x2de"),
  description: _0x40b4("0x2df"),
});
ElementInput["attributes"]["add"]("clickSFX", {
  type: _0x40b4("0x86"),
  default: _0x40b4("0x2e0"),
});
ElementInput["attributes"][_0x40b4("0x2e")](_0x40b4("0x38"), {
  type: _0x40b4("0x9f"),
  default: ![],
});
var inputEvents = Object[_0x40b4("0x239")]({
  DOWN: "down",
  UP: "up",
  CLICK: _0x40b4("0x28c"),
  MOVE: "move",
});
pc[_0x40b4("0x1")](ElementInput[_0x40b4("0x2")], {
  initialize: function () {
    this[_0x40b4("0x2e1")] = InputManager[_0x40b4("0xca")][_0x40b4("0x2e2")]();
    this[_0x40b4("0x2e3")] = InputManager[_0x40b4("0xca")][_0x40b4("0x2e4")]();
    this["_element"] = this[_0x40b4("0xb8")][_0x40b4("0x154")];
    this[_0x40b4("0x2e5")] = this["entity"][_0x40b4("0x2e6")];
    this[_0x40b4("0x2e7")] = ![];
    this["_inputDown"] = ![];
    this[_0x40b4("0x2e8")]();
    this["_createElementEvents"]();
    this[_0x40b4("0x2e9")] = [];
  },
  update: function () {
    if (this["_events"][_0x40b4("0x87")] > 0x0) {
      this[_0x40b4("0x2e9")][_0x40b4("0x156")]((_0x2650df) => {
        this["fire"](_0x2650df[_0x40b4("0x2ea")], _0x2650df[_0x40b4("0xa8")]);
      });
      this["_events"][_0x40b4("0x87")] = 0x0;
    }
  },
  _createButtonEvents: function () {
    this["on"](_0x40b4("0x2eb"), this["_resetButton"], this);
  },
  _resetButton: function () {
    if (this[_0x40b4("0x2e5")]) {
      this[_0x40b4("0x2e5")]["_isHovering"] = ![];
    }
  },
  _createElementEvents: function () {
    if (!this[_0x40b4("0x2ec")]) {
      console[_0x40b4("0x7")](
        _0x40b4("0x2ed"),
        this["entity"][_0x40b4("0x153")],
        _0x40b4("0x2ee")
      );
      return;
    }
    if (!this[_0x40b4("0x2ec")][_0x40b4("0x2ef")]) {
    }
    if (this[_0x40b4("0x2e1")]) {
      this[_0x40b4("0x2ec")]["on"](
        pc[_0x40b4("0x2d2")],
        this[_0x40b4("0x2f0")],
        this
      );
      this[_0x40b4("0x2ec")]["on"](
        pc[_0x40b4("0x2d1")],
        this[_0x40b4("0x2f1")],
        this
      );
      this[_0x40b4("0x2ec")]["on"](
        _0x40b4("0x2f2"),
        this[_0x40b4("0x2f3")],
        this
      );
      this[_0x40b4("0x2ec")]["on"](
        pc[_0x40b4("0x2d0")],
        this["_onTouchEnd"],
        this
      );
    }
    if (this[_0x40b4("0x2e3")]) {
      this["_element"]["on"](pc[_0x40b4("0x2c8")], this["_onMouseDown"], this);
      this[_0x40b4("0x2ec")]["on"](
        pc["EVENT_MOUSEMOVE"],
        this[_0x40b4("0x2f4")],
        this
      );
      this[_0x40b4("0x2ec")]["on"](
        _0x40b4("0x2f5"),
        this["_onMouseLeave"],
        this
      );
      this[_0x40b4("0x2ec")]["on"](
        _0x40b4("0x2f6"),
        this["_onMouseEnter"],
        this
      );
      this[_0x40b4("0x2ec")]["on"](
        pc[_0x40b4("0x2ca")],
        this["_onMouseUp"],
        this
      );
    }
  },
  _onTouchStart: function (_0x34f9fb) {
    if (!this["getButtonActive"]()) return;
    this["_inputDown"] = !![];
    this[_0x40b4("0x2e7")] = !![];
    this[_0x40b4("0x2f7")](_0x34f9fb);
    this[_0x40b4("0x10e")](
      _0x40b4("0x2f8"),
      this[_0x40b4("0x2f9")],
      this[_0x40b4("0x2e7")],
      this[_0x40b4("0x2fa")]()
    );
  },
  _onTouchEnd: function (_0x43df03) {
    if (!this[_0x40b4("0x2fa")]()) return;
    this[_0x40b4("0x2fb")](_0x43df03);
    if (this[_0x40b4("0x2e5")]) {
      this[_0x40b4("0x2e5")][_0x40b4("0x2fc")](_0x43df03);
    }
    if (this[_0x40b4("0x2e7")] && this[_0x40b4("0x2f9")]) {
      this[_0x40b4("0x2fd")](_0x43df03);
    }
    this["_enter"] = ![];
    this[_0x40b4("0x2f9")] = ![];
    this[_0x40b4("0x10e")](
      _0x40b4("0x2f8"),
      this["_inputDown"],
      this[_0x40b4("0x2e7")],
      this["getButtonActive"]()
    );
  },
  _onTouchLeave: function (_0x2f5790) {
    if (!this["getButtonActive"]()) return;
    this[_0x40b4("0x2e7")] = ![];
    this[_0x40b4("0x2f9")] = ![];
    this[_0x40b4("0x10e")](
      _0x40b4("0x2f8"),
      this[_0x40b4("0x2f9")],
      this[_0x40b4("0x2e7")],
      this["getButtonActive"]()
    );
  },
  _onTouchMove: function () {
    if (!this[_0x40b4("0x2fa")]()) return;
    if (this[_0x40b4("0x2e7")]) {
      this[_0x40b4("0x2fe")](event);
    }
  },
  _onMouseDown: function (_0x2c6580) {
    if (!this["getButtonActive"]()) return;
    this[_0x40b4("0x2f9")] = !![];
    this[_0x40b4("0x2e7")] = !![];
    this[_0x40b4("0x2f7")](_0x2c6580);
    this["fire"](
      _0x40b4("0x2f8"),
      this[_0x40b4("0x2f9")],
      this[_0x40b4("0x2e7")],
      this[_0x40b4("0x2fa")]()
    );
  },
  _onMouseLeave: function (_0x5a45a2) {
    if (!this[_0x40b4("0x2fa")]()) return;
    this[_0x40b4("0x2e7")] = ![];
    this[_0x40b4("0x2f9")] = ![];
    this[_0x40b4("0x10e")](
      "onButtonInputChange",
      this[_0x40b4("0x2f9")],
      this[_0x40b4("0x2e7")],
      this[_0x40b4("0x2fa")]()
    );
  },
  _onMouseEnter: function (_0x12c294) {
    if (!this[_0x40b4("0x2fa")]()) return;
    this["_enter"] = !![];
    this[_0x40b4("0x10e")](
      _0x40b4("0x2f8"),
      this[_0x40b4("0x2f9")],
      this[_0x40b4("0x2e7")],
      this["getButtonActive"]()
    );
  },
  _onMouseMove: function (_0x5f12d6) {
    if (!this["getButtonActive"]()) return;
    if (this["_inputDown"] && this[_0x40b4("0x2e7")]) {
      this["_sendMoveEvent"](_0x5f12d6);
    }
  },
  _onMouseUp: function (_0x515e21) {
    if (!this[_0x40b4("0x2fa")]()) return;
    this[_0x40b4("0x2fb")](_0x515e21);
    if (this[_0x40b4("0x2e7")] && this[_0x40b4("0x2f9")]) {
      this[_0x40b4("0x2fd")](_0x515e21);
    }
    this["_enter"] = ![];
    this["_inputDown"] = ![];
    this["fire"](
      _0x40b4("0x2f8"),
      this[_0x40b4("0x2f9")],
      this[_0x40b4("0x2e7")],
      this[_0x40b4("0x2fa")]()
    );
  },
  _sendMoveEvent: function (_0x2fd5d0) {
    if (this[_0x40b4("0x2dd")]) {
      this["addEvent"](inputEvents[_0x40b4("0x2ff")], _0x2fd5d0);
    }
  },
  _sendDownEvent: function (_0x46f56d) {
    if (this[_0x40b4("0x300")]) {
      this[_0x40b4("0x301")](inputEvents[_0x40b4("0x302")], _0x46f56d);
    }
  },
  _sendUpEvent: function (_0x26222e) {
    if (this[_0x40b4("0x2d9")]) {
      this["addEvent"](inputEvents["UP"], _0x26222e);
    }
  },
  _sendClickEvent: function (_0x49fa76) {
    if (this[_0x40b4("0x2db")]) {
      if (this["clickSFX"]) {
        AudioManager[_0x40b4("0xca")][_0x40b4("0xe6")](this[_0x40b4("0x303")]);
      }
      if (this["debug"]) {
        console["warn"](_0x40b4("0x28c"));
      }
      this[_0x40b4("0x301")](inputEvents["CLICK"], _0x49fa76);
    }
  },
  setActive: function (_0x1e3232) {
    this[_0x40b4("0x2e5")][_0x40b4("0x304")] = _0x1e3232;
    this[_0x40b4("0x10e")](
      _0x40b4("0x2f8"),
      this[_0x40b4("0x2f9")],
      this["_enter"],
      this[_0x40b4("0x2fa")]()
    );
  },
  getButtonActive: function () {
    if (this[_0x40b4("0x2e5")]) {
      return this[_0x40b4("0x2e5")][_0x40b4("0x304")];
    } else {
      return !![];
    }
  },
  addEvent(_0x3340c5, _0x1761ab) {
    this[_0x40b4("0x2e9")][_0x40b4("0x18")]({
      inputEvent: _0x3340c5,
      event: _0x1761ab,
    });
  },
});
var Wrapper = pc[_0x40b4("0x2a")](_0x40b4("0x305"));
Wrapper[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x306"), {
  type: "string",
  enum: [{ DEFAULT: _0x40b4("0x307") }, { FAMOBI: _0x40b4("0x0") }],
});
pc[_0x40b4("0x1")](Wrapper["prototype"], {
  initialize: function () {
    Wrapper["instance"] = this;
    this["_script"] = this["_getAPIScript"]();
  },
  _getAPIScript: function () {
    if (!this[_0x40b4("0xb8")][_0x40b4("0x1a9")][this[_0x40b4("0x306")]]) {
      console["warn"]("There\x20is\x20no\x20api\x20script", this["api"]);
      return;
    }
    return this["entity"][_0x40b4("0x1a9")][this["api"]];
  },
  getBrandingButtonImage: function () {
    return this[_0x40b4("0x308")]["getBrandingButtonImage"]();
  },
  moreGamesLink: function () {
    this["_script"]["moreGamesLink"]();
  },
  showAd: function () {
    return this[_0x40b4("0x308")][_0x40b4("0xa")]();
  },
  showInterstitialAd: function () {
    return this[_0x40b4("0x308")][_0x40b4("0x9")]();
  },
  hasRewardedAd: function () {
    return this[_0x40b4("0x308")]["hasRewardedAd"]();
  },
  rewardedAd: function (_0x4443d9, _0x17ec79) {
    this[_0x40b4("0x308")]["rewardedAd"](_0x4443d9["bind"](_0x17ec79));
  },
  setOnPauseRequested: function (_0x324ec6, _0x141e8c) {
    this[_0x40b4("0x308")][_0x40b4("0x309")](_0x324ec6, _0x141e8c);
  },
  setOnResumeRequested: function (_0x51681c, _0x2dd174) {
    this[_0x40b4("0x308")][_0x40b4("0x30a")](_0x51681c, _0x2dd174);
  },
  get: function (_0x3fb5d2) {
    return this["_script"][_0x40b4("0x75")](_0x3fb5d2);
  },
  getCurrentLanguage: function () {
    return this[_0x40b4("0x308")][_0x40b4("0xf")]();
  },
  setLocalStorageItem: function (_0x464c5e, _0x587887) {
    this["_script"][_0x40b4("0x30b")](_0x464c5e, JSON["stringify"](_0x587887));
  },
  getLocalStorageItem: function (_0x553000) {
    try {
      return JSON[_0x40b4("0x30c")](
        this[_0x40b4("0x308")][_0x40b4("0x30d")](_0x553000)
      );
    } catch (_0x4d02c5) {
      return this[_0x40b4("0x308")][_0x40b4("0x30d")](_0x553000);
    }
  },
  removeLocalStorageItem: function (_0x417912) {
    this[_0x40b4("0x308")]["removeLocalStorageItem"](_0x417912);
  },
  clearLocalStorage: function () {
    this[_0x40b4("0x308")][_0x40b4("0x30e")]();
  },
  localStorageHasKey: function () {
    this[_0x40b4("0x308")][_0x40b4("0x30f")]();
  },
  setSessionStorageItem: function (_0x13274c, _0x7b1da4) {
    this["_script"][_0x40b4("0x310")](_0x13274c, JSON["stringify"](_0x7b1da4));
  },
  getSessionStorageItem: function (_0xe1e3be) {
    try {
      return JSON[_0x40b4("0x30c")](
        this[_0x40b4("0x308")][_0x40b4("0x311")](_0xe1e3be)
      );
    } catch (_0x1375f4) {
      return this[_0x40b4("0x308")][_0x40b4("0x311")](_0xe1e3be);
    }
  },
  removeSessionStorageItem: function (_0x4b96e6) {
    this["_script"][_0x40b4("0x312")](_0x4b96e6);
  },
  clearSessionStorage: function () {
    this[_0x40b4("0x308")][_0x40b4("0x313")]();
  },
  getOrientation: function () {
    return this[_0x40b4("0x308")][_0x40b4("0x273")]();
  },
  setOnOrientationChange: function (_0xb289a0, _0x3ce3de) {
    this[_0x40b4("0x308")]["setOnOrientationChange"](
      _0xb289a0[_0x40b4("0xd")](_0x3ce3de)
    );
  },
  gameReady: function () {
    this[_0x40b4("0x308")][_0x40b4("0x6")]();
  },
  hasFeature: function (_0x5a41ba) {
    return this[_0x40b4("0x308")][_0x40b4("0x13")](_0x5a41ba);
  },
  onRequest: function (_0x9c376c, _0x21e9b4) {
    this[_0x40b4("0x308")]["onRequest"](_0x9c376c, _0x21e9b4);
  },
  getFeatureProperties: function (_0x2dd99f) {
    return this[_0x40b4("0x308")][_0x40b4("0x15")](_0x2dd99f);
  },
  getVolume: function () {
    return this[_0x40b4("0x308")][_0x40b4("0x16")]();
  },
  playerReady: function () {
    this[_0x40b4("0x308")]["playerReady"]();
  },
  levelStart: function (..._0x22d02f) {
    return this[_0x40b4("0x308")][_0x40b4("0x133")](..._0x22d02f);
  },
  levelSuccess: function (..._0x193af7) {
    return this["_script"][_0x40b4("0x314")](..._0x193af7);
  },
  levelFail: function (..._0x3c19b0) {
    return this[_0x40b4("0x308")]["levelFail"](..._0x3c19b0);
  },
  levelEnd: function (..._0x3a3681) {
    return this[_0x40b4("0x308")]["levelEnd"](..._0x3a3681);
  },
});
var boilerplateVersion = _0x40b4("0x315");
var type = "prod";
window[_0x40b4("0x3")][_0x40b4("0x56")](
  "%cWanted\x205\x20Games\x20Boilerplate\x20|\x20" +
    type +
    "\x20" +
    boilerplateVersion,
  _0x40b4("0x316")
);
var Singleton = pc[_0x40b4("0x2a")](_0x40b4("0x317"));
pc[_0x40b4("0x1")](Singleton["prototype"], {
  initialize: function () {
    if (this["canCreateInstance"](this)) {
      Singleton[_0x40b4("0xca")] = this;
    }
  },
  canCreateInstance: function (_0x5ea0ae) {
    var _0x25c38e = Object[_0x40b4("0x1d1")](_0x5ea0ae)[_0x40b4("0x1d2")];
    if (_0x25c38e[_0x40b4("0xca")]) {
      console[_0x40b4("0x198")](_0x40b4("0x318"), _0x25c38e[_0x40b4("0x319")]);
    }
    return !_0x25c38e[_0x40b4("0xca")];
  },
  createInstance: function (_0x3328fd, _0x1ed38d) {
    if (this[_0x40b4("0x10d")](_0x1ed38d)) {
      _0x3328fd["instance"] = _0x1ed38d;
    }
  },
});
var StorageManager = pc[_0x40b4("0x2a")](_0x40b4("0x31a"));
StorageManager[_0x40b4("0x2d")][_0x40b4("0x2e")]("defaultSaveData", {
  type: _0x40b4("0x45"),
  assetType: _0x40b4("0x46"),
});
pc["extend"](StorageManager[_0x40b4("0x2")], {
  initialize: function () {
    if (Singleton[_0x40b4("0xca")][_0x40b4("0x10d")](this)) {
      StorageManager[_0x40b4("0xca")] = this;
    }
    this[_0x40b4("0x31b")] = this[_0x40b4("0x31c")]["resource"];
    this[_0x40b4("0x31d")] = Object[_0x40b4("0x239")]({
      LOCALSTORAGE: _0x40b4("0x31e"),
      SESSIONSTORAGE: _0x40b4("0x31f"),
    });
    this[_0x40b4("0x320")] = {};
    this[_0x40b4("0x321")] = {};
    this[_0x40b4("0x322")]();
  },
  get: function (_0x3a7094, _0x1e1d1b) {
    _0x1e1d1b = _0x1e1d1b || _0x40b4("0x31e");
    switch (_0x1e1d1b[_0x40b4("0x323")]()) {
      case this["_storages"][_0x40b4("0x31e")]:
        return this[_0x40b4("0x320")][_0x3a7094];
      case this[_0x40b4("0x31d")][_0x40b4("0x31f")]:
        return this["_sessionStorage"][_0x3a7094];
      default:
        console[_0x40b4("0x7")](
          "Storage\x20is\x20" + _0x1e1d1b + _0x40b4("0x324")
        );
        return null;
    }
  },
  set: function (_0x30c126, _0x5105bb, _0x5979d7, _0xea742f) {
    _0x5979d7 = _0x5979d7 || ![];
    _0xea742f = _0xea742f || _0x40b4("0x4");
    if (_0x5979d7) {
      var _0x4b482f = this[_0x40b4("0x75")](_0x30c126);
      switch (typeof _0x5105bb) {
        case _0x40b4("0x34"):
          if (_0x5105bb <= _0x4b482f) {
            return;
          }
          break;
        default:
          break;
      }
    }
    this[_0x40b4("0x325")](_0x30c126, _0x5105bb, _0xea742f);
  },
  remove: function (_0x2aab36, _0xb46772) {
    this[_0x40b4("0x326")](_0xb46772)[_0x2aab36] =
      this[_0x40b4("0x31b")][_0x2aab36];
    switch (_0xb46772[_0x40b4("0x323")]()) {
      case this[_0x40b4("0x31d")][_0x40b4("0x31e")]:
        Wrapper[_0x40b4("0xca")][_0x40b4("0x327")](_0x2aab36);
        break;
      case this[_0x40b4("0x31d")][_0x40b4("0x31f")]:
        Wrapper["instance"]["removeSessionStorageItem"](_0x2aab36);
        break;
      default:
        console["warn"](
          "Storage\x20is\x20not\x20recognized.",
          "Key\x20is\x20" + _0x2aab36
        );
        break;
    }
  },
  delete: function (_0x147805) {
    var _0x154219 = this[_0x40b4("0x326")](_0x147805);
    _0x154219 = this["_basicInfo"];
    switch (_0x147805[_0x40b4("0x323")]()) {
      case this[_0x40b4("0x31d")][_0x40b4("0x31e")]:
        Wrapper[_0x40b4("0xca")][_0x40b4("0x30e")]();
        break;
      case this[_0x40b4("0x31d")][_0x40b4("0x31f")]:
        Wrapper["instance"]["clearSessionStorage"]();
        break;
      default:
        console[_0x40b4("0x7")](_0x40b4("0x328"));
        break;
    }
  },
  _writeToStorage: function (_0x44f047, _0x334e4b, _0x51f326) {
    this[_0x40b4("0x326")](_0x51f326)[_0x44f047] = _0x334e4b;
    switch (_0x51f326[_0x40b4("0x323")]()) {
      case this["_storages"][_0x40b4("0x31e")]:
        Wrapper[_0x40b4("0xca")][_0x40b4("0x30b")](
          _0x44f047,
          JSON[_0x40b4("0x8c")](_0x334e4b)
        );
        break;
      case this[_0x40b4("0x31d")]["SESSIONSTORAGE"]:
        Wrapper[_0x40b4("0xca")][_0x40b4("0x310")](
          _0x44f047,
          JSON["stringify"](_0x334e4b)
        );
        break;
      default:
        console[_0x40b4("0x7")](
          "Storage\x20is\x20not\x20recognized.",
          _0x40b4("0x329") + _0x44f047
        );
        break;
    }
  },
  _getStorage: function (_0x25e86e) {
    switch (_0x25e86e["toUpperCase"]()) {
      case this["_storages"][_0x40b4("0x31e")]:
        return this["_localStorage"];
      case this[_0x40b4("0x31d")]["SESSIONSTORAGE"]:
        return this[_0x40b4("0x320")];
      default:
        console[_0x40b4("0x7")](
          _0x40b4("0x32a") + _0x25e86e + _0x40b4("0x32b")
        );
        return null;
    }
  },
  loadSaveData: function () {
    var _0x8e5e9d = Object["keys"](this[_0x40b4("0x31b")]);
    for (
      var _0x6d7ea1 = 0x0;
      _0x6d7ea1 < _0x8e5e9d["length"];
      _0x6d7ea1 += 0x1
    ) {
      var _0xec9ef6 = _0x8e5e9d[_0x6d7ea1];
      var _0xf84a03 = Wrapper["instance"][_0x40b4("0x30d")](_0xec9ef6);
      try {
        this["_localStorage"][_0xec9ef6] = JSON[_0x40b4("0x30c")](_0xf84a03);
      } catch (_0x17c7e8) {
        this[_0x40b4("0x320")][_0xec9ef6] = _0xf84a03;
      }
      if (
        this[_0x40b4("0x320")][_0xec9ef6] === undefined ||
        this[_0x40b4("0x320")][_0xec9ef6] === null
      ) {
        this[_0x40b4("0x320")][_0xec9ef6] = this[_0x40b4("0x31b")][_0xec9ef6];
        this[_0x40b4("0x15d")](_0xec9ef6, this[_0x40b4("0x320")][_0xec9ef6]);
      }
      if (
        Array[_0x40b4("0x32c")](this[_0x40b4("0x31b")][_0xec9ef6]) &&
        !Array[_0x40b4("0x32c")](this[_0x40b4("0x320")][_0xec9ef6])
      ) {
        this[_0x40b4("0x320")][_0xec9ef6] = this["_basicInfo"][_0xec9ef6];
        this[_0x40b4("0x15d")](_0xec9ef6, this[_0x40b4("0x320")][_0xec9ef6]);
      }
      if (
        typeof this["_localStorage"][_0xec9ef6] !==
        typeof this["_basicInfo"][_0xec9ef6]
      ) {
        this["_localStorage"][_0xec9ef6] = this[_0x40b4("0x31b")][_0xec9ef6];
        this[_0x40b4("0x15d")](_0xec9ef6, this[_0x40b4("0x320")][_0xec9ef6]);
      }
    }
  },
});
var BrandingButton = pc[_0x40b4("0x2a")](_0x40b4("0x32d"));
pc[_0x40b4("0x1")](BrandingButton["prototype"], {
  initialize: function () {
    var _0x428e22 = window["famobi"][_0x40b4("0x8")]();
    if (!_0x428e22 || _0x428e22["length"] === 0x0) {
      this[_0x40b4("0xb8")][_0x40b4("0xd4")] = ![];
      return;
    }
    var _0xd7b096 = new pc["Asset"](_0x40b4("0x32e"), _0x40b4("0x194"), {
      url: _0x428e22,
    });
    this[_0x40b4("0x10e")](_0x40b4("0x32f"));
    this["app"][_0x40b4("0x5d")][_0x40b4("0x2e")](_0xd7b096);
    LazyLoader[_0x40b4("0xca")][_0x40b4("0x330")](
      _0xd7b096,
      this[_0x40b4("0x331")],
      this
    );
    this[_0x40b4("0xb8")][_0x40b4("0x154")]["on"](
      _0x40b4("0x332"),
      this["onRelease"],
      this
    );
    this[_0x40b4("0xb8")][_0x40b4("0x154")]["on"](
      _0x40b4("0x333"),
      this["onRelease"],
      this
    );
  },
  onLoadedAsset: function (_0x146f95) {
    this[_0x40b4("0xb8")][_0x40b4("0x154")][_0x40b4("0x155")] = 0x1;
    this[_0x40b4("0xb8")][_0x40b4("0x154")][_0x40b4("0x194")] =
      _0x146f95["resource"];
  },
  onRelease: function () {
    window[_0x40b4("0x3")]["openBrandingLink"]();
  },
});
(function () {
  var _0x493a79 = {};
  var _0xe85dd2 = 0x0;
  pc[_0x40b4("0x334")] = {};
  pc[_0x40b4("0x334")][_0x40b4("0x2e")] = function (
    _0x383e63,
    _0x585661,
    _0x524244
  ) {
    if (_0x383e63 > 0x0) {
      var _0x417ccb = {};
      _0x417ccb["id"] = _0xe85dd2;
      _0x493a79[_0xe85dd2] = {
        secsLeft: _0x383e63,
        callback: _0x585661,
        scope: _0x524244,
      };
      _0xe85dd2 += 0x1;
      return _0x417ccb;
    } else {
      _0x585661[_0x40b4("0xef")](_0x524244);
    }
    return null;
  };
  pc[_0x40b4("0x334")]["remove"] = function (_0x2570e7) {
    if (_0x2570e7) {
      delete _0x493a79[_0x2570e7["id"]];
    }
  };
  pc["timer"][_0x40b4("0x236")] = function (_0x421ce4) {
    for (var _0x1fc2ed in _0x493a79) {
      var _0x5a7ebf = _0x493a79[_0x1fc2ed];
      _0x5a7ebf[_0x40b4("0x335")] -= _0x421ce4;
      if (_0x5a7ebf["secsLeft"] <= 0x0) {
        _0x5a7ebf[_0x40b4("0x336")][_0x40b4("0xef")](
          _0x5a7ebf[_0x40b4("0x337")]
        );
        delete _0x493a79[_0x1fc2ed];
      }
    }
  };
  var _0x3753c9 = pc[_0x40b4("0x5b")]["getApplication"]();
  if (_0x3753c9) {
    _0x3753c9["on"]("update", function (_0x339368) {
      pc[_0x40b4("0x334")][_0x40b4("0x236")](_0x339368);
    });
  }
})();
pc[_0x40b4("0x1")](pc[_0x40b4("0x16a")][_0x40b4("0x2")], {
  distanceSq(_0x2d0c0a) {
    const _0x2ac813 = this["x"] - _0x2d0c0a["x"];
    const _0x68466f = this["y"] - _0x2d0c0a["y"];
    const _0x4b3a07 = this["z"] - _0x2d0c0a["z"];
    return (
      _0x2ac813 * _0x2ac813 + _0x68466f * _0x68466f + _0x4b3a07 * _0x4b3a07
    );
  },
});
pc[_0x40b4("0x1")](String[_0x40b4("0x2")], {
  format: function () {
    var _0x415db3 = this,
      _0x5b7a75 = arguments[_0x40b4("0x87")];
    while (_0x5b7a75--) {
      _0x415db3 = _0x415db3[_0x40b4("0x60")](
        new RegExp("\x5c{" + _0x5b7a75 + "\x5c}", "gm"),
        arguments[_0x5b7a75]
      );
    }
    return _0x415db3;
  },
});
pc[_0x40b4("0x1")](pc["Entity"]["prototype"], {
  findScripts: function (_0x3dcc8b, _0x4190c7) {
    _0x4190c7 = _0x4190c7 || [];
    if (this[_0x40b4("0x1a9")] && this["script"][_0x3dcc8b]) {
      _0x4190c7["push"](this["script"][_0x3dcc8b]);
    }
    if (this["children"]) {
      for (
        var _0x4e929c = 0x0;
        _0x4e929c < this[_0x40b4("0x1a8")]["length"];
        _0x4e929c++
      ) {
        if (this["children"][_0x4e929c] instanceof pc[_0x40b4("0x1ac")]) {
          this[_0x40b4("0x1a8")][_0x4e929c][_0x40b4("0x338")](
            _0x3dcc8b,
            _0x4190c7
          );
        }
      }
    }
    return _0x4190c7;
  },
  findLayers: function (_0x177bf2, _0x5b0240 = []) {
    if (
      this["element"] &&
      this[_0x40b4("0x154")]["layers"]["indexOf"](_0x177bf2) !== -0x1
    ) {
      _0x5b0240[_0x40b4("0x18")](this);
    }
    if (this[_0x40b4("0x1a8")]) {
      for (
        var _0x326680 = 0x0;
        _0x326680 < this[_0x40b4("0x1a8")][_0x40b4("0x87")];
        _0x326680++
      ) {
        if (this[_0x40b4("0x1a8")][_0x326680] instanceof pc[_0x40b4("0x1ac")]) {
          this["children"][_0x326680]["findLayer"](_0x177bf2, _0x5b0240);
        }
      }
    }
    return _0x5b0240;
  },
  setEulerAnglesComplex: function (_0x330b70, _0x250896, _0xc7bbdf) {
    pc[_0x40b4("0x1ac")]["QUAT_1"][_0x40b4("0x226")](_0x330b70, _0x250896, 0x0);
    pc[_0x40b4("0x1ac")][_0x40b4("0x339")]["setFromEulerAngles"](
      0x0,
      -_0xc7bbdf,
      0x0
    );
    pc["Entity"][_0x40b4("0x33a")]["mul"](
      pc[_0x40b4("0x1ac")][_0x40b4("0x339")]
    );
    this["setLocalRotation"](pc[_0x40b4("0x1ac")][_0x40b4("0x33a")]);
  },
});
pc[_0x40b4("0x1ac")][_0x40b4("0x33a")] = new pc[_0x40b4("0x21a")]();
pc["Entity"][_0x40b4("0x339")] = new pc[_0x40b4("0x21a")]();
var TrackingManager = pc[_0x40b4("0x2a")](_0x40b4("0x33b"));
TrackingManager[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x33c"), {
  type: _0x40b4("0x45"),
  assetType: _0x40b4("0x46"),
});
pc["extend"](TrackingManager[_0x40b4("0x2")], {
  initialize: function () {
    TrackingManager[_0x40b4("0xca")] = this;
    this[_0x40b4("0x33d")]();
    this[_0x40b4("0x33e")] = this[_0x40b4("0x33c")]["resource"];
    window[_0x40b4("0x9b")][_0x40b4("0x1d0")](
      this["_settings"][_0x40b4("0x33f")],
      this[_0x40b4("0x33e")][_0x40b4("0x340")],
      this[_0x40b4("0x33e")][_0x40b4("0x341")],
      this[_0x40b4("0x33e")]["enableLog"],
      this[_0x40b4("0x33e")][_0x40b4("0x342")]
    );
  },
  _resetData: function () {
    this[_0x40b4("0x343")] = {};
  },
  _levelUpdate: function () {
    window["famobi_tracking"][_0x40b4("0x1a")](
      window[_0x40b4("0x9b")][_0x40b4("0xa2")]["LEVEL_UPDATE"],
      this[_0x40b4("0x344")]()
    );
  },
  _levelEnd: function () {
    window[_0x40b4("0x9b")]["trackEvent"](
      window[_0x40b4("0x9b")][_0x40b4("0xa2")][_0x40b4("0x345")],
      this[_0x40b4("0x344")]()
    );
  },
  _getCurrentData: function () {
    return JSON[_0x40b4("0x30c")](
      JSON[_0x40b4("0x8c")](this[_0x40b4("0x343")])
    );
  },
  levelStart: function (_0x37d8f7) {
    this[_0x40b4("0x33d")]();
    this[_0x40b4("0x346")](_0x37d8f7);
    window[_0x40b4("0x9b")]["trackEvent"](
      window[_0x40b4("0x9b")][_0x40b4("0xa2")][_0x40b4("0x347")],
      this[_0x40b4("0x344")]()
    );
  },
  levelEnd: function (_0x4b46ff) {
    this[_0x40b4("0x346")](_0x4b46ff);
    this["_levelEnd"]();
  },
  levelUpdate: function (_0x3b8b12) {
    this[_0x40b4("0x346")](_0x3b8b12);
    this[_0x40b4("0x348")]();
  },
  setData(_0x292172) {
    const _0x130690 = Object[_0x40b4("0x95")](_0x292172);
    for (
      let _0x43abed = 0x0;
      _0x43abed < _0x130690[_0x40b4("0x87")];
      _0x43abed++
    ) {
      const _0x5c17b3 = _0x130690[_0x43abed];
      this[_0x40b4("0x343")][_0x5c17b3] = _0x292172[_0x5c17b3];
    }
  },
});
class Inventory extends pc[_0x40b4("0xb0")] {
  ["initialize"]() {
    Inventory["instance"] = this;
    this["data"] =
      StorageManager[_0x40b4("0xca")][_0x40b4("0x75")]("inventory");
    this[_0x40b4("0x95")] = Object[_0x40b4("0x95")](
      Inventory[_0x40b4("0x349")]
    );
    for (
      let _0x1719d7 = 0x0;
      _0x1719d7 < this["keys"][_0x40b4("0x87")];
      _0x1719d7++
    ) {
      let _0x23e000 = this["keys"][_0x1719d7];
      if (this[_0x40b4("0xa5")][_0x23e000] === undefined) {
        this[_0x40b4("0xa5")][_0x23e000] =
          Inventory[_0x40b4("0x349")][_0x23e000];
      }
    }
  }
  ["addItem"](_0x1801cb, _0x32d4bf = 0x1) {
    this[_0x40b4("0xa5")][_0x1801cb] += _0x32d4bf;
    this["fire"](
      _0x40b4("0x34a") + _0x1801cb,
      this[_0x40b4("0xa5")][_0x1801cb]
    );
  }
  [_0x40b4("0x78")](_0x2b28d4, _0x4e7864) {
    this[_0x40b4("0xa5")][_0x2b28d4] -= _0x4e7864;
    this["fire"](
      _0x40b4("0x34a") + _0x2b28d4,
      this[_0x40b4("0xa5")][_0x2b28d4]
    );
  }
  [_0x40b4("0x34b")](_0x1e1d4d, _0x11054b) {
    return this["data"][_0x1e1d4d] >= _0x11054b;
  }
  [_0x40b4("0x18f")]() {
    StorageManager[_0x40b4("0xca")][_0x40b4("0x15d")](
      _0x40b4("0x34c"),
      this[_0x40b4("0xa5")]
    );
  }
  ["getItem"](_0x101846) {
    return this[_0x40b4("0xa5")][_0x101846];
  }
}
pc[_0x40b4("0x1f4")](Inventory, _0x40b4("0x34c"));
Inventory[_0x40b4("0x349")] = { coins: 0x0 };
var Copyright = pc[_0x40b4("0x2a")](_0x40b4("0x34d"));
pc[_0x40b4("0x1")](Copyright["prototype"], {
  initialize: function () {
    let _0x331c65 = Wrapper[_0x40b4("0xca")][_0x40b4("0x13")](_0x40b4("0x34d"));
    if (_0x331c65) {
      this[_0x40b4("0xb8")][_0x40b4("0x154")][_0x40b4("0x28f")] =
        "(C)\x20Famobi";
    } else {
      this[_0x40b4("0xb8")][_0x40b4("0xd4")] = ![];
    }
  },
});
var ButtonComponentHelper = pc[_0x40b4("0x2a")](_0x40b4("0x34e"));
ButtonComponentHelper[_0x40b4("0x2d")]["add"](_0x40b4("0x34f"), {
  type: _0x40b4("0x350"),
  default: [0x1, 0x1, 0x1],
});
ButtonComponentHelper[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x351"), {
  type: "rgb",
  default: [0.9, 0.9, 0.9],
});
ButtonComponentHelper[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x352"), {
  type: _0x40b4("0x350"),
  default: [0.65, 0.65, 0.65],
});
ButtonComponentHelper[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x353"), {
  type: _0x40b4("0x350"),
  default: [0.5, 0.5, 0.5],
});
ButtonComponentHelper[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x354"), {
  type: _0x40b4("0x34"),
  default: 0x64,
  placeholder: "ms",
});
pc[_0x40b4("0x1")](ButtonComponentHelper[_0x40b4("0x2")], {
  initialize: function () {
    if (!this[_0x40b4("0xb8")][_0x40b4("0x2e6")]) {
      this[_0x40b4("0x355")]();
    }
    this[_0x40b4("0x356")]();
  },
  _createButtonComponent: function () {
    if (this[_0x40b4("0xb8")][_0x40b4("0x2e6")]) {
      return;
    }
    this[_0x40b4("0xb8")][_0x40b4("0x357")](_0x40b4("0x2e6"), {
      attributes: {},
    });
  },
  _setButtonValues: function () {
    this[_0x40b4("0xb8")][_0x40b4("0x2e6")][_0x40b4("0x34f")] =
      this[_0x40b4("0x34f")];
    this["entity"][_0x40b4("0x2e6")]["hoverTint"] = this[_0x40b4("0x351")];
    this[_0x40b4("0xb8")]["button"][_0x40b4("0x352")] = this["pressedTint"];
    this[_0x40b4("0xb8")][_0x40b4("0x2e6")]["inactiveTint"] =
      this[_0x40b4("0x353")];
    this[_0x40b4("0xb8")]["button"][_0x40b4("0x354")] = this[_0x40b4("0x354")];
    this["entity"]["button"][_0x40b4("0x358")] = this[_0x40b4("0xb8")];
  },
});
class I18n extends pc[_0x40b4("0xb0")] {
  static [_0x40b4("0xb1")]() {
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x359"), {
      type: _0x40b4("0x86"),
      default: "en",
      title: "Default\x20Language",
      enum: [
        { German: "de" },
        { English: "en" },
        { Turkish: "tr" },
        { Polish: "pl" },
        { Russian: "ru" },
        { Dutch: "nl" },
        { Spanish: "es" },
        { Portuguese: "pt" },
        { French: "fr" },
        { Japanese: "ja" },
      ],
    });
  }
  ["initialize"]() {
    if (Singleton[_0x40b4("0xca")][_0x40b4("0x10d")](this)) {
      I18n["instance"] = this;
    }
    if (!this[_0x40b4("0x35a")](this["defaultLanguage"])) {
      console[_0x40b4("0x7")](_0x40b4("0x35b"));
    }
    this["currentLanguage"] = null;
  }
  [_0x40b4("0xde")]() {
    const _0x52c09e = Wrapper[_0x40b4("0xca")][_0x40b4("0xf")]();
    this[_0x40b4("0x35c")](_0x52c09e);
  }
  [_0x40b4("0x35c")](_0x13ed36) {
    this[_0x40b4("0x35d")] = this[_0x40b4("0x35a")](_0x13ed36)
      ? _0x13ed36
      : this[_0x40b4("0x359")];
    this[_0x40b4("0xd6")][_0x40b4("0x35e")]["locale"] = this["currentLanguage"];
    this[_0x40b4("0x10e")](_0x40b4("0x76"), this[_0x40b4("0x35d")]);
    this[_0x40b4("0xd6")][_0x40b4("0x10e")](
      _0x40b4("0x35f"),
      this["currentLanguage"]
    );
  }
  ["hasLanguagePack"](_0x32e6a6) {
    return !!this[_0x40b4("0xd6")][_0x40b4("0x35e")][_0x40b4("0x360")][
      _0x32e6a6
    ];
  }
  ["get"](_0x5cc2d8, ..._0xbdb9ea) {
    const _0x1bc5ce =
      this[_0x40b4("0xd6")]["i18n"][_0x40b4("0x361")](_0x5cc2d8);
    if (!_0x1bc5ce) {
      return _0x5cc2d8;
    }
    if (_0xbdb9ea[_0x40b4("0x87")] === 0x0) {
      return _0x1bc5ce;
    }
    return _0x1bc5ce[_0x40b4("0x362")](..._0xbdb9ea);
  }
}
pc[_0x40b4("0x1f4")](I18n, _0x40b4("0x35e"));
I18n["addAttributes"]();
pc[_0x40b4("0x1")](pc[_0x40b4("0x363")]["prototype"], {
  off: function (_0x1539b0, _0x1b5442, _0x12e3b2) {
    if (_0x1539b0) {
      if (
        this[_0x40b4("0x364")][_0x1539b0] &&
        this[_0x40b4("0x364")][_0x1539b0] === this[_0x40b4("0x365")][_0x1539b0]
      )
        this[_0x40b4("0x364")][_0x1539b0] =
          this[_0x40b4("0x364")][_0x1539b0][_0x40b4("0x366")]();
    } else {
      for (var _0x10f6a0 in this["_callbackActive"]) {
        if (!this[_0x40b4("0x365")][_0x10f6a0]) continue;
        if (
          this[_0x40b4("0x365")][_0x10f6a0] !==
          this[_0x40b4("0x364")][_0x10f6a0]
        )
          continue;
        this[_0x40b4("0x364")][_0x10f6a0] =
          this["_callbackActive"][_0x10f6a0]["slice"]();
      }
    }
    if (!_0x1539b0) {
      this[_0x40b4("0x365")] = {};
    } else if (!_0x1b5442) {
      if (this[_0x40b4("0x365")][_0x1539b0])
        this[_0x40b4("0x365")][_0x1539b0] = [];
    } else {
      var _0x97c81e = this["_callbacks"][_0x1539b0];
      if (!_0x97c81e) return this;
      var _0xe9c039 = _0x97c81e[_0x40b4("0x87")];
      for (
        var _0xbb0a1 = _0x97c81e[_0x40b4("0x87")] - 0x1;
        _0xbb0a1 >= 0x0;
        _0xbb0a1--
      ) {
        if (_0x97c81e[_0xbb0a1][_0x40b4("0x336")] !== _0x1b5442) continue;
        if (_0x12e3b2 && _0x97c81e[_0xbb0a1][_0x40b4("0x337")] !== _0x12e3b2)
          continue;
        _0x97c81e["splice"](_0xbb0a1, 0x1);
        --_0xe9c039;
      }
      _0x97c81e[_0x40b4("0x87")] = _0xe9c039;
    }
    return this;
  },
});
var MessageButton = pc["createScript"](_0x40b4("0x367"));
MessageButton["attributes"][_0x40b4("0x2e")](_0x40b4("0x211"), {
  type: _0x40b4("0xb8"),
});
MessageButton[_0x40b4("0x2d")][_0x40b4("0x2e")]("scriptName", {
  type: _0x40b4("0x86"),
});
MessageButton[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x368"), {
  type: _0x40b4("0x86"),
});
pc[_0x40b4("0x1")](MessageButton[_0x40b4("0x2")], {
  initialize: function () {
    this[_0x40b4("0x1fe")] = this[_0x40b4("0xb8")]["script"][_0x40b4("0x1ff")];
    if (!this[_0x40b4("0x1fe")]) {
      this[_0x40b4("0x1fe")] = this[_0x40b4("0xb8")][_0x40b4("0x1a9")][
        "create"
      ](_0x40b4("0x1ff"));
      console[_0x40b4("0x7")](_0x40b4("0x200"), this[_0x40b4("0xb8")]["name"]);
    }
    this[_0x40b4("0x1fe")]["on"](
      inputEvents[_0x40b4("0x201")],
      this[_0x40b4("0x202")],
      this
    );
  },
  _onClick: function () {
    this[_0x40b4("0x211")][_0x40b4("0x1a9")][this[_0x40b4("0x1ca")]][
      this["functionName"]
    ]();
  },
});
class PauseManager extends pc["ScriptType"] {
  static ["addAttributes"]() {
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x369"), {
      type: _0x40b4("0x9f"),
      default: !![],
    });
  }
  get [_0x40b4("0x36a")]() {
    return this["_gameTimeScale"];
  }
  set [_0x40b4("0x36a")](_0x4d3150) {
    this[_0x40b4("0x36b")] = _0x4d3150;
    this[_0x40b4("0x36c")]();
  }
  get [_0x40b4("0x36d")]() {
    return this[_0x40b4("0x36e")];
  }
  set ["focusTimeScale"](_0x141aa8) {
    this["_focusTimeScale"] = _0x141aa8;
    this["_setTimeScale"]();
  }
  get [_0x40b4("0x36f")]() {
    return this[_0x40b4("0x370")];
  }
  set [_0x40b4("0x36f")](_0x565c19) {
    this[_0x40b4("0x370")] = _0x565c19;
    this[_0x40b4("0x36c")]();
  }
  [_0x40b4("0xc9")]() {
    if (Singleton[_0x40b4("0xca")][_0x40b4("0x10d")](this)) {
      PauseManager[_0x40b4("0xca")] = this;
    }
    this[_0x40b4("0x371")] =
      Wrapper[_0x40b4("0xca")][_0x40b4("0x13")]("external_pause");
    this[_0x40b4("0x36b")] = 0x1;
    this[_0x40b4("0x36e")] = 0x1;
    this[_0x40b4("0x370")] = 0x1;
    this[_0x40b4("0x14d")] = PauseManager[_0x40b4("0x372")]["RESUMED"];
    if (this[_0x40b4("0x371")]) {
      window[_0x40b4("0x3")][_0x40b4("0x14")](
        _0x40b4("0x6e"),
        this[_0x40b4("0x373")][_0x40b4("0xd")](this)
      );
      window[_0x40b4("0x3")][_0x40b4("0x14")](
        _0x40b4("0x374"),
        this[_0x40b4("0x375")][_0x40b4("0xd")](this)
      );
    } else {
      if (this["pauseWhenOutOfFocus"]) {
        window[_0x40b4("0x376")] = this["onFocus"]["bind"](this);
        window[_0x40b4("0x377")] = this[_0x40b4("0x378")][_0x40b4("0xd")](this);
      }
    }
    Wrapper[_0x40b4("0xca")]["setOnPauseRequested"](
      this[_0x40b4("0x379")],
      this
    );
    Wrapper[_0x40b4("0xca")][_0x40b4("0x30a")](
      this["onAdResumeRequested"],
      this
    );
  }
  [_0x40b4("0x379")]() {
    this[_0x40b4("0x36f")] = 0x0;
  }
  [_0x40b4("0x37a")]() {
    this[_0x40b4("0x36f")] = 0x1;
    if (this["_focusTimeScale"] === 0x0) {
      window[_0x40b4("0x112")]();
      if (this[_0x40b4("0x36e")] === 0x0) {
        this[_0x40b4("0x36d")] = 0x1;
      }
    }
  }
  ["onFocus"]() {
    this["focusTimeScale"] = 0x1;
    console[_0x40b4("0x7")](_0x40b4("0x37b"));
  }
  [_0x40b4("0x378")]() {
    this[_0x40b4("0x36d")] = 0x0;
    console[_0x40b4("0x7")](_0x40b4("0x37c"));
  }
  [_0x40b4("0x375")]() {
    this[_0x40b4("0x36d")] = 0x1;
  }
  [_0x40b4("0x373")]() {
    this[_0x40b4("0x36d")] = 0x0;
  }
  [_0x40b4("0x36c")]() {
    this[_0x40b4("0xd6")][_0x40b4("0x213")] =
      this[_0x40b4("0x36a")] * this[_0x40b4("0x36d")] * this["adTimeScale"];
    const _0x224943 =
      this[_0x40b4("0xd6")][_0x40b4("0x213")] === 0x0
        ? PauseManager[_0x40b4("0x372")][_0x40b4("0x37d")]
        : PauseManager[_0x40b4("0x372")]["RESUMED"];
    this[_0x40b4("0xd6")]["fire"](
      _0x40b4("0x37e"),
      this["app"][_0x40b4("0x213")],
      this["gameTimeScale"],
      this[_0x40b4("0x36d")],
      this[_0x40b4("0x36f")]
    );
    if (_0x224943 !== this["state"]) {
      this[_0x40b4("0x14d")] = _0x224943;
      switch (this[_0x40b4("0x14d")]) {
        case PauseManager[_0x40b4("0x372")][_0x40b4("0x37d")]:
          this[_0x40b4("0x37f")]();
          break;
        case PauseManager[_0x40b4("0x372")]["RESUMED"]:
          this[_0x40b4("0x380")]();
          break;
      }
    }
  }
  [_0x40b4("0x37f")]() {
    this["app"]["fire"](_0x40b4("0x381"));
  }
  [_0x40b4("0x380")]() {
    this[_0x40b4("0xd6")][_0x40b4("0x10e")](_0x40b4("0x382"));
  }
  [_0x40b4("0x11a")]() {
    this[_0x40b4("0x36a")] = 0x0;
  }
  ["resume"]() {
    this[_0x40b4("0x36a")] = 0x1;
  }
  [_0x40b4("0x383")](_0x745643) {
    this[_0x40b4("0x36a")] = _0x745643;
  }
}
pc[_0x40b4("0x1f4")](PauseManager, _0x40b4("0x384"));
PauseManager[_0x40b4("0xb1")]();
PauseManager[_0x40b4("0x372")] = Object[_0x40b4("0x239")]({
  PAUSED: _0x40b4("0x385"),
  RESUMED: "resumed",
});
class ForcedModeManager extends pc[_0x40b4("0xb0")] {
  static [_0x40b4("0xb1")]() {
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x46"), {
      type: _0x40b4("0x46"),
      array: !![],
      schema: [
        { name: _0x40b4("0x153"), type: _0x40b4("0x86") },
        { name: _0x40b4("0xb8"), type: _0x40b4("0xb8") },
      ],
    });
  }
  [_0x40b4("0xc9")]() {
    ForcedModeManager[_0x40b4("0xca")] = this;
    this["forcedMode"] =
      Wrapper[_0x40b4("0xca")][_0x40b4("0x13")]("forced_mode");
    this[_0x40b4("0x386")] = Wrapper[_0x40b4("0xca")][_0x40b4("0x15")](
      _0x40b4("0x387")
    );
  }
  [_0x40b4("0x115")]() {
    this["json"]["forEach"]((_0x18f586) => {
      if (
        Array[_0x40b4("0x32c")](
          this["forcedModeProperties"]["override"][_0x40b4("0x388")]
        ) &&
        this["forcedModeProperties"][_0x40b4("0x389")][_0x40b4("0x388")][
          "includes"
        ](_0x18f586["name"])
      ) {
        _0x18f586[_0x40b4("0xb8")][_0x40b4("0xd4")] =
          this[_0x40b4("0x386")]["override"][_0x18f586["name"]];
        _0x18f586[_0x40b4("0xb8")][_0x40b4("0x38a")] =
          !this["forcedModeProperties"][_0x40b4("0x389")][_0x18f586["name"]];
      }
      if (
        typeof this[_0x40b4("0x386")]["override"][
          _0x18f586[_0x40b4("0x153")]
        ] === _0x40b4("0x9f")
      ) {
        _0x18f586[_0x40b4("0xb8")][_0x40b4("0xd4")] =
          this[_0x40b4("0x386")][_0x40b4("0x389")][_0x18f586[_0x40b4("0x153")]];
        _0x18f586[_0x40b4("0xb8")][_0x40b4("0x38a")] =
          !this[_0x40b4("0x386")][_0x40b4("0x389")][_0x18f586["name"]];
      }
    });
  }
  ["hideUI"](_0x59a2e4) {
    if (!this[_0x40b4("0x113")]) {
      return null;
    }
    if (
      Array[_0x40b4("0x32c")](
        this[_0x40b4("0x386")]["override"][_0x40b4("0x388")]
      ) &&
      this["forcedModeProperties"][_0x40b4("0x389")]["hide_ui"][
        _0x40b4("0x38b")
      ](_0x59a2e4)
    ) {
      return !![];
    }
    return ![];
  }
  [_0x40b4("0x38c")](_0x1a025a) {
    if (!this[_0x40b4("0x113")]) {
      return null;
    }
    return this[_0x40b4("0x386")][_0x40b4("0x389")][_0x1a025a];
  }
  [_0x40b4("0x117")](_0x116f60) {
    if (!this[_0x40b4("0x113")]) {
      return null;
    }
    return this[_0x40b4("0x386")]["state"][_0x116f60];
  }
}
pc[_0x40b4("0x1f4")](ForcedModeManager, "forcedModeManager");
ForcedModeManager["addAttributes"]();
class PlayerMovement extends pc[_0x40b4("0xb0")] {
  static [_0x40b4("0xb1")]() {
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x38d"), {
      type: _0x40b4("0x34"),
      default: 0xa,
    });
    this["attributes"][_0x40b4("0x2e")](_0x40b4("0x38e"), {
      type: _0x40b4("0xb8"),
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")]("leftButtonEntity", {
      type: "entity",
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")]("rightButtonEntity", {
      type: "entity",
    });
  }
  [_0x40b4("0xc9")]() {
    PlayerMovement[_0x40b4("0xca")] = this;
    this[_0x40b4("0x38f")] = 0x0;
    this[_0x40b4("0x38e")][_0x40b4("0x170")](
      0x0,
      GameManager[_0x40b4("0xca")][_0x40b4("0x10a")],
      0x0
    );
    var _0x1b3474 = this[_0x40b4("0xd6")][_0x40b4("0x2c7")];
    var _0x2d4621 = this["app"]["keyboard"];
    if (pc[_0x40b4("0x191")]["touch"]) {
      this["leftButton"] = this[_0x40b4("0x390")][_0x40b4("0x2e6")];
      this["rightButton"] = this[_0x40b4("0x391")]["button"];
    } else if (pc[_0x40b4("0x191")][_0x40b4("0x2ad")]) {
      this["leftButtonEntity"][_0x40b4("0xd4")] = ![];
      this[_0x40b4("0x391")][_0x40b4("0xd4")] = ![];
    }
    this["windowWidth"] = ViewportManager["instance"][_0x40b4("0x392")]() / 0x2;
    this["app"]["on"](_0x40b4("0x274"), this[_0x40b4("0x393")], this);
    this[_0x40b4("0xd6")][_0x40b4("0x2c7")][_0x40b4("0x2ba")]();
    if (this["leftButton"]) {
      this["leftButton"]["on"](
        pc[_0x40b4("0x2d2")],
        this[_0x40b4("0x394")],
        this
      );
      this["leftButton"]["on"](
        pc[_0x40b4("0x2d0")],
        this[_0x40b4("0x395")],
        this
      );
      this[_0x40b4("0x396")]["on"](
        pc[_0x40b4("0x2d1")],
        this[_0x40b4("0x394")],
        this
      );
      this[_0x40b4("0x396")]["on"](
        pc[_0x40b4("0x2cf")],
        this[_0x40b4("0x395")],
        this
      );
    }
    if (this[_0x40b4("0x397")]) {
      this[_0x40b4("0x397")]["on"](
        pc["EVENT_TOUCHSTART"],
        this[_0x40b4("0x398")],
        this
      );
      this[_0x40b4("0x397")]["on"](
        pc["EVENT_TOUCHEND"],
        this[_0x40b4("0x395")],
        this
      );
      this[_0x40b4("0x397")]["on"](
        pc[_0x40b4("0x2d1")],
        this[_0x40b4("0x398")],
        this
      );
      this[_0x40b4("0x397")]["on"](
        pc[_0x40b4("0x2cf")],
        this[_0x40b4("0x395")],
        this
      );
    }
    if (_0x1b3474) {
      _0x1b3474["on"](pc[_0x40b4("0x2ca")], this[_0x40b4("0x395")], this);
      _0x1b3474["on"](pc[_0x40b4("0x2c8")], this["onInputDown"], this);
      _0x1b3474["on"](pc[_0x40b4("0x399")], this[_0x40b4("0x39a")], this);
    }
    if (_0x2d4621) {
      _0x2d4621["on"](pc[_0x40b4("0x39b")], this[_0x40b4("0x39c")], this);
      _0x2d4621["on"](pc["EVENT_KEYUP"], this["onKeyUp"], this);
    }
  }
  [_0x40b4("0x393")](_0x340b61, _0x3a6783) {
    this[_0x40b4("0x39d")] = _0x3a6783 / 0x2;
  }
  [_0x40b4("0x39c")](_0x23aeb2) {
    if (!GameManager[_0x40b4("0xca")][_0x40b4("0x123")]) {
      return;
    }
    switch (_0x23aeb2[_0x40b4("0x39e")]) {
      case pc["KEY_LEFT"]:
      case pc[_0x40b4("0x39f")]:
        this[_0x40b4("0x3a0")] = !![];
        break;
      case pc[_0x40b4("0x3a1")]:
      case pc[_0x40b4("0x3a2")]:
        this[_0x40b4("0x3a3")] = !![];
        break;
    }
  }
  [_0x40b4("0x3a4")](_0x1c469c) {
    if (!GameManager[_0x40b4("0xca")][_0x40b4("0x123")]) {
      return;
    }
    switch (_0x1c469c[_0x40b4("0x39e")]) {
      case pc[_0x40b4("0x3a5")]:
      case pc[_0x40b4("0x39f")]:
        this["leftPressed"] = ![];
        break;
      case pc[_0x40b4("0x3a1")]:
      case pc[_0x40b4("0x3a2")]:
        this[_0x40b4("0x3a3")] = ![];
        break;
    }
  }
  ["onInputDown"](_0x501269) {
    if (
      Array[_0x40b4("0x32c")](_0x501269[_0x40b4("0x3a6")]) &&
      !_0x501269[_0x40b4("0x3a6")][0x0]
    ) {
      return;
    }
    const _0x41b7f1 = _0x501269["x"];
    if (_0x41b7f1 < this[_0x40b4("0x39d")]) {
      this[_0x40b4("0x3a0")] = !![];
    }
    if (_0x41b7f1 > this[_0x40b4("0x39d")]) {
      this[_0x40b4("0x3a3")] = !![];
    }
  }
  [_0x40b4("0x395")](_0x56fea0) {
    this[_0x40b4("0x3a0")] = ![];
    this[_0x40b4("0x3a3")] = ![];
  }
  [_0x40b4("0x39a")](_0x41118f) {
    if (
      Array[_0x40b4("0x32c")](_0x41118f[_0x40b4("0x3a6")]) &&
      !_0x41118f["buttons"][0x0]
    ) {
      return;
    }
    const _0x4f7f70 = _0x41118f["x"];
    if (_0x4f7f70 < this[_0x40b4("0x39d")]) {
      this["rightPressed"] = ![];
      this[_0x40b4("0x3a0")] = !![];
    } else {
      this[_0x40b4("0x3a3")] = !![];
      this[_0x40b4("0x3a0")] = ![];
    }
  }
  [_0x40b4("0x394")](_0x1b7cbc) {
    for (
      let _0x29b21c = 0x0;
      _0x29b21c < _0x1b7cbc[_0x40b4("0x3a7")][_0x40b4("0x87")];
      _0x29b21c++
    ) {
      const _0x3ca9c1 = _0x1b7cbc[_0x40b4("0x3a7")][_0x29b21c];
      const _0xf311f8 = _0x3ca9c1["x"];
      this[_0x40b4("0x3a0")] = !![];
    }
  }
  ["onTouchRight"](_0x24e980) {
    for (
      let _0x3f25bf = 0x0;
      _0x3f25bf < _0x24e980[_0x40b4("0x3a7")][_0x40b4("0x87")];
      _0x3f25bf++
    ) {
      const _0x25de35 = _0x24e980[_0x40b4("0x3a7")][_0x3f25bf];
      const _0x55d148 = _0x25de35["x"];
      this[_0x40b4("0x3a3")] = !![];
    }
  }
  [_0x40b4("0x236")](_0x5aa31e) {
    if (!GameManager[_0x40b4("0xca")][_0x40b4("0x123")]) {
      return;
    }
    if (this[_0x40b4("0x3a0")]) {
      this[_0x40b4("0x38f")] += this[_0x40b4("0x38d")] * _0x5aa31e;
    }
    if (this[_0x40b4("0x3a3")]) {
      this["angle"] -= this[_0x40b4("0x38d")] * _0x5aa31e;
    }
    this[_0x40b4("0xb8")][_0x40b4("0x17a")](0x0, 0x0, this[_0x40b4("0x38f")]);
  }
}
pc[_0x40b4("0x1f4")](PlayerMovement, _0x40b4("0x3a8"));
PlayerMovement[_0x40b4("0xb1")]();
class Path extends pc[_0x40b4("0xb0")] {
  static ["addAttributes"]() {
    this["attributes"][_0x40b4("0x2e")](_0x40b4("0x3a9"), {
      type: _0x40b4("0xb8"),
      title: _0x40b4("0x3aa"),
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")]("positionCurveType", {
      type: "string",
      enum: Path[_0x40b4("0x3ab")],
      default: _0x40b4("0x3ac"),
    });
    this["attributes"][_0x40b4("0x2e")](_0x40b4("0x3ad"), {
      type: _0x40b4("0x86"),
      enum: Path[_0x40b4("0x3ab")],
      default: _0x40b4("0x3ac"),
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x3ae"), {
      type: _0x40b4("0x86"),
      enum: Path[_0x40b4("0x3ab")],
      default: _0x40b4("0x3ac"),
    });
    this[_0x40b4("0x2d")]["add"](_0x40b4("0x13b"), {
      type: "number",
      default: 0xa,
      title: _0x40b4("0x3af"),
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")]("showDebugLines", {
      type: _0x40b4("0x9f"),
    });
  }
  [_0x40b4("0xc9")]() {
    Path[_0x40b4("0xca")] = this;
    this[_0x40b4("0x3b0")] = 0x0;
    this[_0x40b4("0x132")]();
    this[_0x40b4("0x3b1")] = [];
    this[_0x40b4("0x3b2")] = [];
    this[_0x40b4("0x3b3")]();
    this["on"](_0x40b4("0x3b4"), function (_0x1ea870, _0x487d93) {
      if (_0x1ea870) {
        this[_0x40b4("0x3b3")]();
        this[_0x40b4("0x132")]();
      }
    });
    this[_0x40b4("0x3b5")] = new pc["Vec3"]();
    this["up"] = new pc[_0x40b4("0x16a")]();
    this[_0x40b4("0x3b6")] = !![];
  }
  [_0x40b4("0x236")](_0x303a11) {
    if (
      !GameManager[_0x40b4("0xca")]["started"] &&
      !GameManager[_0x40b4("0xca")][_0x40b4("0x11f")]
    ) {
      return;
    }
    if (GameManager["instance"][_0x40b4("0x11f")]) {
      _0x303a11 /= 0x3;
    }
    var _0x34c0c3;
    if (this["flyingThrough"]) {
      this[_0x40b4("0x20e")] += _0x303a11;
      if (this["time"] > this[_0x40b4("0x13b")]) {
        this["time"] = this["duration"];
        this[_0x40b4("0x10e")]("complete");
      }
      _0x34c0c3 = this["time"] / this["duration"];
    } else {
      _0x34c0c3 =
        this[_0x40b4("0x3b7")][_0x40b4("0x151")] /
        this["pathSlider"][_0x40b4("0x2a8")];
    }
    const _0x42f97c = this[_0x40b4("0x3b8")] * _0x34c0c3;
    const _0x209c4d = _0x42f97c - this["previousLength"];
    if (GameManager[_0x40b4("0xca")][_0x40b4("0x123")]) {
      ScoreManager[_0x40b4("0xca")]["addScore"](_0x209c4d);
    }
    this[_0x40b4("0x3b9")] = _0x42f97c;
    const _0x294524 = 0.015;
    const _0x2380c0 = {};
    _0x2380c0["x"] = this["px"][_0x40b4("0x151")](_0x34c0c3 - _0x294524);
    _0x2380c0["y"] = this["py"]["value"](_0x34c0c3 - _0x294524);
    _0x2380c0["z"] = this["pz"][_0x40b4("0x151")](_0x34c0c3 - _0x294524);
    const _0x3878ce = this["px"]["value"](_0x34c0c3);
    const _0x12bb8d = this["py"]["value"](_0x34c0c3);
    const _0x2d5202 = this["pz"][_0x40b4("0x151")](_0x34c0c3);
    this[_0x40b4("0xb8")][_0x40b4("0x3ba")](_0x3878ce, _0x12bb8d, _0x2d5202);
    this[_0x40b4("0x3b5")][_0x40b4("0x15d")](
      _0x3878ce + _0x2380c0["x"] - _0x3878ce,
      _0x12bb8d + _0x2380c0["y"] - _0x12bb8d,
      _0x2d5202 + _0x2380c0["z"] - _0x2d5202
    );
    this["up"][_0x40b4("0x15d")](
      this["ux"]["value"](_0x34c0c3),
      this["uy"][_0x40b4("0x151")](_0x34c0c3),
      this["uz"]["value"](_0x34c0c3)
    );
    this["entity"][_0x40b4("0x3b5")](this[_0x40b4("0x3b5")], this["up"]);
    if (this[_0x40b4("0x3bb")]) {
      if (this[_0x40b4("0x3b1")][_0x40b4("0x87")] === 0x0) {
        this[_0x40b4("0x3bc")]();
      }
      this[_0x40b4("0xd6")][_0x40b4("0x3bd")](
        this["debugPositions"],
        this["debugColors"]
      );
    }
  }
  ["updatePath"]() {
    this[_0x40b4("0x3b3")]();
    this[_0x40b4("0x132")]();
    this[_0x40b4("0x3b1")]["length"] = 0x0;
    this[_0x40b4("0x3b2")][_0x40b4("0x87")] = 0x0;
    this[_0x40b4("0x3b9")] = 0x0;
  }
  [_0x40b4("0x132")]() {
    this[_0x40b4("0x20e")] = this["duration"] * 0.003;
  }
  [_0x40b4("0x3be")](_0x577c2a, _0x237d61, _0x381df2) {
    const _0x5e045c = this["px"]["value"](_0x577c2a);
    const _0x162fcc = this["py"]["value"](_0x577c2a);
    const _0x53c497 = this["pz"][_0x40b4("0x151")](_0x577c2a);
    const _0x9fd2ea = this["px"][_0x40b4("0x151")](_0x577c2a - 0.001);
    const _0x478fec = this["py"][_0x40b4("0x151")](_0x577c2a - 0.001);
    const _0x1b93a1 = this["pz"][_0x40b4("0x151")](_0x577c2a - 0.001);
    const _0x834196 = this["ux"][_0x40b4("0x151")](_0x577c2a);
    const _0x2aee29 = this["uy"][_0x40b4("0x151")](_0x577c2a);
    const _0x4c9a75 = this["uz"][_0x40b4("0x151")](_0x577c2a);
    const _0x378b12 = Path["AXIS"]
      ["set"](
        _0x5e045c - _0x9fd2ea,
        _0x162fcc - _0x478fec,
        _0x53c497 - _0x1b93a1
      )
      [_0x40b4("0x3bf")]();
    const _0x2f23b0 = Path["UP"]
      [_0x40b4("0x15d")](_0x834196, _0x2aee29, _0x4c9a75)
      ["normalize"]()
      [_0x40b4("0x3c0")](_0x237d61);
    const _0x2eb321 = Math["cos"](_0x381df2);
    const _0x573ff2 = Math[_0x40b4("0x230")](_0x381df2);
    const _0x3909de =
      _0x2eb321 + _0x378b12["x"] * _0x378b12["x"] * (0x1 - _0x2eb321);
    const _0x5b202f =
      _0x378b12["x"] * _0x378b12["y"] * (0x1 - _0x2eb321) -
      _0x378b12["z"] * _0x573ff2;
    const _0x21e94a =
      _0x378b12["x"] * _0x378b12["z"] * (0x1 - _0x2eb321) +
      _0x378b12["y"] * _0x573ff2;
    const _0x5c179a =
      _0x378b12["y"] * _0x378b12["x"] * (0x1 - _0x2eb321) +
      _0x378b12["z"] * _0x573ff2;
    const _0x31056b =
      _0x2eb321 + _0x378b12["y"] * _0x378b12["y"] * (0x1 - _0x2eb321);
    const _0x614846 =
      _0x378b12["y"] * _0x378b12["z"] * (0x1 - _0x2eb321) -
      _0x378b12["x"] * _0x573ff2;
    const _0x372d0e =
      _0x378b12["z"] * _0x378b12["x"] * (0x1 - _0x2eb321) -
      _0x378b12["y"] * _0x573ff2;
    const _0x548a90 =
      _0x378b12["z"] * _0x378b12["y"] * (0x1 - _0x2eb321) +
      _0x378b12["x"] * _0x573ff2;
    const _0x3e9346 =
      _0x2eb321 + _0x378b12["z"] * _0x378b12["z"] * (0x1 - _0x2eb321);
    const _0x4d0c97 =
      _0x3909de * _0x2f23b0["x"] +
      _0x5b202f * _0x2f23b0["y"] +
      _0x21e94a * _0x2f23b0["z"];
    const _0x46989b =
      _0x5c179a * _0x2f23b0["x"] +
      _0x31056b * _0x2f23b0["y"] +
      _0x614846 * _0x2f23b0["z"];
    const _0x3416a6 =
      _0x372d0e * _0x2f23b0["x"] +
      _0x548a90 * _0x2f23b0["y"] +
      _0x3e9346 * _0x2f23b0["z"];
    return new pc[_0x40b4("0x16a")](
      _0x5e045c + _0x4d0c97,
      _0x162fcc + _0x46989b,
      _0x53c497 + _0x3416a6
    );
  }
  [_0x40b4("0x3b3")]() {
    this["px"] = new pc[_0x40b4("0x3c1")]();
    this["px"]["type"] = pc[this[_0x40b4("0x3c2")]];
    this["py"] = new pc[_0x40b4("0x3c1")]();
    this["py"]["type"] = pc[this[_0x40b4("0x3c2")]];
    this["pz"] = new pc["Curve"]();
    this["pz"]["type"] = pc[this[_0x40b4("0x3c2")]];
    this["p"] = new pc["CurveSet"]();
    this["p"][_0x40b4("0x3c3")]["push"](this["px"], this["py"], this["pz"]);
    this["tx"] = new pc[_0x40b4("0x3c1")]();
    this["tx"][_0x40b4("0x1b8")] = pc[this[_0x40b4("0x3ad")]];
    this["ty"] = new pc[_0x40b4("0x3c1")]();
    this["ty"][_0x40b4("0x1b8")] = pc[this[_0x40b4("0x3ad")]];
    this["tz"] = new pc[_0x40b4("0x3c1")]();
    this["tz"][_0x40b4("0x1b8")] = pc[this["rotationCurveType"]];
    this["t"] = new pc[_0x40b4("0x3c4")]();
    this["t"][_0x40b4("0x3c3")][_0x40b4("0x18")](
      this["tx"],
      this["ty"],
      this["tz"]
    );
    this["ux"] = new pc[_0x40b4("0x3c1")]();
    this["ux"][_0x40b4("0x1b8")] = pc[this[_0x40b4("0x3ae")]];
    this["uy"] = new pc[_0x40b4("0x3c1")]();
    this["uy"][_0x40b4("0x1b8")] = pc[this[_0x40b4("0x3ae")]];
    this["uz"] = new pc["Curve"]();
    this["uz"][_0x40b4("0x1b8")] = pc[this[_0x40b4("0x3ae")]];
    this["u"] = new pc[_0x40b4("0x3c4")]();
    this["u"][_0x40b4("0x3c3")][_0x40b4("0x18")](
      this["ux"],
      this["uy"],
      this["uz"]
    );
    var _0x14905c = this[_0x40b4("0x3a9")][_0x40b4("0x1a8")];
    var _0x19f7d1 = 0x0;
    var _0x1f3947 = [];
    var _0x294079 = new pc["Vec3"]();
    _0x1f3947[_0x40b4("0x18")](0x0);
    for (
      let _0x5ceaaf = 0x1;
      _0x5ceaaf < _0x14905c[_0x40b4("0x87")];
      _0x5ceaaf++
    ) {
      var _0x11562d = _0x14905c[_0x5ceaaf - 0x1];
      var _0x46e8c8 = _0x14905c[_0x5ceaaf];
      _0x294079["sub2"](
        _0x11562d[_0x40b4("0x3c5")](),
        _0x46e8c8[_0x40b4("0x3c5")]()
      );
      _0x19f7d1 += _0x294079["length"]();
      _0x1f3947[_0x40b4("0x18")](_0x19f7d1);
    }
    this[_0x40b4("0x3b8")] = _0x19f7d1;
    for (
      let _0x1dc206 = 0x0;
      _0x1dc206 < _0x14905c[_0x40b4("0x87")];
      _0x1dc206++
    ) {
      var _0x57511a = _0x1f3947[_0x1dc206] / _0x19f7d1;
      var _0x5afc0b = _0x14905c[_0x1dc206];
      _0x5afc0b["removeComponent"](_0x40b4("0x3c6"));
      var _0x1d8668 = _0x5afc0b["getPosition"]();
      this["px"][_0x40b4("0x2e")](_0x57511a, _0x1d8668["x"]);
      this["py"][_0x40b4("0x2e")](_0x57511a, _0x1d8668["y"]);
      this["pz"][_0x40b4("0x2e")](_0x57511a, _0x1d8668["z"]);
      let _0x314ef6 = _0x5afc0b[_0x40b4("0x3c7")];
      if (_0x57511a === 0x0) {
      } else {
        const _0x1aa819 = this["px"][_0x40b4("0x151")](_0x57511a - 0.001);
        const _0x221e43 = this["py"][_0x40b4("0x151")](_0x57511a - 0.001);
        const _0x55fd97 = this["pz"][_0x40b4("0x151")](_0x57511a - 0.001);
        const _0x2e721b = this["px"][_0x40b4("0x151")](_0x57511a);
        const _0x206500 = this["py"][_0x40b4("0x151")](_0x57511a);
        const _0x2688fb = this["pz"]["value"](_0x57511a);
        _0x314ef6 = new pc["Vec3"](
          _0x1aa819 - _0x2e721b,
          _0x221e43 - _0x206500,
          _0x55fd97 - _0x2688fb
        );
      }
      var _0x5c92a7 = _0x1d8668["clone"]()[_0x40b4("0x2e")](_0x314ef6);
      this["tx"][_0x40b4("0x2e")](_0x57511a, _0x5c92a7["x"]);
      this["ty"][_0x40b4("0x2e")](_0x57511a, _0x5c92a7["y"]);
      this["tz"][_0x40b4("0x2e")](_0x57511a, _0x5c92a7["z"]);
      _0x5afc0b["lookAt"](_0x5c92a7, _0x5afc0b["up"]);
      var _0x11cd41 = _0x5afc0b["up"];
      this["ux"][_0x40b4("0x2e")](_0x57511a, _0x11cd41["x"]);
      this["uy"][_0x40b4("0x2e")](_0x57511a, _0x11cd41["y"]);
      this["uz"][_0x40b4("0x2e")](_0x57511a, _0x11cd41["z"]);
      const _0x3792dd = Math[_0x40b4("0x3c8")](
        new pc[_0x40b4("0x16a")]()
          [_0x40b4("0x12e")](_0x314ef6)
          [_0x40b4("0x3c9")](_0x11cd41) /
          (_0x314ef6[_0x40b4("0x87")]() * _0x11cd41[_0x40b4("0x87")]())
      );
    }
  }
  ["createDebugPath"]() {
    let _0x2f34c7 = 0x0;
    let _0x2a2b76 = 0x1 / 0x64;
    this["debugPositions"][_0x40b4("0x87")] = 0x0;
    this[_0x40b4("0x3b2")][_0x40b4("0x87")] = 0x0;
    while (_0x2f34c7 <= 0x1) {
      this[_0x40b4("0x3b1")][_0x40b4("0x18")](
        this["px"][_0x40b4("0x151")](_0x2f34c7),
        this["py"][_0x40b4("0x151")](_0x2f34c7),
        this["pz"][_0x40b4("0x151")](_0x2f34c7)
      );
      this[_0x40b4("0x3b2")][_0x40b4("0x18")](0x1, 0x0, 0x0, 0x1);
      _0x2f34c7 += _0x2a2b76;
      this[_0x40b4("0x3b1")][_0x40b4("0x18")](
        this["px"][_0x40b4("0x151")](_0x2f34c7),
        this["py"][_0x40b4("0x151")](_0x2f34c7),
        this["pz"][_0x40b4("0x151")](_0x2f34c7)
      );
      this["debugColors"]["push"](0x1, 0x0, 0x0, 0x1);
    }
    for (let _0x20ef56 = 0x0; _0x20ef56 < 0x64; _0x20ef56++) {
      const _0x2b4ef8 = _0x20ef56 / 0x64;
      const _0x1b1d78 = this["px"][_0x40b4("0x151")](_0x2b4ef8);
      const _0x21008e = this["py"][_0x40b4("0x151")](_0x2b4ef8);
      const _0x5354a2 = this["pz"][_0x40b4("0x151")](_0x2b4ef8);
      const _0x1e37a1 = this["px"]["value"](_0x2b4ef8 + 0.01);
      const _0x764730 = this["py"][_0x40b4("0x151")](_0x2b4ef8 + 0.01);
      const _0x936371 = this["pz"][_0x40b4("0x151")](_0x2b4ef8 + 0.01);
      this["debugPositions"][_0x40b4("0x18")](_0x1b1d78, _0x21008e, _0x5354a2);
      this[_0x40b4("0x3b2")][_0x40b4("0x18")](0x0, 0x1, 0x0, 0x1);
      const _0xa6c65d = new pc[_0x40b4("0x16a")](
        this["ux"][_0x40b4("0x151")](_0x2b4ef8),
        this["uy"]["value"](_0x2b4ef8),
        this["uz"][_0x40b4("0x151")](_0x2b4ef8)
      )
        ["normalize"]()
        ["mulScalar"](0x2);
      this["debugPositions"][_0x40b4("0x18")](
        _0x1b1d78 + _0xa6c65d["x"],
        _0x21008e + _0xa6c65d["y"],
        _0x5354a2 + _0xa6c65d["z"]
      );
      this[_0x40b4("0x3b2")][_0x40b4("0x18")](0x0, 0x1, 0x0, 0x1);
      const _0x4c80c4 = new pc[_0x40b4("0x16a")](
        _0x1e37a1 - _0x1b1d78,
        _0x764730 - _0x21008e,
        _0x936371 - _0x5354a2
      );
      _0x4c80c4[_0x40b4("0x3bf")]()["mulScalar"](0xa);
      this["debugPositions"][_0x40b4("0x18")](_0x1b1d78, _0x21008e, _0x5354a2);
      this["debugColors"][_0x40b4("0x18")](0x0, 0x0, 0x1, 0x1);
      this[_0x40b4("0x3b1")][_0x40b4("0x18")](
        _0x1b1d78 + _0x4c80c4["x"],
        _0x21008e + _0x4c80c4["y"],
        _0x5354a2 + _0x4c80c4["z"]
      );
      this["debugColors"][_0x40b4("0x18")](0x0, 0x0, 0x1, 0x1);
    }
  }
  [_0x40b4("0x3ca")](_0x3e4ba3, _0x5479e9) {
    const _0x3fb89e = this["px"][_0x40b4("0x151")](_0x5479e9 - 0.01);
    const _0x157c66 = this["px"]["value"](_0x5479e9 - 0.01);
    const _0x589384 = this["px"][_0x40b4("0x151")](_0x5479e9 - 0.01);
    const _0x2632f6 = this["px"][_0x40b4("0x151")](_0x5479e9 + 0.01);
    const _0x329309 = this["py"][_0x40b4("0x151")](_0x5479e9 + 0.01);
    const _0x21422a = this["pz"][_0x40b4("0x151")](_0x5479e9 + 0.01);
    _0x3e4ba3[_0x40b4("0x3ba")](_0x2632f6, _0x329309, _0x21422a);
    this[_0x40b4("0x3b5")][_0x40b4("0x15d")](
      _0x2632f6 + _0x3fb89e - _0x2632f6,
      _0x329309 + _0x157c66 - _0x329309,
      _0x21422a + _0x589384 - _0x21422a
    );
    this["up"][_0x40b4("0x15d")](
      this["ux"][_0x40b4("0x151")](_0x5479e9),
      this["uy"][_0x40b4("0x151")](_0x5479e9),
      this["uz"]["value"](_0x5479e9)
    );
    _0x3e4ba3[_0x40b4("0x3b5")](this[_0x40b4("0x3b5")], this["up"]);
  }
}
Path[_0x40b4("0x3ab")] = [
  { Cardinal: _0x40b4("0x3ac") },
  { Catmull: "CURVE_CATMULL" },
  { Linear: _0x40b4("0x3cb") },
  { SmoothStep: _0x40b4("0x3cc") },
  { Spline: _0x40b4("0x3cd") },
  { Step: "CURVE_STEP" },
];
pc[_0x40b4("0x1f4")](Path, _0x40b4("0x3ce"));
Path[_0x40b4("0xb1")]();
Path["UP"] = new pc[_0x40b4("0x16a")]();
Path["AXIS"] = new pc[_0x40b4("0x16a")]();
class Obstacle extends pc[_0x40b4("0xb0")] {
  static [_0x40b4("0xb1")]() {
    this[_0x40b4("0x2d")][_0x40b4("0x2e")]("rotationEntity", {
      type: _0x40b4("0xb8"),
    });
    this["attributes"]["add"](_0x40b4("0x3cf"), {
      type: _0x40b4("0xb8"),
      array: !![],
    });
  }
  ["initialize"]() {
    this[_0x40b4("0x3d0")] = new pc["Vec3"]();
    this[_0x40b4("0x3d1")] = this[_0x40b4("0xb8")][_0x40b4("0x338")](
      _0x40b4("0x3d2")
    );
    if (this[_0x40b4("0x3d1")][_0x40b4("0x87")] === 0x0) {
      console["warn"](_0x40b4("0x3d3"));
    }
    this[_0x40b4("0x3d4")] = [];
  }
  ["init"](_0x167d73) {
    this[_0x40b4("0xd6")]["on"](_0x40b4("0x3d5"), this[_0x40b4("0x3d6")], this);
    this[_0x40b4("0x3d7")][_0x40b4("0x17a")](
      0x0,
      0x0,
      Math[_0x40b4("0x3d8")]() * 0x168
    );
    this[_0x40b4("0x38d")] = (Math["random"]() * 0x2 - 0x1) * 0xb4 * _0x167d73;
    for (
      let _0x328a0e = 0x0;
      _0x328a0e < this[_0x40b4("0x3d1")][_0x40b4("0x87")];
      _0x328a0e++
    ) {
      const _0x105a1d = this["hitboxScripts"][_0x328a0e];
      _0x105a1d[_0x40b4("0x1d0")]();
    }
    if (this[_0x40b4("0x3cf")]["length"] > 0x0) {
      this["othersRotationSpeed"][_0x40b4("0x87")] = 0x0;
      for (
        let _0x34d0dd = 0x0;
        _0x34d0dd < this[_0x40b4("0x3cf")][_0x40b4("0x87")];
        _0x34d0dd += 0x1
      ) {
        const _0xea81aa = this[_0x40b4("0x3cf")][_0x34d0dd];
        _0xea81aa[_0x40b4("0x17a")](0x0, 0x0, Math[_0x40b4("0x3d8")]() * 0x168);
        this[_0x40b4("0x3d4")][_0x34d0dd] =
          (Math[_0x40b4("0x3d8")]() * 0x2 - 0x1) * 0xb4 * _0x167d73;
      }
    }
    this["dodged"] = ![];
  }
  [_0x40b4("0x236")](_0x346ad7) {
    if (this[_0x40b4("0x38d")] === 0x0) {
      return;
    }
    this[_0x40b4("0x3d7")][_0x40b4("0x3d9")](
      0x0,
      0x0,
      this[_0x40b4("0x38d")] * _0x346ad7
    );
    for (
      var _0x4bcc19 = 0x0;
      _0x4bcc19 < this[_0x40b4("0x3cf")]["length"];
      _0x4bcc19 += 0x1
    ) {
      const _0x496e2e = this[_0x40b4("0x3cf")][_0x4bcc19];
      const _0x31ed28 = this[_0x40b4("0x3d4")][_0x4bcc19];
      _0x496e2e[_0x40b4("0x3d9")](0x0, 0x0, _0x31ed28 * _0x346ad7);
    }
  }
  ["checkCollision"](_0x34d976, _0x1e1719, _0xfc5b4f, _0x15bf5a) {
    if (!GameManager["instance"][_0x40b4("0x123")]) {
      return;
    }
    if (this[_0x40b4("0x3da")]) {
      return;
    }
    const _0x3df51b = this["entity"]["getPosition"]();
    this[_0x40b4("0x3d0")]
      [_0x40b4("0x12e")](_0x3df51b)
      [_0x40b4("0x16d")](_0x34d976[_0x40b4("0x3db")]);
    if (
      _0x34d976[_0x40b4("0x3db")]["z"] -
        GameManager[_0x40b4("0xca")]["radiusSq"] * 0x2 >
      _0x3df51b["z"]
    ) {
      this[_0x40b4("0x3da")] = !![];
      StatisticsManager[_0x40b4("0xca")]["incrementStat"](
        _0x40b4("0x3dc"),
        0x1,
        { obstacle_type: this[_0x40b4("0xb8")][_0x40b4("0x153")] }
      );
      return;
    }
    const _0x18c320 = this[_0x40b4("0x3d0")][_0x40b4("0x3dd")]();
    if (TunnelMeshGenerator[_0x40b4("0xca")][_0x40b4("0x10f")] < _0x18c320) {
      return;
    }
    if (_0x15bf5a) {
      return;
    }
    for (
      var _0x2d255d = 0x0;
      _0x2d255d < this[_0x40b4("0x3d1")][_0x40b4("0x87")];
      _0x2d255d++
    ) {
      const _0x79d959 = this["hitboxScripts"][_0x2d255d];
      _0x79d959[_0x40b4("0x3d6")](_0x34d976, _0x1e1719, _0xfc5b4f);
    }
  }
  [_0x40b4("0x1f1")]() {
    this[_0x40b4("0xd6")][_0x40b4("0x100")](
      _0x40b4("0x3d5"),
      this["checkCollision"],
      this
    );
    this["entity"][_0x40b4("0x1ef")]["recycle"](this["entity"]);
  }
}
pc[_0x40b4("0x1f4")](Obstacle, _0x40b4("0x3de"));
Obstacle["addAttributes"]();
class PathGenerator extends pc[_0x40b4("0xb0")] {
  static [_0x40b4("0xb1")]() {
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x3df"), {
      type: _0x40b4("0xb8"),
    });
    this[_0x40b4("0x2d")]["add"](_0x40b4("0x3e0"), { type: _0x40b4("0xb8") });
    this[_0x40b4("0x2d")]["add"]("distanceBetweenNodes", {
      type: _0x40b4("0x34"),
      default: 0xa,
    });
    this[_0x40b4("0x2d")]["add"](_0x40b4("0x3e1"), {
      type: _0x40b4("0x34"),
      default: 0x2,
    });
    this["attributes"][_0x40b4("0x2e")](_0x40b4("0x3e2"), {
      type: "number",
      default: 0x28,
    });
    this["attributes"][_0x40b4("0x2e")]("nodeParent", {
      type: _0x40b4("0xb8"),
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")]("obstacleParents", {
      type: _0x40b4("0xb8"),
    });
  }
  [_0x40b4("0xc9")]() {
    PathGenerator[_0x40b4("0xca")] = this;
    this["path"] = this["pathEntity"]["script"][_0x40b4("0x3ce")];
    this[_0x40b4("0x3e3")] =
      this[_0x40b4("0x3e0")][_0x40b4("0x1a9")][_0x40b4("0x3e3")];
    this[_0x40b4("0x3e4")] = [];
    this[_0x40b4("0x3e5")] = this[_0x40b4("0x3e6")][_0x40b4("0x1a8")];
    this[_0x40b4("0x3e5")][0x0][_0x40b4("0x3ba")](
      pc[_0x40b4("0x16a")][_0x40b4("0x15c")]
    );
    this[_0x40b4("0x3e7")] = this[_0x40b4("0x3e8")][_0x40b4("0x1a8")];
    this[_0x40b4("0xd6")]["on"](_0x40b4("0x3e9"));
    this[_0x40b4("0x3e3")]["init"](this[_0x40b4("0x3ce")]);
  }
  [_0x40b4("0xde")]() {}
  [_0x40b4("0x120")](_0xa8f876, _0x279b36 = !![]) {
    this["obstaclePositions"][_0x40b4("0x87")] = 0x0;
    this["recycleObstacles"]();
    this[_0x40b4("0x3ea")]();
    this[_0x40b4("0x3eb")](_0xa8f876);
    this[_0x40b4("0x3e3")][_0x40b4("0x3ec")](_0x279b36);
  }
  [_0x40b4("0x3ea")]() {
    let _0x3b6eb1 = 0x0;
    let _0x3114d7 = 0x0;
    let _0x483f48 = 0x0;
    let _0x5d0b73 = 0x0;
    for (
      let _0x437ffa = 0x1;
      _0x437ffa < this[_0x40b4("0x3e5")][_0x40b4("0x87")];
      _0x437ffa++
    ) {
      const _0x612e69 = this[_0x40b4("0x3e5")][_0x437ffa];
      _0x3114d7 = _0x437ffa * this["distanceBetweenNodes"];
      const _0x1d2df3 = pc["math"][_0x40b4("0x3d8")](0x0, 0x2) * Math["PI"];
      const _0x4c3f7d =
        this["radiusBetweenNodes"] * Math[_0x40b4("0x22f")](_0x1d2df3);
      const _0x1e215c =
        this["radiusBetweenNodes"] * Math[_0x40b4("0x230")](_0x1d2df3);
      _0x483f48 += _0x4c3f7d;
      _0x3b6eb1 += _0x1e215c;
      _0x5d0b73 +=
        pc[_0x40b4("0x3ed")]["random"](-0x1, 0x1) * this[_0x40b4("0x3e2")];
      _0x612e69["setLocalEulerAngles"](0x0, 0x0, _0x5d0b73);
      _0x612e69[_0x40b4("0x3ba")](_0x483f48, _0x3b6eb1, _0x3114d7);
    }
    this[_0x40b4("0x3ce")][_0x40b4("0x3ee")]();
  }
  [_0x40b4("0x3eb")](_0x169cef) {
    if (GameManager[_0x40b4("0xca")]["intro"]) {
      return;
    }
    const _0x48e48f = Chunks[_0x40b4("0xca")][_0x40b4("0x3ef")](
      LevelManager[_0x40b4("0xca")]["level"]
    );
    for (
      var _0x3cb8e1 = 0x0;
      _0x3cb8e1 < _0x48e48f[_0x40b4("0x3f0")];
      _0x3cb8e1++
    ) {
      const _0x214faf = this["getValidObstaclePosition"](_0x169cef);
      if (typeof _0x214faf !== _0x40b4("0x34")) {
        window[_0x40b4("0x3")][_0x40b4("0x56")](
          "Couldn\x27t\x20find\x20a\x20valid\x20position"
        );
        continue;
      }
      const _0x3fac66 = Chunks[_0x40b4("0xca")][_0x40b4("0x3f1")]();
      const _0x1914e3 =
        _0x3fac66[_0x40b4("0x1a9")]["objectPool"][_0x40b4("0x1f0")]();
      _0x1914e3[_0x40b4("0xd4")] = !![];
      _0x1914e3[_0x40b4("0x1f3")](this[_0x40b4("0x3e8")]);
      this[_0x40b4("0x3ce")][_0x40b4("0x3ca")](_0x1914e3, _0x214faf);
      _0x1914e3[_0x40b4("0x1a9")][_0x40b4("0x3de")][_0x40b4("0x1d0")](
        _0x48e48f[_0x40b4("0x3f2")]
      );
    }
    this["obstaclePositions"][_0x40b4("0x3f3")]();
  }
  [_0x40b4("0x3f4")](_0x281212) {
    let _0x47882f = 0x0;
    let _0x3e460b = 0x32;
    let _0x17713f = ![];
    do {
      _0x47882f = pc["math"][_0x40b4("0x3d8")](
        _0x281212
          ? PathGenerator[_0x40b4("0x3f5")]
          : PathGenerator[_0x40b4("0x3f6")],
        PathGenerator[_0x40b4("0x3f7")]
      );
      _0x17713f = ![];
      for (
        var _0x372d0d = 0x0;
        _0x372d0d < this["obstaclePositions"]["length"];
        _0x372d0d++
      ) {
        const _0x104cc7 = this[_0x40b4("0x3e4")][_0x372d0d];
        if (
          Math[_0x40b4("0x3f8")](_0x47882f - _0x104cc7) <
          PathGenerator["MINIMAL_DISTANCE_T"]
        ) {
          _0x17713f = !![];
          break;
        }
      }
      _0x3e460b--;
      if (_0x3e460b === 0x0) {
        break;
      }
    } while (_0x17713f);
    if (_0x3e460b <= 0x0 && _0x17713f) {
      return null;
    }
    this[_0x40b4("0x3e4")][_0x40b4("0x18")](_0x47882f);
    return _0x47882f;
  }
  ["recycleObstacles"]() {
    for (
      var _0x312032 = this["obstacleParents"][_0x40b4("0x1a8")]["length"] - 0x1;
      _0x312032 >= 0x0;
      _0x312032--
    ) {
      const _0x3c653a =
        this[_0x40b4("0x3e8")]["children"][_0x312032][_0x40b4("0x1a9")][
          _0x40b4("0x3de")
        ];
      _0x3c653a[_0x40b4("0x1f1")]();
    }
  }
}
pc["registerScript"](PathGenerator, "pathGenerator");
PathGenerator["addAttributes"]();
PathGenerator[_0x40b4("0x3f5")] = 0.05;
PathGenerator[_0x40b4("0x3f6")] = 0.05;
PathGenerator[_0x40b4("0x3f7")] = 0.95;
PathGenerator[_0x40b4("0x3f9")] = 0.02;
class ObstacleMeshGenerator extends pc[_0x40b4("0xb0")] {
  static ["addAttributes"]() {
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x3fa"), {
      type: _0x40b4("0x45"),
      assetType: _0x40b4("0x46"),
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x3fb"), {
      type: _0x40b4("0x45"),
      assetType: _0x40b4("0x3fb"),
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")]("obstacleX", {
      type: _0x40b4("0x34"),
      default: -0x1,
    });
    this["attributes"]["add"](_0x40b4("0x3fc"), {
      type: _0x40b4("0x34"),
      default: 0x2,
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x3fd"), {
      type: _0x40b4("0x34"),
      default: 0.5,
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")]("renderStyle", {
      type: "number",
      enum: [
        { Solid: pc["RENDERSTYLE_SOLID"] },
        { Points: pc[_0x40b4("0x3fe")] },
        { Wireframe: pc[_0x40b4("0x3ff")] },
      ],
      default: pc["RENDERSTYLE_SOLID"],
    });
  }
  ["initialize"]() {
    ObstacleMeshGenerator[_0x40b4("0xca")] = this;
    this["multiplierArray"] = [
      this[_0x40b4("0x400")],
      this[_0x40b4("0x3fc")],
      this[_0x40b4("0x3fd")],
    ];
    this["on"]("attr:renderStyle", () => {
      this[_0x40b4("0x3c6")][_0x40b4("0x401")] = this[_0x40b4("0x401")];
    });
    this[_0x40b4("0x402")] = new pc[_0x40b4("0x403")](
      this["app"][_0x40b4("0x2ab")]
    );
    this[_0x40b4("0x3ec")]();
  }
  ["createRender"]() {
    var _0x5ca3df = null;
    if (!this[_0x40b4("0x3fb")]) {
      _0x5ca3df = new pc[_0x40b4("0x404")]();
      _0x5ca3df[_0x40b4("0x405")][_0x40b4("0x15d")](0x1, 0x0, 0x0, 0x1);
      _0x5ca3df[_0x40b4("0x236")]();
    } else {
      _0x5ca3df = this[_0x40b4("0x3fb")]["resource"];
    }
    var _0x1287a5 = new pc[_0x40b4("0x406")]();
    var _0x4434a7 = new pc["MeshInstance"](
      this[_0x40b4("0x402")],
      _0x5ca3df,
      _0x1287a5
    );
    this[_0x40b4("0xb8")][_0x40b4("0x357")](_0x40b4("0x3c6"), {
      meshInstances: [_0x4434a7],
    });
    this[_0x40b4("0x3c6")] = this[_0x40b4("0xb8")]["render"];
    this[_0x40b4("0x3c6")][_0x40b4("0x401")] = this["renderStyle"];
    this[_0x40b4("0xb8")][_0x40b4("0x407")](_0x1287a5);
  }
  ["generateMesh"]() {
    this[_0x40b4("0x408")]();
    if (!this[_0x40b4("0x3c6")]) {
      this[_0x40b4("0x409")]();
    }
  }
  [_0x40b4("0x408")]() {
    const _0x4addc7 = [
      ...this[_0x40b4("0x3fa")][_0x40b4("0x5a")][_0x40b4("0x40a")],
    ];
    for (
      var _0x4d7fb5 = 0x0;
      _0x4d7fb5 < _0x4addc7[_0x40b4("0x87")];
      _0x4d7fb5++
    ) {
      const _0x4fbf8d = _0x4d7fb5 % this["multiplierArray"][_0x40b4("0x87")];
      _0x4addc7[_0x4d7fb5] =
        _0x4addc7[_0x4d7fb5] * this["multiplierArray"][_0x4fbf8d];
    }
    this[_0x40b4("0x40a")] = new Float32Array(_0x4addc7);
    this["uvs"] = new Float32Array(
      this["meshData"]["resource"][_0x40b4("0x40b")]
    );
    this[_0x40b4("0x40c")] =
      this[_0x40b4("0x3fa")]["resource"][_0x40b4("0x40c")];
    this[_0x40b4("0x40d")]();
  }
  ["updateMesh"]() {
    this[_0x40b4("0x402")][_0x40b4("0x40e")](this["positions"]);
    this[_0x40b4("0x402")][_0x40b4("0x40f")](0x0, this[_0x40b4("0x40b")]);
    this[_0x40b4("0x402")][_0x40b4("0x410")](this[_0x40b4("0x40c")]);
    this["mesh"]["setNormals"](
      pc[_0x40b4("0x411")](this[_0x40b4("0x40a")], this[_0x40b4("0x40c")])
    );
    this[_0x40b4("0x402")][_0x40b4("0x236")]();
  }
}
pc[_0x40b4("0x1f4")](ObstacleMeshGenerator, _0x40b4("0x412"));
ObstacleMeshGenerator[_0x40b4("0xb1")]();
class TunnelMeshGenerator extends pc[_0x40b4("0xb0")] {
  static [_0x40b4("0xb1")]() {
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x413"), {
      type: _0x40b4("0x34"),
      default: 0x9,
    });
    this[_0x40b4("0x2d")]["add"](_0x40b4("0x414"), {
      type: _0x40b4("0x34"),
      default: 0xc8,
    });
    this["attributes"]["add"]("radius", {
      type: _0x40b4("0x34"),
      default: 1.5,
    });
    this["attributes"][_0x40b4("0x2e")]("material", {
      type: "asset",
      assetType: _0x40b4("0x3fb"),
    });
    this[_0x40b4("0x2d")]["add"]("uvXDivision", {
      type: _0x40b4("0x34"),
      default: 0x1,
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")]("uvYDivision", {
      type: _0x40b4("0x34"),
      default: 0x1,
    });
  }
  ["initialize"]() {
    TunnelMeshGenerator[_0x40b4("0xca")] = this;
    this[_0x40b4("0x10f")] =
      this[_0x40b4("0x10a")] * this["radius"] * this[_0x40b4("0x10a")];
    this["app"]["on"](_0x40b4("0x38"), () => {
      this[_0x40b4("0x3c6")][_0x40b4("0x401")] = GameManager["instance"][
        _0x40b4("0x38")
      ]
        ? pc[_0x40b4("0x3ff")]
        : pc[_0x40b4("0x415")];
    });
    this["on"](_0x40b4("0x416"), this["generateMesh"], this);
    this["on"](_0x40b4("0x417"), this[_0x40b4("0x3ec")], this);
    this[_0x40b4("0x418")] = !![];
    this["positions"] = new Float32Array(
      this[_0x40b4("0x413")] * this[_0x40b4("0x414")] * 0x3
    );
    this[_0x40b4("0x40b")] = new Float32Array(
      this[_0x40b4("0x413")] * this[_0x40b4("0x414")] * 0x2
    );
    this[_0x40b4("0x40c")] = [];
    this[_0x40b4("0x419")] = [];
    this["on"](_0x40b4("0x41a"), this["updateUV"], this);
    this["on"](_0x40b4("0x41b"), this[_0x40b4("0x41c")], this);
    this["mesh"] = new pc["Mesh"](this[_0x40b4("0xd6")]["graphicsDevice"]);
  }
  [_0x40b4("0x1d0")](_0x107159) {
    this["path"] = _0x107159;
  }
  [_0x40b4("0x409")]() {
    var _0x10b61b = this[_0x40b4("0x3fb")]
      ? this[_0x40b4("0x3fb")][_0x40b4("0x5a")]
      : new pc["StandardMaterial"]();
    var _0x3c6330 = new pc["GraphNode"]();
    var _0x13cb31 = new pc[_0x40b4("0x41d")](
      this[_0x40b4("0x402")],
      _0x10b61b,
      _0x3c6330
    );
    this[_0x40b4("0xb8")][_0x40b4("0x357")](_0x40b4("0x3c6"), {
      meshInstances: [_0x13cb31],
    });
    this["render"] = this["entity"]["render"];
    this[_0x40b4("0x3c6")]["renderStyle"] = this[_0x40b4("0x401")];
    this[_0x40b4("0x3c6")]["renderStyle"] = GameManager[_0x40b4("0xca")][
      _0x40b4("0x38")
    ]
      ? pc[_0x40b4("0x3ff")]
      : pc[_0x40b4("0x415")];
  }
  ["reset"]() {
    this[_0x40b4("0x40a")] = new Float32Array(
      this["circleDivision"] * this["lengthDivision"] * 0x3
    );
    this[_0x40b4("0x40b")] = new Float32Array(
      this[_0x40b4("0x413")] * this[_0x40b4("0x414")] * 0x2
    );
    this[_0x40b4("0x40c")][_0x40b4("0x87")] = 0x0;
    this[_0x40b4("0x419")]["length"] = 0x0;
  }
  [_0x40b4("0x3ec")](_0x5c4fe8) {
    this[_0x40b4("0x41e")]();
    this[_0x40b4("0x41f")]();
    this["createMesh"]();
    this[_0x40b4("0x40d")]();
    this[_0x40b4("0x420")](_0x5c4fe8);
    if (!this["render"]) {
      this[_0x40b4("0x409")]();
    }
  }
  [_0x40b4("0x41f")]() {
    for (let _0x180f22 = 0x0; _0x180f22 < this["circleDivision"]; _0x180f22++) {
      const _0x1bb709 = [];
      const _0x4407d9 =
        (_0x180f22 / (this["circleDivision"] - 0x1)) * 0x2 * Math["PI"];
      for (
        let _0x20e79d = 0x0;
        _0x20e79d < this[_0x40b4("0x414")];
        _0x20e79d++
      ) {
        const _0x57e139 = _0x20e79d / (this[_0x40b4("0x414")] - 0x1);
        const _0x17ef7a = this[_0x40b4("0x3ce")][_0x40b4("0x3be")](
          _0x57e139,
          this[_0x40b4("0x10a")],
          _0x4407d9
        );
        _0x1bb709[_0x40b4("0x18")](_0x17ef7a);
      }
      this[_0x40b4("0x419")][_0x40b4("0x18")](_0x1bb709);
    }
  }
  [_0x40b4("0x408")]() {
    let _0x4b9b07 = 0x0;
    for (let _0x4ced63 = 0x0; _0x4ced63 < this[_0x40b4("0x413")]; _0x4ced63++) {
      for (
        let _0x3fbf52 = 0x0;
        _0x3fbf52 < this[_0x40b4("0x414")];
        _0x3fbf52++
      ) {
        const _0x1521de = this[_0x40b4("0x419")][_0x4ced63][_0x3fbf52];
        this[_0x40b4("0x40a")][_0x4b9b07++] = _0x1521de["x"];
        this[_0x40b4("0x40a")][_0x4b9b07++] = _0x1521de["y"];
        this[_0x40b4("0x40a")][_0x4b9b07++] = _0x1521de["z"];
      }
    }
    _0x4b9b07 = 0x0;
    for (let _0x3795ea = 0x0; _0x3795ea < this[_0x40b4("0x413")]; _0x3795ea++) {
      for (
        let _0x3391b5 = 0x0;
        _0x3391b5 < this[_0x40b4("0x414")];
        _0x3391b5++
      ) {
        this[_0x40b4("0x40b")][_0x4b9b07++] =
          (_0x3795ea / (this[_0x40b4("0x413")] - 0x1)) * this["uvXDivision"];
        this[_0x40b4("0x40b")][_0x4b9b07++] =
          (_0x3391b5 / (this[_0x40b4("0x414")] - 0x1)) * this[_0x40b4("0x421")];
      }
    }
    for (
      let _0x216e37 = 0x0;
      _0x216e37 < this[_0x40b4("0x413")] - 0x1;
      _0x216e37++
    ) {
      for (
        let _0x15cb74 = 0x0;
        _0x15cb74 < this[_0x40b4("0x414")] - 0x1;
        _0x15cb74++
      ) {
        const _0x35c2b6 = _0x216e37 * this[_0x40b4("0x414")] + _0x15cb74;
        const _0x426659 =
          (_0x216e37 + 0x1) * this[_0x40b4("0x414")] + _0x15cb74;
        const _0x4f3117 =
          (_0x216e37 + 0x1) * this[_0x40b4("0x414")] + _0x15cb74 + 0x1;
        const _0x4c85b3 = _0x216e37 * this[_0x40b4("0x414")] + _0x15cb74 + 0x1;
        this[_0x40b4("0x40c")][_0x40b4("0x18")](
          _0x35c2b6,
          _0x4f3117,
          _0x426659
        );
        this[_0x40b4("0x40c")][_0x40b4("0x18")](
          _0x35c2b6,
          _0x4c85b3,
          _0x4f3117
        );
      }
    }
  }
  [_0x40b4("0x41c")]() {
    this[_0x40b4("0x40b")] = new Float32Array(
      this[_0x40b4("0x413")] * this[_0x40b4("0x414")] * 0x2
    );
    let _0x40722c = 0x0;
    for (let _0xb89c67 = 0x0; _0xb89c67 < this["circleDivision"]; _0xb89c67++) {
      for (
        let _0x48f4c4 = 0x0;
        _0x48f4c4 < this["lengthDivision"];
        _0x48f4c4++
      ) {
        this[_0x40b4("0x40b")][_0x40722c++] =
          (_0xb89c67 / this[_0x40b4("0x413")]) * this[_0x40b4("0x422")];
        this[_0x40b4("0x40b")][_0x40722c++] =
          (_0x48f4c4 / this["lengthDivision"]) * this["uvYDivision"];
      }
    }
    this["mesh"][_0x40b4("0x40f")](0x0, this[_0x40b4("0x40b")]);
    this[_0x40b4("0x402")][_0x40b4("0x236")]();
  }
  ["updateMesh"]() {
    const _0x148be1 = this[_0x40b4("0x423")](
      pc[_0x40b4("0x411")](this[_0x40b4("0x40a")], this[_0x40b4("0x40c")])
    );
    this[_0x40b4("0x402")][_0x40b4("0x40e")](this[_0x40b4("0x40a")]);
    this[_0x40b4("0x402")]["setUvs"](0x0, this[_0x40b4("0x40b")]);
    this[_0x40b4("0x402")]["setIndices"](this["indices"]);
    this[_0x40b4("0x402")]["setNormals"](_0x148be1);
    this[_0x40b4("0x402")][_0x40b4("0x236")]();
  }
  ["fixSharedNormals"](_0x1de906) {
    for (
      var _0x480049 = 0x0;
      _0x480049 < this[_0x40b4("0x414")] * 0x3;
      _0x480049 += 0x3
    ) {
      var _0x3d394f = _0x1de906[_0x480049];
      var _0x3bbc50 = _0x1de906[_0x480049 + 0x1];
      var _0x45b949 = _0x1de906[_0x480049 + 0x2];
      _0x1de906[
        this[_0x40b4("0x414")] * (this[_0x40b4("0x413")] - 0x1) * 0x3 +
          _0x480049
      ] = _0x3d394f;
      _0x1de906[
        this[_0x40b4("0x414")] * (this["circleDivision"] - 0x1) * 0x3 +
          _0x480049 +
          0x1
      ] = _0x3bbc50;
      _0x1de906[
        this[_0x40b4("0x414")] * (this["circleDivision"] - 0x1) * 0x3 +
          _0x480049 +
          0x2
      ] = _0x45b949;
    }
    return _0x1de906;
  }
  ["setTexture"](_0x5820c6) {
    const _0x4ef574 =
      TextureGenerator[_0x40b4("0xca")][_0x40b4("0x424")](_0x5820c6);
    this[_0x40b4("0x422")] = _0x4ef574[_0x40b4("0x422")];
    this[_0x40b4("0x421")] = _0x4ef574[_0x40b4("0x421")];
    this["material"]["resource"][_0x40b4("0x425")] =
      _0x4ef574[_0x40b4("0x194")];
    this[_0x40b4("0x3fb")][_0x40b4("0x5a")][_0x40b4("0x236")]();
  }
}
pc["registerScript"](TunnelMeshGenerator, _0x40b4("0x3e3"));
TunnelMeshGenerator[_0x40b4("0xb1")]();
class ObstacleHitbox extends pc[_0x40b4("0xb0")] {
  static [_0x40b4("0xb1")]() {
    this["attributes"]["add"](_0x40b4("0x426"), { type: "vec3" });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x427"), {
      type: _0x40b4("0xb8"),
    });
  }
  [_0x40b4("0xc9")]() {
    this["aabb"] = new pc["OrientedBox"](
      this["entity"][_0x40b4("0x428")](),
      this[_0x40b4("0x426")]
    );
    this["render"] = this[_0x40b4("0x427")][_0x40b4("0x3c6")];
    this[_0x40b4("0x427")][_0x40b4("0x184")](
      this["halfExtents"]["x"] * 0x2,
      this[_0x40b4("0x426")]["y"] * 0x2,
      this[_0x40b4("0x426")]["z"] * 0x2
    );
    if (this["render"]) {
      this["render"][_0x40b4("0x401")] = pc["RENDERSTYLE_WIREFRAME"];
    }
    this["app"]["on"](_0x40b4("0x38"), this["setRenderVisibility"], this);
    this[_0x40b4("0x429")](GameManager[_0x40b4("0xca")][_0x40b4("0x38")]);
  }
  [_0x40b4("0x1d0")]() {
    this[_0x40b4("0x42a")][_0x40b4("0x42b")] =
      this[_0x40b4("0xb8")][_0x40b4("0x428")]();
  }
  [_0x40b4("0x429")](
    _0x2fa693 = GameManager[_0x40b4("0xca")][_0x40b4("0x38")]
  ) {
    if (!this[_0x40b4("0x3c6")]) {
      console[_0x40b4("0x7")]("it\x20has\x20no\x20render\x20component");
      return;
    }
    this[_0x40b4("0x3c6")][_0x40b4("0xd4")] = _0x2fa693;
  }
  [_0x40b4("0x3d6")](_0x2fd035, _0x46d1c2, _0x475521) {
    if (!this[_0x40b4("0x42a")]) {
      return;
    }
    this["aabb"][_0x40b4("0x42b")] = this[_0x40b4("0xb8")][_0x40b4("0x428")]();
    if (
      this["aabb"][_0x40b4("0x42c")](
        _0x46d1c2,
        ObstacleHitbox[_0x40b4("0x42d")]
      )
    ) {
      var _0x16f077 = ObstacleHitbox["POINT"]["distance"](
        PlayerHurtbox[_0x40b4("0xca")][_0x40b4("0x42e")]
      );
      if (_0x16f077 < _0x475521) {
        GameManager[_0x40b4("0xca")][_0x40b4("0x42f")]();
      }
    }
    if (this["aabb"][_0x40b4("0x430")](_0x2fd035)) {
      GameManager[_0x40b4("0xca")][_0x40b4("0x42f")]();
    }
  }
}
pc[_0x40b4("0x1f4")](ObstacleHitbox, _0x40b4("0x3d2"));
ObstacleHitbox[_0x40b4("0xb1")]();
ObstacleHitbox[_0x40b4("0x42d")] = new pc[_0x40b4("0x16a")]();
class PlayerHurtbox extends pc[_0x40b4("0xb0")] {
  static ["addAttributes"]() {
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x10a"), {
      type: "number",
      default: 0.05,
    });
  }
  [_0x40b4("0xc9")]() {
    PlayerHurtbox["instance"] = this;
    this["app"]["on"](_0x40b4("0x431"), this[_0x40b4("0x432")], this);
    this["previousPosition"] = this[_0x40b4("0xb8")]
      [_0x40b4("0x3c5")]()
      ["clone"]();
    this[_0x40b4("0x433")] = new pc[_0x40b4("0x16a")]();
    this[_0x40b4("0x434")] = new pc[_0x40b4("0x435")](
      this[_0x40b4("0x42e")],
      this[_0x40b4("0xb8")][_0x40b4("0x3c7")]
    );
    this[_0x40b4("0x42a")] = new pc[_0x40b4("0x436")](
      this[_0x40b4("0xb8")][_0x40b4("0x3c5")](),
      this[_0x40b4("0x10a")]
    );
    this[_0x40b4("0x429")]();
    this[_0x40b4("0x437")]();
    this["on"](_0x40b4("0x438"), this["setRadius"], this);
    this["app"]["on"](_0x40b4("0x38"), this[_0x40b4("0x429")], this);
    this[_0x40b4("0x42e")] = this[_0x40b4("0xb8")]
      [_0x40b4("0x3c5")]()
      [_0x40b4("0x166")]();
    this[_0x40b4("0x434")] = new pc[_0x40b4("0x435")]();
  }
  [_0x40b4("0x437")]() {
    this[_0x40b4("0x42a")][_0x40b4("0x10a")] = this["radius"];
    this["entity"][_0x40b4("0x184")](
      this[_0x40b4("0x10a")] * 0x2,
      this[_0x40b4("0x10a")] * 0x2,
      this[_0x40b4("0x10a")] * 0x2
    );
  }
  [_0x40b4("0x429")](_0x29560c = GameManager["instance"][_0x40b4("0x38")]) {
    this["entity"]["render"]["enabled"] = _0x29560c;
  }
  [_0x40b4("0x432")]() {
    const _0x4442b3 = this[_0x40b4("0xb8")]["getPosition"]();
    this[_0x40b4("0x42a")][_0x40b4("0x3db")] = _0x4442b3;
    PlayerHurtbox[_0x40b4("0x439")]
      [_0x40b4("0x16f")](_0x4442b3, this[_0x40b4("0x42e")])
      [_0x40b4("0x3bf")]();
    this["ray"][_0x40b4("0x15d")](
      this["previousPosition"],
      PlayerHurtbox[_0x40b4("0x439")]
    );
    const _0x3a2249 = this[_0x40b4("0x42e")][_0x40b4("0x3d0")](_0x4442b3);
    this["app"]["fire"](
      _0x40b4("0x3d5"),
      this[_0x40b4("0x42a")],
      this["ray"],
      _0x3a2249,
      this[_0x40b4("0x43a")]
    );
    this[_0x40b4("0x42e")]["copy"](_0x4442b3);
  }
  [_0x40b4("0x43b")](_0x3af625 = 0x3) {
    this[_0x40b4("0x43a")] = !![];
    pc[_0x40b4("0x334")]["add"](_0x3af625, this["disableInvincibility"], this);
  }
  ["disableInvincibility"]() {
    this[_0x40b4("0x43a")] = ![];
  }
}
pc["registerScript"](PlayerHurtbox, _0x40b4("0x43c"));
PlayerHurtbox[_0x40b4("0xb1")]();
PlayerHurtbox["VEC_3"] = new pc[_0x40b4("0x16a")]();
class TextureGenerator extends pc["ScriptType"] {
  static ["addAttributes"]() {}
  [_0x40b4("0xc9")]() {
    TextureGenerator[_0x40b4("0xca")] = this;
    this[_0x40b4("0x43d")] = 0x0;
    this[_0x40b4("0x194")] = null;
    this["uvXDivision"] = 0x1;
    this[_0x40b4("0x421")] = 0x1;
    this[_0x40b4("0x43e")] = 0x3;
    this[_0x40b4("0x43d")] = Math[_0x40b4("0x43f")](
      Math[_0x40b4("0x3d8")]() * this["textureAmount"]
    );
    this[_0x40b4("0x440")] = -0x1;
  }
  [_0x40b4("0x441")]() {
    if (this[_0x40b4("0x194")] instanceof pc[_0x40b4("0x442")]) {
      this[_0x40b4("0x194")][_0x40b4("0x1b0")]();
      delete this[_0x40b4("0x194")];
    }
  }
  [_0x40b4("0x424")](_0x317ae5 = !![]) {
    this[_0x40b4("0x441")]();
    this[_0x40b4("0x43d")] += _0x317ae5 ? 0x1 : 0x0;
    let _0x3de85e = this["index"] % this[_0x40b4("0x43e")];
    switch (_0x3de85e) {
      case 0x0:
        this[_0x40b4("0x194")] = this[_0x40b4("0x443")]();
        break;
      case 0x1:
        this[_0x40b4("0x194")] = this[_0x40b4("0x444")]();
        break;
      case 0x2:
        this[_0x40b4("0x194")] = this[_0x40b4("0x445")]();
        break;
      default:
        console["warn"](_0x40b4("0x446"));
        break;
    }
    return {
      texture: this[_0x40b4("0x194")],
      uvXDivision: this[_0x40b4("0x422")],
      uvYDivision: this[_0x40b4("0x421")],
    };
  }
  [_0x40b4("0x445")]() {
    const _0x56c0ae = 0x8;
    const _0x55f391 = 0x8;
    var _0x1553a8 = new pc[_0x40b4("0x442")](
      this[_0x40b4("0xd6")][_0x40b4("0x2ab")],
      {
        width: _0x56c0ae,
        height: _0x55f391,
        format: pc[_0x40b4("0x447")],
        magFilter: pc["FILTER_NEAREST"],
      }
    );
    var _0x41a445 = _0x1553a8[_0x40b4("0x448")]();
    var _0x26cc72 = 0x0;
    const _0x344327 = Colors[_0x40b4("0xca")][_0x40b4("0x449")]()["colors"];
    for (var _0x542fed = 0x0; _0x542fed < _0x56c0ae; _0x542fed++) {
      for (var _0x155383 = 0x0; _0x155383 < _0x55f391; _0x155383++) {
        const _0x29f8d5 = (_0x542fed + _0x155383) % 0x2;
        _0x41a445[_0x26cc72++] = _0x344327[_0x29f8d5]["r"] * 0xff;
        _0x41a445[_0x26cc72++] = _0x344327[_0x29f8d5]["g"] * 0xff;
        _0x41a445[_0x26cc72++] = _0x344327[_0x29f8d5]["b"] * 0xff;
      }
    }
    this["uvXDivision"] = 2.25;
    this[_0x40b4("0x421")] = 0xa;
    _0x1553a8[_0x40b4("0x44a")]();
    return _0x1553a8;
  }
  [_0x40b4("0x443")]() {
    const _0x17025e = 0x400;
    const _0x341b2e = 0x400;
    var _0x5b19cb = new pc[_0x40b4("0x442")](
      this[_0x40b4("0xd6")][_0x40b4("0x2ab")],
      {
        width: _0x17025e,
        height: _0x341b2e,
        format: pc[_0x40b4("0x447")],
        magFilter: pc[_0x40b4("0x44b")],
      }
    );
    var _0x40d1d3 = _0x5b19cb[_0x40b4("0x448")]();
    var _0x2bebeb = 0x0;
    const _0x1e731b = 0x64;
    const _0xde5510 = (_0x17025e - _0x1e731b * 0x2) / 0x2;
    const _0x3a3544 = Colors[_0x40b4("0xca")]["getColor"]()[_0x40b4("0x44c")];
    for (var _0x31b7fb = 0x0; _0x31b7fb < _0x17025e; _0x31b7fb++) {
      for (var _0x2df508 = 0x0; _0x2df508 < _0x341b2e; _0x2df508++) {
        let _0x197c9c = null;
        if (_0x31b7fb < _0x1e731b / 0x2) {
          _0x197c9c = _0x3a3544[0x0];
        } else if (_0x31b7fb > 0x2 * _0xde5510 + 1.5 * _0x1e731b) {
          _0x197c9c = _0x3a3544[0x0];
        } else if (_0x2df508 < _0x1e731b / 0x2) {
          _0x197c9c = _0x3a3544[0x0];
        } else if (_0x2df508 > 0x2 * _0xde5510 + 1.5 * _0x1e731b) {
          _0x197c9c = _0x3a3544[0x0];
        } else if (
          _0x31b7fb < _0xde5510 + 1.5 * _0x1e731b &&
          _0x31b7fb > _0xde5510 + 0.5 * _0x1e731b
        ) {
          _0x197c9c = _0x3a3544[0x0];
        } else if (
          _0x2df508 < _0xde5510 + 1.5 * _0x1e731b &&
          _0x2df508 > _0xde5510 + 0.5 * _0x1e731b
        ) {
          _0x197c9c = _0x3a3544[0x0];
        } else {
          _0x197c9c = _0x3a3544[0x1];
        }
        _0x40d1d3[_0x2bebeb++] = _0x197c9c["r"] * 0xff;
        _0x40d1d3[_0x2bebeb++] = _0x197c9c["g"] * 0xff;
        _0x40d1d3[_0x2bebeb++] = _0x197c9c["b"] * 0xff;
      }
    }
    _0x5b19cb[_0x40b4("0x44a")]();
    this[_0x40b4("0x422")] = 4.5;
    this[_0x40b4("0x421")] = 0x50;
    return _0x5b19cb;
  }
  ["createStripesTexture"]() {
    const _0x426bf1 = 0x200;
    const _0x2dbca7 = 0x200;
    var _0x3ead92 = new pc["Texture"](this[_0x40b4("0xd6")][_0x40b4("0x2ab")], {
      width: _0x426bf1,
      height: _0x2dbca7,
      format: pc["PIXELFORMAT_R8_G8_B8"],
      magFilter: pc[_0x40b4("0x44d")],
      mipmaps: !![],
    });
    var _0x3ea9b6 = _0x3ead92["lock"]();
    var _0x2ee9a5 = 0x0;
    const _0x29f87c = 0x4;
    const _0x10d51a = _0x426bf1 / 0xa;
    const _0xa6df0d = ((_0x426bf1 / _0x29f87c) * 0x4) / 0x5;
    const _0x57426d = ((_0x426bf1 / _0x29f87c) * 0x1) / 0x5;
    const _0x5b40bd = (_0x2dbca7 - 0x2 * _0x10d51a) / 0x2;
    const _0x40b831 =
      Colors[_0x40b4("0xca")][_0x40b4("0x449")]()[_0x40b4("0x44c")];
    for (var _0x3f43e7 = 0x0; _0x3f43e7 < _0x426bf1; _0x3f43e7++) {
      for (var _0x117bd0 = 0x0; _0x117bd0 < _0x2dbca7; _0x117bd0++) {
        let _0x206e41 = null;
        const _0x2052b7 =
          _0x3f43e7 > _0x2dbca7 / 0x2 ? 0x0 : _0x426bf1 / _0x29f87c / 0x2;
        if (_0x3f43e7 < _0x10d51a / 0x2) {
          _0x206e41 = _0x40b831[0x0];
        } else if (_0x3f43e7 > 0x2 * _0x5b40bd + 1.5 * _0x10d51a) {
          _0x206e41 = _0x40b831[0x0];
        } else if (
          _0x3f43e7 < _0x5b40bd + 1.5 * _0x10d51a &&
          _0x3f43e7 > _0x5b40bd + 0.5 * _0x10d51a
        ) {
          _0x206e41 = _0x40b831[0x0];
        } else {
          const _0x48128a = (_0x117bd0 + _0x2052b7) % (_0xa6df0d + _0x57426d);
          if (_0x48128a < _0xa6df0d) {
            _0x206e41 = _0x40b831[0x0];
          } else {
            _0x206e41 = _0x40b831[0x1];
          }
        }
        _0x3ea9b6[_0x2ee9a5++] = _0x206e41["r"] * 0xff;
        _0x3ea9b6[_0x2ee9a5++] = _0x206e41["g"] * 0xff;
        _0x3ea9b6[_0x2ee9a5++] = _0x206e41["b"] * 0xff;
      }
    }
    _0x3ead92["unlock"]();
    this[_0x40b4("0x422")] = 2.25;
    this[_0x40b4("0x421")] = 0x32;
    return _0x3ead92;
  }
}
pc["registerScript"](TextureGenerator, _0x40b4("0x44e"));
TextureGenerator["addAttributes"]();
class CircleObstacle extends pc["ScriptType"] {
  static [_0x40b4("0xb1")]() {
    this["attributes"][_0x40b4("0x2e")](_0x40b4("0x3fa"), {
      type: _0x40b4("0x45"),
      assetType: _0x40b4("0x46"),
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x3fb"), {
      type: _0x40b4("0x45"),
      assetType: _0x40b4("0x3fb"),
    });
    this["attributes"][_0x40b4("0x2e")](_0x40b4("0x44f"), {
      type: "number",
      default: 0x3c,
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x450"), {
      type: _0x40b4("0x34"),
      default: 0x1,
    });
    this["attributes"][_0x40b4("0x2e")](_0x40b4("0x451"), {
      type: _0x40b4("0x34"),
      default: 0.7,
    });
    this["attributes"]["add"](_0x40b4("0x452"), {
      type: _0x40b4("0x34"),
      default: 0x1,
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x401"), {
      type: _0x40b4("0x34"),
      enum: [
        { Solid: pc[_0x40b4("0x415")] },
        { Points: pc[_0x40b4("0x3fe")] },
        { Wireframe: pc[_0x40b4("0x3ff")] },
      ],
      default: pc["RENDERSTYLE_SOLID"],
    });
  }
  [_0x40b4("0xc9")]() {
    this["on"]("attr:renderStyle", () => {
      this["render"][_0x40b4("0x401")] = this["renderStyle"];
    });
    this["mesh"] = new pc[_0x40b4("0x403")](this["app"][_0x40b4("0x2ab")]);
    this[_0x40b4("0x3ec")]();
  }
  [_0x40b4("0x409")]() {
    var _0x581dde = null;
    if (!this[_0x40b4("0x3fb")]) {
      _0x581dde = new pc[_0x40b4("0x404")]();
      _0x581dde[_0x40b4("0x405")][_0x40b4("0x15d")](0x1, 0x0, 0x0, 0x1);
      _0x581dde[_0x40b4("0x236")]();
    } else {
      _0x581dde = this["material"][_0x40b4("0x5a")];
    }
    var _0x564fdd = new pc["GraphNode"]();
    var _0x23c73b = new pc[_0x40b4("0x41d")](
      this[_0x40b4("0x402")],
      _0x581dde,
      _0x564fdd
    );
    this["entity"][_0x40b4("0x357")](_0x40b4("0x3c6"), {
      meshInstances: [_0x23c73b],
    });
    this[_0x40b4("0x3c6")] = this[_0x40b4("0xb8")]["render"];
    this["render"][_0x40b4("0x401")] = this[_0x40b4("0x401")];
    this[_0x40b4("0xb8")][_0x40b4("0x407")](_0x564fdd);
  }
  [_0x40b4("0x3ec")]() {
    this["createMesh"]();
    if (!this[_0x40b4("0x3c6")]) {
      this[_0x40b4("0x409")]();
    }
  }
  [_0x40b4("0x408")]() {
    this[_0x40b4("0x40a")] = new Float32Array(
      this["meshData"]["resource"]["positions"]
    );
    this["uvs"] = new Float32Array(
      this[_0x40b4("0x3fa")][_0x40b4("0x5a")][_0x40b4("0x40b")]
    );
    this[_0x40b4("0x40c")] =
      this[_0x40b4("0x3fa")][_0x40b4("0x5a")][_0x40b4("0x40c")];
    this[_0x40b4("0x40d")]();
  }
  ["updateMesh"]() {
    this[_0x40b4("0x402")]["setPositions"](this[_0x40b4("0x40a")]);
    this[_0x40b4("0x402")]["setUvs"](0x0, this[_0x40b4("0x40b")]);
    this[_0x40b4("0x402")][_0x40b4("0x410")](this[_0x40b4("0x40c")]);
    this["mesh"][_0x40b4("0x453")](
      pc[_0x40b4("0x411")](this[_0x40b4("0x40a")], this["indices"])
    );
    this[_0x40b4("0x402")][_0x40b4("0x236")]();
  }
}
pc[_0x40b4("0x1f4")](CircleObstacle, _0x40b4("0x454"));
CircleObstacle["addAttributes"]();
class ResultScreen extends pc[_0x40b4("0xb0")] {
  static [_0x40b4("0xb1")]() {
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x455"), {
      type: "entity",
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x456"), {
      type: _0x40b4("0xb8"),
    });
    this["attributes"][_0x40b4("0x2e")](_0x40b4("0x457"), {
      type: _0x40b4("0xb8"),
    });
    this["attributes"]["add"](_0x40b4("0x458"), { type: _0x40b4("0xb8") });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x459"), {
      type: "entity",
    });
    this[_0x40b4("0x2d")]["add"](_0x40b4("0x45a"), { type: "entity" });
    this[_0x40b4("0x2d")]["add"](_0x40b4("0x45b"), { type: "entity" });
  }
  [_0x40b4("0xc9")]() {
    this["adButtonEntityAnim"]["enabled"] = ![];
    this[_0x40b4("0x457")]["element"][_0x40b4("0x28f")] = this["currentScore"];
    this[_0x40b4("0x45c")] = !![];
  }
  [_0x40b4("0x1d7")]() {
    this[_0x40b4("0x45d")] = ![];
    this[_0x40b4("0x45c")] = !![];
    ScoreManager[_0x40b4("0xca")][_0x40b4("0x45e")]();
    Wrapper[_0x40b4("0xca")][_0x40b4("0x45f")](
      LevelManager[_0x40b4("0xca")]["level"],
      ScoreManager[_0x40b4("0xca")][_0x40b4("0x121")]
    );
    this[_0x40b4("0x460")]();
  }
  async [_0x40b4("0x460")]() {
    this[_0x40b4("0x455")][_0x40b4("0x184")](pc["Vec3"][_0x40b4("0x15c")]);
    this["highscoreGroup"][_0x40b4("0x184")](pc["Vec3"]["ZERO"]);
    this[_0x40b4("0x45a")][_0x40b4("0x184")](
      pc[_0x40b4("0x16a")][_0x40b4("0x15c")]
    );
    this[_0x40b4("0x45b")][_0x40b4("0x184")](pc["Vec3"][_0x40b4("0x15c")]);
    await this[_0x40b4("0x455")]
      [_0x40b4("0xf1")](this["scoreTextEntity"][_0x40b4("0x181")]())
      ["to"](new pc["Vec3"](1.15, 1.25, 0x1), 0.25, pc[_0x40b4("0x461")], 0.5)
      [_0x40b4("0x116")]()
      [_0x40b4("0x462")]();
    this[_0x40b4("0x458")][_0x40b4("0x154")][_0x40b4("0x28f")] =
      ScoreManager["instance"][_0x40b4("0x463")][_0x40b4("0x464")](0x1) +
      "\x20m";
    await this["highscoreGroup"]
      ["tween"](this["highscoreGroup"][_0x40b4("0x181")]())
      ["to"](pc["Vec3"][_0x40b4("0x465")], 0.25, pc["BackOut"], 0.5)
      [_0x40b4("0x116")]()
      [_0x40b4("0x462")]();
    const _0x4466d8 = ScoreManager[_0x40b4("0xca")][_0x40b4("0x463")];
    const _0x56a861 = ScoreManager[_0x40b4("0xca")][_0x40b4("0x466")];
    if (_0x56a861 > _0x4466d8) {
      ResultScreen[_0x40b4("0x467")][_0x40b4("0x468")] = _0x4466d8;
      await this["scoreTextEntity"]
        [_0x40b4("0xf1")](ResultScreen[_0x40b4("0x467")])
        ["to"]({ score: _0x56a861 }, 1.5, pc["Linear"], 0.5)
        ["on"](_0x40b4("0x236"), this["updateHighScore"], this)
        [_0x40b4("0x116")]()
        ["getPromise"]();
      ScoreManager[_0x40b4("0xca")][_0x40b4("0x463")] = _0x56a861;
    }
    await new Promise((_0x9364d0) => {
      pc["timer"][_0x40b4("0x2e")](0.25, _0x9364d0);
    });
    this["adButtonEntityAnim"]["enabled"] =
      GameManager[_0x40b4("0xca")][_0x40b4("0x469")]();
    const _0x874354 = this[_0x40b4("0x45b")]
      [_0x40b4("0xf1")](this[_0x40b4("0x45b")][_0x40b4("0x181")]())
      ["to"](pc["Vec3"][_0x40b4("0x465")], 0.25, pc[_0x40b4("0x46a")])
      [_0x40b4("0x116")]();
    this[_0x40b4("0x46b")] = this[_0x40b4("0x45b")]
      [_0x40b4("0xf1")](this["adButtonEntityAnim"][_0x40b4("0x181")]())
      ["to"](
        new pc[_0x40b4("0x16a")](0.78, 0.78, 0.78),
        0.5,
        pc[_0x40b4("0x46a")]
      )
      ["loop"](!![])
      [_0x40b4("0x224")](!![]);
    _0x874354[_0x40b4("0x46c")](this[_0x40b4("0x46b")]);
    await new Promise((_0x42a498) => {
      pc[_0x40b4("0x334")][_0x40b4("0x2e")](0.25, _0x42a498);
    });
    await this[_0x40b4("0x45a")]
      [_0x40b4("0xf1")](this[_0x40b4("0x45a")]["getLocalScale"]())
      ["to"](pc[_0x40b4("0x16a")][_0x40b4("0x465")], 0.25, pc[_0x40b4("0x461")])
      [_0x40b4("0x116")]()
      [_0x40b4("0x462")]();
    this[_0x40b4("0x45c")] = ![];
    this[_0x40b4("0xd6")]["keyboard"]["on"](
      pc["EVENT_KEYDOWN"],
      this["restartGame"],
      this
    );
  }
  ["updateHighScore"]() {
    this["highscoreTextEntity"][_0x40b4("0x154")][_0x40b4("0x28f")] =
      ResultScreen["SCORE"][_0x40b4("0x468")][_0x40b4("0x464")](0x1) + "\x20m";
  }
  ["onUIEntityClose"]() {
    this["tween2"][_0x40b4("0xea")]();
  }
  ["restartGame"]() {
    if (this[_0x40b4("0x45c")]) {
      return;
    }
    if (
      this["app"][_0x40b4("0x2cc")]["wasPressed"](pc[_0x40b4("0x46d")]) &&
      !this[_0x40b4("0x45c")] &&
      !GameManager[_0x40b4("0xca")][_0x40b4("0x123")]
    ) {
      this[_0x40b4("0x46e")]();
    }
  }
  ["onRestart"]() {
    if (this["continueClicked"]) {
      return;
    }
    const _0x2c68ea = UIManager[_0x40b4("0xca")][_0x40b4("0x135")](
      _0x40b4("0x129")
    );
    if (_0x2c68ea) {
      _0x2c68ea["then"](
        GameManager[_0x40b4("0xca")][_0x40b4("0x46f")],
        GameManager[_0x40b4("0xca")]
      );
    } else {
      GameManager[_0x40b4("0xca")][_0x40b4("0x46f")]();
    }
    PlayerMovement[_0x40b4("0xca")]["leftPressed"] = ![];
    PlayerMovement[_0x40b4("0xca")][_0x40b4("0x3a3")] = ![];
    this[_0x40b4("0x45c")] = !![];
  }
  [_0x40b4("0x470")]() {
    if (!GameManager[_0x40b4("0xca")][_0x40b4("0x469")]()) {
      window["famobi"]["log"](_0x40b4("0x471"));
      return;
    }
    if (this[_0x40b4("0x45d")]) {
      return;
    }
    this["continueClicked"] = !![];
    Wrapper[_0x40b4("0xca")][_0x40b4("0xc")](this[_0x40b4("0x472")], this);
    PlayerMovement[_0x40b4("0xca")][_0x40b4("0x3a0")] = ![];
    PlayerMovement[_0x40b4("0xca")]["rightPressed"] = ![];
    this[_0x40b4("0x45c")] = !![];
  }
  [_0x40b4("0x472")](_0x197c6c) {
    if (_0x197c6c[_0x40b4("0x473")]) {
      UIManager[_0x40b4("0xca")][_0x40b4("0x135")](_0x40b4("0x129"));
      if (pc["platform"][_0x40b4("0x2a6")]) {
        GameManager["instance"][_0x40b4("0x474")]();
      } else {
        UIManager[_0x40b4("0xca")][_0x40b4("0x114")](_0x40b4("0x475"));
      }
    }
    this[_0x40b4("0x45d")] = ![];
    this[_0x40b4("0x45c")] = !![];
  }
}
pc[_0x40b4("0x1f4")](ResultScreen, _0x40b4("0x476"));
ResultScreen[_0x40b4("0xb1")]();
ResultScreen[_0x40b4("0x467")] = { score: 0x0 };
class EndOfLevel extends pc[_0x40b4("0xb0")] {
  static [_0x40b4("0xb1")]() {
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x477"), {
      type: _0x40b4("0x45"),
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x173"), {
      type: _0x40b4("0x25a"),
    });
  }
  [_0x40b4("0xc9")]() {
    this[_0x40b4("0x194")] = null;
    this[_0x40b4("0x422")] = 0x1;
    this[_0x40b4("0x421")] = 0x1;
    this["createTexture"]();
    this[_0x40b4("0x478")]();
    this["tmpVec2"] = new pc[_0x40b4("0x15b")]();
    this["tmpOffset"] = new pc[_0x40b4("0x15b")]();
    if (this[_0x40b4("0x477")]) {
      this[_0x40b4("0x3fb")] = this["materialAsset"]["resource"];
    }
    this[_0x40b4("0x3fb")][_0x40b4("0x425")] = this[_0x40b4("0x194")];
    this[_0x40b4("0x3fb")][_0x40b4("0x479")] = this[_0x40b4("0x194")];
  }
  ["createTexture"]() {
    this["texture"] = this[_0x40b4("0x478")]();
    return {
      texture: this["texture"],
      uvXDivision: this["uvXDivision"],
      uvYDivision: this[_0x40b4("0x421")],
    };
  }
  ["createDiagonalLinesTexture"]() {
    const _0x2317f6 = 0x400;
    const _0x550d1a = 0x400;
    var _0xc934e3 = new pc["Texture"](this[_0x40b4("0xd6")][_0x40b4("0x2ab")], {
      width: _0x2317f6,
      height: _0x550d1a,
      format: pc[_0x40b4("0x447")],
      magFilter: pc["FILTER_LINEAR"],
    });
    var _0x34a793 = _0xc934e3[_0x40b4("0x448")]();
    var _0x2acaba = 0x0;
    const _0x357ae5 = _0x2317f6 / 0x2;
    const _0xfe6c1e = [
      [
        pc["math"][_0x40b4("0x3d8")](0.5, 0x1) * 0xff,
        pc[_0x40b4("0x3ed")][_0x40b4("0x3d8")](0.5, 0x1) * 0xff,
        pc[_0x40b4("0x3ed")][_0x40b4("0x3d8")](0.5, 0x1) * 0xff,
      ],
      [
        pc["math"]["random"](0.5, 0x1) * 0xff,
        pc[_0x40b4("0x3ed")]["random"](0.5, 0x1) * 0xff,
        pc[_0x40b4("0x3ed")][_0x40b4("0x3d8")](0.5, 0x1) * 0xff,
      ],
    ];
    for (var _0x102d7d = 0x0; _0x102d7d < _0x2317f6; _0x102d7d++) {
      for (var _0x62b524 = 0x0; _0x62b524 < _0x550d1a; _0x62b524++) {
        const _0x1844a3 =
          Math[_0x40b4("0x3f8")](
            Math[_0x40b4("0x43f")]((_0x102d7d - _0x62b524) / _0x357ae5)
          ) % 0x2;
        _0x34a793[_0x2acaba++] = _0xfe6c1e[_0x1844a3][0x0];
        _0x34a793[_0x2acaba++] = _0xfe6c1e[_0x1844a3][0x1];
        _0x34a793[_0x2acaba++] = _0xfe6c1e[_0x1844a3][0x2];
      }
    }
    _0xc934e3["unlock"]();
    this[_0x40b4("0x422")] = 2.285;
    this[_0x40b4("0x421")] = 0x10;
    return _0xc934e3;
  }
  [_0x40b4("0x236")](_0x2d9321) {
    var _0x3529aa = this[_0x40b4("0x47a")];
    var _0x458000 = this["tmpOffset"];
    _0x3529aa[_0x40b4("0x15d")](
      this[_0x40b4("0x173")]["x"],
      this[_0x40b4("0x173")]["y"]
    );
    _0x3529aa[_0x40b4("0x16e")](_0x2d9321);
    _0x458000["copy"](this["material"][_0x40b4("0x47b")]);
    _0x458000[_0x40b4("0x2e")](_0x3529aa);
    this[_0x40b4("0x3fb")][_0x40b4("0x47b")] = _0x458000;
    this[_0x40b4("0x3fb")][_0x40b4("0x47c")] = _0x458000;
    this[_0x40b4("0x3fb")][_0x40b4("0x236")]();
  }
}
pc[_0x40b4("0x1f4")](EndOfLevel, _0x40b4("0x47d"));
EndOfLevel[_0x40b4("0xb1")]();
class Chunks extends pc[_0x40b4("0xb0")] {
  static [_0x40b4("0xb1")]() {
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x47e"), {
      type: _0x40b4("0x46"),
      array: !![],
      schema: [
        { name: _0x40b4("0x3f2"), type: _0x40b4("0x34"), default: 0x1 },
        { name: _0x40b4("0x3e7"), type: _0x40b4("0xb8"), array: !![] },
        {
          name: _0x40b4("0x47f"),
          type: _0x40b4("0x34"),
          array: !![],
          default: [0x1],
        },
        { name: _0x40b4("0x3f0"), type: _0x40b4("0x34"), default: 0xa },
      ],
    });
  }
  [_0x40b4("0xc9")]() {
    Chunks[_0x40b4("0xca")] = this;
    this["info"] = null;
  }
  ["reset"]() {
    this["amountOfObstacles"] = 0x0;
  }
  ["chunkLevel"](_0x1eb881) {
    this["info"] = this[_0x40b4("0x480")](_0x1eb881);
    this["obstacles"] = this[_0x40b4("0x481")][_0x40b4("0x3e7")];
    this[_0x40b4("0x47f")] = this[_0x40b4("0x481")][_0x40b4("0x47f")];
    if (
      this["obstacles"][_0x40b4("0x87")] !== this["weights"][_0x40b4("0x87")]
    ) {
      console[_0x40b4("0x7")](_0x40b4("0x482"));
    }
    this[_0x40b4("0x483")] = this[_0x40b4("0x484")]();
    return this[_0x40b4("0x481")];
  }
  [_0x40b4("0x480")](_0xd1cb75) {
    while (_0xd1cb75 > this[_0x40b4("0x47e")][_0x40b4("0x87")]) {
      _0xd1cb75 = _0xd1cb75 - 0x2;
    }
    return this[_0x40b4("0x47e")][_0xd1cb75 - 0x1];
  }
  ["getTotalWeight"]() {
    let _0x54bc75 = 0x0;
    for (
      var _0x126e16 = 0x0;
      _0x126e16 < this["weights"]["length"];
      _0x126e16++
    ) {
      let _0x232a81 = this[_0x40b4("0x47f")][_0x126e16];
      _0x54bc75 += _0x232a81;
    }
    return _0x54bc75;
  }
  [_0x40b4("0x3f1")]() {
    const _0x47feb9 = pc[_0x40b4("0x3ed")][_0x40b4("0x3d8")](
      0x0,
      this[_0x40b4("0x483")]
    );
    let _0x79ae66 = 0x0;
    let _0x2aa48e = 0x0;
    for (
      var _0x6de97b = 0x0;
      _0x6de97b < this["weights"][_0x40b4("0x87")];
      _0x6de97b++
    ) {
      _0x2aa48e = _0x6de97b;
      _0x79ae66 += this[_0x40b4("0x47f")][_0x6de97b];
      if (_0x47feb9 <= _0x79ae66) {
        break;
      }
    }
    return this[_0x40b4("0x3e7")][_0x2aa48e];
  }
}
pc[_0x40b4("0x1f4")](Chunks, "chunks");
Chunks[_0x40b4("0xb1")]();
class ScoreManager extends pc[_0x40b4("0xb0")] {
  ["initialize"]() {
    ScoreManager[_0x40b4("0xca")] = this;
    this[_0x40b4("0x466")] = StorageManager["instance"][_0x40b4("0x75")](
      _0x40b4("0x466")
    );
    this[_0x40b4("0x463")] = this[_0x40b4("0x466")];
    this["score"] = 0x0;
    this["roundedScore"] = 0x0;
  }
  ["addScore"](_0x23fa0d, _0xead0d1 = ![]) {
    const _0x14dfe0 = this[_0x40b4("0x468")] % ScoreManager[_0x40b4("0x485")];
    this[_0x40b4("0x468")] += _0x23fa0d;
    this[_0x40b4("0x121")] = this[_0x40b4("0x486")]();
    const _0x17be60 = this[_0x40b4("0x468")] % ScoreManager[_0x40b4("0x485")];
    if (_0x14dfe0 !== _0x17be60 || _0xead0d1) {
      this[_0x40b4("0x487")]();
    }
    this["app"][_0x40b4("0x10e")](_0x40b4("0x488"), this[_0x40b4("0x121")]);
  }
  [_0x40b4("0x487")]() {
    if (!GameManager[_0x40b4("0xca")][_0x40b4("0x123")]) {
      return;
    }
    window[_0x40b4("0x19")][_0x40b4("0x1a")]("EVENT_LIVESCORE", {
      liveScore: this[_0x40b4("0x121")],
    });
  }
  ["getRoundedScore"]() {
    return Math[_0x40b4("0x489")](this[_0x40b4("0x468")] * 0xa) / 0xa;
  }
  [_0x40b4("0x41e")]() {
    this["score"] = 0x0;
    this[_0x40b4("0x121")] = 0x0;
  }
  [_0x40b4("0x45e")]() {
    if (this[_0x40b4("0x121")] > this[_0x40b4("0x466")]) {
      StorageManager[_0x40b4("0xca")][_0x40b4("0x15d")](
        "highscore",
        this[_0x40b4("0x121")]
      );
      this[_0x40b4("0x463")] = this[_0x40b4("0x466")];
      this[_0x40b4("0x466")] = this[_0x40b4("0x121")];
    }
  }
}
pc[_0x40b4("0x1f4")](ScoreManager, _0x40b4("0x48a"));
ScoreManager[_0x40b4("0x485")] = 0x64;
class CameraShake extends pc[_0x40b4("0xb0")] {
  static [_0x40b4("0xb1")]() {
    this[_0x40b4("0x2d")]["add"](_0x40b4("0x48b"), {
      type: _0x40b4("0x34"),
      default: 0.1,
      title: _0x40b4("0x48c"),
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x48d"), {
      type: "number",
      default: 0.1,
      title: "Max\x20Shake\x20Distance",
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x13b"), {
      type: _0x40b4("0x34"),
      default: 0x1,
      title: _0x40b4("0x48e"),
    });
  }
  [_0x40b4("0xc9")]() {
    this[_0x40b4("0x20e")] = Number[_0x40b4("0x48f")];
    this["timeSinceLastShake"] = 0x0;
    this[_0x40b4("0xd6")]["on"]("camera:shake", this[_0x40b4("0x490")], this);
  }
  [_0x40b4("0x236")](_0x433f11) {
    this[_0x40b4("0x20e")] += _0x433f11;
    if (this["time"] < this[_0x40b4("0x13b")]) {
      this[_0x40b4("0x491")] += _0x433f11;
      if (this[_0x40b4("0x491")] >= this[_0x40b4("0x48b")]) {
        var _0x2587d6 =
          0x1 -
          pc[_0x40b4("0x3ed")][_0x40b4("0x492")](
            this[_0x40b4("0x20e")] / this["duration"],
            0x0,
            0x1
          );
        var _0x55c5d3 =
          0x2 * Math["PI"] * pc[_0x40b4("0x3ed")][_0x40b4("0x3d8")](0x0, 0x1);
        var _0x4ae4ef =
          pc[_0x40b4("0x3ed")][_0x40b4("0x3d8")](0x0, this[_0x40b4("0x48d")]) *
            _0x2587d6 +
          pc[_0x40b4("0x3ed")]["random"](0x0, this[_0x40b4("0x48d")]) *
            _0x2587d6;
        var _0xf12b74 = _0x4ae4ef > 0x1 ? 0x2 - _0x4ae4ef : _0x4ae4ef;
        var _0x27140e = _0xf12b74 * Math[_0x40b4("0x22f")](_0x55c5d3);
        var _0x76d4ab = _0xf12b74 * Math["sin"](_0x55c5d3);
        this["entity"][_0x40b4("0x170")](
          this[_0x40b4("0x493")]["x"] + _0x27140e,
          this[_0x40b4("0x493")]["y"] + _0x76d4ab,
          this["startPosition"]["z"]
        );
        this[_0x40b4("0x491")] -= this["shakeInterval"];
      }
    }
  }
  [_0x40b4("0x490")]() {
    this[_0x40b4("0x20e")] = 0x0;
    this["startPosition"] = this[_0x40b4("0xb8")]
      ["getLocalPosition"]()
      [_0x40b4("0x166")]();
  }
}
pc[_0x40b4("0x1f4")](CameraShake, _0x40b4("0x494"));
CameraShake[_0x40b4("0xb1")]();
class LevelManager extends pc[_0x40b4("0xb0")] {
  static [_0x40b4("0xb1")]() {}
  [_0x40b4("0xc9")]() {
    LevelManager[_0x40b4("0xca")] = this;
    this[_0x40b4("0xd6")]["on"](
      _0x40b4("0x11d"),
      this[_0x40b4("0x11e")](0x1),
      this
    );
    this[_0x40b4("0xd6")]["on"](
      "LevelManager:increaseLevel",
      this["increaseLevel"],
      this
    );
    this[_0x40b4("0xd6")]["on"](
      "GameManager:restart",
      this["resetLevel"],
      this
    );
  }
  [_0x40b4("0x11e")](_0x381ca9) {
    this["level"] = _0x381ca9;
    this[_0x40b4("0xd6")][_0x40b4("0x10e")](
      _0x40b4("0x3e9"),
      this[_0x40b4("0x118")]
    );
  }
  [_0x40b4("0x495")]() {
    StatisticsManager[_0x40b4("0xca")][_0x40b4("0x496")](
      _0x40b4("0x497"),
      0x1,
      { level: this["level"] }
    );
    this[_0x40b4("0x118")] += 0x1;
    this[_0x40b4("0xd6")][_0x40b4("0x10e")](_0x40b4("0x498"), this["level"]);
  }
  [_0x40b4("0x499")]() {
    this[_0x40b4("0x118")] = 0x1;
    this[_0x40b4("0xd6")]["fire"](_0x40b4("0x49a"), this["level"]);
  }
}
pc[_0x40b4("0x1f4")](LevelManager, _0x40b4("0x49b"));
LevelManager["addAttributes"]();
class ScoreTracker extends pc["ScriptType"] {
  ["initialize"]() {
    this[_0x40b4("0x49c")](ScoreManager[_0x40b4("0xca")]["roundedScore"]);
    this[_0x40b4("0xd6")]["on"](
      "ScoreManager:updateScore",
      this[_0x40b4("0x49c")],
      this
    );
  }
  [_0x40b4("0x49c")](_0x19a170) {
    this["entity"][_0x40b4("0x154")][_0x40b4("0x28f")] =
      _0x19a170["toFixed"](0x1) + "\x20m";
  }
}
pc[_0x40b4("0x1f4")](ScoreTracker, _0x40b4("0x49d"));
class Colors extends pc[_0x40b4("0xb0")] {
  static ["addAttributes"]() {
    this[_0x40b4("0x2d")]["add"](_0x40b4("0x49e"), {
      type: _0x40b4("0x25a"),
      array: !![],
      placeholder: [_0x40b4("0x2a9"), _0x40b4("0x2a8")],
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x49f"), {
      type: _0x40b4("0x45"),
      assetType: "material",
    });
    this["attributes"][_0x40b4("0x2e")]("tunnelAO", {
      type: _0x40b4("0x45"),
      assetType: "material",
    });
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x4a0"), {
      type: _0x40b4("0x46"),
      array: !![],
      schema: [
        { name: _0x40b4("0x44c"), type: _0x40b4("0x350"), array: !![] },
        {
          name: _0x40b4("0x4a1"),
          type: _0x40b4("0x350"),
          default: [0x1, 0x0, 0x0],
        },
        {
          name: _0x40b4("0x4a2"),
          type: _0x40b4("0x350"),
          default: [0x0, 0x1, 0x0],
        },
        {
          name: _0x40b4("0x4a3"),
          type: _0x40b4("0x350"),
          default: [0x1, 0x1, 0x1],
        },
      ],
    });
    this["attributes"][_0x40b4("0x2e")]("level2Colors", {
      type: _0x40b4("0x46"),
      array: !![],
      schema: [
        { name: "colors", type: _0x40b4("0x350"), array: !![] },
        {
          name: _0x40b4("0x4a1"),
          type: _0x40b4("0x350"),
          default: [0x1, 0x0, 0x0],
        },
        { name: _0x40b4("0x4a2"), type: "rgb", default: [0x0, 0x1, 0x0] },
        {
          name: _0x40b4("0x4a3"),
          type: _0x40b4("0x350"),
          default: [0x1, 0x1, 0x1],
        },
      ],
    });
    this["attributes"][_0x40b4("0x2e")](_0x40b4("0x4a4"), {
      type: _0x40b4("0x46"),
      array: !![],
      schema: [
        { name: _0x40b4("0x44c"), type: _0x40b4("0x350"), array: !![] },
        {
          name: _0x40b4("0x4a1"),
          type: _0x40b4("0x350"),
          default: [0x1, 0x0, 0x0],
        },
        { name: "backgroundColor", type: "rgb", default: [0x0, 0x1, 0x0] },
        {
          name: _0x40b4("0x4a3"),
          type: _0x40b4("0x350"),
          default: [0x1, 0x1, 0x1],
        },
      ],
    });
  }
  [_0x40b4("0xc9")]() {
    Colors[_0x40b4("0xca")] = this;
    this[_0x40b4("0x4a5")] = -0x1;
    this[_0x40b4("0x118")] = -0x1;
    this[_0x40b4("0x440")] = -0x1;
    this[_0x40b4("0x44c")] = null;
  }
  [_0x40b4("0x11e")](_0x44d6aa, _0x1ea6df = !![]) {
    if (!_0x1ea6df) {
      return;
    }
    const _0x3a42e9 = this[_0x40b4("0x4a6")](_0x44d6aa);
    if (this["levelRangeIndex"] !== _0x3a42e9) {
      this["resetIndex"]();
      this[_0x40b4("0x4a5")] = _0x3a42e9;
    }
    this[_0x40b4("0x440")] = this["getRandomIndex"]();
    this[_0x40b4("0x4a7")] = this["colors"][this[_0x40b4("0x440")]];
    this[_0x40b4("0x4a8")][_0x40b4("0x5a")]["ambient"] =
      this[_0x40b4("0x4a7")][_0x40b4("0x4a3")];
    this[_0x40b4("0x4a8")][_0x40b4("0x5a")][_0x40b4("0x236")]();
    this["obstacleMaterial"]["resource"][_0x40b4("0x405")] =
      this[_0x40b4("0x4a7")][_0x40b4("0x4a1")];
    this[_0x40b4("0x49f")][_0x40b4("0x5a")]["update"]();
  }
  ["getColor"]() {
    return this[_0x40b4("0x4a7")];
  }
  [_0x40b4("0x4a9")]() {
    this[_0x40b4("0x440")] = -0x1;
  }
  [_0x40b4("0x4a6")](_0x414d9d) {
    for (
      let _0x343f9c = 0x0;
      _0x343f9c < this[_0x40b4("0x49e")][_0x40b4("0x87")];
      _0x343f9c += 0x1
    ) {
      const _0x567f74 = this[_0x40b4("0x49e")][_0x343f9c];
      if (_0x414d9d >= _0x567f74["x"] && _0x414d9d <= _0x567f74["y"]) {
        return _0x343f9c;
      }
    }
  }
  [_0x40b4("0x4aa")]() {
    switch (this["levelRangeIndex"]) {
      case 0x0:
        this[_0x40b4("0x44c")] = this[_0x40b4("0x4a0")];
        break;
      case 0x1:
        this[_0x40b4("0x44c")] = this[_0x40b4("0x4ab")];
        break;
      case 0x2:
        this[_0x40b4("0x44c")] = this[_0x40b4("0x4a4")];
        break;
      default:
        console[_0x40b4("0x7")](_0x40b4("0x4ac"), this["levelRange"]);
        break;
    }
    return this["getIndex"](this[_0x40b4("0x44c")]);
  }
  [_0x40b4("0x12f")]() {
    return this[_0x40b4("0x4a7")][_0x40b4("0x4a2")];
  }
  [_0x40b4("0x4ad")](_0x24ee77) {
    let _0xd94612 = 0x0;
    let _0x44aba2 = 0x1e;
    do {
      _0xd94612 = Math[_0x40b4("0x43f")](
        Math["random"]() * _0x24ee77["length"]
      );
      _0x44aba2--;
      if (_0x44aba2 < 0x0) {
        break;
      }
    } while (_0xd94612 === this[_0x40b4("0x440")]);
    return _0xd94612;
  }
}
pc[_0x40b4("0x1f4")](Colors, _0x40b4("0x44c"));
Colors[_0x40b4("0xb1")]();
class LevelTracker extends pc[_0x40b4("0xb0")] {
  [_0x40b4("0xc9")]() {
    this[_0x40b4("0xd6")]["on"](_0x40b4("0x3e9"), this[_0x40b4("0x4ae")], this);
    this[_0x40b4("0xd6")]["on"](_0x40b4("0x498"), this[_0x40b4("0x4ae")], this);
    this[_0x40b4("0xd6")]["on"](_0x40b4("0x49a"), this[_0x40b4("0x4ae")], this);
  }
  ["postInitialize"]() {
    this[_0x40b4("0x4ae")](LevelManager[_0x40b4("0xca")]["level"]);
  }
  [_0x40b4("0x4ae")](_0x453b50) {
    this[_0x40b4("0xb8")][_0x40b4("0x154")][_0x40b4("0x28f")] =
      "level\x20" + _0x453b50;
  }
}
pc["registerScript"](LevelTracker, _0x40b4("0x4af"));
class MenuScreen extends pc["ScriptType"] {
  async [_0x40b4("0x4b0")](_0x2cb471 = 0x1) {
    const _0x137383 = UIManager["instance"][_0x40b4("0x114")]("Flash");
    await _0x137383;
    UIManager[_0x40b4("0xca")]["hideUI"](_0x40b4("0x4b1"));
    await Wrapper[_0x40b4("0xca")][_0x40b4("0x133")](_0x2cb471);
    GameManager[_0x40b4("0xca")][_0x40b4("0x116")](_0x2cb471, ![]);
    UIManager[_0x40b4("0xca")][_0x40b4("0x135")](_0x40b4("0x134"));
    UIManager["instance"][_0x40b4("0x114")](_0x40b4("0x127"));
  }
  [_0x40b4("0xc9")]() {
    if (pc[_0x40b4("0x191")][_0x40b4("0x2ad")]) {
      this[_0x40b4("0xd6")][_0x40b4("0x2cc")]["on"](
        pc["EVENT_KEYDOWN"],
        this[_0x40b4("0x39c")],
        this
      );
      this[_0x40b4("0xd6")]["mouse"]["on"](
        pc[_0x40b4("0x2c8")],
        this[_0x40b4("0x4b2")],
        this
      );
    }
    this["onKeyDown"]();
    if (pc[_0x40b4("0x191")]["touch"]) {
      this["app"][_0x40b4("0x2c1")]["on"](
        pc[_0x40b4("0x2d0")],
        this[_0x40b4("0x4b2")],
        this
      );
    }
    this[_0x40b4("0xd0")] = !![];
  }
  [_0x40b4("0x39c")]() {
    if (!this[_0x40b4("0xb8")][_0x40b4("0xd4")]) {
      return;
    }
    if (
      this[_0x40b4("0xd6")][_0x40b4("0x2cc")][_0x40b4("0x4b3")](
        pc[_0x40b4("0x3a5")]
      ) &&
      this["ready"]
    ) {
      this[_0x40b4("0x4b0")](0x1);
      this[_0x40b4("0xd0")] = ![];
    } else if (
      this["app"][_0x40b4("0x2cc")][_0x40b4("0x4b3")](pc[_0x40b4("0x3a1")]) &&
      this["ready"]
    ) {
      this[_0x40b4("0x4b0")](0x1);
      this[_0x40b4("0xd0")] = ![];
    } else if (
      this[_0x40b4("0xd6")][_0x40b4("0x2cc")][_0x40b4("0x4b3")](
        pc[_0x40b4("0x39f")]
      ) &&
      this[_0x40b4("0xd0")]
    ) {
      this[_0x40b4("0x4b0")](0x1);
      this[_0x40b4("0xd0")] = ![];
    } else if (
      this[_0x40b4("0xd6")]["keyboard"][_0x40b4("0x4b3")](
        pc[_0x40b4("0x3a2")]
      ) &&
      this[_0x40b4("0xd0")]
    ) {
      this[_0x40b4("0x4b0")](0x1);
      this["ready"] = ![];
    }
  }
  [_0x40b4("0x4b2")]() {
    if (!this[_0x40b4("0xb8")]["enabled"]) {
      return;
    }
    this[_0x40b4("0xd0")] = ![];
  }
}
pc[_0x40b4("0x1f4")](MenuScreen, "menuScreen");
class RollingCube extends pc["ScriptType"] {
  [_0x40b4("0xc9")]() {
    this["rotationSpeed"] = 0xfa;
  }
  ["update"](_0x479020) {
    this["entity"][_0x40b4("0x4b4")](
      0x0,
      0x0,
      -this["rotationSpeed"] * _0x479020
    );
  }
}
pc[_0x40b4("0x1f4")](RollingCube, _0x40b4("0x4b5"));
class Flash extends pc[_0x40b4("0xb0")] {
  [_0x40b4("0x1d7")]() {
    this[_0x40b4("0xb8")][_0x40b4("0x154")]["opacity"] = 0x0;
    Flash[_0x40b4("0x4b6")]["opacity"] = 0x1;
    const _0x22ba13 = this[_0x40b4("0xb8")]
      ["tween"](this[_0x40b4("0xb8")][_0x40b4("0x154")])
      ["to"](
        Flash[_0x40b4("0x4b6")],
        Flash[_0x40b4("0x4b7")],
        pc[_0x40b4("0xf2")]
      )
      [_0x40b4("0x116")]();
    return _0x22ba13[_0x40b4("0x462")]();
  }
  ["onUIEntityClose"]() {
    this[_0x40b4("0xb8")][_0x40b4("0x154")]["opacity"] = 0x1;
    Flash[_0x40b4("0x4b6")][_0x40b4("0x155")] = 0x0;
    const _0x417efe = this[_0x40b4("0xb8")]
      [_0x40b4("0xf1")](this["entity"][_0x40b4("0x154")])
      ["to"](
        Flash[_0x40b4("0x4b6")],
        Flash[_0x40b4("0x4b7")],
        pc[_0x40b4("0xf2")]
      )
      [_0x40b4("0x116")]();
    return _0x417efe[_0x40b4("0x462")]();
  }
}
pc[_0x40b4("0x1f4")](Flash, "flash");
Flash[_0x40b4("0x4b6")] = { opacity: 0x1 };
Flash[_0x40b4("0x4b7")] = 0.1;
class StatisticsManager extends pc[_0x40b4("0xb0")] {
  [_0x40b4("0xc9")]() {
    StatisticsManager[_0x40b4("0xca")] = this;
    this["statistics"] = StorageManager[_0x40b4("0xca")]["get"](
      _0x40b4("0x4b8")
    );
    this[_0x40b4("0x304")] =
      window[_0x40b4("0x3")][_0x40b4("0x13")]("trackstats");
  }
  ["setStat"](_0x1e7ebb, _0x36c08b, _0x3bad4e) {
    this["setStatistic"](_0x1e7ebb, _0x36c08b, _0x3bad4e);
  }
  [_0x40b4("0x496")](_0x982e70, _0x34ae5c, _0x355dfb) {
    this[_0x40b4("0x4b9")](_0x982e70, _0x34ae5c, _0x355dfb);
  }
  [_0x40b4("0x4ba")](_0x476801, _0x563b9d = 0x1, _0x134527 = {}) {
    if (!this[_0x40b4("0x304")]) {
      return;
    }
    window[_0x40b4("0x19")]["trackStats"](_0x476801, _0x134527, _0x563b9d);
  }
  [_0x40b4("0x4b9")](_0x485195, _0x297d0b = 0x1, _0x15ebc3 = {}) {
    if (!this["active"]) {
      return;
    }
    window["famobi"]["log"](_0x485195, _0x15ebc3, _0x297d0b);
    window[_0x40b4("0x19")][_0x40b4("0x4bb")](_0x485195, _0x15ebc3, _0x297d0b);
  }
}
pc["registerScript"](StatisticsManager, _0x40b4("0x4bc"));
class Tutorial extends pc[_0x40b4("0xb0")] {
  static [_0x40b4("0xb1")]() {
    this[_0x40b4("0x2d")][_0x40b4("0x2e")](_0x40b4("0x396"), {
      type: _0x40b4("0xb8"),
    });
    this[_0x40b4("0x2d")]["add"]("rightButton", { type: "entity" });
  }
  [_0x40b4("0xc9")]() {
    this[_0x40b4("0x4bd")]();
    this[_0x40b4("0x460")]();
  }
  [_0x40b4("0x460")]() {
    this[_0x40b4("0x396")]["setLocalScale"](new pc["Vec3"](0.85, 0.85, 0.85));
    this[_0x40b4("0x397")]["setLocalScale"](
      new pc[_0x40b4("0x16a")](0.85, 0.85, 0.85)
    );
    this[_0x40b4("0x396")]
      [_0x40b4("0xf1")](this[_0x40b4("0x396")]["getLocalScale"]())
      ["to"](pc["Vec3"][_0x40b4("0x465")], 0.5, pc[_0x40b4("0x46a")])
      [_0x40b4("0x4be")](!![])
      [_0x40b4("0x224")](!![])
      [_0x40b4("0x116")]();
    this[_0x40b4("0x397")]
      [_0x40b4("0xf1")](this[_0x40b4("0x397")][_0x40b4("0x181")]())
      ["to"](pc[_0x40b4("0x16a")]["ONE"], 0.5, pc["SineInOut"])
      [_0x40b4("0x4be")](!![])
      [_0x40b4("0x224")](!![])
      ["start"]();
  }
  [_0x40b4("0x4bd")]() {
    if (window["famobi"][_0x40b4("0x13")](_0x40b4("0x4bf"))) {
      this[_0x40b4("0x4c0")]();
      return;
    }
    if (pc[_0x40b4("0x191")]["touch"]) {
      this[_0x40b4("0x4c0")]();
      return;
    }
    this["showUI"] = !![];
  }
  [_0x40b4("0x4c0")]() {
    this[_0x40b4("0xb8")][_0x40b4("0xd4")] = ![];
    this[_0x40b4("0x396")][_0x40b4("0xd4")] = ![];
    this[_0x40b4("0x397")]["enabled"] = ![];
  }
}
pc[_0x40b4("0x1f4")](Tutorial, "tutorial");
Tutorial["addAttributes"]();
class GameScreen extends pc[_0x40b4("0xb0")] {
  [_0x40b4("0xc9")]() {}
  [_0x40b4("0x1d7")]() {}
  ["onUIEntityClose"]() {}
}
pc["registerScript"](GameScreen, "gameScreen");
class InputScreen extends pc[_0x40b4("0xb0")] {
  [_0x40b4("0xc9")]() {}
  [_0x40b4("0x4c1")]() {
    GameManager["instance"][_0x40b4("0x474")]();
    UIManager[_0x40b4("0xca")][_0x40b4("0x135")]("Input\x20Screen");
  }
}
pc[_0x40b4("0x1f4")](InputScreen, _0x40b4("0x4c2"));
